﻿using System;

namespace BunifUITest.Codes.Offsets
{
	// Token: 0x0200000A RID: 10
	public static class Host
	{
		// Token: 0x0400025E RID: 606
		public static uint CreativeMenu1 = 843167412U;

		// Token: 0x0400025F RID: 607
		public static uint CreativeMenu2 = 843167652U;

		// Token: 0x04000260 RID: 608
		public static uint CreativeMenu3 = 843167892U;

		// Token: 0x04000261 RID: 609
		public static uint CreativeMenu4 = 843168132U;

		// Token: 0x04000262 RID: 610
		public static uint CreativeMenu5 = 843168372U;

		// Token: 0x04000263 RID: 611
		public static uint CreativeMenu6 = 843168612U;

		// Token: 0x04000264 RID: 612
		public static uint CreativeMenu7 = 843168852U;

		// Token: 0x04000265 RID: 613
		public static uint GetSpecialBlocks = 2198095U;

		// Token: 0x04000266 RID: 614
		public static uint SpecBlock = 21793924U;

		// Token: 0x04000267 RID: 615
		public static uint BatEggOfflineMode = 843158457U;

		// Token: 0x04000268 RID: 616
		public static uint BatEggCrash = 843158457U;

		// Token: 0x04000269 RID: 617
		public static uint DriftBoat = 2259172U;

		// Token: 0x0400026A RID: 618
		public static uint WaterJump = 3849576U;

		// Token: 0x0400026B RID: 619
		public static uint RemoveXP = 4915372U;

		// Token: 0x0400026C RID: 620
		public static uint MaxXP = 4915348U;

		// Token: 0x0400026D RID: 621
		public static uint GunItems = 21784704U;

		// Token: 0x0400026E RID: 622
		public static uint AutoSave = 11464276U;

		// Token: 0x0400026F RID: 623
		public static uint ReverseKnockback = 3817496U;

		// Token: 0x04000270 RID: 624
		public static uint AntiKnockback = 3817496U;

		// Token: 0x04000271 RID: 625
		public static uint Knockback = 3817496U;

		// Token: 0x04000272 RID: 626
		public static uint NoDamageHit = 3817456U;

		// Token: 0x04000273 RID: 627
		public static uint InstantKillFire = 2251000U;

		// Token: 0x04000274 RID: 628
		public static uint BypassKillAll = 2253160U;

		// Token: 0x04000275 RID: 629
		public static uint InstaKillAll = 3817572U;

		// Token: 0x04000276 RID: 630
		public static uint InstantDamage = 3817456U;

		// Token: 0x04000277 RID: 631
		public static uint AutoRegen = 2809064U;

		// Token: 0x04000278 RID: 632
		public static uint DemiGod = 3817572U;

		// Token: 0x04000279 RID: 633
		public static uint GodMode = 4923425U;

		// Token: 0x0400027A RID: 634
		public static uint CreeperNoGrief = 1886247U;

		// Token: 0x0400027B RID: 635
		public static uint CreeperFireExplode = 1886356U;

		// Token: 0x0400027C RID: 636
		public static uint CreeperInstantExplode = 1887276U;

		// Token: 0x0400027D RID: 637
		public static uint CreeperExtremExplode = 1886176U;

		// Token: 0x0400027E RID: 638
		public static uint CreeperMedExplode2 = 1886176U;

		// Token: 0x0400027F RID: 639
		public static uint BigCreeper = 1886236U;

		// Token: 0x04000280 RID: 640
		public static uint TNTSilent = 2382820U;

		// Token: 0x04000281 RID: 641
		public static uint TNTDown = 5367128U;

		// Token: 0x04000282 RID: 642
		public static uint TNTFly = 5367128U;

		// Token: 0x04000283 RID: 643
		public static uint TNTMoreParticle = 2383448U;

		// Token: 0x04000284 RID: 644
		public static uint SmallTNT = 2382924U;

		// Token: 0x04000285 RID: 645
		public static uint TNTNoGreif2 = 2383344U;

		// Token: 0x04000286 RID: 646
		public static uint TNTNoGreif = 2383339U;

		// Token: 0x04000287 RID: 647
		public static uint InstantExplodeTNT = 5367456U;

		// Token: 0x04000288 RID: 648
		public static uint EnableRain = 3751823U;

		// Token: 0x04000289 RID: 649
		public static uint LightningBolt = 9996063U;

		// Token: 0x0400028A RID: 650
		public static uint FlashSky = 3751476U;

		// Token: 0x0400028B RID: 651
		public static uint SmallRain = 3751476U;

		// Token: 0x0400028C RID: 652
		public static uint RainToSnow = 19990868U;

		// Token: 0x0400028D RID: 653
		public static uint RainbowStorm = 3751476U;

		// Token: 0x0400028E RID: 654
		public static uint DarkStorm = 3751476U;

		// Token: 0x0400028F RID: 655
		public static uint KillNoDissappearEntity = 3798407U;

		// Token: 0x04000290 RID: 656
		public static uint KillDissapearEntity = 3798407U;

		// Token: 0x04000291 RID: 657
		public static uint Spectator = 21794888U;

		// Token: 0x04000292 RID: 658
		public static uint InfiniteBreath = 3792424U;

		// Token: 0x04000293 RID: 659
		public static uint SpectralArrows = 21795028U;

		// Token: 0x04000294 RID: 660
		public static uint EntityGodmode = 3817324U;

		// Token: 0x04000295 RID: 661
		public static uint NoWeb = 2314143U;

		// Token: 0x04000296 RID: 662
		public static uint BypassStackLimit = 3214076U;

		// Token: 0x04000297 RID: 663
		public static uint RemoveHitDelay = 3817456U;

		// Token: 0x04000298 RID: 664
		public static uint StopGravity = 2386476U;

		// Token: 0x04000299 RID: 665
		public static uint KillMobSpawn = 6026062U;

		// Token: 0x0400029A RID: 666
		public static uint RemoveWater = 2252416U;

		// Token: 0x0400029B RID: 667
		public static uint BurnInWater = 2252456U;

		// Token: 0x0400029C RID: 668
		public static uint lobbyMSG = 3849768U;

		// Token: 0x0400029D RID: 669
		public static uint InfinitePlace = 1075007U;

		// Token: 0x0400029E RID: 670
		public static uint NoFall = 3817628U;

		// Token: 0x0400029F RID: 671
		public static uint MobsIgnoreYou = 11112272U;

		// Token: 0x040002A0 RID: 672
		public static uint WolfRemoveWater = 7079472U;

		// Token: 0x040002A1 RID: 673
		public static uint WolfTurnHead = 7079440U;

		// Token: 0x040002A2 RID: 674
		public static uint NoMob = 4594148U;

		// Token: 0x040002A3 RID: 675
		public static uint GlitchMob = 15370722U;

		// Token: 0x040002A4 RID: 676
		public static uint NoGrab2 = 4865976U;

		// Token: 0x040002A5 RID: 677
		public static uint NoGrab = 3214092U;

		// Token: 0x040002A6 RID: 678
		public static uint MaxPickup = 3214036U;

		// Token: 0x040002A7 RID: 679
		public static uint UnlimArrows = 2247443U;

		// Token: 0x040002A8 RID: 680
		public static uint potionFlyArrows = 6683488U;

		// Token: 0x040002A9 RID: 681
		public static uint RemoveArrows = 1029700U;

		// Token: 0x040002AA RID: 682
		public static uint BlockArrows = 1029468U;

		// Token: 0x040002AB RID: 683
		public static uint ChangeArrowDir = 1029468U;

		// Token: 0x040002AC RID: 684
		public static uint StopBow = 1029317U;

		// Token: 0x040002AD RID: 685
		public static uint FastBow = 1029317U;

		// Token: 0x040002AE RID: 686
		public static uint LockWeather = 3751556U;

		// Token: 0x040002AF RID: 687
		public static uint LockGamemode = 3081168U;

		// Token: 0x040002B0 RID: 688
		public static uint AllPlayersLeftHand = 22147824U;

		// Token: 0x040002B1 RID: 689
		public static uint AllPlayersDamage = 3793620U;

		// Token: 0x040002B2 RID: 690
		public static uint AllPlayersStop = 4614326U;

		// Token: 0x040002B3 RID: 691
		public static uint AllPlayersNoRun = 101604U;

		// Token: 0x040002B4 RID: 692
		public static uint AllPlayersSpeed2 = 4614326U;

		// Token: 0x040002B5 RID: 693
		public static uint AllPlayersSpeed = 101604U;

		// Token: 0x040002B6 RID: 694
		public static uint AllPlayersFastMine2 = 1106116U;

		// Token: 0x040002B7 RID: 695
		public static uint AllPlayersFastMine = 1106116U;

		// Token: 0x040002B8 RID: 696
		public static uint AntiJoinWorld = 9996063U;

		// Token: 0x040002B9 RID: 697
		public static uint MultiJump2NHost = 3866634U;

		// Token: 0x040002BA RID: 698
		public static uint AirToWaterNHost = 1933260U;

		// Token: 0x040002BB RID: 699
		public static uint AutoLadderNHost = 3831027U;

		// Token: 0x040002BC RID: 700
		public static uint CrouchRunNHost = 11539499U;

		// Token: 0x040002BD RID: 701
		public static uint NoEntityCollisionNHost = 67756U;

		// Token: 0x040002BE RID: 702
		public static uint MaxRiptideNHost = 2194895U;

		// Token: 0x040002BF RID: 703
		public static uint MakeRainNHost = 11121214U;

		// Token: 0x040002C0 RID: 704
		public static uint NightVisNHost = 11118280U;

		// Token: 0x040002C1 RID: 705
		public static uint LevitationNHost = 3849680U;

		// Token: 0x040002C2 RID: 706
		public static uint DayNightNHost = 21784704U;

		// Token: 0x040002C3 RID: 707
		public static uint RemoveTextNHost = 7890412U;

		// Token: 0x040002C4 RID: 708
		public static uint SeeOutMapNHost = 11108148U;

		// Token: 0x040002C5 RID: 709
		public static uint BetterTimeNHost = 11118300U;

		// Token: 0x040002C6 RID: 710
		public static uint DownCamNHost = 4922592U;

		// Token: 0x040002C7 RID: 711
		public static uint MoongravNHost = 3850120U;

		// Token: 0x040002C8 RID: 712
		public static uint WalkInSkyNHost = 72448U;

		// Token: 0x040002C9 RID: 713
		public static uint StaticMovementNHost = 11112356U;

		// Token: 0x040002CA RID: 714
		public static uint NameOverHead2NHost = 11370768U;

		// Token: 0x040002CB RID: 715
		public static uint NameOverHead1NHost = 11370840U;

		// Token: 0x040002CC RID: 716
		public static uint XrayNHost = 11112788U;

		// Token: 0x040002CD RID: 717
		public static uint Knockback2NHost = 72396U;

		// Token: 0x040002CE RID: 718
		public static uint Knockback1NHost = 3850044U;

		// Token: 0x040002CF RID: 719
		public static uint WalkAloneNHost = 3849752U;

		// Token: 0x040002D0 RID: 720
		public static uint DisableRunNHost = 11543288U;

		// Token: 0x040002D1 RID: 721
		public static uint ExtremeCamSensitivityNHost = 11249992U;

		// Token: 0x040002D2 RID: 722
		public static uint FastCamSensitivityNHost = 11249992U;

		// Token: 0x040002D3 RID: 723
		public static uint AntiAFK3NHost = 2254768U;

		// Token: 0x040002D4 RID: 724
		public static uint AntiAFK1NHost = 2254768U;

		// Token: 0x040002D5 RID: 725
		public static uint UFOModsNHost = 3849680U;

		// Token: 0x040002D6 RID: 726
		public static uint AntiTeleportNHost = 3865440U;

		// Token: 0x040002D7 RID: 727
		public static uint MiniGameHUDNHost = 11371648U;

		// Token: 0x040002D8 RID: 728
		public static uint InfiniteCraftNHost = 9996063U;

		// Token: 0x040002D9 RID: 729
		public static uint InstantMineNHost = 11448464U;

		// Token: 0x040002DA RID: 730
		public static uint R3CamDownNHost = 4922720U;

		// Token: 0x040002DB RID: 731
		public static uint FastBreakNHost = 11448604U;

		// Token: 0x040002DC RID: 732
		public static uint DeadScreenNHost = 3831380U;

		// Token: 0x040002DD RID: 733
		public static uint ChestESP2NHost = 11125428U;

		// Token: 0x040002DE RID: 734
		public static uint ChestESP1NHost = 11112268U;

		// Token: 0x040002DF RID: 735
		public static uint FloatUpNHost = 3849672U;

		// Token: 0x040002E0 RID: 736
		public static uint ChangeViewNHost = 11113504U;

		// Token: 0x040002E1 RID: 737
		public static uint LockInBlockNHost = 3709756U;

		// Token: 0x040002E2 RID: 738
		public static uint NoFlightNHost = 11543400U;

		// Token: 0x040002E3 RID: 739
		public static uint AntiKickNHost = 11461684U;

		// Token: 0x040002E4 RID: 740
		public static uint ShowIDsNHost = 3184584U;

		// Token: 0x040002E5 RID: 741
		public static uint ShowIDsNHost2 = 3184568U;

		// Token: 0x040002E6 RID: 742
		public static uint StaticSpeedNHost = 11468388U;

		// Token: 0x040002E7 RID: 743
		public static uint ModeratorFlightNHost = 11543416U;

		// Token: 0x040002E8 RID: 744
		public static uint SuicideNHost = 3849680U;

		// Token: 0x040002E9 RID: 745
		public static uint FlyXNHost = 11543532U;

		// Token: 0x040002EA RID: 746
		public static uint XMBKick2NHost = 11371296U;

		// Token: 0x040002EB RID: 747
		public static uint XMBKick1NHost = 7888316U;

		// Token: 0x040002EC RID: 748
		public static uint NoCollisionBypassNHost = 2257328U;

		// Token: 0x040002ED RID: 749
		public static uint NoCollisionNHost = 70192U;

		// Token: 0x040002EE RID: 750
		public static uint SwimGlitchNHost = 11543196U;

		// Token: 0x040002EF RID: 751
		public static uint ChangeSwimMovementNHost = 3849540U;

		// Token: 0x040002F0 RID: 752
		public static uint DisableSwimNHost = 3455220U;

		// Token: 0x040002F1 RID: 753
		public static uint JumpSpeedNHost = 3844505U;

		// Token: 0x040002F2 RID: 754
		public static uint RemoveJumpNHost = 3849673U;

		// Token: 0x040002F3 RID: 755
		public static uint JumpForwardNHost = 3844505U;

		// Token: 0x040002F4 RID: 756
		public static uint SuperJump2NHost = 3843964U;

		// Token: 0x040002F5 RID: 757
		public static uint SuperJump1NHost = 3843964U;

		// Token: 0x040002F6 RID: 758
		public static uint JumpInSkyNHost = 72412U;

		// Token: 0x040002F7 RID: 759
		public static uint JumpForBuildNHost = 2257396U;

		// Token: 0x040002F8 RID: 760
		public static uint MultiJumpNHost = 2259211U;

		// Token: 0x040002F9 RID: 761
		public static uint SpeedLegitNHost = 3849545U;

		// Token: 0x040002FA RID: 762
		public static uint Speed6NHost = 3844504U;

		// Token: 0x040002FB RID: 763
		public static uint Speed5NHost = 3849544U;

		// Token: 0x040002FC RID: 764
		public static uint Speed4NHost = 3849544U;

		// Token: 0x040002FD RID: 765
		public static uint Speed2NHost = 3844505U;

		// Token: 0x040002FE RID: 766
		public static uint Speed1NHost = 3849545U;

		// Token: 0x040002FF RID: 767
		public static uint ShowArmourNHost = 9483760U;

		// Token: 0x04000300 RID: 768
		public static uint XToHitNHost = 11463555U;

		// Token: 0x04000301 RID: 769
		public static uint NoHurtCamNHost = 11104944U;

		// Token: 0x04000302 RID: 770
		public static uint NoSLowDownNHost = 3865440U;

		// Token: 0x04000303 RID: 771
		public static uint CriticalmodeNHost = 3849680U;

		// Token: 0x04000304 RID: 772
		public static uint FastBuildNHost = 11456112U;

		// Token: 0x04000305 RID: 773
		public static uint KillAuraNHost = 2306704U;

		// Token: 0x04000306 RID: 774
		public static uint InstantHitNHost = 11452116U;

		// Token: 0x04000307 RID: 775
		public static uint BlockStatic = 11418687U;

		// Token: 0x04000308 RID: 776
		public static uint UnFairAttack = 11452116U;
	}
}
