﻿using System;

namespace BunifUITest.Codes.Offsets
{
	// Token: 0x0200000B RID: 11
	public static class NonHost
	{
	}
}
