﻿using System;

namespace BunifUITest.Codes.Values
{
	// Token: 0x02000008 RID: 8
	public static class HostValues
	{
		// Token: 0x06000104 RID: 260 RVA: 0x00013A7C File Offset: 0x00011C7C
		// Note: this type is marked as 'beforefieldinit'.
		static HostValues()
		{
			byte[] array = new byte[2];
			array[0] = 63;
			HostValues.NoDamageHitOff = array;
			HostValues.InstantKillFireOn = new byte[]
			{
				79,
				128
			};
			HostValues.InstantKillFireOff = new byte[]
			{
				63,
				128
			};
			HostValues.BypassKillAllOn = new byte[]
			{
				64
			};
			HostValues.BypassKillAllOff = new byte[]
			{
				65
			};
			HostValues.InstaKillAllOn = new byte[]
			{
				224,
				40,
				144
			};
			HostValues.InstaKillAllOff = new byte[]
			{
				224,
				8,
				144
			};
			HostValues.InstantDamageOn = new byte[]
			{
				64,
				128
			};
			byte[] array2 = new byte[2];
			array2[0] = 63;
			HostValues.InstantDamageOff = array2;
			byte[] array3 = new byte[4];
			array3[0] = 104;
			array3[1] = 99;
			HostValues.AutoRegenOn = array3;
			HostValues.AutoRegenOff = new byte[]
			{
				104,
				99,
				0,
				1
			};
			HostValues.DemiGodOn = new byte[]
			{
				byte.MaxValue,
				64,
				136,
				144
			};
			HostValues.DemiGodOff = new byte[]
			{
				byte.MaxValue,
				64,
				8,
				144
			};
			HostValues.GodModeOn = new byte[]
			{
				128
			};
			HostValues.GodModeOff = new byte[]
			{
				32
			};
			HostValues.CreeperNoGriefOn = new byte[1];
			HostValues.CreeperNoGriefOff = new byte[]
			{
				1
			};
			HostValues.CreeperFireExplodeOn = new byte[]
			{
				57,
				64,
				0,
				16
			};
			byte[] array4 = new byte[4];
			array4[0] = 57;
			array4[1] = 64;
			HostValues.CreeperFireExplodeOff = array4;
			HostValues.CreeperInstantExplodeOn = new byte[]
			{
				64
			};
			HostValues.CreeperInstantExplodeOff = new byte[]
			{
				65
			};
			HostValues.CreeperExtremExplodeOn = new byte[]
			{
				66,
				byte.MaxValue
			};
			HostValues.CreeperExtremExplodeOff = new byte[]
			{
				63,
				128
			};
			HostValues.CreeperMedExplode2On = new byte[]
			{
				63,
				byte.MaxValue
			};
			HostValues.CreeperMedExplode2Off = new byte[]
			{
				63,
				128
			};
			HostValues.BigCreeperOn = new byte[]
			{
				65
			};
			HostValues.BigCreeperOff = new byte[]
			{
				64
			};
			HostValues.TNTSilentOn = new byte[]
			{
				byte.MaxValue,
				96,
				24,
				144
			};
			HostValues.TNTSilentOff = new byte[]
			{
				byte.MaxValue,
				96,
				8,
				144
			};
			HostValues.TNTDownOn = new byte[]
			{
				79
			};
			HostValues.TNTDownOff = new byte[]
			{
				63
			};
			HostValues.TNTFlyOn = new byte[]
			{
				47,
				164
			};
			HostValues.TNTFlyOff = new byte[]
			{
				63,
				164
			};
			HostValues.TNTMoreParticleOn = new byte[]
			{
				64
			};
			HostValues.TNTMoreParticleOff = new byte[]
			{
				65
			};
			HostValues.SmallTNTOn = new byte[]
			{
				64
			};
			HostValues.SmallTNTOff = new byte[]
			{
				65
			};
			HostValues.TNTNoGreif2On = new byte[]
			{
				64
			};
			HostValues.TNTNoGreif2Off = new byte[]
			{
				65
			};
			HostValues.TNTNoGreifOn = new byte[1];
			HostValues.TNTNoGreifOff = new byte[]
			{
				1
			};
			HostValues.InstantExplodeTNTOn = new byte[]
			{
				64
			};
			HostValues.InstantExplodeTNTOff = new byte[]
			{
				65
			};
			HostValues.EnableRainOn = new byte[]
			{
				1
			};
			HostValues.EnableRainOff = new byte[1];
			HostValues.LightningBoltOn = new byte[]
			{
				1
			};
			HostValues.LightningBoltOff = new byte[1];
			HostValues.FlashSkyOn = new byte[]
			{
				byte.MaxValue,
				128
			};
			HostValues.FlashSkyOff = new byte[]
			{
				63,
				128
			};
			HostValues.SmallRainOn = new byte[]
			{
				62
			};
			HostValues.SmallRainOff = new byte[]
			{
				63
			};
			HostValues.RainToSnowOn = new byte[]
			{
				126
			};
			HostValues.RainToSnowOff = new byte[]
			{
				62
			};
			HostValues.RainbowStormOn = new byte[]
			{
				79,
				128
			};
			HostValues.RainbowStormOff = new byte[]
			{
				63,
				128
			};
			HostValues.DarkStormOn = new byte[]
			{
				63,
				byte.MaxValue
			};
			HostValues.DarkStormOff = new byte[]
			{
				63,
				128
			};
			HostValues.KillNoDissappearEntityOn = new byte[1];
			HostValues.KillNoDissappearEntityOff = new byte[]
			{
				20
			};
			HostValues.KillDissapearEntityOn = new byte[]
			{
				1
			};
			HostValues.KillDissapearEntityOff = new byte[]
			{
				20
			};
			HostValues.SpectatorOn = new byte[]
			{
				50,
				58,
				132,
				192
			};
			HostValues.SpectatorOff = new byte[]
			{
				50,
				57,
				75,
				208
			};
			HostValues.InfiniteBreathOn = new byte[]
			{
				65
			};
			HostValues.InfiniteBreathOff = new byte[]
			{
				64
			};
			HostValues.SpectralArrowsOn = new byte[]
			{
				50,
				32,
				141,
				160
			};
			HostValues.SpectralArrowsOff = new byte[]
			{
				50,
				30,
				173,
				160
			};
			HostValues.EntityGodmodeOn = new byte[]
			{
				64
			};
			HostValues.EntityGodmodeOff = new byte[]
			{
				65
			};
			HostValues.NoWebOn = new byte[1];
			HostValues.NoWebOff = new byte[]
			{
				1
			};
			HostValues.BypassStackLimitOn = new byte[]
			{
				65
			};
			HostValues.BypassStackLimitOff = new byte[]
			{
				64
			};
			HostValues.RemoveHitDelayOn = new byte[]
			{
				32
			};
			HostValues.RemoveHitDelayOff = new byte[1];
			HostValues.StopGravityOn = new byte[]
			{
				byte.MaxValue
			};
			HostValues.StopGravityOff = new byte[]
			{
				63
			};
			HostValues.KillMobSpawnOn = new byte[]
			{
				72
			};
			HostValues.KillMobSpawnOff = new byte[]
			{
				8
			};
			HostValues.RemoveWaterOn = new byte[]
			{
				64
			};
			HostValues.RemoveWaterOff = new byte[]
			{
				65
			};
			HostValues.BurnInWaterOn = new byte[]
			{
				65
			};
			HostValues.BurnInWaterOff = new byte[]
			{
				64
			};
			HostValues.lobbyMSGOn = new byte[]
			{
				byte.MaxValue,
				96,
				136,
				144
			};
			HostValues.lobbyMSGOff = new byte[]
			{
				byte.MaxValue,
				96,
				8,
				144
			};
			HostValues.InfinitePlaceOn = new byte[1];
			HostValues.InfinitePlaceOff = new byte[]
			{
				1
			};
			HostValues.NoFallOn = new byte[]
			{
				64
			};
			HostValues.NoFallOff = new byte[]
			{
				65
			};
			byte[] array5 = new byte[2];
			array5[0] = 63;
			HostValues.MobsIgnoreYouOn = array5;
			HostValues.MobsIgnoreYouOff = new byte[]
			{
				61,
				140
			};
			HostValues.WolfRemoveWaterOn = new byte[]
			{
				64
			};
			HostValues.WolfRemoveWaterOff = new byte[]
			{
				65
			};
			HostValues.WolfTurnHeadOn = new byte[]
			{
				64
			};
			HostValues.WolfTurnHeadOff = new byte[]
			{
				65
			};
			HostValues.NoMobOn = new byte[]
			{
				64
			};
			HostValues.NoMobOff = new byte[]
			{
				65
			};
			HostValues.GlitchMobOn = new byte[]
			{
				24
			};
			HostValues.GlitchMobOff = new byte[]
			{
				8
			};
			HostValues.NoGrab2On = new byte[]
			{
				65
			};
			HostValues.NoGrab2Off = new byte[]
			{
				64
			};
			HostValues.NoGrabOn = new byte[]
			{
				65
			};
			HostValues.NoGrabOff = new byte[]
			{
				64
			};
			HostValues.MaxPickupOn = new byte[]
			{
				65
			};
			HostValues.MaxPickupOff = new byte[]
			{
				64
			};
			HostValues.UnlimArrowsOn = new byte[1];
			HostValues.UnlimArrowsOff = new byte[]
			{
				1
			};
			HostValues.potionFlyArrowsOn = new byte[]
			{
				45
			};
			HostValues.potionFlyArrowsOff = new byte[]
			{
				61
			};
			HostValues.RemoveArrowsOn = new byte[]
			{
				65
			};
			HostValues.RemoveArrowsOff = new byte[]
			{
				64
			};
			HostValues.BlockArrowsOn = new byte[]
			{
				128
			};
			HostValues.BlockArrowsOff = new byte[]
			{
				64
			};
			HostValues.ChangeArrowDirOn = new byte[]
			{
				69
			};
			HostValues.ChangeArrowDirOff = new byte[]
			{
				64
			};
			HostValues.StopBowOn = new byte[]
			{
				224,
				88
			};
			HostValues.StopBowOff = new byte[]
			{
				224,
				8
			};
			HostValues.FastBowOn = new byte[]
			{
				224,
				24,
				24
			};
			HostValues.FastBowOff = new byte[]
			{
				224,
				8,
				24
			};
			HostValues.LockWeatherOn = new byte[]
			{
				65
			};
			HostValues.LockWeatherOff = new byte[]
			{
				64
			};
			HostValues.LockGamemodeOn = new byte[]
			{
				65
			};
			HostValues.LockGamemodeOff = new byte[]
			{
				64
			};
			HostValues.AllPlayersLeftHandOn = new byte[]
			{
				48,
				1,
				135,
				240
			};
			HostValues.AllPlayersLeftHandOff = new byte[]
			{
				48,
				1,
				135,
				248
			};
			HostValues.AllPlayersDamageOn = new byte[]
			{
				64
			};
			HostValues.AllPlayersDamageOff = new byte[]
			{
				65
			};
			HostValues.AllPlayersStopOn = new byte[]
			{
				120
			};
			HostValues.AllPlayersStopOff = new byte[]
			{
				8
			};
			HostValues.AllPlayersNoRunOn = new byte[]
			{
				byte.MaxValue,
				224,
				40,
				144
			};
			HostValues.AllPlayersNoRunOff = new byte[]
			{
				byte.MaxValue,
				224,
				8,
				144
			};
			HostValues.AllPlayersSpeed2On = new byte[]
			{
				88
			};
			HostValues.AllPlayersSpeed2Off = new byte[]
			{
				8
			};
			HostValues.AllPlayersSpeedOn = new byte[]
			{
				byte.MaxValue,
				224,
				0,
				144
			};
			HostValues.AllPlayersSpeedOff = new byte[]
			{
				byte.MaxValue,
				224,
				8,
				144
			};
			HostValues.AllPlayersFastMine2On = new byte[]
			{
				byte.MaxValue,
				224,
				24,
				144
			};
			HostValues.AllPlayersFastMine2Off = new byte[]
			{
				byte.MaxValue,
				224,
				8,
				144
			};
			HostValues.AllPlayersFastMineOn = new byte[]
			{
				byte.MaxValue,
				224,
				40,
				144
			};
			HostValues.AllPlayersFastMineOff = new byte[]
			{
				byte.MaxValue,
				224,
				8,
				144
			};
			HostValues.AntiJoinWorldOn = new byte[]
			{
				1
			};
			HostValues.AntiJoinWorldOff = new byte[1];
		}

		// Token: 0x04000107 RID: 263
		public static byte[] CreativeMenu1On = new byte[]
		{
			50,
			27,
			180,
			32
		};

		// Token: 0x04000108 RID: 264
		public static byte[] CreativeMenu2On = new byte[]
		{
			50,
			27,
			183,
			240
		};

		// Token: 0x04000109 RID: 265
		public static byte[] CreativeMenu3On = new byte[]
		{
			50,
			29,
			69,
			144
		};

		// Token: 0x0400010A RID: 266
		public static byte[] CreativeMenu4On = new byte[]
		{
			50,
			29,
			155,
			16
		};

		// Token: 0x0400010B RID: 267
		public static byte[] CreativeMenu5On = new byte[]
		{
			50,
			29,
			157,
			224
		};

		// Token: 0x0400010C RID: 268
		public static byte[] CreativeMenu6On = new byte[]
		{
			50,
			29,
			112,
			0
		};

		// Token: 0x0400010D RID: 269
		public static byte[] CreativeMenu7On = new byte[]
		{
			50,
			32,
			141,
			160
		};

		// Token: 0x0400010E RID: 270
		public static byte[] GetSpecialBlocksOn = new byte[]
		{
			1
		};

		// Token: 0x0400010F RID: 271
		public static byte[] GetSpecialBlocksOff = new byte[1];

		// Token: 0x04000110 RID: 272
		public static byte[] SpecBlockBarrier = new byte[]
		{
			50,
			25,
			147,
			192
		};

		// Token: 0x04000111 RID: 273
		public static byte[] SpecBlockChainCMD = new byte[]
		{
			50,
			25,
			239,
			48
		};

		// Token: 0x04000112 RID: 274
		public static byte[] SpecBlockRepeatCMD = new byte[]
		{
			50,
			25,
			237,
			176
		};

		// Token: 0x04000113 RID: 275
		public static byte[] SpecBlockCMD = new byte[]
		{
			50,
			25,
			79,
			32
		};

		// Token: 0x04000114 RID: 276
		public static byte[] SpecBlockDragonEgg = new byte[]
		{
			50,
			25,
			46,
			16
		};

		// Token: 0x04000115 RID: 277
		public static byte[] SpecBlockEndGate = new byte[]
		{
			50,
			25,
			236,
			0
		};

		// Token: 0x04000116 RID: 278
		public static byte[] SpecBlockIce = new byte[]
		{
			50,
			25,
			241,
			224
		};

		// Token: 0x04000117 RID: 279
		public static byte[] SpecBlockMagma = new byte[]
		{
			50,
			25,
			244,
			192
		};

		// Token: 0x04000118 RID: 280
		public static byte[] SpecBlockSign = new byte[]
		{
			50,
			24,
			190,
			0
		};

		// Token: 0x04000119 RID: 281
		public static byte[] SpecBlockDiamondOre = new byte[]
		{
			50,
			24,
			180,
			96
		};

		// Token: 0x0400011A RID: 282
		public static byte[] BatEggCrashOn = new byte[]
		{
			1
		};

		// Token: 0x0400011B RID: 283
		public static byte[] BatEggCrashOff = new byte[1];

		// Token: 0x0400011C RID: 284
		public static byte[] bateggOfflineModeOn = new byte[]
		{
			8
		};

		// Token: 0x0400011D RID: 285
		public static byte[] BatEggOfflineModeOff = new byte[1];

		// Token: 0x0400011E RID: 286
		public static byte[] DriftBoatOn = new byte[]
		{
			65
		};

		// Token: 0x0400011F RID: 287
		public static byte[] DriftBoatOff = new byte[]
		{
			64
		};

		// Token: 0x04000120 RID: 288
		public static byte[] WaterJumpOn = new byte[]
		{
			63,
			249,
			153,
			153
		};

		// Token: 0x04000121 RID: 289
		public static byte[] WaterJumpOff = new byte[]
		{
			63,
			233,
			153,
			153
		};

		// Token: 0x04000122 RID: 290
		public static byte[] RemoveXPOn = new byte[]
		{
			65
		};

		// Token: 0x04000123 RID: 291
		public static byte[] RemoveXPOff = new byte[]
		{
			64
		};

		// Token: 0x04000124 RID: 292
		public static byte[] MaxXPOn = new byte[]
		{
			124,
			165,
			16,
			20
		};

		// Token: 0x04000125 RID: 293
		public static byte[] MaxXPOff = new byte[]
		{
			124,
			165,
			32,
			20
		};

		// Token: 0x04000126 RID: 294
		public static byte[] GunItemsOn = new byte[]
		{
			63,
			byte.MaxValue
		};

		// Token: 0x04000127 RID: 295
		public static byte[] GunItemsOff = new byte[]
		{
			63,
			128
		};

		// Token: 0x04000128 RID: 296
		public static byte[] AutoSaveOn = new byte[]
		{
			64
		};

		// Token: 0x04000129 RID: 297
		public static byte[] AutoSaveOff = new byte[]
		{
			65
		};

		// Token: 0x0400012A RID: 298
		public static byte[] ReverseKnockbackOn = new byte[]
		{
			191,
			128
		};

		// Token: 0x0400012B RID: 299
		public static byte[] ReverseKnockbackOff = new byte[]
		{
			62,
			204
		};

		// Token: 0x0400012C RID: 300
		public static byte[] AntiKnockbackOn = new byte[2];

		// Token: 0x0400012D RID: 301
		public static byte[] AntiKnockbackOff = new byte[]
		{
			62,
			204
		};

		// Token: 0x0400012E RID: 302
		public static byte[] KnockbackOn = new byte[]
		{
			64,
			128
		};

		// Token: 0x0400012F RID: 303
		public static byte[] KnockbackOff = new byte[]
		{
			62,
			204
		};

		// Token: 0x04000130 RID: 304
		public static byte[] NoDamageHitOn = new byte[]
		{
			byte.MaxValue,
			byte.MaxValue
		};

		// Token: 0x04000131 RID: 305
		public static byte[] NoDamageHitOff;

		// Token: 0x04000132 RID: 306
		public static byte[] InstantKillFireOn;

		// Token: 0x04000133 RID: 307
		public static byte[] InstantKillFireOff;

		// Token: 0x04000134 RID: 308
		public static byte[] BypassKillAllOn;

		// Token: 0x04000135 RID: 309
		public static byte[] BypassKillAllOff;

		// Token: 0x04000136 RID: 310
		public static byte[] InstaKillAllOn;

		// Token: 0x04000137 RID: 311
		public static byte[] InstaKillAllOff;

		// Token: 0x04000138 RID: 312
		public static byte[] InstantDamageOn;

		// Token: 0x04000139 RID: 313
		public static byte[] InstantDamageOff;

		// Token: 0x0400013A RID: 314
		public static byte[] AutoRegenOn;

		// Token: 0x0400013B RID: 315
		public static byte[] AutoRegenOff;

		// Token: 0x0400013C RID: 316
		public static byte[] DemiGodOn;

		// Token: 0x0400013D RID: 317
		public static byte[] DemiGodOff;

		// Token: 0x0400013E RID: 318
		public static byte[] GodModeOn;

		// Token: 0x0400013F RID: 319
		public static byte[] GodModeOff;

		// Token: 0x04000140 RID: 320
		public static byte[] CreeperNoGriefOn;

		// Token: 0x04000141 RID: 321
		public static byte[] CreeperNoGriefOff;

		// Token: 0x04000142 RID: 322
		public static byte[] CreeperFireExplodeOn;

		// Token: 0x04000143 RID: 323
		public static byte[] CreeperFireExplodeOff;

		// Token: 0x04000144 RID: 324
		public static byte[] CreeperInstantExplodeOn;

		// Token: 0x04000145 RID: 325
		public static byte[] CreeperInstantExplodeOff;

		// Token: 0x04000146 RID: 326
		public static byte[] CreeperExtremExplodeOn;

		// Token: 0x04000147 RID: 327
		public static byte[] CreeperExtremExplodeOff;

		// Token: 0x04000148 RID: 328
		public static byte[] CreeperMedExplode2On;

		// Token: 0x04000149 RID: 329
		public static byte[] CreeperMedExplode2Off;

		// Token: 0x0400014A RID: 330
		public static byte[] BigCreeperOn;

		// Token: 0x0400014B RID: 331
		public static byte[] BigCreeperOff;

		// Token: 0x0400014C RID: 332
		public static byte[] TNTSilentOn;

		// Token: 0x0400014D RID: 333
		public static byte[] TNTSilentOff;

		// Token: 0x0400014E RID: 334
		public static byte[] TNTDownOn;

		// Token: 0x0400014F RID: 335
		public static byte[] TNTDownOff;

		// Token: 0x04000150 RID: 336
		public static byte[] TNTFlyOn;

		// Token: 0x04000151 RID: 337
		public static byte[] TNTFlyOff;

		// Token: 0x04000152 RID: 338
		public static byte[] TNTMoreParticleOn;

		// Token: 0x04000153 RID: 339
		public static byte[] TNTMoreParticleOff;

		// Token: 0x04000154 RID: 340
		public static byte[] SmallTNTOn;

		// Token: 0x04000155 RID: 341
		public static byte[] SmallTNTOff;

		// Token: 0x04000156 RID: 342
		public static byte[] TNTNoGreif2On;

		// Token: 0x04000157 RID: 343
		public static byte[] TNTNoGreif2Off;

		// Token: 0x04000158 RID: 344
		public static byte[] TNTNoGreifOn;

		// Token: 0x04000159 RID: 345
		public static byte[] TNTNoGreifOff;

		// Token: 0x0400015A RID: 346
		public static byte[] InstantExplodeTNTOn;

		// Token: 0x0400015B RID: 347
		public static byte[] InstantExplodeTNTOff;

		// Token: 0x0400015C RID: 348
		public static byte[] EnableRainOn;

		// Token: 0x0400015D RID: 349
		public static byte[] EnableRainOff;

		// Token: 0x0400015E RID: 350
		public static byte[] LightningBoltOn;

		// Token: 0x0400015F RID: 351
		public static byte[] LightningBoltOff;

		// Token: 0x04000160 RID: 352
		public static byte[] FlashSkyOn;

		// Token: 0x04000161 RID: 353
		public static byte[] FlashSkyOff;

		// Token: 0x04000162 RID: 354
		public static byte[] SmallRainOn;

		// Token: 0x04000163 RID: 355
		public static byte[] SmallRainOff;

		// Token: 0x04000164 RID: 356
		public static byte[] RainToSnowOn;

		// Token: 0x04000165 RID: 357
		public static byte[] RainToSnowOff;

		// Token: 0x04000166 RID: 358
		public static byte[] RainbowStormOn;

		// Token: 0x04000167 RID: 359
		public static byte[] RainbowStormOff;

		// Token: 0x04000168 RID: 360
		public static byte[] DarkStormOn;

		// Token: 0x04000169 RID: 361
		public static byte[] DarkStormOff;

		// Token: 0x0400016A RID: 362
		public static byte[] KillNoDissappearEntityOn;

		// Token: 0x0400016B RID: 363
		public static byte[] KillNoDissappearEntityOff;

		// Token: 0x0400016C RID: 364
		public static byte[] KillDissapearEntityOn;

		// Token: 0x0400016D RID: 365
		public static byte[] KillDissapearEntityOff;

		// Token: 0x0400016E RID: 366
		public static byte[] SpectatorOn;

		// Token: 0x0400016F RID: 367
		public static byte[] SpectatorOff;

		// Token: 0x04000170 RID: 368
		public static byte[] InfiniteBreathOn;

		// Token: 0x04000171 RID: 369
		public static byte[] InfiniteBreathOff;

		// Token: 0x04000172 RID: 370
		public static byte[] SpectralArrowsOn;

		// Token: 0x04000173 RID: 371
		public static byte[] SpectralArrowsOff;

		// Token: 0x04000174 RID: 372
		public static byte[] EntityGodmodeOn;

		// Token: 0x04000175 RID: 373
		public static byte[] EntityGodmodeOff;

		// Token: 0x04000176 RID: 374
		public static byte[] NoWebOn;

		// Token: 0x04000177 RID: 375
		public static byte[] NoWebOff;

		// Token: 0x04000178 RID: 376
		public static byte[] BypassStackLimitOn;

		// Token: 0x04000179 RID: 377
		public static byte[] BypassStackLimitOff;

		// Token: 0x0400017A RID: 378
		public static byte[] RemoveHitDelayOn;

		// Token: 0x0400017B RID: 379
		public static byte[] RemoveHitDelayOff;

		// Token: 0x0400017C RID: 380
		public static byte[] StopGravityOn;

		// Token: 0x0400017D RID: 381
		public static byte[] StopGravityOff;

		// Token: 0x0400017E RID: 382
		public static byte[] KillMobSpawnOn;

		// Token: 0x0400017F RID: 383
		public static byte[] KillMobSpawnOff;

		// Token: 0x04000180 RID: 384
		public static byte[] RemoveWaterOn;

		// Token: 0x04000181 RID: 385
		public static byte[] RemoveWaterOff;

		// Token: 0x04000182 RID: 386
		public static byte[] BurnInWaterOn;

		// Token: 0x04000183 RID: 387
		public static byte[] BurnInWaterOff;

		// Token: 0x04000184 RID: 388
		public static byte[] lobbyMSGOn;

		// Token: 0x04000185 RID: 389
		public static byte[] lobbyMSGOff;

		// Token: 0x04000186 RID: 390
		public static byte[] InfinitePlaceOn;

		// Token: 0x04000187 RID: 391
		public static byte[] InfinitePlaceOff;

		// Token: 0x04000188 RID: 392
		public static byte[] NoFallOn;

		// Token: 0x04000189 RID: 393
		public static byte[] NoFallOff;

		// Token: 0x0400018A RID: 394
		public static byte[] MobsIgnoreYouOn;

		// Token: 0x0400018B RID: 395
		public static byte[] MobsIgnoreYouOff;

		// Token: 0x0400018C RID: 396
		public static byte[] WolfRemoveWaterOn;

		// Token: 0x0400018D RID: 397
		public static byte[] WolfRemoveWaterOff;

		// Token: 0x0400018E RID: 398
		public static byte[] WolfTurnHeadOn;

		// Token: 0x0400018F RID: 399
		public static byte[] WolfTurnHeadOff;

		// Token: 0x04000190 RID: 400
		public static byte[] NoMobOn;

		// Token: 0x04000191 RID: 401
		public static byte[] NoMobOff;

		// Token: 0x04000192 RID: 402
		public static byte[] GlitchMobOn;

		// Token: 0x04000193 RID: 403
		public static byte[] GlitchMobOff;

		// Token: 0x04000194 RID: 404
		public static byte[] NoGrab2On;

		// Token: 0x04000195 RID: 405
		public static byte[] NoGrab2Off;

		// Token: 0x04000196 RID: 406
		public static byte[] NoGrabOn;

		// Token: 0x04000197 RID: 407
		public static byte[] NoGrabOff;

		// Token: 0x04000198 RID: 408
		public static byte[] MaxPickupOn;

		// Token: 0x04000199 RID: 409
		public static byte[] MaxPickupOff;

		// Token: 0x0400019A RID: 410
		public static byte[] UnlimArrowsOn;

		// Token: 0x0400019B RID: 411
		public static byte[] UnlimArrowsOff;

		// Token: 0x0400019C RID: 412
		public static byte[] potionFlyArrowsOn;

		// Token: 0x0400019D RID: 413
		public static byte[] potionFlyArrowsOff;

		// Token: 0x0400019E RID: 414
		public static byte[] RemoveArrowsOn;

		// Token: 0x0400019F RID: 415
		public static byte[] RemoveArrowsOff;

		// Token: 0x040001A0 RID: 416
		public static byte[] BlockArrowsOn;

		// Token: 0x040001A1 RID: 417
		public static byte[] BlockArrowsOff;

		// Token: 0x040001A2 RID: 418
		public static byte[] ChangeArrowDirOn;

		// Token: 0x040001A3 RID: 419
		public static byte[] ChangeArrowDirOff;

		// Token: 0x040001A4 RID: 420
		public static byte[] StopBowOn;

		// Token: 0x040001A5 RID: 421
		public static byte[] StopBowOff;

		// Token: 0x040001A6 RID: 422
		public static byte[] FastBowOn;

		// Token: 0x040001A7 RID: 423
		public static byte[] FastBowOff;

		// Token: 0x040001A8 RID: 424
		public static byte[] LockWeatherOn;

		// Token: 0x040001A9 RID: 425
		public static byte[] LockWeatherOff;

		// Token: 0x040001AA RID: 426
		public static byte[] LockGamemodeOn;

		// Token: 0x040001AB RID: 427
		public static byte[] LockGamemodeOff;

		// Token: 0x040001AC RID: 428
		public static byte[] AllPlayersLeftHandOn;

		// Token: 0x040001AD RID: 429
		public static byte[] AllPlayersLeftHandOff;

		// Token: 0x040001AE RID: 430
		public static byte[] AllPlayersDamageOn;

		// Token: 0x040001AF RID: 431
		public static byte[] AllPlayersDamageOff;

		// Token: 0x040001B0 RID: 432
		public static byte[] AllPlayersStopOn;

		// Token: 0x040001B1 RID: 433
		public static byte[] AllPlayersStopOff;

		// Token: 0x040001B2 RID: 434
		public static byte[] AllPlayersNoRunOn;

		// Token: 0x040001B3 RID: 435
		public static byte[] AllPlayersNoRunOff;

		// Token: 0x040001B4 RID: 436
		public static byte[] AllPlayersSpeed2On;

		// Token: 0x040001B5 RID: 437
		public static byte[] AllPlayersSpeed2Off;

		// Token: 0x040001B6 RID: 438
		public static byte[] AllPlayersSpeedOn;

		// Token: 0x040001B7 RID: 439
		public static byte[] AllPlayersSpeedOff;

		// Token: 0x040001B8 RID: 440
		public static byte[] AllPlayersFastMine2On;

		// Token: 0x040001B9 RID: 441
		public static byte[] AllPlayersFastMine2Off;

		// Token: 0x040001BA RID: 442
		public static byte[] AllPlayersFastMineOn;

		// Token: 0x040001BB RID: 443
		public static byte[] AllPlayersFastMineOff;

		// Token: 0x040001BC RID: 444
		public static byte[] AntiJoinWorldOn;

		// Token: 0x040001BD RID: 445
		public static byte[] AntiJoinWorldOff;
	}
}
