﻿using System;

namespace BunifUITest.Codes.Values
{
	// Token: 0x02000009 RID: 9
	public static class NonHostValues
	{
		// Token: 0x06000105 RID: 261 RVA: 0x000147A8 File Offset: 0x000129A8
		// Note: this type is marked as 'beforefieldinit'.
		static NonHostValues()
		{
			byte[] array = new byte[4];
			array[0] = 56;
			array[1] = 128;
			NonHostValues.ShowArmourNHostOff = array;
			NonHostValues.XToHitNHostOn = new byte[]
			{
				15
			};
			NonHostValues.XToHitNHostOff = new byte[]
			{
				1
			};
			NonHostValues.NoHurtCamNHostOn = new byte[2];
			NonHostValues.NoHurtCamNHostOff = new byte[]
			{
				64,
				73
			};
			NonHostValues.NoSLowDownNHostOn = new byte[]
			{
				79
			};
			NonHostValues.NoSLowDownNHostOff = new byte[]
			{
				63
			};
			NonHostValues.CriticalmodeNHostOn = new byte[]
			{
				63,
				175
			};
			NonHostValues.CriticalmodeNHostOff = new byte[]
			{
				63,
				239
			};
			NonHostValues.FastBuildNHostOn = new byte[]
			{
				64
			};
			NonHostValues.FastBuildNHostOff = new byte[]
			{
				65
			};
			NonHostValues.KillAuraNHostOn = new byte[]
			{
				byte.MaxValue
			};
			NonHostValues.KillAuraNHostOff = new byte[1];
			NonHostValues.InstantHitNHostOn = new byte[]
			{
				byte.MaxValue
			};
			NonHostValues.InstantHitNHostOff = new byte[]
			{
				62
			};
			NonHostValues.BlockStaticOn = new byte[]
			{
				1
			};
			NonHostValues.BlockStaticOff = new byte[1];
			NonHostValues.UnFairAttackOn = new byte[]
			{
				190
			};
			NonHostValues.UnFairAttackOff = new byte[]
			{
				62
			};
		}

		// Token: 0x040001BE RID: 446
		public static byte[] MultiJump2NHostOn = new byte[]
		{
			2
		};

		// Token: 0x040001BF RID: 447
		public static byte[] MultiJump2NHostOff = new byte[]
		{
			1
		};

		// Token: 0x040001C0 RID: 448
		public static byte[] AirToWaterNHostOn = new byte[]
		{
			64
		};

		// Token: 0x040001C1 RID: 449
		public static byte[] AirToWaterNHostOff = new byte[]
		{
			65
		};

		// Token: 0x040001C2 RID: 450
		public static byte[] AutoLadderNHostOn = new byte[]
		{
			1
		};

		// Token: 0x040001C3 RID: 451
		public static byte[] AutoLadderNHostOff = new byte[1];

		// Token: 0x040001C4 RID: 452
		public static byte[] CrouchRunNHostOn = new byte[]
		{
			1
		};

		// Token: 0x040001C5 RID: 453
		public static byte[] CrouchRunNHostOff = new byte[1];

		// Token: 0x040001C6 RID: 454
		public static byte[] NoEntityCollisionNHostOn = new byte[]
		{
			65
		};

		// Token: 0x040001C7 RID: 455
		public static byte[] NoEntityCollisionNHostOff = new byte[]
		{
			64
		};

		// Token: 0x040001C8 RID: 456
		public static byte[] MaxRiptideNHostOn = new byte[]
		{
			8
		};

		// Token: 0x040001C9 RID: 457
		public static byte[] MaxRiptideNHostOff = new byte[1];

		// Token: 0x040001CA RID: 458
		public static byte[] MakeRainNHostOn = new byte[]
		{
			72
		};

		// Token: 0x040001CB RID: 459
		public static byte[] MakeRainNHostOff = new byte[]
		{
			8
		};

		// Token: 0x040001CC RID: 460
		public static byte[] NightVisNHostOn = new byte[]
		{
			127
		};

		// Token: 0x040001CD RID: 461
		public static byte[] NightVisNHostOff = new byte[]
		{
			63
		};

		// Token: 0x040001CE RID: 462
		public static byte[] LevitationNHostOn = new byte[]
		{
			191
		};

		// Token: 0x040001CF RID: 463
		public static byte[] LevitationNHostOff = new byte[]
		{
			63
		};

		// Token: 0x040001D0 RID: 464
		public static byte[] DayNightNHostOn = new byte[]
		{
			47
		};

		// Token: 0x040001D1 RID: 465
		public static byte[] DayNightNHostOff = new byte[]
		{
			63
		};

		// Token: 0x040001D2 RID: 466
		public static byte[] RemoveTextNHostOn = new byte[]
		{
			64
		};

		// Token: 0x040001D3 RID: 467
		public static byte[] RemoveTextNHostOff = new byte[]
		{
			65
		};

		// Token: 0x040001D4 RID: 468
		public static byte[] SeeOutMapNHostOn = new byte[]
		{
			223
		};

		// Token: 0x040001D5 RID: 469
		public static byte[] SeeOutMapNHostOff = new byte[]
		{
			63
		};

		// Token: 0x040001D6 RID: 470
		public static byte[] BetterTimeNHostOn = new byte[]
		{
			15
		};

		// Token: 0x040001D7 RID: 471
		public static byte[] BetterTimeNHostOff = new byte[]
		{
			63
		};

		// Token: 0x040001D8 RID: 472
		public static byte[] DownCamNHostOn = new byte[]
		{
			252,
			2,
			16
		};

		// Token: 0x040001D9 RID: 473
		public static byte[] DownCamNHostOff = new byte[]
		{
			252,
			1,
			16
		};

		// Token: 0x040001DA RID: 474
		public static byte[] MoongravNHostOn = new byte[]
		{
			64
		};

		// Token: 0x040001DB RID: 475
		public static byte[] MoongravNHostOff = new byte[]
		{
			65
		};

		// Token: 0x040001DC RID: 476
		public static byte[] WalkInSkyNHostOn = new byte[]
		{
			64
		};

		// Token: 0x040001DD RID: 477
		public static byte[] WalkInSkyNHostOff = new byte[]
		{
			65
		};

		// Token: 0x040001DE RID: 478
		public static byte[] StaticMovementNHostOn = new byte[]
		{
			byte.MaxValue,
			160,
			24,
			144
		};

		// Token: 0x040001DF RID: 479
		public static byte[] StaticMovementNHostOff = new byte[]
		{
			byte.MaxValue,
			160,
			8,
			144
		};

		// Token: 0x040001E0 RID: 480
		public static byte[] NameOverHead2NHostOn = new byte[]
		{
			byte.MaxValue,
			192,
			224,
			144
		};

		// Token: 0x040001E1 RID: 481
		public static byte[] NameOverHead2NHostOff = new byte[]
		{
			byte.MaxValue,
			192,
			16,
			144
		};

		// Token: 0x040001E2 RID: 482
		public static byte[] NameOverHead1NHostOn = new byte[]
		{
			76
		};

		// Token: 0x040001E3 RID: 483
		public static byte[] NameOverHead1NHostOff = new byte[]
		{
			44
		};

		// Token: 0x040001E4 RID: 484
		public static byte[] XrayNHostOn = new byte[]
		{
			252,
			128,
			48,
			144
		};

		// Token: 0x040001E5 RID: 485
		public static byte[] XrayNHostOff = new byte[]
		{
			252,
			96,
			48,
			144
		};

		// Token: 0x040001E6 RID: 486
		public static byte[] Knockback2NHostOn = new byte[]
		{
			64
		};

		// Token: 0x040001E7 RID: 487
		public static byte[] Knockback2NHostOff = new byte[]
		{
			65
		};

		// Token: 0x040001E8 RID: 488
		public static byte[] Knockback1NHostOn = new byte[]
		{
			65
		};

		// Token: 0x040001E9 RID: 489
		public static byte[] Knockback1NHostOff = new byte[]
		{
			64
		};

		// Token: 0x040001EA RID: 490
		public static byte[] WalkAloneNHostOn = new byte[]
		{
			byte.MaxValue,
			64
		};

		// Token: 0x040001EB RID: 491
		public static byte[] WalkAloneNHostOff = new byte[]
		{
			byte.MaxValue,
			32
		};

		// Token: 0x040001EC RID: 492
		public static byte[] DisableRunNHostOn = new byte[]
		{
			76
		};

		// Token: 0x040001ED RID: 493
		public static byte[] DisableRunNHostOff = new byte[]
		{
			44
		};

		// Token: 0x040001EE RID: 494
		public static byte[] ExtremeCamSensitivityNHostOn = new byte[]
		{
			68,
			byte.MaxValue
		};

		// Token: 0x040001EF RID: 495
		public static byte[] ExtremeCamSensitivityNHostOff = new byte[]
		{
			66,
			72
		};

		// Token: 0x040001F0 RID: 496
		public static byte[] FastCamSensitivityNHostOn = new byte[]
		{
			66,
			byte.MaxValue
		};

		// Token: 0x040001F1 RID: 497
		public static byte[] FastCamSensitivityNHostOff = new byte[]
		{
			66,
			72
		};

		// Token: 0x040001F2 RID: 498
		public static byte[] AntiAFK3NHostOn = new byte[]
		{
			63,
			240
		};

		// Token: 0x040001F3 RID: 499
		public static byte[] AntiAFK3NHostOff = new byte[4];

		// Token: 0x040001F4 RID: 500
		public static byte[] AntiAFK1NHostOn = new byte[]
		{
			63,
			128
		};

		// Token: 0x040001F5 RID: 501
		public static byte[] AntiAFK1NHostOff = new byte[2];

		// Token: 0x040001F6 RID: 502
		public static byte[] UFOModsNHostOn = new byte[]
		{
			63,
			0,
			122,
			byte.MaxValue
		};

		// Token: 0x040001F7 RID: 503
		public static byte[] UFOModsNHostOff = new byte[]
		{
			63,
			239,
			92,
			41
		};

		// Token: 0x040001F8 RID: 504
		public static byte[] AntiTeleportNHostOn = new byte[]
		{
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue
		};

		// Token: 0x040001F9 RID: 505
		public static byte[] AntiTeleportNHostOff = new byte[]
		{
			63,
			122,
			225,
			72
		};

		// Token: 0x040001FA RID: 506
		public static byte[] MiniGameHUDNHostOn = new byte[]
		{
			65,
			130
		};

		// Token: 0x040001FB RID: 507
		public static byte[] MiniGameHUDNHostOff = new byte[]
		{
			64,
			130
		};

		// Token: 0x040001FC RID: 508
		public static byte[] InfiniteCraftNHostOn = new byte[]
		{
			1
		};

		// Token: 0x040001FD RID: 509
		public static byte[] InfiniteCraftNHostOff = new byte[1];

		// Token: 0x040001FE RID: 510
		public static byte[] InstantMineNHostOn = new byte[]
		{
			191
		};

		// Token: 0x040001FF RID: 511
		public static byte[] InstantMineNHostOff = new byte[]
		{
			63
		};

		// Token: 0x04000200 RID: 512
		public static byte[] R3CamDownNHostOn = new byte[]
		{
			252,
			0,
			248,
			144
		};

		// Token: 0x04000201 RID: 513
		public static byte[] R3CamDownNHostOff = new byte[]
		{
			252,
			32,
			248,
			144
		};

		// Token: 0x04000202 RID: 514
		public static byte[] FastBreakNHostOn = new byte[]
		{
			65
		};

		// Token: 0x04000203 RID: 515
		public static byte[] FastBreakNHostOff = new byte[]
		{
			64
		};

		// Token: 0x04000204 RID: 516
		public static byte[] DeadScreenNHostOn = new byte[]
		{
			65
		};

		// Token: 0x04000205 RID: 517
		public static byte[] DeadScreenNHostOff = new byte[]
		{
			64
		};

		// Token: 0x04000206 RID: 518
		public static byte[] ChestESP2NHostOn = new byte[]
		{
			62,
			byte.MaxValue
		};

		// Token: 0x04000207 RID: 519
		public static byte[] ChestESP2NHostOff = new byte[]
		{
			63,
			128
		};

		// Token: 0x04000208 RID: 520
		public static byte[] ChestESP1NHostOn = new byte[]
		{
			80
		};

		// Token: 0x04000209 RID: 521
		public static byte[] ChestESP1NHostOff = new byte[]
		{
			64
		};

		// Token: 0x0400020A RID: 522
		public static byte[] FloatUpNHostOn = new byte[]
		{
			63
		};

		// Token: 0x0400020B RID: 523
		public static byte[] FloatUpNHostOff = new byte[]
		{
			191
		};

		// Token: 0x0400020C RID: 524
		public static byte[] ChangeViewNHostOn = new byte[]
		{
			64
		};

		// Token: 0x0400020D RID: 525
		public static byte[] ChangeViewNHostOff = new byte[]
		{
			65
		};

		// Token: 0x0400020E RID: 526
		public static byte[] LockInBlockNHostOn = new byte[]
		{
			64
		};

		// Token: 0x0400020F RID: 527
		public static byte[] LockInBlockNHostOff = new byte[]
		{
			65
		};

		// Token: 0x04000210 RID: 528
		public static byte[] NoFlightNHostOn = new byte[]
		{
			65
		};

		// Token: 0x04000211 RID: 529
		public static byte[] NoFlightNHostOff = new byte[]
		{
			64
		};

		// Token: 0x04000212 RID: 530
		public static byte[] AntiKickNHostOn = new byte[]
		{
			64
		};

		// Token: 0x04000213 RID: 531
		public static byte[] AntiKickNHostOff = new byte[]
		{
			65
		};

		// Token: 0x04000214 RID: 532
		public static byte[] ShowIDsNHostOn = new byte[]
		{
			64
		};

		// Token: 0x04000215 RID: 533
		public static byte[] ShowIDsNHostOff = new byte[]
		{
			65
		};

		// Token: 0x04000216 RID: 534
		public static byte[] ShowIDsNHost2On = new byte[]
		{
			64
		};

		// Token: 0x04000217 RID: 535
		public static byte[] ShowIDsNHost2Off = new byte[]
		{
			65
		};

		// Token: 0x04000218 RID: 536
		public static byte[] StaticSpeedNHostOn = new byte[]
		{
			65
		};

		// Token: 0x04000219 RID: 537
		public static byte[] StaticSpeedNHostOff = new byte[]
		{
			64
		};

		// Token: 0x0400021A RID: 538
		public static byte[] ModeratorFlightNHostOn = new byte[]
		{
			64
		};

		// Token: 0x0400021B RID: 539
		public static byte[] ModeratorFlightNHostOff = new byte[]
		{
			65
		};

		// Token: 0x0400021C RID: 540
		public static byte[] SuicideNHostOn = new byte[]
		{
			63,
			byte.MaxValue
		};

		// Token: 0x0400021D RID: 541
		public static byte[] SuicideNHostOff = new byte[]
		{
			63,
			239
		};

		// Token: 0x0400021E RID: 542
		public static byte[] FlyXNHostOn = new byte[]
		{
			64
		};

		// Token: 0x0400021F RID: 543
		public static byte[] FlyXNHostOff = new byte[]
		{
			65
		};

		// Token: 0x04000220 RID: 544
		public static byte[] XMBKick2NHostOn = new byte[]
		{
			64
		};

		// Token: 0x04000221 RID: 545
		public static byte[] XMBKick2NHostOff = new byte[]
		{
			65
		};

		// Token: 0x04000222 RID: 546
		public static byte[] XMBKick1NHostOn = new byte[]
		{
			64
		};

		// Token: 0x04000223 RID: 547
		public static byte[] XMBKick1NHostOff = new byte[]
		{
			65
		};

		// Token: 0x04000224 RID: 548
		public static byte[] NoCollisionBypassNHostOn = new byte[]
		{
			64
		};

		// Token: 0x04000225 RID: 549
		public static byte[] NoCollisionBypassNHostOff = new byte[]
		{
			65
		};

		// Token: 0x04000226 RID: 550
		public static byte[] NoCollisionNHostOn = new byte[]
		{
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue
		};

		// Token: 0x04000227 RID: 551
		public static byte[] NoCollisionNHostOff = new byte[8];

		// Token: 0x04000228 RID: 552
		public static byte[] SwimGlitchNHostOn = new byte[]
		{
			64
		};

		// Token: 0x04000229 RID: 553
		public static byte[] SwimGlitchNHostOff = new byte[]
		{
			65
		};

		// Token: 0x0400022A RID: 554
		public static byte[] ChangeSwimMovementNHostOn = new byte[]
		{
			188
		};

		// Token: 0x0400022B RID: 555
		public static byte[] ChangeSwimMovementNHostOff = new byte[]
		{
			60
		};

		// Token: 0x0400022C RID: 556
		public static byte[] DisableSwimNHostOn = new byte[]
		{
			65
		};

		// Token: 0x0400022D RID: 557
		public static byte[] DisableSwimNHostOff = new byte[]
		{
			64
		};

		// Token: 0x0400022E RID: 558
		public static byte[] JumpSpeedNHostOn = new byte[]
		{
			160
		};

		// Token: 0x0400022F RID: 559
		public static byte[] JumpSpeedNHostOff = new byte[]
		{
			104
		};

		// Token: 0x04000230 RID: 560
		public static byte[] RemoveJumpNHostOn = new byte[]
		{
			244
		};

		// Token: 0x04000231 RID: 561
		public static byte[] RemoveJumpNHostOff = new byte[]
		{
			180
		};

		// Token: 0x04000232 RID: 562
		public static byte[] JumpForwardNHostOn = new byte[]
		{
			128
		};

		// Token: 0x04000233 RID: 563
		public static byte[] JumpForwardNHostOff = new byte[]
		{
			104
		};

		// Token: 0x04000234 RID: 564
		public static byte[] SuperJump2NHostOn = new byte[]
		{
			63
		};

		// Token: 0x04000235 RID: 565
		public static byte[] SuperJump2NHostOff = new byte[]
		{
			62
		};

		// Token: 0x04000236 RID: 566
		public static byte[] SuperJump1NHostOn = new byte[]
		{
			63,
			71,
			127,
			66
		};

		// Token: 0x04000237 RID: 567
		public static byte[] SuperJump1NHostOff = new byte[]
		{
			62,
			215,
			10,
			61
		};

		// Token: 0x04000238 RID: 568
		public static byte[] JumpInSkyNHostOn = new byte[]
		{
			64
		};

		// Token: 0x04000239 RID: 569
		public static byte[] JumpInSkyNHostOff = new byte[]
		{
			65
		};

		// Token: 0x0400023A RID: 570
		public static byte[] JumpForBuildNHostOn = new byte[]
		{
			252,
			128
		};

		// Token: 0x0400023B RID: 571
		public static byte[] JumpForBuildNHostOff = new byte[]
		{
			252,
			32
		};

		// Token: 0x0400023C RID: 572
		public static byte[] MultiJumpNHostOn = new byte[]
		{
			20
		};

		// Token: 0x0400023D RID: 573
		public static byte[] MultiJumpNHostOff = new byte[]
		{
			24
		};

		// Token: 0x0400023E RID: 574
		public static byte[] SpeedLegitNHostOn = new byte[]
		{
			134
		};

		// Token: 0x0400023F RID: 575
		public static byte[] SpeedLegitNHostOff = new byte[]
		{
			38
		};

		// Token: 0x04000240 RID: 576
		public static byte[] Speed6NHostOn = new byte[]
		{
			62
		};

		// Token: 0x04000241 RID: 577
		public static byte[] Speed6NHostOff = new byte[]
		{
			63
		};

		// Token: 0x04000242 RID: 578
		public static byte[] Speed5NHostOn = new byte[]
		{
			65,
			byte.MaxValue
		};

		// Token: 0x04000243 RID: 579
		public static byte[] Speed5NHostOff = new byte[]
		{
			62,
			38
		};

		// Token: 0x04000244 RID: 580
		public static byte[] Speed4NHostOn = new byte[]
		{
			63,
			byte.MaxValue,
			0,
			1
		};

		// Token: 0x04000245 RID: 581
		public static byte[] Speed4NHostOff = new byte[]
		{
			62,
			38,
			173,
			137
		};

		// Token: 0x04000246 RID: 582
		public static byte[] Speed2NHostOn = new byte[1];

		// Token: 0x04000247 RID: 583
		public static byte[] Speed2NHostOff = new byte[]
		{
			104
		};

		// Token: 0x04000248 RID: 584
		public static byte[] Speed1NHostOn = new byte[]
		{
			byte.MaxValue,
			byte.MaxValue,
			byte.MaxValue
		};

		// Token: 0x04000249 RID: 585
		public static byte[] Speed1NHostOff = new byte[]
		{
			38,
			173,
			137
		};

		// Token: 0x0400024A RID: 586
		public static byte[] ShowArmourNHostOn = new byte[]
		{
			56,
			128,
			0,
			1
		};

		// Token: 0x0400024B RID: 587
		public static byte[] ShowArmourNHostOff;

		// Token: 0x0400024C RID: 588
		public static byte[] XToHitNHostOn;

		// Token: 0x0400024D RID: 589
		public static byte[] XToHitNHostOff;

		// Token: 0x0400024E RID: 590
		public static byte[] NoHurtCamNHostOn;

		// Token: 0x0400024F RID: 591
		public static byte[] NoHurtCamNHostOff;

		// Token: 0x04000250 RID: 592
		public static byte[] NoSLowDownNHostOn;

		// Token: 0x04000251 RID: 593
		public static byte[] NoSLowDownNHostOff;

		// Token: 0x04000252 RID: 594
		public static byte[] CriticalmodeNHostOn;

		// Token: 0x04000253 RID: 595
		public static byte[] CriticalmodeNHostOff;

		// Token: 0x04000254 RID: 596
		public static byte[] FastBuildNHostOn;

		// Token: 0x04000255 RID: 597
		public static byte[] FastBuildNHostOff;

		// Token: 0x04000256 RID: 598
		public static byte[] KillAuraNHostOn;

		// Token: 0x04000257 RID: 599
		public static byte[] KillAuraNHostOff;

		// Token: 0x04000258 RID: 600
		public static byte[] InstantHitNHostOn;

		// Token: 0x04000259 RID: 601
		public static byte[] InstantHitNHostOff;

		// Token: 0x0400025A RID: 602
		public static byte[] BlockStaticOn;

		// Token: 0x0400025B RID: 603
		public static byte[] BlockStaticOff;

		// Token: 0x0400025C RID: 604
		public static byte[] UnFairAttackOn;

		// Token: 0x0400025D RID: 605
		public static byte[] UnFairAttackOff;
	}
}
