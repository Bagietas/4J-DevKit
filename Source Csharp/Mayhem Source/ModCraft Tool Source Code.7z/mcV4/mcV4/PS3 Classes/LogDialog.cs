using System;
using System.ComponentModel;
using System.Drawing;
using System.Resources;
using System.Windows.Forms;

namespace PS3Lib
{
	public class LogDialog : Form
	{
        private PS3Lib.PS3MAPI PS3MAPI;

		private IContainer components;

		protected internal TextBox tB_Log;

		private Button btnRefresh;

		private Button button1;

		public LogDialog()
		{
			this.InitializeComponent();
		}

        public LogDialog(PS3Lib.PS3MAPI MyPS3MAPI)
            : this()
		{
			this.PS3MAPI = MyPS3MAPI;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			base.Hide();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(LogDialog));
			this.tB_Log = new TextBox();
			this.btnRefresh = new Button();
			this.button1 = new Button();
			base.SuspendLayout();
			this.tB_Log.BackColor = Color.White;
			this.tB_Log.Location = new Point(12, 12);
			this.tB_Log.MaxLength = 16;
			this.tB_Log.Multiline = true;
			this.tB_Log.Name = "tB_Log";
			this.tB_Log.ReadOnly = true;
			this.tB_Log.ScrollBars = ScrollBars.Both;
			this.tB_Log.Size = new System.Drawing.Size(429, 327);
			this.tB_Log.TabIndex = 10;
			this.btnRefresh.Location = new Point(290, 345);
			this.btnRefresh.Name = "btnRefresh";
			this.btnRefresh.Size = new System.Drawing.Size(71, 21);
			this.btnRefresh.TabIndex = 1;
			this.btnRefresh.Text = "Refresh";
			this.btnRefresh.UseVisualStyleBackColor = true;
			this.btnRefresh.Click += new EventHandler(this.LogDialog_Refresh);
			this.button1.Location = new Point(370, 345);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(71, 21);
			this.button1.TabIndex = 2;
			this.button1.Text = "Close";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new EventHandler(this.button1_Click);
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(453, 378);
			base.ControlBox = false;
			base.Controls.Add(this.button1);
			base.Controls.Add(this.btnRefresh);
			base.Controls.Add(this.tB_Log);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.Icon = (System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "LogDialog";
			base.StartPosition = FormStartPosition.CenterParent;
			this.Text = "PS3 Manager API Log";
			base.Activated += new EventHandler(this.LogDialog_Refresh);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		private void LogDialog_Refresh(object sender, EventArgs e)
		{
			if (this.PS3MAPI != null)
			{
				this.tB_Log.Text = this.PS3MAPI.Log;
			}
		}
	}
}