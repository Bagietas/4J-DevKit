using System;
using System.ComponentModel;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace PS3Lib
{
	public class PS3MAPI
	{
		public int PS3M_API_PC_LIB_VERSION = 288;

		public PS3MAPI.CORE_CMD Core = new PS3MAPI.CORE_CMD();

		public PS3MAPI.SERVER_CMD Server = new PS3MAPI.SERVER_CMD();

		public PS3MAPI.PS3_CMD PS3 = new PS3MAPI.PS3_CMD();

		public PS3MAPI.PROCESS_CMD Process = new PS3MAPI.PROCESS_CMD();

		public PS3MAPI.VSH_PLUGINS_CMD VSH_Plugin = new PS3MAPI.VSH_PLUGINS_CMD();

        private PS3Lib.LogDialog LogDialog;

		public bool IsAttached
		{
			get
			{
				return PS3MAPI.PS3MAPI_Client_Server.IsAttached;
			}
		}

		public bool IsConnected
		{
			get
			{
				return PS3MAPI.PS3MAPI_Client_Server.IsConnected;
			}
		}

		public string Log
		{
			get
			{
				return PS3MAPI.PS3MAPI_Client_Server.Log;
			}
		}

		public PS3MAPI()
		{
			this.Core = new PS3MAPI.CORE_CMD();
			this.Server = new PS3MAPI.SERVER_CMD();
			this.PS3 = new PS3MAPI.PS3_CMD();
			this.Process = new PS3MAPI.PROCESS_CMD();
		}

		public bool AttachProcess(uint pid)
		{
			bool flag;
			try
			{
				this.Process.Process_Pid = pid;
				flag = true;
			}
			catch (Exception exception1)
			{
				Exception exception = exception1;
				throw new Exception(exception.Message, exception);
			}
			return flag;
		}

		public bool AttachProcess()
		{
			bool flag;
			DialogResult dialogResult;
			bool flag1;
			AttachDialog attachDialog = null;
			try
			{
				do
				{
					flag = false;
					if (attachDialog != null)
					{
						attachDialog.Dispose();
						attachDialog = null;
					}
					attachDialog = new AttachDialog(this);
					dialogResult = attachDialog.ShowDialog();
					if (dialogResult != DialogResult.OK)
					{
						continue;
					}
					string[] strArrays = attachDialog.comboBox1.Text.Split(new char[] { '\u005F' });
					flag = this.AttachProcess(Convert.ToUInt32(strArrays[0], 16));
					break;
				}
				while (dialogResult == DialogResult.Retry);
				if (attachDialog != null)
				{
					attachDialog.Dispose();
				}
				flag1 = flag;
			}
			catch (Exception exception1)
			{
				Exception exception = exception1;
				if (attachDialog != null)
				{
					attachDialog.Dispose();
					attachDialog = null;
				}
				throw new Exception(exception.Message, exception);
			}
			return flag1;
		}

		public bool ConnectTarget(string ip, int port = 7887)
		{
			bool flag;
			try
			{
				PS3MAPI.PS3MAPI_Client_Server.Connect(ip, port);
				flag = true;
			}
			catch (Exception exception1)
			{
				Exception exception = exception1;
				throw new Exception(exception.Message, exception);
			}
			return flag;
		}

		public bool ConnectTarget()
		{
			bool flag;
			ConnectDialog connectDialog = new ConnectDialog();
			try
			{
				bool flag1 = false;
				if (connectDialog.ShowDialog() == DialogResult.OK)
				{
					flag1 = this.ConnectTarget(connectDialog.txtIp.Text, int.Parse(connectDialog.txtPort.Text));
				}
				if (connectDialog != null)
				{
					connectDialog.Dispose();
					connectDialog = null;
				}
				flag = flag1;
			}
			catch (Exception exception1)
			{
				Exception exception = exception1;
				if (connectDialog != null)
				{
					connectDialog.Dispose();
					connectDialog = null;
				}
				throw new Exception(exception.Message, exception);
			}
			return flag;
		}

		public void DisconnectTarget()
		{
			try
			{
				PS3MAPI.PS3MAPI_Client_Server.Disconnect();
			}
			catch
			{
			}
		}

		public string GetLibVersion_Str()
		{
			string str = this.PS3M_API_PC_LIB_VERSION.ToString("X4");
			string str1 = string.Concat(str.Substring(1, 1), ".");
			string str2 = string.Concat(str.Substring(2, 1), ".");
			string str3 = str.Substring(3, 1);
			return string.Concat(str1, str2, str3);
		}

		public void ShowLog()
		{
			if (this.LogDialog == null)
			{
                this.LogDialog = new PS3Lib.LogDialog(this);
			}
			this.LogDialog.Show();
		}

		public class CORE_CMD
		{
			public CORE_CMD()
			{
			}

			public uint GetVersion()
			{
				uint num;
				try
				{
					num = PS3MAPI.PS3MAPI_Client_Server.Core_Get_Version();
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
				return num;
			}

			public string GetVersion_Str()
			{
				string str = PS3MAPI.PS3MAPI_Client_Server.Core_Get_Version().ToString("X4");
				string str1 = string.Concat(str.Substring(1, 1), ".");
				string str2 = string.Concat(str.Substring(2, 1), ".");
				string str3 = str.Substring(3, 1);
				return string.Concat(str1, str2, str3);
			}
		}

		public class PROCESS_CMD
		{
			public PS3MAPI.PROCESS_CMD.MEMORY_CMD Memory;

			public PS3MAPI.PROCESS_CMD.MODULES_CMD Modules;

			public uint Process_Pid
			{
				get
				{
					return PS3MAPI.PS3MAPI_Client_Server.Process_Pid;
				}
				set
				{
					PS3MAPI.PS3MAPI_Client_Server.Process_Pid = value;
				}
			}

			public uint[] Processes_Pid
			{
				get
				{
					return PS3MAPI.PS3MAPI_Client_Server.Processes_Pid;
				}
			}

			public PROCESS_CMD()
			{
				this.Memory = new PS3MAPI.PROCESS_CMD.MEMORY_CMD();
				this.Modules = new PS3MAPI.PROCESS_CMD.MODULES_CMD();
			}

			public string GetName(uint pid)
			{
				string str;
				try
				{
					str = PS3MAPI.PS3MAPI_Client_Server.Process_GetName(pid);
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
				return str;
			}

			public uint[] GetPidProcesses()
			{
				uint[] numArray;
				try
				{
					numArray = PS3MAPI.PS3MAPI_Client_Server.Process_GetPidList();
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
				return numArray;
			}

			public class MEMORY_CMD
			{
				public MEMORY_CMD()
				{
				}

				public void Get(uint Pid, ulong Address, byte[] Bytes)
				{
					try
					{
						PS3MAPI.PS3MAPI_Client_Server.Memory_Get(Pid, Address, Bytes);
					}
					catch (Exception exception1)
					{
						Exception exception = exception1;
						throw new Exception(exception.Message, exception);
					}
				}
                //
				public byte[] Get(uint Pid, ulong Address, uint Length)
				{
						byte[] numArray;
						try
						{
							byte[] numArray1 = new byte[Length];
							PS3MAPI.PS3MAPI_Client_Server.Memory_Get(Pid, Address, numArray1);
							numArray = numArray1;
						}
						catch (Exception exception1)
						{
							Exception exception = exception1;
							throw new Exception(exception.Message, exception);
						}
						return numArray;
					
				}

				public void Set(uint Pid, ulong Address, byte[] Bytes)
				{
					try
					{
						PS3MAPI.PS3MAPI_Client_Server.Memory_Set(Pid, Address, Bytes);
					}
					catch (Exception exception1)
					{
						Exception exception = exception1;
						throw new Exception(exception.Message, exception);
					}
				}
			}

			public class MODULES_CMD
			{
				public int[] Modules_Prx_Id
				{
					get
					{
						return PS3MAPI.PS3MAPI_Client_Server.Modules_Prx_Id;
					}
				}

				public MODULES_CMD()
				{
				}

				public string GetFilename(uint pid, int prxid)
				{
					string str;
					try
					{
						str = PS3MAPI.PS3MAPI_Client_Server.Module_GetFilename(pid, prxid);
					}
					catch (Exception exception1)
					{
						Exception exception = exception1;
						throw new Exception(exception.Message, exception);
					}
					return str;
				}

				public string GetName(uint pid, int prxid)
				{
					string str;
					try
					{
						str = PS3MAPI.PS3MAPI_Client_Server.Module_GetName(pid, prxid);
					}
					catch (Exception exception1)
					{
						Exception exception = exception1;
						throw new Exception(exception.Message, exception);
					}
					return str;
				}

				public int[] GetPrxIdModules(uint pid)
				{
					int[] numArray;
					try
					{
						numArray = PS3MAPI.PS3MAPI_Client_Server.Module_GetPrxIdList(pid);
					}
					catch (Exception exception1)
					{
						Exception exception = exception1;
						throw new Exception(exception.Message, exception);
					}
					return numArray;
				}

				public void Load(uint pid, string path)
				{
					try
					{
						PS3MAPI.PS3MAPI_Client_Server.Module_Load(pid, path);
					}
					catch (Exception exception1)
					{
						Exception exception = exception1;
						throw new Exception(exception.Message, exception);
					}
				}

				public void Unload(uint pid, int prxid)
				{
					try
					{
						PS3MAPI.PS3MAPI_Client_Server.Module_Unload(pid, prxid);
					}
					catch (Exception exception1)
					{
						Exception exception = exception1;
						throw new Exception(exception.Message, exception);
					}
				}
			}
		}

		public class PS3_CMD
		{
			public PS3_CMD()
			{
			}

			public bool CheckSyscall(int num)
			{
				bool flag;
				try
				{
					flag = PS3MAPI.PS3MAPI_Client_Server.PS3_CheckSyscall(num);
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
				return flag;
			}

			public void ClearHistory(bool include_directory = true)
			{
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.PS3_ClearHistory(include_directory);
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

			public void DisableSyscall(int num)
			{
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.PS3_DisableSyscall(num);
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

			public string GetFirmwareType()
			{
				string str;
				try
				{
					str = PS3MAPI.PS3MAPI_Client_Server.PS3_GetFirmwareType();
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
				return str;
			}

			public uint GetFirmwareVersion()
			{
				uint num;
				try
				{
					num = PS3MAPI.PS3MAPI_Client_Server.PS3_GetFwVersion();
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
				return num;
			}

			public string GetFirmwareVersion_Str()
			{
				string str = PS3MAPI.PS3MAPI_Client_Server.PS3_GetFwVersion().ToString("X4");
				string str1 = string.Concat(str.Substring(1, 1), ".");
				string str2 = str.Substring(2, 1);
				string str3 = str.Substring(3, 1);
				return string.Concat(str1, str2, str3);
			}

			public string GetIDPS()
			{
				string str;
				try
				{
					str = PS3MAPI.PS3MAPI_Client_Server.PS3_GetIDPS();
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
				return str;
			}

			public string GetPSID()
			{
				string str;
				try
				{
					str = PS3MAPI.PS3MAPI_Client_Server.PS3_GetPSID();
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
				return str;
			}

			public void GetTemperature(out uint cpu, out uint rsx)
			{
				cpu = 0;
				rsx = 0;
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.PS3_GetTemp(out cpu, out rsx);
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

			public void Led(PS3MAPI.PS3_CMD.LedColor color, PS3MAPI.PS3_CMD.LedMode mode)
			{
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.PS3_Led(Convert.ToInt32(color), Convert.ToInt32(mode));
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

			public void Notify(string msg)
			{
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.PS3_Notify(msg);
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

			public PS3MAPI.PS3_CMD.Syscall8Mode PartialCheckSyscall8()
			{
				PS3MAPI.PS3_CMD.Syscall8Mode syscall8Mode;
				try
				{
					if (PS3MAPI.PS3MAPI_Client_Server.PS3_PartialCheckSyscall8() == 0)
					{
						syscall8Mode = PS3MAPI.PS3_CMD.Syscall8Mode.Enabled;
					}
					else if (PS3MAPI.PS3MAPI_Client_Server.PS3_PartialCheckSyscall8() != 1)
					{
						syscall8Mode = (PS3MAPI.PS3MAPI_Client_Server.PS3_PartialCheckSyscall8() != 2 ? PS3MAPI.PS3_CMD.Syscall8Mode.FakeDisabled : PS3MAPI.PS3_CMD.Syscall8Mode.Only_PS3MAPI_Enabled);
					}
					else
					{
						syscall8Mode = PS3MAPI.PS3_CMD.Syscall8Mode.Only_CobraMambaAndPS3MAPI_Enabled;
					}
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
				return syscall8Mode;
			}

			public void PartialDisableSyscall8(PS3MAPI.PS3_CMD.Syscall8Mode mode)
			{
				try
				{
					if (mode == PS3MAPI.PS3_CMD.Syscall8Mode.Enabled)
					{
						PS3MAPI.PS3MAPI_Client_Server.PS3_PartialDisableSyscall8(0);
					}
					else if (mode == PS3MAPI.PS3_CMD.Syscall8Mode.Only_CobraMambaAndPS3MAPI_Enabled)
					{
						PS3MAPI.PS3MAPI_Client_Server.PS3_PartialDisableSyscall8(1);
					}
					else if (mode == PS3MAPI.PS3_CMD.Syscall8Mode.Only_PS3MAPI_Enabled)
					{
						PS3MAPI.PS3MAPI_Client_Server.PS3_PartialDisableSyscall8(2);
					}
					else if (mode == PS3MAPI.PS3_CMD.Syscall8Mode.FakeDisabled)
					{
						PS3MAPI.PS3MAPI_Client_Server.PS3_PartialDisableSyscall8(3);
					}
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

			public void Power(PS3MAPI.PS3_CMD.PowerFlags flag)
			{
				try
				{
					if (flag == PS3MAPI.PS3_CMD.PowerFlags.ShutDown)
					{
						PS3MAPI.PS3MAPI_Client_Server.PS3_Shutdown();
					}
					else if (flag == PS3MAPI.PS3_CMD.PowerFlags.QuickReboot)
					{
						PS3MAPI.PS3MAPI_Client_Server.PS3_Reboot();
					}
					else if (flag == PS3MAPI.PS3_CMD.PowerFlags.SoftReboot)
					{
						PS3MAPI.PS3MAPI_Client_Server.PS3_SoftReboot();
					}
					else if (flag == PS3MAPI.PS3_CMD.PowerFlags.HardReboot)
					{
						PS3MAPI.PS3MAPI_Client_Server.PS3_HardReboot();
					}
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

			public void RemoveHook()
			{
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.PS3_RemoveHook();
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

			public void RingBuzzer(PS3MAPI.PS3_CMD.BuzzerMode mode)
			{
				try
				{
					if (mode == PS3MAPI.PS3_CMD.BuzzerMode.Single)
					{
						PS3MAPI.PS3MAPI_Client_Server.PS3_Buzzer(1);
					}
					else if (mode == PS3MAPI.PS3_CMD.BuzzerMode.Double)
					{
						PS3MAPI.PS3MAPI_Client_Server.PS3_Buzzer(2);
					}
					else if (mode == PS3MAPI.PS3_CMD.BuzzerMode.Triple)
					{
						PS3MAPI.PS3MAPI_Client_Server.PS3_Buzzer(3);
					}
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

			public void SetIDPS(string IDPS)
			{
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.PS3_SetIDPS(IDPS);
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

			public void SetPSID(string PSID)
			{
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.PS3_SetPSID(PSID);
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

			public enum BuzzerMode
			{
				Single,
				Double,
				Triple
			}

			public enum LedColor
			{
				Red,
				Green,
				Yellow
			}

			public enum LedMode
			{
				Off,
				On,
				BlinkFast,
				BlinkSlow
			}

			public enum PowerFlags
			{
				ShutDown,
				QuickReboot,
				SoftReboot,
				HardReboot
			}

			public enum Syscall8Mode
			{
				Enabled,
				Only_CobraMambaAndPS3MAPI_Enabled,
				Only_PS3MAPI_Enabled,
				FakeDisabled,
				Disabled
			}
		}

		public class PS3MAPI_Client_Server
		{
			private static int ps3m_api_server_minversion;

			private static PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode eResponseCode;

			private static string sResponse;

			private static string sMessages;

			private static string sServerIP;

			private static int iPort;

			private static string sBucket;

			private static int iTimeout;

			private static uint iPid;

			private static uint[] iprocesses_pid;

			private static int[] imodules_prx_id;

			private static string sLog;

			public static Socket main_sock;

			public static Socket listening_sock;

			public static Socket data_sock;

			public static IPEndPoint main_ipEndPoint;

			public static IPEndPoint data_ipEndPoint;

			public static bool IsAttached
			{
				get
				{
					if (PS3MAPI.PS3MAPI_Client_Server.iPid == 0)
					{
						return false;
					}
					return true;
				}
			}

			public static bool IsConnected
			{
				get
				{
					if (PS3MAPI.PS3MAPI_Client_Server.main_sock == null)
					{
						return false;
					}
					return PS3MAPI.PS3MAPI_Client_Server.main_sock.Connected;
				}
			}

			public static string Log
			{
				get
				{
					return PS3MAPI.PS3MAPI_Client_Server.sLog;
				}
			}

			public static int[] Modules_Prx_Id
			{
				get
				{
					return PS3MAPI.PS3MAPI_Client_Server.imodules_prx_id;
				}
			}

			public static uint Process_Pid
			{
				get
				{
					return PS3MAPI.PS3MAPI_Client_Server.iPid;
				}
				set
				{
					PS3MAPI.PS3MAPI_Client_Server.iPid = value;
				}
			}

			public static uint[] Processes_Pid
			{
				get
				{
					return PS3MAPI.PS3MAPI_Client_Server.iprocesses_pid;
				}
			}

			public static int Timeout
			{
				get
				{
					return PS3MAPI.PS3MAPI_Client_Server.iTimeout;
				}
				set
				{
					PS3MAPI.PS3MAPI_Client_Server.iTimeout = value;
				}
			}

			static PS3MAPI_Client_Server()
			{
				PS3MAPI.PS3MAPI_Client_Server.ps3m_api_server_minversion = 288;
				PS3MAPI.PS3MAPI_Client_Server.sMessages = "";
				PS3MAPI.PS3MAPI_Client_Server.sServerIP = "";
				PS3MAPI.PS3MAPI_Client_Server.iPort = 7887;
				PS3MAPI.PS3MAPI_Client_Server.sBucket = "";
				PS3MAPI.PS3MAPI_Client_Server.iTimeout = 5000;
				PS3MAPI.PS3MAPI_Client_Server.iPid = 0;
				PS3MAPI.PS3MAPI_Client_Server.iprocesses_pid = new uint[16];
				PS3MAPI.PS3MAPI_Client_Server.imodules_prx_id = new int[64];
				PS3MAPI.PS3MAPI_Client_Server.sLog = "";
			}

			public PS3MAPI_Client_Server()
			{
			}

			public static void CloseDataSocket()
			{
				if (PS3MAPI.PS3MAPI_Client_Server.data_sock != null)
				{
					if (PS3MAPI.PS3MAPI_Client_Server.data_sock.Connected)
					{
						PS3MAPI.PS3MAPI_Client_Server.data_sock.Close();
					}
					PS3MAPI.PS3MAPI_Client_Server.data_sock = null;
				}
				PS3MAPI.PS3MAPI_Client_Server.data_ipEndPoint = null;
			}

			public static void Connect()
			{
				PS3MAPI.PS3MAPI_Client_Server.Connect(PS3MAPI.PS3MAPI_Client_Server.sServerIP, PS3MAPI.PS3MAPI_Client_Server.iPort);
			}

			public static void Connect(string sServer, int Port)
			{
				PS3MAPI.PS3MAPI_Client_Server.sServerIP = sServer;
				PS3MAPI.PS3MAPI_Client_Server.iPort = Port;
				if (Port.ToString().Length == 0)
				{
					throw new Exception("Unable to Connect - No Port Specified.");
				}
				if (PS3MAPI.PS3MAPI_Client_Server.sServerIP.Length == 0)
				{
					throw new Exception("Unable to Connect - No Server Specified.");
				}
				if (PS3MAPI.PS3MAPI_Client_Server.main_sock != null && PS3MAPI.PS3MAPI_Client_Server.main_sock.Connected)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.main_sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
				PS3MAPI.PS3MAPI_Client_Server.main_ipEndPoint = new IPEndPoint(Dns.GetHostByName(PS3MAPI.PS3MAPI_Client_Server.sServerIP).AddressList[0], Port);
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.main_sock.Connect(PS3MAPI.PS3MAPI_Client_Server.main_ipEndPoint);
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
				PS3MAPI.PS3MAPI_Client_Server.ReadResponse();
				if (PS3MAPI.PS3MAPI_Client_Server.eResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.PS3MAPIConnected)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				PS3MAPI.PS3MAPI_Client_Server.ReadResponse();
				if (PS3MAPI.PS3MAPI_Client_Server.eResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.PS3MAPIConnectedOK)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				if (PS3MAPI.PS3MAPI_Client_Server.Server_GetMinVersion() < (long)PS3MAPI.PS3MAPI_Client_Server.ps3m_api_server_minversion)
				{
					PS3MAPI.PS3MAPI_Client_Server.Disconnect();
					throw new Exception("PS3M_API SERVER (webMAN-MOD) OUTDATED! PLEASE UPDATE.");
				}
				if (PS3MAPI.PS3MAPI_Client_Server.Server_GetMinVersion() > (long)PS3MAPI.PS3MAPI_Client_Server.ps3m_api_server_minversion)
				{
					PS3MAPI.PS3MAPI_Client_Server.Disconnect();
					throw new Exception("PS3M_API PC_LIB (PS3ManagerAPI.dll) OUTDATED! PLEASE UPDATE.");
				}
			}

			public static void ConnectDataSocket()
			{
				if (PS3MAPI.PS3MAPI_Client_Server.data_sock != null)
				{
					return;
				}
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.data_sock = PS3MAPI.PS3MAPI_Client_Server.listening_sock.Accept();
					PS3MAPI.PS3MAPI_Client_Server.listening_sock.Close();
					PS3MAPI.PS3MAPI_Client_Server.listening_sock = null;
					if (PS3MAPI.PS3MAPI_Client_Server.data_sock == null)
					{
						throw new Exception(string.Concat("Winsock error: ", Convert.ToString(Marshal.GetLastWin32Error())));
					}
				}
				catch (Exception exception)
				{
					throw new Exception(string.Concat("Failed to connect for data transfer: ", exception.Message));
				}
			}

			public static uint Core_Get_Version()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("CORE GETVERSION");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				return Convert.ToUInt32(PS3MAPI.PS3MAPI_Client_Server.sResponse);
			}

			public static uint Core_GetMinVersion()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("CORE GETMINVERSION");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				return Convert.ToUInt32(PS3MAPI.PS3MAPI_Client_Server.sResponse);
			}

			public static void Disconnect()
			{
				PS3MAPI.PS3MAPI_Client_Server.CloseDataSocket();
				if (PS3MAPI.PS3MAPI_Client_Server.main_sock != null)
				{
					if (PS3MAPI.PS3MAPI_Client_Server.main_sock.Connected)
					{
						PS3MAPI.PS3MAPI_Client_Server.SendCommand("DISCONNECT");
						PS3MAPI.PS3MAPI_Client_Server.iPid = 0;
						PS3MAPI.PS3MAPI_Client_Server.main_sock.Close();
					}
					PS3MAPI.PS3MAPI_Client_Server.main_sock = null;
				}
				PS3MAPI.PS3MAPI_Client_Server.main_ipEndPoint = null;
			}

			public static void Fail()
			{
				PS3MAPI.PS3MAPI_Client_Server.Fail(new Exception(string.Concat("[", PS3MAPI.PS3MAPI_Client_Server.eResponseCode.ToString(), "] ", PS3MAPI.PS3MAPI_Client_Server.sResponse)));
			}

			public static void Fail(Exception e)
			{
				PS3MAPI.PS3MAPI_Client_Server.Disconnect();
				throw e;
			}

			public static void FillBucket()
			{
				byte[] numArray = new byte[512];
				int num = 0;
				while (PS3MAPI.PS3MAPI_Client_Server.main_sock.Available < 1)
				{
					Thread.Sleep(50);
					num += 50;
					if (num <= PS3MAPI.PS3MAPI_Client_Server.Timeout)
					{
						continue;
					}
					PS3MAPI.PS3MAPI_Client_Server.Fail(new Exception("Timed out waiting on server to respond."));
				}
				while (PS3MAPI.PS3MAPI_Client_Server.main_sock.Available > 0)
				{
					long num1 = (long)PS3MAPI.PS3MAPI_Client_Server.main_sock.Receive(numArray, 512, SocketFlags.None);
					PS3MAPI.PS3MAPI_Client_Server.sBucket = string.Concat(PS3MAPI.PS3MAPI_Client_Server.sBucket, Encoding.ASCII.GetString(numArray, 0, (int)num1));
					Thread.Sleep(50);
				}
			}

			public static string GetLineFromBucket()
			{
				int i;
				string str = "";
				for (i = PS3MAPI.PS3MAPI_Client_Server.sBucket.IndexOf('\n'); i < 0; i = PS3MAPI.PS3MAPI_Client_Server.sBucket.IndexOf('\n'))
				{
					PS3MAPI.PS3MAPI_Client_Server.FillBucket();
				}
				str = PS3MAPI.PS3MAPI_Client_Server.sBucket.Substring(0, i);
				PS3MAPI.PS3MAPI_Client_Server.sBucket = PS3MAPI.PS3MAPI_Client_Server.sBucket.Substring(i + 1);
				return str;
			}
            public static  bool usingMem = false;
            public static void Memory_Get(uint Pid, ulong Address, byte[] Bytes)
            {
                if (!usingMem)
                {
                    usingMem = true;
                    if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
                    {
                        throw new Exception("PS3MAPI not connected!");
                    }
                    PS3MAPI.PS3MAPI_Client_Server.SetBinaryMode(true);
                    int length = (int)Bytes.Length;
                    long num = (long)0;
                    long num1 = (long)0;
                    bool flag = false;
                    PS3MAPI.PS3MAPI_Client_Server.OpenDataSocket();
                    string[] strArrays = new string[] { "MEMORY GET ", string.Format("{0}", Pid), " ", string.Format("{0:X16}", Address), " ", string.Format("{0}", (int)Bytes.Length) };
                    PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat(strArrays));
                    PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
                    if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.DataConnectionAlreadyOpen && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.MemoryStatusOK)
                    {
                        throw new Exception(PS3MAPI.PS3MAPI_Client_Server.sResponse);
                    }
                    PS3MAPI.PS3MAPI_Client_Server.ConnectDataSocket();
                    byte[] numArray = new byte[(int)Bytes.Length];
                    while (!flag)
                    {
                        try
                        {
                            num1 = (long)PS3MAPI.PS3MAPI_Client_Server.data_sock.Receive(numArray, length, SocketFlags.None);
                            if (num1 <= (long)0)
                            {
                                flag = true;
                            }
                            else
                            {
                                Buffer.BlockCopy(numArray, 0, Bytes, (int)num, (int)num1);
                                num += num1;
                                if ((int)(num * (long)100 / (long)length) >= 100)
                                {
                                    flag = true;
                                }
                            }
                            if (flag)
                            {
                                PS3MAPI.PS3MAPI_Client_Server.CloseDataSocket();
                                PS3MAPI.PS3MAPI_Client_Server.ReadResponse();
                                PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode1 = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
                                if (pS3MAPIResponseCode1 != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful && pS3MAPIResponseCode1 != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.MemoryActionCompleted)
                                {
                                    throw new Exception(PS3MAPI.PS3MAPI_Client_Server.sResponse);
                                }
                                PS3MAPI.PS3MAPI_Client_Server.SetBinaryMode(false);
                            }
                        }
                        catch (Exception exception1)
                        {
                            Exception exception = exception1;
                            PS3MAPI.PS3MAPI_Client_Server.CloseDataSocket();
                            PS3MAPI.PS3MAPI_Client_Server.ReadResponse();
                            PS3MAPI.PS3MAPI_Client_Server.SetBinaryMode(false);
                            throw exception;
                        }
                    }
                    usingMem = false;
                }
            }

			public static void Memory_Set(uint Pid, ulong Address, byte[] Bytes)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SetBinaryMode(true);
				int length = (int)Bytes.Length;
				long num = (long)0;
				long num1 = (long)0;
				bool flag = false;
				PS3MAPI.PS3MAPI_Client_Server.OpenDataSocket();
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("MEMORY SET ", string.Format("{0}", Pid), " ", string.Format("{0:X16}", Address)));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.DataConnectionAlreadyOpen && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.MemoryStatusOK)
				{
					throw new Exception(PS3MAPI.PS3MAPI_Client_Server.sResponse);
				}
				PS3MAPI.PS3MAPI_Client_Server.ConnectDataSocket();
				while (!flag)
				{
					try
					{
						byte[] numArray = new byte[length - (int)num];
						Buffer.BlockCopy(Bytes, (int)num1, numArray, 0, length - (int)num);
						num1 = (long)PS3MAPI.PS3MAPI_Client_Server.data_sock.Send(numArray, (int)Bytes.Length - (int)num, SocketFlags.None);
						flag = false;
						if (num1 <= (long)0)
						{
							flag = true;
						}
						else
						{
							num += num1;
							if ((int)(num * (long)100 / (long)length) >= 100)
							{
								flag = true;
							}
						}
						if (flag)
						{
							PS3MAPI.PS3MAPI_Client_Server.CloseDataSocket();
							PS3MAPI.PS3MAPI_Client_Server.ReadResponse();
							PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode1 = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
							if (pS3MAPIResponseCode1 != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful && pS3MAPIResponseCode1 != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.MemoryActionCompleted)
							{
								throw new Exception(PS3MAPI.PS3MAPI_Client_Server.sResponse);
							}
							PS3MAPI.PS3MAPI_Client_Server.SetBinaryMode(false);
						}
					}
					catch (Exception exception1)
					{
						Exception exception = exception1;
						PS3MAPI.PS3MAPI_Client_Server.CloseDataSocket();
						PS3MAPI.PS3MAPI_Client_Server.ReadResponse();
						PS3MAPI.PS3MAPI_Client_Server.SetBinaryMode(false);
						throw exception;
					}
				}
			}

			public static string Module_GetFilename(uint pid, int prxid)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("MODULE GETFILENAME ", string.Format("{0}", pid), " ", prxid.ToString()));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				return PS3MAPI.PS3MAPI_Client_Server.sResponse;
			}

			public static string Module_GetName(uint pid, int prxid)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("MODULE GETNAME ", string.Format("{0}", pid), " ", prxid.ToString()));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				return PS3MAPI.PS3MAPI_Client_Server.sResponse;
			}

			public static int[] Module_GetPrxIdList(uint pid)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("MODULE GETALLPRXID ", string.Format("{0}", pid)));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				int num = 0;
				PS3MAPI.PS3MAPI_Client_Server.imodules_prx_id = new int[128];
				string[] strArrays = PS3MAPI.PS3MAPI_Client_Server.sResponse.Split(new char[] { '|' });
				for (int i = 0; i < (int)strArrays.Length; i++)
				{
					string str = strArrays[i];
					if (str.Length != 0 && str != null && str != "" && str != " " && str != "0")
					{
						PS3MAPI.PS3MAPI_Client_Server.imodules_prx_id[num] = Convert.ToInt32(str, 10);
						num++;
					}
				}
				return PS3MAPI.PS3MAPI_Client_Server.imodules_prx_id;
			}

			public static void Module_Load(uint pid, string path)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("MODULE LOAD ", string.Format("{0}", pid), " ", path));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public static void Module_Unload(uint pid, int prx_id)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("MODULE UNLOAD ", string.Format("{0}", pid), " ", prx_id.ToString()));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public static void OpenDataSocket()
			{
				string[] strArrays;
				PS3MAPI.PS3MAPI_Client_Server.Connect();
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PASV");
				if (PS3MAPI.PS3MAPI_Client_Server.eResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.EnteringPassiveMode)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				try
				{
					int num = PS3MAPI.PS3MAPI_Client_Server.sResponse.IndexOf('(') + 1;
					int num1 = PS3MAPI.PS3MAPI_Client_Server.sResponse.IndexOf(')') - num;
					strArrays = PS3MAPI.PS3MAPI_Client_Server.sResponse.Substring(num, num1).Split(new char[] { ',' });
				}
				catch (Exception exception)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail(new Exception(string.Concat("Malformed PASV response: ", PS3MAPI.PS3MAPI_Client_Server.sResponse)));
					throw new Exception(string.Concat("Malformed PASV response: ", PS3MAPI.PS3MAPI_Client_Server.sResponse));
				}
				if ((int)strArrays.Length < 6)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail(new Exception(string.Concat("Malformed PASV response: ", PS3MAPI.PS3MAPI_Client_Server.sResponse)));
				}
				object[] objArray = new object[] { strArrays[0], strArrays[1], strArrays[2], strArrays[3] };
				string.Format("{0}.{1}.{2}.{3}", objArray);
				int num2 = (int.Parse(strArrays[4]) << 8) + int.Parse(strArrays[5]);
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.CloseDataSocket();
					PS3MAPI.PS3MAPI_Client_Server.data_sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
					PS3MAPI.PS3MAPI_Client_Server.data_ipEndPoint = new IPEndPoint(Dns.GetHostByName(PS3MAPI.PS3MAPI_Client_Server.sServerIP).AddressList[0], num2);
					PS3MAPI.PS3MAPI_Client_Server.data_sock.Connect(PS3MAPI.PS3MAPI_Client_Server.data_ipEndPoint);
				}
				catch (Exception exception1)
				{
					throw new Exception(string.Concat("Failed to connect for data transfer: ", exception1.Message));
				}
			}

			public static string Process_GetName(uint pid)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("PROCESS GETNAME ", string.Format("{0}", pid)));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				return PS3MAPI.PS3MAPI_Client_Server.sResponse;
			}

			public static uint[] Process_GetPidList()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PROCESS GETALLPID");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				int num = 0;
				PS3MAPI.PS3MAPI_Client_Server.iprocesses_pid = new uint[16];
				string[] strArrays = PS3MAPI.PS3MAPI_Client_Server.sResponse.Split(new char[] { '|' });
				for (int i = 0; i < (int)strArrays.Length; i++)
				{
					string str = strArrays[i];
					if (str.Length != 0 && str != null && str != "" && str != " " && str != "0")
					{
						PS3MAPI.PS3MAPI_Client_Server.iprocesses_pid[num] = Convert.ToUInt32(str, 10);
						num++;
					}
				}
				return PS3MAPI.PS3MAPI_Client_Server.iprocesses_pid;
			}

			public static void PS3_Buzzer(int mode)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("PS3 BUZZER", mode.ToString()));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public static bool PS3_CheckSyscall(int num)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("PS3 CHECKSYSCALL ", num.ToString()));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				if (Convert.ToInt32(PS3MAPI.PS3MAPI_Client_Server.sResponse) == 0)
				{
					return true;
				}
				return false;
			}

			public static void PS3_ClearHistory(bool include_directory)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				if (!include_directory)
				{
					PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 DELHISTORY");
				}
				else
				{
					PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 DELHISTORY+D");
				}
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public static void PS3_DisableSyscall(int num)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("PS3 DISABLESYSCALL ", num.ToString()));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public static string PS3_GetFirmwareType()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 GETFWTYPE");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				return PS3MAPI.PS3MAPI_Client_Server.sResponse;
			}

			public static uint PS3_GetFwVersion()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 GETFWVERSION");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				return Convert.ToUInt32(PS3MAPI.PS3MAPI_Client_Server.sResponse);
			}

			public static string PS3_GetIDPS()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 GETIDPS");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				return PS3MAPI.PS3MAPI_Client_Server.sResponse;
			}

			public static string PS3_GetPSID()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 GETPSID");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				return PS3MAPI.PS3MAPI_Client_Server.sResponse;
			}

			public static void PS3_GetTemp(out uint cpu, out uint rsx)
			{
				cpu = 0;
				rsx = 0;
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 GETTEMP");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				string[] strArrays = PS3MAPI.PS3MAPI_Client_Server.sResponse.Split(new char[] { '|' });
				cpu = Convert.ToUInt32(strArrays[0], 10);
				rsx = Convert.ToUInt32(strArrays[1], 10);
			}

			public static void PS3_HardReboot()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 HARDREBOOT");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Disconnect();
			}

			public static void PS3_Led(int color, int mode)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("PS3 LED ", color.ToString(), " ", mode.ToString()));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public static void PS3_Notify(string msg)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("PS3 NOTIFY  ", msg));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public static int PS3_PartialCheckSyscall8()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 PCHECKSYSCALL8");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				return Convert.ToInt32(PS3MAPI.PS3MAPI_Client_Server.sResponse);
			}

			public static void PS3_PartialDisableSyscall8(int mode)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("PS3 PDISABLESYSCALL8 ", mode.ToString()));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public static void PS3_Reboot()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 REBOOT");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Disconnect();
			}

			public static void PS3_RemoveHook()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 REMOVEHOOK");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public static void PS3_SetIDPS(string IDPS)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("PS3 SETIDPS ", IDPS.Substring(0, 16), " ", IDPS.Substring(16, 16)));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public static void PS3_SetPSID(string PSID)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("PS3 SETPSID ", PSID.Substring(0, 16), " ", PSID.Substring(16, 16)));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public static void PS3_Shutdown()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 SHUTDOWN");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Disconnect();
			}

			public static void PS3_SoftReboot()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("PS3 SOFTREBOOT");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Disconnect();
			}

			public static void ReadResponse()
			{
				string lineFromBucket;
				PS3MAPI.PS3MAPI_Client_Server.sMessages = "";
				while (true)
				{
					lineFromBucket = PS3MAPI.PS3MAPI_Client_Server.GetLineFromBucket();
					if (Regex.Match(lineFromBucket, "^[0-9]+ ").Success)
					{
						break;
					}
					PS3MAPI.PS3MAPI_Client_Server.sMessages = string.Concat(PS3MAPI.PS3MAPI_Client_Server.sMessages, Regex.Replace(lineFromBucket, "^[0-9]+-", ""), "\n");
				}
				PS3MAPI.PS3MAPI_Client_Server.sResponse = lineFromBucket.Substring(4).Replace("\r", "").Replace("\n", "");
				PS3MAPI.PS3MAPI_Client_Server.eResponseCode = (PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode)int.Parse(lineFromBucket.Substring(0, 3));
				PS3MAPI.PS3MAPI_Client_Server.sLog = string.Concat(PS3MAPI.PS3MAPI_Client_Server.sLog, "RESPONSE CODE: ", PS3MAPI.PS3MAPI_Client_Server.eResponseCode.ToString(), Environment.NewLine);
				string[] newLine = new string[] { PS3MAPI.PS3MAPI_Client_Server.sLog, "RESPONSE MSG: ", PS3MAPI.PS3MAPI_Client_Server.sResponse, Environment.NewLine, Environment.NewLine };
				PS3MAPI.PS3MAPI_Client_Server.sLog = string.Concat(newLine);
			}

			public static void SendCommand(string sCommand)
			{
				PS3MAPI.PS3MAPI_Client_Server.sLog = string.Concat(PS3MAPI.PS3MAPI_Client_Server.sLog, "COMMAND: ", sCommand, Environment.NewLine);
				PS3MAPI.PS3MAPI_Client_Server.Connect();
				byte[] bytes = Encoding.ASCII.GetBytes(string.Concat(sCommand, "\r\n").ToCharArray());
				PS3MAPI.PS3MAPI_Client_Server.main_sock.Send(bytes, (int)bytes.Length, SocketFlags.None);
				PS3MAPI.PS3MAPI_Client_Server.ReadResponse();
			}

			public static uint Server_Get_Version()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("SERVER GETVERSION");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				return Convert.ToUInt32(PS3MAPI.PS3MAPI_Client_Server.sResponse);
			}

			public static uint Server_GetMinVersion()
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand("SERVER GETMINVERSION");
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				return Convert.ToUInt32(PS3MAPI.PS3MAPI_Client_Server.sResponse);
			}

			public static void SetBinaryMode(bool bMode)
			{
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("TYPE", (bMode ? " I" : " A")));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
			}

			public static void VSHPlugins_GetInfoBySlot(uint slot, out string name, out string path)
			{
				name = "";
				path = "";
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("MODULE GETVSHPLUGINFO ", string.Format("{0}", slot)));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK && pS3MAPIResponseCode != PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					PS3MAPI.PS3MAPI_Client_Server.Fail();
				}
				string[] strArrays = PS3MAPI.PS3MAPI_Client_Server.sResponse.Split(new char[] { '|' });
				name = strArrays[0];
				path = strArrays[1];
			}

			public static void VSHPlugins_Load(uint slot, string path)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("MODULE LOADVSHPLUG ", string.Format("{0}", slot), " ", path));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public static void VSHPlugins_Unload(uint slot)
			{
				if (!PS3MAPI.PS3MAPI_Client_Server.IsConnected)
				{
					throw new Exception("PS3MAPI not connected!");
				}
				PS3MAPI.PS3MAPI_Client_Server.SendCommand(string.Concat("MODULE UNLOADVSHPLUGS ", string.Format("{0}", slot)));
				PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode pS3MAPIResponseCode = PS3MAPI.PS3MAPI_Client_Server.eResponseCode;
				if (pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.CommandOK || pS3MAPIResponseCode == PS3MAPI.PS3MAPI_Client_Server.PS3MAPI_ResponseCode.RequestSuccessful)
				{
					return;
				}
				PS3MAPI.PS3MAPI_Client_Server.Fail();
			}

			public enum PS3MAPI_ResponseCode
			{
				DataConnectionAlreadyOpen = 125,
				MemoryStatusOK = 150,
				CommandOK = 200,
				PS3MAPIConnected = 220,
				RequestSuccessful = 226,
				EnteringPassiveMode = 227,
				PS3MAPIConnectedOK = 230,
				MemoryActionCompleted = 250,
				MemoryActionPended = 350
			}
		}

		public class PS3MAPI_Client_Web
		{
			public PS3MAPI_Client_Web()
			{
			}
		}

		public class SERVER_CMD
		{
			public int Timeout
			{
				get
				{
					return PS3MAPI.PS3MAPI_Client_Server.Timeout;
				}
				set
				{
					PS3MAPI.PS3MAPI_Client_Server.Timeout = value;
				}
			}

			public SERVER_CMD()
			{
			}

			public uint GetVersion()
			{
				uint num;
				try
				{
					num = PS3MAPI.PS3MAPI_Client_Server.Server_Get_Version();
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
				return num;
			}

			public string GetVersion_Str()
			{
				string str = PS3MAPI.PS3MAPI_Client_Server.Server_Get_Version().ToString("X4");
				string str1 = string.Concat(str.Substring(1, 1), ".");
				string str2 = string.Concat(str.Substring(2, 1), ".");
				string str3 = str.Substring(3, 1);
				return string.Concat(str1, str2, str3);
			}
		}

		public class VSH_PLUGINS_CMD
		{
			public VSH_PLUGINS_CMD()
			{
			}

			public void GetInfoBySlot(uint slot, out string name, out string path)
			{
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.VSHPlugins_GetInfoBySlot(slot, out name, out path);
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

			public void Load(uint slot, string path)
			{
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.VSHPlugins_Load(slot, path);
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}

            public void Unload(uint slot)
			{
				try
				{
					PS3MAPI.PS3MAPI_Client_Server.VSHPlugins_Unload(slot);
				}
				catch (Exception exception1)
				{
					Exception exception = exception1;
					throw new Exception(exception.Message, exception);
				}
			}
		}
	}
}