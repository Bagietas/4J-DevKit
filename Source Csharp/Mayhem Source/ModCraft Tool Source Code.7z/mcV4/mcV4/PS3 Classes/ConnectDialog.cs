using System;
using System.ComponentModel;
using System.Drawing;
using System.Resources;
using System.Windows.Forms;

namespace PS3Lib
{
	public class ConnectDialog : Form
	{
		private IContainer components;

		private Label label1;

		private Button btnOK;

		private Button btnCancel;

		protected internal TextBox txtIp;

		protected internal TextBox txtPort;

		private Label label2;

		public ConnectDialog()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(ConnectDialog));
			this.label1 = new Label();
			this.txtIp = new TextBox();
			this.btnOK = new Button();
			this.btnCancel = new Button();
			this.txtPort = new TextBox();
			this.label2 = new Label();
			base.SuspendLayout();
			this.label1.AutoSize = true;
			this.label1.Location = new Point(16, 26);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(23, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "IP: ";
			this.txtIp.Location = new Point(45, 23);
			this.txtIp.MaxLength = 16;
			this.txtIp.Name = "txtIp";
			this.txtIp.Size = new System.Drawing.Size(116, 20);
			this.txtIp.TabIndex = 1;
			this.txtIp.Text = "127.0.0.1";
			this.txtIp.TextAlign = HorizontalAlignment.Center;
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.Location = new Point(118, 58);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(75, 21);
			this.btnOK.TabIndex = 2;
			this.btnOK.Text = "Connect";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new Point(203, 58);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(75, 21);
			this.btnCancel.TabIndex = 3;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.txtPort.Enabled = false;
			this.txtPort.Location = new Point(223, 23);
			this.txtPort.MaxLength = 5;
			this.txtPort.Name = "txtPort";
			this.txtPort.Size = new System.Drawing.Size(55, 20);
			this.txtPort.TabIndex = 5;
			this.txtPort.Text = "7887";
			this.txtPort.TextAlign = HorizontalAlignment.Center;
			this.label2.AutoSize = true;
			this.label2.Location = new Point(174, 26);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(43, 13);
			this.label2.TabIndex = 4;
			this.label2.Text = "PORT: ";
			base.AcceptButton = this.btnOK;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.CancelButton = this.btnCancel;
			base.ClientSize = new System.Drawing.Size(292, 85);
			base.ControlBox = false;
			base.Controls.Add(this.txtPort);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.btnCancel);
			base.Controls.Add(this.btnOK);
			base.Controls.Add(this.txtIp);
			base.Controls.Add(this.label1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.Icon = (System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "ConnectDialog";
			base.StartPosition = FormStartPosition.CenterParent;
			this.Text = "Connection with PS3 Manager API";
			base.ResumeLayout(false);
			base.PerformLayout();
		}
	}
}