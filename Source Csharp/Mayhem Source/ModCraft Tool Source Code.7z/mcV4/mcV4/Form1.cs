﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;
using PS3Lib;
using System.Net;
using System.IO;
using System.Security.Cryptography;
using System.Diagnostics;
using System.Xml;
using System.Security.Principal;
using System.Management;
using System.Text.RegularExpressions;
using System.Drawing.Drawing2D;
using System.Management.Instrumentation;
using System.Drawing.Imaging;
using mcConnect;
using System.Reflection;

namespace mcV4
{
    public partial class Form1 : Form
    {
        #region form load close
        public Form1()
        {
            //const string appName = "mcV4";
            //bool createdNew;
            //mutex = new Mutex(true, appName, out createdNew);
            //if (!createdNew)
            //    Environment.Exit(0);

            InitializeComponent();

            //llllllllllllllll();
            //new Thread(() => Protections.iiiiiii()) { IsBackground = true }.Start();
            //try
            //{
            //    ServicePointManager.Expect100Continue = true;
            //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            //}
            //catch (Exception)
            //{
            //    MessageBox.Show("Error Code: 3", Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    Environment.Exit(0);
            //}
        }
        private Button btnAdd = new Button();
        ToolStripMenuItem[] tsMenuItems = new ToolStripMenuItem[100];
        private void Form1_Load(object sender, EventArgs e)
        {
            saveInfoLoad();
            runTheme(saveThemeColor, saveTextColor, saveBackColor);
            #region set
            Size = new Size(563, 436);
            mainPanels = new Panel[] { connectionPanel, gameManagerPanel, settingsPanel, modMenuPanel };
            mainBtns = new Button[] { connectionBtn, gameManagerBtn, settingsBtn, modMenuBtn };
            GMpanels = new Panel[] { autoBuildStructurePanel, hostOptsPanel, btnBindsPanel, posPanel, itemPanel };
            GMbtns = new Button[] { btnM1, btnM2, btnM3, btnM4, btnM5 };
            connectionPanel.Size = new Size(563, 287);
            connectionPanel.Location = new Point(0, 68);
            gameManagerPanel.Location = new Point(0, 68);
            gameManagerPanel.Size = new Size(563, 356);
            settingsPanel.Location = new Point(0, 68);
            settingsPanel.Size = new Size(434, 305);
            modMenuPanel.Location = new Point(0, 68);
            modMenuPanel.Size = new Size(160, 242);

            hostOptsPanel.Location = new Point(0, 35);
            hostOptsPanel.Size = new Size(332, 251);

            autoBuildStructurePanel.Location = new Point(0, 35);
            autoBuildStructurePanel.Size = new Size(321, 154);

            btnBindsPanel.Location = new Point(0, 35);
            btnBindsPanel.Size = new Size(303, 287);

            posPanel.Location = new Point(0, 35);
            posPanel.Size = new Size(563, 307);

            itemPanel.Location = new Point(0, 35);
            itemPanel.Size = new Size(496, 312);
            curSlot.Text = "";
            toolStripComboBox5.SelectedIndex = 0;

            setupTS();
            // string[] bindBlackList = new string[] { "HUD Color", "Aimbot Command", "Entity Filter", "Entity Radius", "Aim Key", "Aim Reset Key", "Aim Position", "Auto Hit Proximity", "Target Info", "Target Locator", "Radar", "Compass Pointer", "Depth Indicator", "Compass Radius", "Self Info" };

            //for (int i = 0; i < sycx2ae5ous3hhx86e2ir.Count; i++)
            //{
            //    if (sycx2ae5ous3hhx86e2ir[i][0] == 1)
            //    {
            //        for (int x = 0; x < sycx2ae5ous3hhx86e2ir[i][3]; x++)
            //        {
            //            int index = menuOptStartIndex[i] + x;
            //            if (menuOptState[index] == "multiOpt" || menuOptState[index] == "checkBox")
            //            {
            //                menuOptTxt[index] = menuOptTxt[index].Replace("     ", "");
            //                string[] check = bindBlackList.Where(a => a.Contains(menuOptTxt[index])).ToArray();
            //                if (check.Length == 0)
            //                {
            //                    bindNonHostStr.Add(menuOptTxt[index]);
            //                    bindNonHostStrState.Add(menuOptState[index]);
            //                }
            //            }
            //        }
            //    }
            //    else if (sycx2ae5ous3hhx86e2ir[i][0] == 2)
            //    {
            //        for (int x = 0; x < sycx2ae5ous3hhx86e2ir[i][3]; x++)
            //        {
            //            int index = menuOptStartIndex[i] + x;
            //            if (menuOptState[index] == "multiOpt" || menuOptState[index] == "checkBox")
            //            {
            //                menuOptTxt[index] = menuOptTxt[index].Replace("     ", "");
            //                bindHostStr.Add(menuOptTxt[index]);
            //                bindHostStrState.Add(menuOptState[index]);
            //            }
            //        }
            //    }
            //}

            #endregion
            timer3.Start();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            saveInfoClose();
        }
        #endregion

        #region form controls

        #region TS controls
        private void TS_MenuItem0_Closing(object sender, ToolStripDropDownClosingEventArgs e)
        {
            if (e.CloseReason == ToolStripDropDownCloseReason.ItemClicked)
            {
                e.Cancel = true;
            }
        }
        private void TS_MenuItem_Closing(object sender, ToolStripDropDownClosingEventArgs e)
        {
            if (e.CloseReason == ToolStripDropDownCloseReason.ItemClicked)
            {
                e.Cancel = true;
            }
        }
        private void TS_Item_Click(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                for (int i = 0; i < TS_Item.Length; i++)
                {
                    if (!Object.ReferenceEquals(TS_Item[i], null))
                    {
                        if (TS_Item[i].Selected && TS_Item[i].Name == "checkBox")
                        {
                            try
                            {
                                LabelMenuItem label = new LabelMenuItem();
                                label.ForeColor = textColorCM;
                                label.BackColor = backgroundColorCM;
                                label.Text = TS_Item[i].Text;
                                selectedOptionTxt = label.Text;
                                selectedOptionState = func_state[i];
                                contextMenuStrip1.Items.RemoveAt(0);
                                contextMenuStrip1.Items.Insert(0, label);
                                contextMenuStrip1.Show(Cursor.Position);
                            }
                            catch
                            {

                            }
                            break;
                        }
                    }
                }
            }
        }
        private void TS_TrackBar_Click(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                for (int i = 0; i < TS_TrackBar.Length; i++)
                {
                    if (!Object.ReferenceEquals(TS_TrackBar[i], null))
                    {
                        if (selectedTrack == TS_TrackBar[i])
                        {
                            try
                            {
                                string[] split = Regex.Split(TS_Label[i].Text, " : ");

                                LabelMenuItem label = new LabelMenuItem();
                                label.ForeColor = textColorCM;
                                label.BackColor = backgroundColorCM;
                                label.Text = split[0];
                                selectedOptionTxt = label.Text;
                                selectedOptionState = func_state[i];
                                contextMenuStrip1.Items.RemoveAt(0);
                                contextMenuStrip1.Items.Insert(0, label);
                                contextMenuStrip1.Show(Cursor.Position);
                            }
                            catch
                            {

                            }
                            break;
                        }
                    }
                }
            }
        }
        private void TS_ComboBox_Click(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                for (int i = 0; i < TS_ComboBox.Length; i++)
                {
                    if (selectedBox == TS_ComboBox[i])
                    {
                        try
                        {
                            selectedOptionTxt = TS_Label[i].Text;
                            selectedOptionState = func_state[i];
                            contextMenuStrip1.Items.RemoveAt(0);
                            contextMenuStrip1.Items.Insert(0, TS_Label[i]);
                            contextMenuStrip1.Show(Cursor.Position);
                        }
                        catch
                        {

                        }
                        break;
                    }
                }
            }
        }

        string selectedOptionTxt = "";
        string selectedOptionState = "";
        colorCBTS selectedBox;
        TrackBarMenuItem selectedTrack;
        private void TS_ComboBox_MouseHover(object sender, EventArgs e)
        {
            if (sender is colorCBTS)
            {
                colorCBTS item = sender as colorCBTS;
                selectedBox = item;
            }
        }
        private void TS_TrackBar_MouseHover(object sender, EventArgs e)
        {
            if (sender is TrackBarMenuItem)
            {
                TrackBarMenuItem item = sender as TrackBarMenuItem;
                selectedTrack = item;
            }
        }
        #endregion

        #region main form control
        private void listBox3_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                e = new DrawItemEventArgs(e.Graphics,
                                          e.Font,
                                          e.Bounds,
                                          e.Index,
                                          e.State ^ DrawItemState.Selected,
                                          saveTextColor,
                                          saveThemeColor);

            SolidBrush brush = new SolidBrush(saveTextColor);
            e.DrawBackground();
            e.Graphics.DrawString(listBox3.Items[e.Index].ToString(), e.Font, brush, e.Bounds, StringFormat.GenericDefault);
            e.DrawFocusRectangle();
        }
        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            TopMost = checkBox10.Checked;
        }


        private void panel1_MouseEnter(object sender, EventArgs e)
        {
            Point pos = Location;
            pos.Y += panel3.Location.Y + panel3.Size.Height;

            sub1.Show(pos, ToolStripDropDownDirection.Default);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void label2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                newpoint = Control.MousePosition;
                newpoint.X -= x;
                newpoint.Y -= y;
                Location = newpoint;
            }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.Style |= WS_MINIMIZEBOX;
                cp.ClassStyle |= CS_DBLCLKS;
                return cp;
            }
        }

        private void label2_MouseDown(object sender, MouseEventArgs e)
        {
            x = Control.MousePosition.X - Location.X;
            y = Control.MousePosition.Y - Location.Y;

        }

        #endregion

        private class MyRenderer : ToolStripProfessionalRenderer
        {
            protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
            {
                Rectangle rc = new Rectangle(Point.Empty, e.Item.Size);
                Color c = e.Item.Selected ? selectColorCM : backgroundColorCM;
                using (SolidBrush brush = new SolidBrush(c))
                    e.Graphics.FillRectangle(brush, rc);
            }
            protected override void OnRenderItemCheck(ToolStripItemImageRenderEventArgs e)
            {

                Rectangle rc = new Rectangle(new Point(4, 2), new Size(e.Item.Height - 4, e.Item.Height - 4));
                Color c = Color.Black;

                Rectangle rc2 = new Rectangle(new Point(5, 3), new Size(e.Item.Height - 6, e.Item.Height - 6));
                Color c2 = selectColorCM;

                int x = 2, y = 1;
                using (SolidBrush brush = new SolidBrush(c))
                    e.Graphics.FillRectangle(brush, rc);
                using (SolidBrush brush = new SolidBrush(c2))
                    e.Graphics.FillRectangle(brush, rc2);
                e.Graphics.DrawLine(new Pen(Color.White, 2), new Point(6 + x, 10 + y), new Point(10 + x, 14 + y));
                e.Graphics.DrawLine(new Pen(Color.White, 2), new Point(10 + x, 14 + y), new Point(16 + x, 5 + y));
            }
            protected override void OnRenderArrow(ToolStripArrowRenderEventArgs e)
            {
                Rectangle rc1 = new Rectangle(Point.Empty, new Size(2, e.Item.Size.Height));
                Color c1 = textColorCM;

                using (SolidBrush brush = new SolidBrush(c1))
                    e.Graphics.FillRectangle(brush, rc1);

                int middle = e.Item.Height / 2;
                int size = 5;
                e.Graphics.DrawLine(new Pen(saveTextColor, 1), new Point(e.Item.Width - size - 5, middle - 3), new Point(e.Item.Width - size - 2, middle));
                e.Graphics.DrawLine(new Pen(saveTextColor, 1), new Point(e.Item.Width - size - 5, middle + 3), new Point(e.Item.Width - size - 2, middle));
            }
        }
        Panel[] mainPanels;
        Button[] mainBtns;
        #region buttont tabs
        private void sub1_Opened(object sender, EventArgs e)
        {
            panel1.BackColor = ChangeColorBrightness(backgroundColorCM, (float)0.05);
            label1.BackColor = ChangeColorBrightness(backgroundColorCM, (float)0.05);
        }

        private void sub1_Closed(object sender, ToolStripDropDownClosedEventArgs e)
        {
            panel1.BackColor = ChangeColorBrightness(backgroundColorCM, 0);
            label1.BackColor = ChangeColorBrightness(backgroundColorCM, 0);
        }
        private void panelControl(Panel E9ZwEb1b7Zjo5ged5OAEa, Panel[] panels)
        {
            for (int i = 0; i < panels.Length; i++)
            {
                if (E9ZwEb1b7Zjo5ged5OAEa.Name == panels[i].Name)
                {
                    if (!E9ZwEb1b7Zjo5ged5OAEa.Visible)
                    {
                        E9ZwEb1b7Zjo5ged5OAEa.Visible = true;
                    }
                    else
                    {
                        E9ZwEb1b7Zjo5ged5OAEa.Visible = false;
                    }
                }
                else
                    panels[i].Visible = false;
            }
        }

        private void buttonControl(Button button, Button[] buttons)
        {
            for (int i = 0; i < buttons.Length; i++)
            {
                if (button.Name == buttons[i].Name)
                {
                    if (button.FlatAppearance.BorderSize == 0)
                    {
                        button.FlatAppearance.BorderSize = 1;
                    }
                    else
                    {
                        button.FlatAppearance.BorderSize = 0;
                    }
                }
                else
                    buttons[i].FlatAppearance.BorderSize = 0;
            }
        }

        private void settingsBtn_Click(object sender, EventArgs e)
        {
            panelControl(settingsPanel, mainPanels);
            buttonControl(settingsBtn, mainBtns);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panelControl(modMenuPanel, mainPanels);
            buttonControl(modMenuBtn, mainBtns);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panelControl(connectionPanel, mainPanels);
            buttonControl(connectionBtn, mainBtns);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panelControl(gameManagerPanel, mainPanels);
            buttonControl(gameManagerBtn, mainBtns);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            panelControl(autoBuildStructurePanel, GMpanels);
            buttonControl(btnM1, GMbtns);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            panelControl(hostOptsPanel, GMpanels);
            buttonControl(btnM2, GMbtns);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            panelControl(btnBindsPanel, GMpanels);
            buttonControl(btnM3, GMbtns);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            panelControl(posPanel, GMpanels);
            buttonControl(btnM4, GMbtns);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            panelControl(itemPanel, GMpanels);
            buttonControl(btnM5, GMbtns);
        }
        #endregion
        #endregion

        #region vars
        #region tool vars
        private static Mutex mutex = null;
        public static connect conn = new connect();
        public static PS3API PS3 = new PS3API();
        public static PS3MAPI PS3H = new PS3MAPI();
        ToolStripMenuItem[] TS_Item = new ToolStripMenuItem[10000];
        ToolStripSeparator[] TS_Seperator = new ToolStripSeparator[10000];
        ToolStripTextBox[] TS_TextBox = new ToolStripTextBox[10000];
        ToolStripMenuItem[] TS_MenuItem = new ToolStripMenuItem[10000];
        colorCBTS[] TS_ComboBox = new colorCBTS[10000];
        TrackBarMenuItem[] TS_TrackBar = new TrackBarMenuItem[10000];
        LabelMenuItem[] TS_Label = new LabelMenuItem[10000];
        string[] func_state = new string[10000];
        public static string MF_SubMenu = "subMenu;", MF_textOnly = "textOnly;", MF_textBox = "textBox;", MF_Seperator = "seperator;", MF_CheckBox = "checkBox;", MF_Trackbar = "trackBar;", MF_ComboBox = "comboBox;", MF_button = "button;", MF_button2 = "btn;", MF_none = "none;";
        string[][] itemTxt = new string[1000][];
        public static Color selectColorCM = Color.ForestGreen;
        public static Color backgroundColorCM = Color.FromArgb(50, 50, 50);
        public static Color textColorCM = Color.White;
        string[] funcVal = new string[10000];
        bool setOnce = false;
        bool[] getSubMenus = new bool[100];
        bool[] saveLabel = new bool[10000];
        string[] saveL = new string[10000];
        ToolStripItemCollection mainOpts;
        public static int y;
        public static int x;
        public static Point newpoint = new Point();
        const int WS_MINIMIZEBOX = 0x20000;
        const int CS_DBLCLKS = 0x8;
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        Panel[] GMpanels;
        Button[] GMbtns;
        string[] TSbtns = new string[10000];
        public static Color saveThemeColor = Color.FromArgb(70, 70, 245);
        public static Color saveTextColor = Color.FromArgb(200, 200, 200);
        public static Color saveBackColor = Color.FromArgb(40, 40, 40);
        Random rgbR = new Random();
        Color transKey = SystemColors.ControlDarkDark;

        #endregion
        #region game vars
        bool useOP = false;
        bool useUfo = false;
        uint clientPick = 0x6F3;
        uint clientInvul = 0x7F6;
        uint clientXp = 0x700;
        uint clientView = 0xE0;
        uint clientView2 = 0x148;
        uint clientPlus = 0x6F2;
        uint clientOrg = 0x100;
        string name_backup = "";
        bool checkCon = false;
        bool canUseTool = false;
        Random rhudRGB = new Random();
        int[] hudRGB = new int[] { 255, 0, 0 };
        Random rhudRGB_ = new Random();
        int[] hudRGB_ = new int[] { 255, 0, 0 };
        int colorInt = 0;
        ColorDialog rgb = new ColorDialog();
        bool useProgressBar = false;
        int progressVal = 0, progressMax = 0;
        public static int targetIndex = -1;
        public static string ps3IP = "-1";
        public static string ps3Status = "False";
        public static string gameStatus = "False";
        public static string apiStatus = "None";
        public static string accStatus = "Not Logged In";
        public static string targetStatus = "Target Number: N/A";
        public static string ccapiipStatus = "PS3 IP: N/A";
        public static List<CCAPI.ConsoleInfo> cList = Form1.PS3.CCAPI.GetConsoleList();
        public static apiForm apiForm_ = new apiForm();
        public static string labelTxtCT = "";
        public static string textBoxCT = "1";
        public static List<string> listCT = new List<string>();
        public static string curAPI = "";

        #endregion
        #region tool vars
        bool loaded = false;
        public string[] checkArray = { "", "Missing Text!", "Incorrect info!", "You need to buy the tool!", "IP spoofing detected", "This account is assigned to a different computer", "Please try again!", "You have been banned from the tool!" };
        public string[] check;
        public string[] saveText = { "-1", "-1", "0", "False", "192.168.1.1", "70-70-255", "200-200-200", "40-40-40", "False", "False", "N/A", "10-100-170", "255-255-255", "30-30-30" };
        public string app_file = @"C:\Users\" + Environment.UserName + @"\AppData\Roaming\modcraftV4\settings.mcs";
        public string app_folder = @"C:\Users\" + Environment.UserName + @"\AppData\Roaming\modcraftV4";
        public string headC = "b3981ae01cf6d3739af28037daf38416b29ca314";
        public WebClient client = new WebClient();
        string errorCode = "";
        string[] mmx = { };
        string[] mma = { };
        string[] mmb = { };
        string[] mmc = { };
        string[] mmd = { };
        ColorDialog colorDialog1 = new ColorDialog();
        ColorDialog colorDialog2 = new ColorDialog();
        ColorDialog colorDialog3 = new ColorDialog();
        ulti ult = new ulti();
        #endregion

        #endregion

        #region login
        private void loadInfo()
        {
            errorCode = "";
            try
            {
                loaded = true;
                string[] Decrypt_ = connect.con;
                string[] Decrypt = new string[Decrypt_.Length];
                List<string> Str = new List<string>();
                using (var service = new Cryptography(hglsk394gusu92))
                {
                    for (int i = 0; i < Decrypt.Length; i++)
                        Str.Add(service.Decrypt(Decrypt_[i]));
                }
                string hg38565hfdw36 = "";
                string[] decrypt_ = Str.ToArray();
                string[] decrypt = new string[decrypt_.Length];
                string str = "";
                using (var service = new Cryptography(hg38565hfdw36))
                {
                    for (int i = 0; i < decrypt.Length; i++)
                        str += service.Decrypt(decrypt_[i]);
                }
                //not working...
                initialTxt = str;
            }
            catch
            {

            }

            if (initialTxt.StartsWith("jgighagwmvbsq"))
            {
                try
                {
                    initialTxt = initialTxt.Remove(0, 13);
                }
                catch
                {
                    errorCode += "1.2" + "\n";
                }
                try
                {
                    mmx = Regex.Split(initialTxt, "<x>");
                    mma = Regex.Split(mmx[0], "<m1>");
                    mmb = Regex.Split(mmx[1], "<m2>");
                    mmc = Regex.Split(mmx[2], "<m3>");
                    mmd = Regex.Split(mmx[3], "<m4>");

                    ins1.Clear();
                    ins2.Clear();
                    ins3.Clear();
                    ins4.Clear();
                }
                catch
                {
                    errorCode += "1.3" + "\n";
                }
                try
                {
                    for (int i = 0; i < mma.Length; i++)
                        ins1.Add(Convert.ToUInt32(mma[i], 16));

                    for (int i = 0; i < mmb.Length; i++)
                        ins2.Add(Convert.ToDouble(mmb[i]));

                    for (int i = 0; i < mmc.Length; i++)
                        ins3.Add(Convert.ToUInt32(mmc[i], 16));

                    for (int i = 0; i < mmd.Length; i++)
                        ins4.Add(Convert.ToUInt32(mmd[i], 16));

                }
                catch
                {
                    errorCode += "1.4" + "\n";
                }
                if (errorCode != "")
                    MessageBox.Show("Error Code(s):\n" + errorCode, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("Error Code: 2", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        #endregion

        #region save info
        private void saveInfoLoad()
        {
            try
            {
                if (File.Exists(app_file))
                {
                    saveText = File.ReadAllLines(app_file);
                }
                else
                {
                    if (!Directory.Exists(app_folder))
                        Directory.CreateDirectory(app_folder);
                    File.WriteAllLines(app_file, saveText);
                    saveText = File.ReadAllLines(app_file);
                }
                targetIndex = Convert.ToInt32(saveText[0]);
                ps3IP = saveText[1];

                if (targetIndex != -1)
                    targetStatus = "Target Number: " + targetIndex;
                if (ps3IP != "-1")
                    ccapiipStatus = "PS3 IP: " + ps3IP;
                label3.Text = targetStatus + "\n" + ccapiipStatus;

                if (saveText[2] == "1")
                    radioButton1.Checked = true;
                else if (saveText[2] == "2")
                    radioButton2.Checked = true;
                else if (saveText[2] == "3")
                    radioButton3.Checked = true;
                checkBox2.Checked = Convert.ToBoolean(saveText[3]);
                notifyIp = saveText[4];
                textBox3.Text = saveText[4];
                textBox3.Enabled = checkBox2.Checked;
                string[] rgbInt = Regex.Split(saveText[5], "-");
                string[] rgbInt1 = Regex.Split(saveText[6], "-");
                string[] rgbInt2 = Regex.Split(saveText[7], "-");

                string[] rgbInt3 = Regex.Split(saveText[11], "-");
                string[] rgbInt4 = Regex.Split(saveText[12], "-");
                string[] rgbInt5 = Regex.Split(saveText[13], "-");

                Color getColor = Color.FromArgb(Convert.ToInt32(rgbInt[0]), Convert.ToInt32(rgbInt[1]), Convert.ToInt32(rgbInt[2]));
                Color getColor1 = Color.FromArgb(Convert.ToInt32(rgbInt1[0]), Convert.ToInt32(rgbInt1[1]), Convert.ToInt32(rgbInt1[2]));
                Color getColor2 = Color.FromArgb(Convert.ToInt32(rgbInt2[0]), Convert.ToInt32(rgbInt2[1]), Convert.ToInt32(rgbInt2[2]));

                Color getColor3 = Color.FromArgb(Convert.ToInt32(rgbInt3[0]), Convert.ToInt32(rgbInt3[1]), Convert.ToInt32(rgbInt3[2]));
                Color getColor4 = Color.FromArgb(Convert.ToInt32(rgbInt4[0]), Convert.ToInt32(rgbInt4[1]), Convert.ToInt32(rgbInt4[2]));
                Color getColor5 = Color.FromArgb(Convert.ToInt32(rgbInt5[0]), Convert.ToInt32(rgbInt5[1]), Convert.ToInt32(rgbInt5[2]));

                saveThemeColor = getColor;
                saveTextColor = getColor1;
                saveBackColor = getColor2;
                Mtheme = getColor3;
                Mtext = getColor4;
                Mback = getColor5;
                colorDialog1.Color = saveThemeColor;
                colorDialog2.Color = saveTextColor;
                colorDialog3.Color = saveBackColor;
                McolorDialogTheme.Color = Mtheme;
                McolorDialogText.Color = Mtext;
                McolorDialogBackground.Color = Mback;
                checkBox10.Checked = Convert.ToBoolean(saveText[8]);
                checkBox9.Checked = Convert.ToBoolean(saveText[9]);
                loadConfigPath = saveText[10];

            }
            catch
            {
                MessageBox.Show("Error has ocurred when retrieving settings.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void saveInfoClose()
        {
            try
            {
                saveText = new string[] { targetIndex.ToString(), ps3IP, (radioButton1.Checked) ? "1" : (radioButton2.Checked) ? "2" : (radioButton3.Checked) ? "3" : "0", checkBox2.Checked.ToString(), textBox3.Text, saveThemeColor.R + "-" + saveThemeColor.G + "-" + saveThemeColor.B, saveTextColor.R + "-" + saveTextColor.G + "-" + saveTextColor.B, saveBackColor.R + "-" + saveBackColor.G + "-" + saveBackColor.B, checkBox10.Checked.ToString(), checkBox9.Checked.ToString(), loadConfigPath, Mtheme.R + "-" + Mtheme.G + "-" + Mtheme.B, Mtext.R + "-" + Mtext.G + "-" + Mtext.B, Mback.R + "-" + Mback.G + "-" + Mback.B };
                if (!Directory.Exists(app_folder))
                    Directory.CreateDirectory(app_folder);
                File.WriteAllLines(app_file, saveText);
            }
            catch
            {
                MessageBox.Show("Error has ocurred when saving settings.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region connection
        private void updateInfoLabel()
        {
            label6.Text = " PS3 Connect: " + ps3Status + "\n Game Attach: " + gameStatus + "\nSelected API: " + apiStatus;
            label6.Update();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                curAPI = "tm";
                labelTxtCT = "Select a Target Number(Default = 1)";
                listCT.Clear();
                for (int i = 1; i < 10; i++)
                    listCT.Add("Target " + i.ToString());
            }
            else if (radioButton2.Checked || radioButton3.Checked)
            {
                curAPI = "cc";
                labelTxtCT = "Select an IP";
                listCT.Clear();
                if (cList.Count != 0)
                {
                    foreach (CCAPI.ConsoleInfo item in cList)
                        listCT.Add(item.Name + " : " + item.Ip);
                }
                else
                {
                    textBoxCT = "192.168.1.1";
                    labelTxtCT = "No IPs Found - Enter IP Manually";
                }
            }
            radioButton1.Enabled = false;
            radioButton2.Enabled = false;
            radioButton3.Enabled = false;
            apiForm_.ShowDialog();
            radioButton1.Enabled = true;
            radioButton2.Enabled = true;
            radioButton3.Enabled = true;


            if (radioButton1.Checked)
                targetStatus = "Target Number: " + targetIndex;
            else if (radioButton2.Checked)
                ccapiipStatus = "PS3 IP: " + ps3IP;

            label3.Text = targetStatus + "\n" + ccapiipStatus;


        }

        private void button6_Click(object sender, EventArgs e)
        {
            doConnect();
        }
        private void doConnect()
        {
            bool canConnect = false;

            bool canTry2Connect = false;
            if (radioButton1.Checked)
            {
                if (targetIndex != -1)
                    canTry2Connect = true;
            }
            else if (radioButton2.Checked)
            {
                if (ps3IP != "-1")
                    canTry2Connect = true;
            }
            else if (radioButton3.Checked)
                if (ps3IP != "-1")
                    canTry2Connect = true;
            if (canTry2Connect)
            {
                try
                {
                    if (radioButton1.Checked) { PS3.ChangeAPI(SelectAPI.TargetManager); canConnect = PS3.ConnectTarget(targetIndex - 1); }
                    else if (radioButton2.Checked) { PS3.ChangeAPI(SelectAPI.ControlConsole); canConnect = PS3.ConnectTarget(ps3IP); }
                    else if (radioButton3.Checked) { PS3.ChangeAPI(SelectAPI.PS3Manager); canConnect = PS3.ConnectTarget(ps3IP, true); }

                    if (canConnect == true)
                    {
                        ps3Status = "True";
                        try
                        {
                            if (PS3.AttachProcess())
                            {
                                gameStatus = "True";
                                afterAttach();
                            }
                            else
                            {
                                gameStatus = "Cannot";
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                            gameStatus = "Impossible";
                        }
                    }
                    else
                    {
                        ps3Status = "Cannot";
                    }
                }
                catch
                {
                    ps3Status = "Impossible";
                }
                updateInfoLabel();
            }
            else
            {
                if (radioButton1.Checked)
                    MessageBox.Show("Please click the 'Change' button and select a target number to connect with.\n\nNOTE: Target 1 is default.", "Change Target Number", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else if (radioButton2.Checked)
                    MessageBox.Show("Please click the 'Change' button and select an IP to connect with.", "Change IP", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        #endregion

        #region after attach
        private void afterAttach()
        {
            button6.Enabled = false;
            button7.Enabled = false;
            radioButton1.Enabled = false;
            radioButton2.Enabled = false;
            radioButton3.Enabled = false;
            uint setCheckTool = 0x01D66000;
            uint getCheckTool = 0x01D66004;
            if (!loaded)
                loadInfo();
            canUseTool = true;
            name_backup = PS3.Extension.ReadString(getOfs(mcOfs.sx6si2n76p73uwk613zim));
            useMenu = PS3.Extension.ReadBool(getCheckTool);
            PS3.Extension.WriteBool(setCheckTool, true);
            if (ins4.Count == 2)
                PS3.Extension.WriteUInt32(ins4[0], ins4[1]);
            modsTimer.Stop();
            modsTimer.Start();
            timer2.Stop();
            timer2.Start();
            if (!backgroundWorker1.IsBusy)
                backgroundWorker1.RunWorkerAsync();
            if (!backgroundWorker2.IsBusy)
                backgroundWorker2.RunWorkerAsync();
            if (!backgroundWorker3.IsBusy)
                backgroundWorker3.RunWorkerAsync();
            apiStatus = PS3.GetCurrentAPIName();
            gameManagerPanel.Enabled = true;
            sub1.Enabled = true;
            if (apiStatus == "PS3 Manager")
            {
                autoBuildStructurePanel.Enabled = false;
                hostOptsPanel.Enabled = false;
                posPanel.Enabled = false;
                itemPanel.Enabled = false;
            }
            else
                modMenuPanel.Enabled = true;
            updateInfoLabel();
            button20.Enabled = true;
            if (checkBox9.Checked)
                loadOpts(false);
        }
        #endregion

        #region ult txt
        public class mc_list
        {
            public static string
            #region mclist
 GOD_MODEmc = "GOD_MODEmc",
             INFINITE_BREATH = "INFINITE_BREATH",
             INFINITE_BLOCKS = "INFINITE_BLOCKS",
             INFINITE_ARROWS = "INFINITE_ARROWS",
             INFINITE_FOODmc = "INFINITE_FOODmc",
             CREATIVE_MODE = "CREATIVE_MODE",
             NO_TARGET = "NO_TARGET",
             INFINITE_HUNGER = "INFINITE_HUNGER",
             INSTANT_BOW_DRAW = "INSTANT_BOW_DRAW",
             FAST_BREAKING = "FAST_BREAKING",
             OP_SWORD = "OP_SWORD",
             OP_MODE = "OP_MODE",
             NO_FALL_DAMAGE = "NO_FALL_DAMAGE",
             INFINITE_PICK_UPmc = "INFINITE_PICK_UPmc",
             SUFFOCATE_ALL = "SUFFOCATE_ALL",
             UFO_MODEmc = "UFO_MODEmc",
             THROW_ITEM_HIGH = "THROW_ITEM_HIGH",
             ITEM_GRAVITY = "ITEM_GRAVITY",
             ARROW_GRAVITY = "ARROW_GRAVITY",
             ARROW_ARCH = "ARROW_ARCH",
             DISABLE_BLOCK_FALLING = "DISABLE_BLOCK_FALLING",
             STOP_ARROWS = "STOP_ARROWS",
             MOB_SPEED = "MOB_SPEED",
             TNT_DAMAGE = "TNT_DAMAGE",
             CREEPER_DMG = "CREEPER_DMG",
             CREEPER_FIRE_DMG = "CREEPER_FIRE_DMG",
             HEALTH = "HEALTH",
             XP_LEVEL = "XP_LEVEL",
             KNOCKBACK = "KNOCKBACK",
             INSTANT_BREAK = "INSTANT_BREAK",
             GLIDE = "GLIDE",
             SWIM_MODE = "SWIM_MODE",
             SKY_MODE = "SKY_MODE",
             INFINITE_CRAFTING_ITEMS = "INFINITE_CRAFTING_ITEMS",
             CAN_FLYmc = "CAN_FLYmc",
             FAST_FLY = "FAST_FLY",
             AUTO_JUMPmc = "AUTO_JUMPmc",
             AUTO_HITmc = "AUTO_HITmc",
             AUTO_BUILD = "AUTO_BUILD",
             AUTO_MINEmc = "AUTO_MINEmc",
             AUTO_SPRINT = "AUTO_SPRINT",
             ITEM_IDS = "ITEM_IDS",
             TRANSPARENT_LEVEL = "TRANSPARENT_LEVEL",
             INVISIBLE_BLOCKS = "INVISIBLE_BLOCKS",
             NIGHT_VISIONmc = "NIGHT_VISIONmc",
             SELF_NAME_TAG = "SELF_NAME_TAG",
             CONTRAST = "CONTRAST",
             BLACK_HORIZON = "BLACK_HORIZON",
             BODY_LIGHT = "BODY_LIGHT",
             UNDERWATER_VIEW = "UNDERWATER_VIEW",
             DUSK = "DUSK",
             STATIC_BLOCK_CRACK = "STATIC_BLOCK_CRACK",
             NORMALIZE_CROUCH = "NORMALIZE_CROUCH",
             FIRE_ANIMATION = "FIRE_ANIMATION",
             SWIM_ANIMATION = "SWIM_ANIMATION",
             FOG = "FOG",
             CAMERA_ROTATION = "CAMERA_ROTATION",
             MULTI_JUMPmc = "MULTI_JUMPmc",
             BRIGHT_STARS = "BRIGHT_STARS",
             HIDE_ALL = "HIDE_ALL",
             HIDE_HOT_BAR = "HIDE_HOT_BAR",
             HIDE_CLOUDS = "HIDE_CLOUDS",
             HIDE_STARS = "HIDE_STARS",
             NO_BOXES = "NO_BOXES",
             BLACK_BOXES = "BLACK_BOXES",
             SLIDING = "SLIDING",
             UPSIDE_DOWN_ENTITIES = "UPSIDE_DOWN_ENTITIES",
             NEAR_BY_SOUNDS = "NEAR_BY_SOUNDS",
             IMITATE_HOST = "IMITATE_HOST",
             GOD_MODE_INVISIBILITY = "GOD_MODE_INVISIBILITY",
             ZOOM = "ZOOM",
             FIELD_OF_VIEW = "FIELD_OF_VIEW",
             ACTION_REACH = "ACTION_REACH",
             ACTION_SPEED = "ACTION_SPEED",
             HIT_SPAN = "HIT_SPAN",
             BLOCK_CRACK_COLOR = "BLOCK_CRACK_COLOR",
             X_RAY = "X_RAY",
             TIME_OF_DAY = "TIME_OF_DAY",
             LIGHT_COLOR = "LIGHT_COLOR",
             SKY_COLOR = "SKY_COLOR",
             PLAYER_DIMENSION = "PLAYER_DIMENSION",
             ENTITIY_GRAVITY = "ENTITIY_GRAVITY",
             ENTITIY_SPEED = "ENTITIY_SPEED",
             EXIT_WATER = "EXIT_WATER",
             VERTICAL_SWIM = "VERTICAL_SWIM",
             SWIM_SPEED = "SWIM_SPEED",
             NAME_CHANGER = "NAME_CHANGER",
             HUD_COLOR = "HUD_COLOR",
             STOP_WATER_FLOW = "STOP_WATER_FLOW",
             CREEPER_DAMAGE = "CREEPER_DAMAGE",
             STOP_BLOCK_FALLING = "STOP_BLOCK_FALLING",
             UNDER_WATER_VIEW = "UNDER_WATER_VIEW",
             CAMERA_ZOOM = "CAMERA_ZOOM",
             SPACE_JUMP = "SPACE_JUMP";
            #endregion
        }
        public class ult_list
        {
            public static string
            #region ult txt
 GOD_MODE = "GOD_MODE",
            INSTANT_DAMAGE = "INSTANT_DAMAGE",
            KNOCKBACK_ULT = "KNOCKBACK_ULT",
            ANTI_KNOCKBACK = "ANTI_KNOCKBACK",
            INSTANT_KILL = "INSTANT_KILL",
            WATER_JUMP = "WATER_JUMP",
            INFINITE_PICK_UP = "INFINITE_PICK_UP",
            FAST_BOW = "FAST_BOW",
            ALL_PLAYERS_FAST_MINE = "ALL_PLAYERS_FAST_MINE",
            ALL_PLAYERS_FAST_SPEED = "ALL_PLAYERS_FAST_SPEED",
            AUTO_SAVE = "AUTO_SAVE",
            SUPER_SPEED = "SUPER_SPEED",
            DISABLE_MOBS = "DISABLE_MOBS",
            FIRE_CREEPER_EXPLODE = "FIRE_CREEPER_EXPLODE",
            JUMP_SPEED = "JUMP_SPEED",
            MULTI_JUMP = "MULTI_JUMP",
            SUPER_JUMP = "SUPER_JUMP",
            AUTO_JUMP = "AUTO_JUMP",
            REACH_ATTACK = "REACH_ATTACK",
            INSTANT_MINE = "INSTANT_MINE",
            INFINITE_CRAFT = "INFINITE_CRAFT",
            ANTI_TELEPORT_BY_HOST = "ANTI_TELEPORT_BY_HOST",
            UFO_MODE = "UFO_MODE",
            JUMP_FORWARD = "JUMP_FORWARD",
            CAM_DOWN = "CAM_DOWN",
            CAM_DOWN_R3 = "CAM_DOWN_R3",
            TOGGLE_SPRINT = "TOGGLE_SPRINT",
            NAME_OVER_HEAD = "NAME_OVER_HEAD",
            X_RAY = "X_RAY",
            HUD_MINI_GAME = "HUD_MINI_GAME",
            SHOW_ARMOR = "SHOW_ARMOR",
            AUTO_VIEW = "AUTO_VIEW",
            REMOVE_JUMP = "REMOVE_JUMP",
            AUTO_CROUCH = "AUTO_CROUCH",
            DISABLE_SWIM = "DISABLE_SWIM",
            AUTO_MINE = "AUTO_MINE",
            AUTO_HIT = "AUTO_HIT",
            ANIM_SWIM_FLY = "ANIM_SWIM_FLY",
            LEVITATION = "LEVITATION",
            REMOVE_ALL_TEXT = "REMOVE_ALL_TEXT",
            POSITION_VIEW = "POSITION_VIEW",
            REMOVE_SWIM = "REMOVE_SWIM",
            MOVEMENT_SWIM = "MOVEMENT_SWIM",
            SEE_OUTSIDE_MAP = "SEE_OUTSIDE_MAP",
            LOOK_FORBACK = "LOOK_FORBACK",
            INSTANT_HIT = "INSTANT_HIT",
            NO_COLISSION = "NO_COLISSION",
            APOCALIPSE = "APOCALIPSE",
            FUNNY_SCREEN = "FUNNY_SCREEN",
            PLAYERS_POSITION = "PLAYERS_POSITION",
            HORROR_VIEW = "HORROR_VIEW",
            ANIMATION_RUNNING = "ANIMATION_RUNNING",
            SPLIT_SCREEN = "SPLIT_SCREEN",
            FUNNY_SOUND = "FUNNY_SOUND",
            SIZE_HUD = "SIZE_HUD",
            BURN_IN_WATER = "BURN_IN_WATER",
            MAX_PICKUP_ITEMS = "MAX_PICKUP_ITEMS",
            TEXT_TO_ALIEN = "TEXT_TO_ALIEN",
            KICK_TO_XMB_HUD = "KICK_TO_XMB_HUD",
            BROKEN_TEXTURES = "BROKEN_TEXTURES",
            SHOCKWAVE_EFFECT = "SHOCKWAVE_EFFECT",
            NIGHT_VISION = "NIGHT_VISION",
            KILL_AURA = "KILL_AURA",
            FLY_MODE_X = "FLY_MODE_X",
            WALL_HACK_V1 = "WALL_HACK_V1",
            GHOST_PLAYERS = "GHOST_PLAYERS",
            TEXTURE_PLASTIC = "TEXTURE_PLASTIC",
            SUICIDE = "SUICIDE",
            GUN_ITEMS = "GUN_ITEMS",
            REMOVE_PARTICLES = "REMOVE_PARTICLES",
            BIG_PARTICLES = "BIG_PARTICLES",
            FAST_BUILD = "FAST_BUILD",
            CAN_FLY = "CAN_FLY",
            GAME_SPEED_STATIC = "GAME_SPEED_STATIC",
            DARK_STORM = "DARK_STORM",
            RAINBOW_STORM = "RAINBOW_STORM",
            RAIN_TO_SNOW = "RAIN_TO_SNOW",
            SKY_TO_RAINBOW_WITH_SNOW = "SKY_TO_RAINBOW_WITH_SNOW",
            FLASH_STARS_IN_SKY = "FLASH_STARS_IN_SKY",
            REMOVE_STARS_IN_SKY = "REMOVE_STARS_IN_SKY",
            IDS_ITEMS = "IDS_ITEMS",
            BYPASS_MAX_ITEMS = "BYPASS_MAX_ITEMS",
            AUTO_TOSS_ITEMS = "AUTO_TOSS_ITEMS",
            FREEZE_PARTICLES = "FREEZE_PARTICLES",
            SEMI_BLACKSCREEN = "SEMI_BLACKSCREEN",
            DISABLE_FLY_CREATIVE = "DISABLE_FLY_CREATIVE",
            INSTANT_PLACE_SURVIVAL = "INSTANT_PLACE_SURVIVAL",
            NO_DAMAGE_HIT = "NO_DAMAGE_HIT",
            BREAK_PARTICLES_FLY = "BREAK_PARTICLES_FLY",
            STUCK_IN_BLOCKS = "STUCK_IN_BLOCKS",
            SMALL_RAIN = "SMALL_RAIN",
            FLASH_SKY_WITH_PARTICLES = "FLASH_SKY_WITH_PARTICLES",
            NEW_SUPER_SPEED = "NEW_SUPER_SPEED",
            PLAYERS_PAPER_MODELS = "PLAYERS_PAPER_MODELS",
            PLAYERS_BIG_MODELS = "PLAYERS_BIG_MODELS",
            INFINITE_BLOCK = "INFINITE_BLOCK",
            BEST_SKY = "BEST_SKY",
            DISABLE_RUN = "DISABLE_RUN",
            PLAYERS_SKATE_MODE = "PLAYERS_SKATE_MODE",
            ARMS_AND_LEGS_WEIRD = "ARMS_AND_LEGS_WEIRD",
            RAYMAN_MODE = "RAYMAN_MODE",
            ARMS_HIT_SPEED = "ARMS_HIT_SPEED",
            CREATIVE_SLOT = "CREATIVE_SLOT",
            SURVIVAL_SLOT = "SURVIVAL_SLOT",
            SUPER_SPEED_V3 = "SUPER_SPEED_V3",
            CRITICAL_HIT_V1 = "CRITICAL_HIT_V1",
            DRIFT_BOAT = "DRIFT_BOAT",
            REMOVE_ANIMATION_RUN = "REMOVE_ANIMATION_RUN",
            GAME_GAMEMODE_LOCKED = "GAME_GAMEMODE_LOCKED",
            FLOAT_UP = "FLOAT_UP",
            PRESS_X_FOR_HIT = "PRESS_X_FOR_HIT",
            ESP_CHESTS_V1 = "ESP_CHESTS_V1",
            SMALL_GRAPHIC = "SMALL_GRAPHIC",
            SUPER_SPEED_V4 = "SUPER_SPEED_V4",
            CAMERA_RIGHT_POSITION = "CAMERA_RIGHT_POSITION",
            CAMERA_LEFT_POSITION = "CAMERA_LEFT_POSITION",
            TNT_CANT_DESTROY_BLOCKS = "TNT_CANT_DESTROY_BLOCKS",
            BIG_GAMEPLAY = "BIG_GAMEPLAY",
            KNOCKBACK_V1 = "KNOCKBACK_V1",
            REMOVE_INVENTORY_HUD = "REMOVE_INVENTORY_HUD",
            REMOVE_POINTER_AIM = "REMOVE_POINTER_AIM",
            HUD_SHOW_PLAYERS_AROUND_YOU = "HUD_SHOW_PLAYERS_AROUND_YOU",
            CREEPER_EXPLODE_MEDIUM = "CREEPER_EXPLODE_MEDIUM",
            CREEPER_CANT_DESTROY_BLOCKS = "CREEPER_CANT_DESTROY_BLOCKS",
            MAKE_CREEPER_BIG = "MAKE_CREEPER_BIG",
            NO_SLOW_DOWN = "NO_SLOW_DOWN",
            HUD_INVENTORY_DOWN_ON_SCREEN = "HUD_INVENTORY_DOWN_ON_SCREEN",
            FAST_BROKEN_BLOCKS_IN_CREATIVE = "FAST_BROKEN_BLOCKS_IN_CREATIVE",
            CANT_GRAB_ITEMS = "CANT_GRAB_ITEMS",
            REMOVE_SOME_FPS = "REMOVE_SOME_FPS",
            DISABLE_CHANGING_WEATHER = "DISABLE_CHANGING_WEATHER",
            FUNNY_ARMS_LEGS = "FUNNY_ARMS_LEGS",
            BYPASS_CREATIVE_IN_TRUMBLE = "BYPASS_CREATIVE_IN_TRUMBLE",
            HIDE_ARMS = "HIDE_ARMS",
            BETTER_TIME = "BETTER_TIME",
            STOP_BOW = "STOP_BOW",
            NO_COLISSION_BYPASS = "NO_COLISSION_BYPASS",
            NO_KNOCKBACK = "NO_KNOCKBACK",
            ROTATION_BODY = "ROTATION_BODY",
            FOG_BLUE = "FOG_BLUE",
            DAYS_NIGHT = "DAYS_NIGHT",
            CREEPER_SMALL_EXPLOSION = "CREEPER_SMALL_EXPLOSION",
            CREEPER_MEDIUM_EXPLOSION = "CREEPER_MEDIUM_EXPLOSION",
            CREEPER_EXTREM_EXPLOSION = "CREEPER_EXTREM_EXPLOSION",
            CREEPER_NUCLEAR_EXPLOSION = "CREEPER_NUCLEAR_EXPLOSION",
            INSTANT_KILL_IN_FIRE = "INSTANT_KILL_IN_FIRE",
            ALL_PLAYERS_SET_IN_FIRE = "ALL_PLAYERS_SET_IN_FIRE",
            INSTANT_JUMP_IN_SKY = "INSTANT_JUMP_IN_SKY",
            PLAYERS_BODY_LIGHT = "PLAYERS_BODY_LIGHT",
            JUMP_FOR_BUILD = "JUMP_FOR_BUILD",
            CREEPER_INSTANT_EXPLODE = "CREEPER_INSTANT_EXPLODE",
            WOLF_TURN_HEAD = "WOLF_TURN_HEAD",
            WOLF_REMOVE_WATER = "WOLF_REMOVE_WATER",
            TNT_CANT_EXPLODE_BLOCKS = "TNT_CANT_EXPLODE_BLOCKS",
            TNT_MAKE_MORE_PARTICLES = "TNT_MAKE_MORE_PARTICLES",
            CANT_GRAB_ITEMS_V2 = "CANT_GRAB_ITEMS_V2",
            TNT_FLY_IN_AIR_WHEN_ENABLED = "TNT_FLY_IN_AIR_WHEN_ENABLED",
            TNT_INSTANT_EXPLODE = "TNT_INSTANT_EXPLODE",
            ALL_PLAYERS_FREEZE_PS3 = "ALL_PLAYERS_FREEZE_PS3",
            ANTI_KICK_PREMIUM = "ANTI_KICK_PREMIUM",
            ANTI_AFK = "ANTI_AFK",
            FOOT_STEP_FAST = "FOOT_STEP_FAST",
            FOOT_STEP_SLOW = "FOOT_STEP_SLOW",
            SENSIBILITY_FAST = "SENSIBILITY_FAST",
            SENSIBILITY_MAX = "SENSIBILITY_MAX",
            SWIM_GLITCH = "SWIM_GLITCH",
            REMOVE_HURT_CAM = "REMOVE_HURT_CAM",
            REMOVE_FALL_DAMAGE = "REMOVE_FALL_DAMAGE",
            MAX_XP_LEVEL = "MAX_XP_LEVEL",
            SUPER_SPEED_V5 = "SUPER_SPEED_V5",
            ALL_PLAYERS_FAST_MINE_V2 = "ALL_PLAYERS_FAST_MINE_V2",
            WALL_HACK_V2 = "WALL_HACK_V2",
            SUPER_SPEED_V6 = "SUPER_SPEED_V6",
            PLAYERS_SLIDE = "PLAYERS_SLIDE",
            ENTITY_INVISIBLE = "ENTITY_INVISIBLE",
            CRITICAL_HIT_V2 = "CRITICAL_HIT_V2",
            REVERSE_KNOCKBACK = "REVERSE_KNOCKBACK",
            TNT_SMALL_PARTICLES = "TNT_SMALL_PARTICLES",
            DEBUG_SKINS_TEXTURE = "DEBUG_SKINS_TEXTURE",
            ALL_WORLD_LIGHT_WHITE = "ALL_WORLD_LIGHT_WHITE",
            RAINBOW_LIGHT = "RAINBOW_LIGHT",
            TNT_GO_DOWN = "TNT_GO_DOWN",
            ESP_CHESTS_V2 = "ESP_CHESTS_V2",
            EPS_CHEST_V3 = "EPS_CHEST_V3",
            SHADOW_SKINS_V2 = "SHADOW_SKINS_V2",
            WALK_ALONE = "WALK_ALONE",
            SHADOW_SKINS_PLAYERS = "SHADOW_SKINS_PLAYERS",
            ANTI_AFK_V2 = "ANTI_AFK_V2",
            ALL_PLAYERS_CANT_RUN = "ALL_PLAYERS_CANT_RUN",
            RETURN_TO_XMB = "RETURN_TO_XMB",
            LIGHT_MAKE_MORE_POWER = "LIGHT_MAKE_MORE_POWER",
            TNT_EXPLODE_SOUND_OFF = "TNT_EXPLODE_SOUND_OFF",
            NAME_OVER_HEAD_GO_UP_DOWN = "NAME_OVER_HEAD_GO_UP_DOWN",
            STATIC_MOVEMENT = "STATIC_MOVEMENT",
            LOBBY_MESSAGES = "LOBBY_MESSAGES",
            SHAKE_CAMERA = "SHAKE_CAMERA",
            DEMI_GOD = "DEMI_GOD",
            INSTANT_KILL_ALL = "INSTANT_KILL_ALL",
            ENTITY_SKINS_RED = "ENTITY_SKINS_RED",
            GLITCHED_DEAD_MOBS = "GLITCHED_DEAD_MOBS",
            FIRE_INSTANT_REMOVED = "FIRE_INSTANT_REMOVED",
            WALK_IN_SKY = "WALK_IN_SKY",
            BYPASS_KILL_ALL = "BYPASS_KILL_ALL",
            SUPER_JUMP_V2 = "SUPER_JUMP_V2",
            REMOVE_LEVEL_XP = "REMOVE_LEVEL_XP",
            AUTO_REGENERATE_HEALTH = "AUTO_REGENERATE_HEALTH",
            CANT_GRAB_ITEMS_V3 = "CANT_GRAB_ITEMS_V3",
            GRAVITY_MOON = "GRAVITY_MOON",
            FLAT_BLOCKS = "FLAT_BLOCKS",
            BLOCKS_HAND_UP = "BLOCKS_HAND_UP",
            SUPER_SPEED_V7 = "SUPER_SPEED_V7",
            POTIONS_GRAVITY_FLY = "POTIONS_GRAVITY_FLY",
            POTIONS_NO_GRAVITY = "POTIONS_NO_GRAVITY",
            TOGGLE_SPRINT_V2 = "TOGGLE_SPRINT_V2",
            ARROWS_BLOCKS_ITEMS = "ARROWS_BLOCKS_ITEMS",
            ARROWS_REMOVE = "ARROWS_REMOVE",
            ARROWS_DIRECTIONS = "ARROWS_DIRECTIONS",
            VIBRATE_WALK = "VIBRATE_WALK",
            PARTICLES_FLY_V2 = "PARTICLES_FLY_V2",
            POSITIONS_PLACE = "POSITIONS_PLACE",
            DESTROY_GAME = "DESTROY_GAME",
            LINES_BLOCKS_MOVE = "LINES_BLOCKS_MOVE",
            DISABLE_PLAYERS = "DISABLE_PLAYERS",
            LOBBY_MESSAGES_SPAM = "LOBBY_MESSAGES_SPAM",
            ALL_PLAYERS_FAST_SPEED_V2 = "ALL_PLAYERS_FAST_SPEED_V2",
            PLAYERS_LISTS = "PLAYERS_LISTS",
            SMALL_TEXT = "SMALL_TEXT",
            POSITIONS_HUD = "POSITIONS_HUD",
            ARMS_BROKEN_V2 = "ARMS_BROKEN_V2",
            AUTO_KILL_MOBS_SPAWNED = "AUTO_KILL_MOBS_SPAWNED",
            WEATHER_SNOW = "WEATHER_SNOW",
            WEATHER_RAIN = "WEATHER_RAIN",
            FOG_BLACK = "FOG_BLACK",
            LIGHTING_BOLT = "LIGHTING_BOLT",
            LIGHTNING_BOLT_V2 = "LIGHTNING_BOLT_V2",
            SUPER_SPEED_LEGIT = "SUPER_SPEED_LEGIT",
            SCAFFOLD_BETA = "SCAFFOLD_BETA",
            ALL_PLAYERS_CANT_RUN_V2 = "ALL_PLAYERS_CANT_RUN_V2",
            BLINK_SKY = "BLINK_SKY",
            STOP_FALL_GRAVITY = "STOP_FALL_GRAVITY",
            ALL_PLAYERS_SPAM_ZOOM = "ALL_PLAYERS_SPAM_ZOOM",
            ANTI_AFK_V3 = "ANTI_AFK_V3",
            SKY_TO_NETHER = "SKY_TO_NETHER",
            SMOKE_LOBBY = "SMOKE_LOBBY",
            CAN_SEE_UNDER_WORLD = "CAN_SEE_UNDER_WORLD",
            FREE_CAM = "FREE_CAM",
            CORRUPT_WORLD = "CORRUPT_WORLD",
            LIGHT_EYES_ENDERMAN = "LIGHT_EYES_ENDERMAN",
            REMOVE_HANDS = "REMOVE_HANDS",
            LABYMOD_SETTINGS = "LABYMOD_SETTINGS",
            PARTICLES_TORNADO = "PARTICLES_TORNADO",
            FAST_MOVE_LEGS_ARMS = "FAST_MOVE_LEGS_ARMS",
            LEGS_IN_AIR = "LEGS_IN_AIR",
            DAMAGE_HIT_RED_BLUE = "DAMAGE_HIT_RED_BLUE",
            NO_DELAY_HIT_DAMAGE = "NO_DELAY_HIT_DAMAGE",
            DISABLE_FOG = "DISABLE_FOG",
            ESP_ENTITY_RED = "ESP_ENTITY_RED",
            ESP_ENTITY_BLUE = "ESP_ENTITY_BLUE",
            FOV_WITHOUT_HAND = "FOV_WITHOUT_HAND",
            ZOOM_WITHOUT_HAND = "ZOOM_WITHOUT_HAND",
            ALL_PLAYERS_TAKE_DAMAGE = "ALL_PLAYERS_TAKE_DAMAGE",
            INFINITE_FOOD = "INFINITE_FOOD",
            UNFAIR_ATTACK = "UNFAIR_ATTACK",
            AUTO_BUILD_IN_SURVIVAL = "AUTO_BUILD_IN_SURVIVAL",
            ESP_PLAYERS = "ESP_PLAYERS",
            HITBOX_BETA = "HITBOX_BETA",
            WEATHER_TO_RAIN_ANYTIME = "WEATHER_TO_RAIN_ANYTIME",
            WALL_HACK_V3 = "WALL_HACK_V3",
            OLD_FLY_OPTIONS = "OLD_FLY_OPTIONS",
            MOBS_IGNORE_ME = "MOBS_IGNORE_ME",
            DISALBE_HUD_TEXT = "DISALBE_HUD_TEXT",
            MINE_IN_ADVENTURE = "MINE_IN_ADVENTURE",
            NAME_OVER_HEAD_DOUBLE = "NAME_OVER_HEAD_DOUBLE",
            BOAT_STOP_WORKING = "BOAT_STOP_WORKING",
            HUD_HIDE_EVERYTHING = "HUD_HIDE_EVERYTHING",
            GAME_NO_ITEMS = "GAME_NO_ITEMS",
            IRON_HELMET_EVERYONE = "IRON_HELMET_EVERYONE",
            TEXTURE_BLACK = "TEXTURE_BLACK",
            GAMMA_TO_MAX = "GAMMA_TO_MAX",
            NAME_AND_SHADOW_BLACK = "NAME_AND_SHADOW_BLACK",
            TRIDENT_RIPTIDE_TO_MAX = "TRIDENT_RIPTIDE_TO_MAX",
            ALLOW_ALL_ITEMS_ON_HEAD = "ALLOW_ALL_ITEMS_ON_HEAD",
            NO_COLISSION_ENTITY = "NO_COLISSION_ENTITY",
            ENABLE_ALL_ENCHANTEMENT = "ENABLE_ALL_ENCHANTEMENT",
            FROST_WALKER = "FROST_WALKER",
            NO_WEB_HAX = "NO_WEB_HAX",
            FLY_OR_RUN_ON_CROUCH = "FLY_OR_RUN_ON_CROUCH",
            AUTO_LADDER = "AUTO_LADDER",
            ANIMATION_CHARACTER = "ANIMATION_CHARACTER",
            BIG_ANIMATION_CHARACTER = "BIG_ANIMATION_CHARACTER",
            NETHER_VISION = "NETHER_VISION",
            ENTITY_GOD_MODE = "ENTITY_GOD_MODE",
            ENABLE_SPECIAL_BLOCK = "ENABLE_SPECIAL_BLOCK",
            SPECTRAL_ARROWS_WITH_BOW = "SPECTRAL_ARROWS_WITH_BOW",
            AIR_TO_WATER = "AIR_TO_WATER",
            MULTI_JUMP_V2 = "MULTI_JUMP_V2",
            ALL_PLAYERS_LEFT_HAND = "ALL_PLAYERS_LEFT_HAND",
            PARTICLES_DAMAGE_NO_STOP = "PARTICLES_DAMAGE_NO_STOP",
            ROBLOX_ANIMATION = "ROBLOX_ANIMATION",
            INFINITE_OXYGEN_IN_WATER = "INFINITE_OXYGEN_IN_WATER",
            ENTITY_TO_BABY = "ENTITY_TO_BABY",
            GET_SPECTATOR_GAMEMODE = "GET_SPECTATOR_GAMEMODE",
            BLOCKS_STATIC_CRACK = "BLOCKS_STATIC_CRACK",
            KILL_DISAPPEAR_ENTITY = "KILL_DISAPPEAR_ENTITY",
            KILL_DONT_DISAPPEAR_ENTITY = "KILL_DONT_DISAPPEAR_ENTITY",
            GET_IDS_PLAYERS_ON_HEAD = "GET_IDS_PLAYERS_ON_HEAD",
            GET_64_ITEMS_BLOCKS = "GET_64_ITEMS_BLOCKS",
            SWITCH_GAME_TO_OFFLINE = "SWITCH_GAME_TO_OFFLINE",
            FREEZE_THE_WORLD_WITH_EGG = "FREEZE_THE_WORLD_WITH_EGG",
            FISHING_ROD_CANT_BE_REMOVED = "FISHING_ROD_CANT_BE_REMOVED",
            FISHING_ROD_NO_GRAVITY = "FISHING_ROD_NO_GRAVITY",
            REMOVE_ANIMATION_DETAILED_SKINS = "REMOVE_ANIMATION_DETAILED_SKINS",
            CREEPER_CHARGED_DISABLED = "CREEPER_CHARGED_DISABLED",
            LEAD_CANT_BE_REMOVED = "LEAD_CANT_BE_REMOVED",
            IGNIORING_PRESSURE_PLATE = "IGNIORING_PRESSURE_PLATE",
            DEAD_PLAYERS_REMAINS_STANDING = "DEAD_PLAYERS_REMAINS_STANDING",
            DISABLE_KILLED_OUT_OF_WORLD = "DISABLE_KILLED_OUT_OF_WORLD",
            DISABLE_TOTEM_OF_UNDYING = "DISABLE_TOTEM_OF_UNDYING",
            ENABLE_AIM_ON_3TH_PRESON = "ENABLE_AIM_ON_3TH_PRESON",
            TOTEM_FLOAT_HEALTH = "TOTEM_FLOAT_HEALTH",
            ENDERMAN_AND_CHORUS_FRUIT_CANT_BE_TELEPORTED = "ENDERMAN_AND_CHORUS_FRUIT_CANT_BE_TELEPORTED",
            PLAYERS_ON_ELYTRA = "PLAYERS_ON_ELYTRA",
            WATER_SLOW_DOWN = "WATER_SLOW_DOWN",
            JUMP_IN_LAVA = "JUMP_IN_LAVA",
            FREEZE_ALL_ENTITY = "FREEZE_ALL_ENTITY",
            AUTO_KILL_PLAYERS = "AUTO_KILL_PLAYERS",
            DISABLE_PORTALS = "DISABLE_PORTALS",
            ALL_PLAYERS_SUFFOCATE = "ALL_PLAYERS_SUFFOCATE",
            ENTITY_RENDER = "ENTITY_RENDER",
            NETHER_PORTAL_WITH_STONE = "NETHER_PORTAL_WITH_STONE",
            DETECT_IF_PLAYERS_HAS_BEEN_ALREADY_DAMAGED = "DETECT_IF_PLAYERS_HAS_BEEN_ALREADY_DAMAGED",
            RUNNING_PARTICLES_SPECTRAL = "RUNNING_PARTICLES_SPECTRAL",
            RUNNING_PARTICLES_WEIRD = "RUNNING_PARTICLES_WEIRD",
            AUTO_CROUCH_ON_MOVEMENT = "AUTO_CROUCH_ON_MOVEMENT",
            ROTATION_HEAD_360_DEGRES = "ROTATION_HEAD_360_DEGRES",
            PLACE_BLOCKS_IN_BATTLE_WORLDS = "PLACE_BLOCKS_IN_BATTLE_WORLDS",
            CREATIVE_INVENTORY_IN_LOBBY = "CREATIVE_INVENTORY_IN_LOBBY",
            PERMISSIONS_DESTROY_BLOCKS = "PERMISSIONS_DESTROY_BLOCKS",
            INVENTORY_SPECIAL_BLOCKS = "INVENTORY_SPECIAL_BLOCKS",
            GET_CRAFTING_IN_BATTLE_WORLD = "GET_CRAFTING_IN_BATTLE_WORLD",
            ENABLE_TAKE_EVERYTHING_IN_CHESTS = "ENABLE_TAKE_EVERYTHING_IN_CHESTS",
            GOD_MODE_V3 = "GOD_MODE_V3",
            CAN_SEE_REAL_SKINS_IN_SPECTATOR = "CAN_SEE_REAL_SKINS_IN_SPECTATOR",
            DISABLE_RESPAWN = "DISABLE_RESPAWN",
            GENEREATE_BUBBLE_IN_WATER = "GENEREATE_BUBBLE_IN_WATER",
            ELYTRA_ON_ALL_ENTITY = "ELYTRA_ON_ALL_ENTITY",
            MOVE_HEAD_BUT_NOT_BODY = "MOVE_HEAD_BUT_NOT_BODY",
            STOP_ANIMATIONS = "STOP_ANIMATIONS",
            STOP_WALK_ANIMATIONS = "STOP_WALK_ANIMATIONS",
            ALLOW_PORTAL_IN_MINI_GAMES = "ALLOW_PORTAL_IN_MINI_GAMES",
            CREATIVE_SLOT_V2 = "CREATIVE_SLOT_V2",
            STARVED_ALL_PLAYERS_IN_BATTLE_WORLD = "STARVED_ALL_PLAYERS_IN_BATTLE_WORLD",
            OPTIMIZE_CHUNKS_LOAD = "OPTIMIZE_CHUNKS_LOAD",
            STOP_CHUNKS_LOAD = "STOP_CHUNKS_LOAD",
            DISABLE_3RD_PERSON_VIEW = "DISABLE_3RD_PERSON_VIEW",
            NETHER_PORTAL_WITH_DIRT = "NETHER_PORTAL_WITH_DIRT",
            TNT_CAN_DESTROY_BLOCKS_IN_MINI_GAMES = "TNT_CAN_DESTROY_BLOCKS_IN_MINI_GAMES",
            SURVIVAL_IN_LOBBY = "SURVIVAL_IN_LOBBY",
            VELOCITY_SMALL = "VELOCITY_SMALL",
            VELOCITY_BIG = "VELOCITY_BIG",
            TNT_EXPLODE_RADIUS_SMALL = "TNT_EXPLODE_RADIUS_SMALL",
            STOP_SHOW_LOGS_NOTIFS = "STOP_SHOW_LOGS_NOTIFS",
            ADD_FAKE_CLONE_CONTROLLER = "ADD_FAKE_CLONE_CONTROLLER",
            REAL_JUMP_ANIMATION = "REAL_JUMP_ANIMATION",
            SCREEN_DEAD = "SCREEN_DEAD",
            MAX_PLAYERS_FOR_SMALL_MAPS = "MAX_PLAYERS_FOR_SMALL_MAPS",

            ITEMS_WATER_TO_FOUR_4J_DEBUG = "ITEMS_WATER_TO_FOUR_4J_DEBUG",
            ITEMS_WATER_TO_ = "ITEMS_WATER_TO_",
            ITEMS_WATER_TO_DIAMOND = "ITEMS_WATER_TO_DIAMOND",
            ITEMS_WATER_TO_COMMAND_BLOCK = "ITEMS_WATER_TO_COMMAND_BLOCK",
            ITEMS_WATER_TO_SPAWN_EGGS = "ITEMS_WATER_TO_SPAWN_EGGS",
            ITEMS_WATER_TO_DIAMOND_SWORD = "ITEMS_WATER_TO_DIAMOND_SWORD",
            bunifuImage1 = "bunifuImage1",
            bunifuImage2 = "bunifuImage2",
            FROSTED_ICE_TO_BARRIERE = "FROSTED_ICE_TO_BARRIERE",
            FROSTED_ICE_TO_EGGS_DRAGON = "FROSTED_ICE_TO_EGGS_DRAGON",
            FROSTED_ICE_TO_REAPETING_COMMAND_BLOCK = "FROSTED_ICE_TO_REAPETING_COMMAND_BLOCK",
            FROSTED_ICE_TO_GREEN_COMMAND_BLOCK = "FROSTED_ICE_TO_GREEN_COMMAND_BLOCK",
            FROSTED_ICE_TO_COMMAND_BLOCK = "FROSTED_ICE_TO_COMMAND_BLOCK",
            FROSTED_ICE_TO_DEFAULT = "FROSTED_ICE_TO_DEFAULT",
            FROSTED_ICE_TO_MAGMA = "FROSTED_ICE_TO_MAGMA",
            FROSTED_ICE_TO_ENDER_GATEWAY = "FROSTED_ICE_TO_ENDER_GATEWAY",
            FROSTED_ICE_TO_DAIMOND_ORE = "FROSTED_ICE_TO_DAIMOND_ORE",
            FROSTED_ICE_TO_SIGN = "FROSTED_ICE_TO_SIGN",
            LAST_PLAYERS_JOINED_THE_WORLD = "LAST_PLAYERS_JOINED_THE_WORLD",
            SPAWN_DRAGON_EGGS = "SPAWN_DRAGON_EGGS",
            SPAWN_WHITER_EGGS = "SPAWN_WHITER_EGGS",
            SPAWN_BUNNY_KILLER_EGGS = "SPAWN_BUNNY_KILLER_EGGS",
            SPAWN_GIANT_EGGS = "SPAWN_GIANT_EGGS",
            SPAWN_IRON_GOLEM_EGGS = "SPAWN_IRON_GOLEM_EGGS",
            SPAWN_SNOWBALL_EGGS = "SPAWN_SNOWBALL_EGGS",
            SPAWN_ARMOR_STAND_EGGS = "SPAWN_ARMOR_STAND_EGGS",
            GET_YOUR_PING = "GET_YOUR_PING",
            HUD_NEW_COLORS = "HUD_NEW_COLORS",
            TIME_SPEED = "TIME_SPEED",
            DAMAGE_COLOR = "DAMAGE_COLOR",
            TIMECYCLE = "TIMECYCLE",
            TIMECYCLE_V2 = "TIMECYCLE_V2",
            ITEMS_SIZE = "ITEMS_SIZE",
            FOV_VALUE = "FOV_VALUE",
            SKY_COLORS = "SKY_COLORS",
            HUD_COLORS = "HUD_COLORS",
            ENTITY_VISION = "ENTITY_VISION",
            ENTITY_VISUAL = "ENTITY_VISUAL",
            FPS_VALUES = "FPS_VALUES",
            DRAW_MODE = "DRAW_MODE",
            GAMEPLAY_COLORS = "GAMEPLAY_COLORS",
            CLOUD_COLORS = "CLOUD_COLORS",
            NO_SHADOW_ENTITY = "NO_SHADOW_ENTITY",
            SELECTED_BLOCKS = "SELECTED_BLOCKS",
            SUN_MOON_SIZE = "SUN_MOON_SIZE",
            HAND_POSITION = "HAND_POSITION",
            ITEMS_IN_HAND = "ITEMS_IN_HAND",
            WEATHER_STATE = "WEATHER_STATE",
            REACH_VALUES = "REACH_VALUES",
            XP_LEVELV2 = "XP_LEVELV2",
            SOURCE_KILL = "SOURCE_KILL",
            PLAYING_ALONE = "PLAYING_ALONE",
            PLAYING_MULTI = "PLAYING_MULTI",
            PLAYER_JOIN = "PLAYER_JOIN",
            PLAYER_LEAVE = "PLAYER_LEAVE",
            NAMEV2 = "NAMEV2",
            NAME_GLITCH = "NAME_GLITCH",
            NAME_COLORED = "NAME_COLORED",
            ITEMS_2TH_HAND = "ITEMS_2TH_HAND",
            NAME_LINE = "NAME_LINE",
            WORLD_DIMENSION = "WORLD_DIMENSION",
            NETHER_DIMENSION = "NETHER_DIMENSION",
            THE_END_DIMENSION = "THE_END_DIMENSION";
            #endregion
        }
        #endregion

        #region mc num
        #region ofs

        private class mcOfs
        {
            public static int count = 0;
            public static int
            Lhpvb05sk0dopf5u4qakf = count++,
            Wqmmsn21ib54wnbqodtt9 = count++,
            efl4z4r3hqvin0z55ddx7 = count++,
            Bdki4i2cepg06qkaeswx5 = count++,
            m9u1qxr6xguka5w54d9qc = count++,
            toy2j4l6py0nrp28ts1h1 = count++,
            a6p845zb4pfbsfurk2swl = count++,
            Ovq8ph3udxmml1zg907ne = count++,
            lkbaty4m5ky0af6gpqswc = count++,
            Ee7hc300pnrt4eratqp1m = count++,
            Urz29vmf5s1shkl9n3707 = count++,
            Wd6s3e56y5w9b0kupfiqq = count++,
            Iu57v8mt2rxzsy3ivh940 = count++,
            tqr952rqa1uivrjni8642 = count++,
            eldhi6qm7b9ifn0ad5b3r = count++,
            r5tb6oeapq9wlecomj08l = count++,
            Xet81mch1ikm7cn72ck32 = count++,
            Bq7qbm7blmy3fcsmlvjum = count++,
            P6jggxzi0ewj96g5gd6po = count++,
            Ia5purh5uawh30r5g1kox = count++,
            Xykgzo4i5xfhy4flb4wzp = count++,
            R3y0soqjplyp2r10zyzfw = count++,
            R9964os9uf4mfv939uyl8 = count++,
            au2u80ogcpwmfqcq415d6 = count++,
            Trykqmkhs80faohcho8e9 = count++,
            pl6etshyst8hzuoq5rewq = count++,
            ogydyql0iaip30euuu18e = count++,
            Lvy99spq91gzkly2x3pcg = count++,
            Cqpskto9q35lzfs5syegb = count++,
            t51r4sfsbl71ez1yfgzqe = count++,
            rq9f549f33k9yjalz8y1n = count++,
            g67e6dhan3zm8xbv5vw9t = count++,
            Sayia8c4zq9hr7cis5i1w = count++,
            B919d8aaiopdlyinhye8a = count++,
            Xml74s4bv3cam4mtjzec7 = count++,
            Ucwka552zza30k0kx3evd = count++,
            F9polp0qlyestba80b79w = count++,
            cbl63ijcec5put88wh8uf = count++,
            cpqaurkzj1tw6f8bxtvcf = count++,
            zxmj2z8adclscm3hvkll8 = count++,
            Hu3msjsov6kdw5psdhi5t = count++,
            Qjvhpbtum0qnhjev490tg = count++,
            rtog1i5h7lencq2y8v6rz = count++,
            l8c4p76n13xdryza5pqhf = count++,
            smxawdk1rpxici4hqu03m = count++,
            Zsqdxa5o013tfylnlbimw = count++,
            qe5mgpbi3rtkyw5x5tnvh = count++,
            K6azvecn6r6omoghwe7h9 = count++,
            Xwuiht4s3yr1ywezdg0cm = count++,
            exlmve8kqyb1wfwvm2rbj = count++,
            Mtuiae00kqepn54lkixdv = count++,
            Sucfw0fs9tnlyy23dcmrn = count++,
            li99tvn0kkkdeoqzqpwk8 = count++,
            ki01d21ycbih6fznudvbm = count++,
            sphzijgkhdmyqbtfri614 = count++,
            tyxjcch9zden3u7tbas3w = count++,
            Erq9zt14wt5lh4hx18wgc = count++,
            Ehue8945e9eq0cemhyusl = count++,
            immfi2f9nk1col0p6ma0z = count++,
            x50wpovez4pcne5z4p5f3 = count++,
            F4s3hbcomzq4x43qwz04h = count++,
            Obkt4zzjqburr564m6onl = count++,
            Lh29nuptlpdfza82u88sm = count++,
            s37lf9n278dzkmt9ikfkk = count++,
            Mf8b8p2q7ejo76bsjr4oh = count++,
            owwmmn4mr8tk3yih45m0h = count++,
            D653yy2ola01q0cxsvzvu = count++,
            Gp98u9vix4xneehk13xxu = count++,
            Vpbqi23cvvyjg1f176izd = count++,
            Jt1rnmwms25z7cafns01f = count++,
            msxcfohm8qn4u8tbyud6g = count++,
            vrt3z8ld1anpgrtu6zl8e = count++,
            Yjncpaf9s9r3o4vx93mhd = count++,
            Pev8c7yco8f9jf16dqoy2 = count++,
            Alu2sual55vcme5ayparm = count++,
            Hcuu4stjcytsoyo1t2pr6 = count++,
            amhsmcwfk1hyq7m01a8aa = count++,
            g1jhldyxzdr59tu95ch15 = count++,
            ho9lq5crlyas4oqfd9gjn = count++,
            u8pgkmz6mn4z3gfw280qa = count++,
            ygmbd8bvcp5557o692aeg = count++,
            dfe84lzxi4mfjzjhwodlk = count++,
            oe37r8352jxa7vk4bng2j = count++,
            Ynmic0wfxgjuyz4blhr5r = count++,
            h359hmiypofjhlc61v50m = count++,
            Yyivacli1is45llpsnbzs = count++,
            u70ib9mnw7k0m0t2vj9ea = count++,
            i97g5lo6awootfio89uaz = count++,
            I8v382se2s4in6zsaunzv = count++,
            dqn9t5ggse4vz9pcndhd2 = count++,
            Pjer2fawq0now4ojuwkdv = count++,
            Blwxxitorwe7mj6ml5ho4 = count++,
            tt020q94ufr13errxr4tv = count++,
            fvf3vqbm7c7zo6ibu36hi = count++,
            tz4memeh1py4by2io6gko = count++,
            sx6si2n76p73uwk613zim = count++,
            E4usndy0d9xxxv2v3mem9 = count++,
            zhlmr5jon6rvh88ucneed = count++,
            Yw362jg84zcpznifsibr3 = count++,
            Ekmhsbqyxhsph9innotiz = count++,
            Vlty3b63z3b4mxl2kwo03 = count++,
            krlwgxize51ey32s0ynqf = count++,
            ow84fxduxqc1a3oh97rg3 = count++,
            Ngz4b7gt43bvi7vhtrqtt = count++,
            sycx2ae5ous3hhx86e2ir = count++,
            Ruz3ortcigysq7wfdbbb3 = count++,
            uleklhoakwkoyic99ijlr = count++,
            Wcxh69njus44c0pgppsgc = count++,
            ks2v6j4h5xg520u0x7nm4 = count++,
            lfq11pm735ut0ci8kblwf = count++,
            Tgn7m9cmgyssbgm7ba4q7 = count++,
            Y6oadwezrvqwv0hx2tp1n = count++,
            Wa1fnbsuzl6jg5zi1n305 = count++,
            om4uh66k8yfsudd7fjwbd = count++,
            yuagyhp0b85pzz6afg7rf = count++,
            bhvagnzd12ds02wkmx6aq = count++,
            afja2z35gc19lf5699akr = count++,
            nl8j5nz6dvxsj7a98uiqu = count++,
            L47zadhu6zlnwvsfhaepa = count++,
            n71upjznf67o0u0xoji1f = count;
        }
        #endregion
        #region num
        public static List<uint> ins1 = new List<uint>();
        public static List<double> ins2 = new List<double>();
        public static List<uint> ins3 = new List<uint>();
        public static List<uint> ins4 = new List<uint>();

        private class mcNum
        {
            public static int count = 0;
            public static int
            num1_1 = count++,
            num1_2 = count++,
            num1_3 = count++,
            num2_1 = count++,
            num2_2 = count++,
            num2_3 = count++,
            num3_1 = count++,
            num3_2 = count++,
            num3_3 = count++,
            num4_1 = count++,
            num4_2 = count++,
            num4_3 = count++,
            num5_1 = count++,
            num5_2 = count++,
            num5_3 = count++,
            num6_1 = count++,
            num6_2 = count++,
            num6_3 = count++,
            num7_1 = count++,
            num7_2 = count++,
            num7_3 = count++,
            num8_1 = count++,
            num8_2 = count++,
            num8_3 = count++,
            num10_1 = count++,
            num10_2 = count++,
            num11_1 = count++,
            num11_2 = count++,
            num12_1 = count++,
            num12_2 = count++,
            num13_1 = count++,
            num13_2 = count++,
            num14_1 = count++,
            num14_2 = count++,
            num15_1 = count++,
            num15_2 = count++,
            num16_1 = count++,
            num16_2 = count++,
            num17_1 = count++,
            num17_2 = count;
        }
        public static double getNum(int num)
        {
            return ins2[num];
        }
        #endregion
        #endregion

        #region setup toolstrip
        private void setupTS()
        {
            timer1.Stop();
            timer1.Start();
            countSM = 0;
            // oooooooooooooo();

            menuOptTxt.Clear();
            menuOptState.Clear();
            sycx2ae5ous3hhx86e2ir.Clear();
            menuOptStartIndex.Clear();
            optsMax.Clear();
            string[] main1 = { MF_SubMenu + "Non-host", MF_SubMenu + "Host Required" };
            string[] _main1 = { MF_SubMenu + "Non-host", MF_SubMenu + "Host Required", MF_SubMenu + "SPRX Options" };
            addMenuOpt(0, 0, 0, main1);

            string[] main1_sub1 = { MF_SubMenu + "Combat", MF_SubMenu + "Explore", MF_SubMenu + "Action", MF_SubMenu + "Entities", MF_SubMenu + "Weather", MF_SubMenu + "Visuals", MF_SubMenu + "Camera", MF_SubMenu + "HUD", MF_SubMenu + "Blocks", MF_SubMenu + "Game Settings", MF_SubMenu + "Name Changer" };
            string[] main1_sub2 = { MF_SubMenu + "Combat", MF_SubMenu + "Items", MF_SubMenu + "Enities", MF_SubMenu + "Enchantement", MF_SubMenu + "Explosion", MF_SubMenu + "Weather", MF_SubMenu + "Water", MF_SubMenu + "Game Settings", };
            string[] main1_sub3 = { MF_SubMenu + "Combat", MF_SubMenu + "Explore" };
            addMenuOpt(1, 0, 0, main1_sub1);
            addMenuOpt(2, 0, 0, main1_sub2);
            // addMenuOpt(3, 0, 0, main1_sub3);
            #region combat
            string[] main1_sub1_opt1_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Damage" };
            string[] main1_sub1_opt1_lvl2 = { MF_ComboBox + mc_list.HIT_SPAN, MF_ComboBox + mc_list.ACTION_REACH, MF_ComboBox + mc_list.ACTION_SPEED, MF_Trackbar + ult_list.SOURCE_KILL, MF_Trackbar + ult_list.DAMAGE_COLOR };
            string[] main1_sub1_opt1_lvl3 = { MF_CheckBox + ult_list.REACH_ATTACK, MF_CheckBox + ult_list.UNFAIR_ATTACK, MF_CheckBox + ult_list.CRITICAL_HIT_V1, MF_CheckBox + ult_list.CRITICAL_HIT_V2, MF_CheckBox + ult_list.INSTANT_HIT, MF_CheckBox + ult_list.KILL_AURA, MF_CheckBox + ult_list.AUTO_HIT, MF_CheckBox + ult_list.AUTO_KILL_MOBS_SPAWNED, MF_CheckBox + ult_list.AUTO_KILL_PLAYERS, MF_CheckBox + ult_list.DAMAGE_HIT_RED_BLUE, MF_CheckBox + ult_list.HITBOX_BETA, MF_CheckBox + ult_list.KNOCKBACK_V1, MF_CheckBox + ult_list.NO_KNOCKBACK, MF_CheckBox + ult_list.PRESS_X_FOR_HIT, MF_CheckBox + ult_list.DETECT_IF_PLAYERS_HAS_BEEN_ALREADY_DAMAGED, MF_CheckBox + ult_list.KILL_DISAPPEAR_ENTITY, MF_CheckBox + ult_list.STARVED_ALL_PLAYERS_IN_BATTLE_WORLD, MF_CheckBox + ult_list.SUICIDE };
            addMenuOpt(1, 1, 1, main1_sub1_opt1_lvl1);
            addMenuOpt(1, 1, 2, main1_sub1_opt1_lvl2);
            addMenuOpt(1, 1, 3, main1_sub1_opt1_lvl3);
            int count_1122 = 0;
            string[][] main1_sub1_opt1_lvl2_Combo = new string[100][];
            main1_sub1_opt1_lvl2_Combo[count_1122++] = new string[] { "Default", "None", "Short", "Medium", "Far" }; optsMax.Add(mc_list.HIT_SPAN + ";5");
            main1_sub1_opt1_lvl2_Combo[count_1122++] = new string[] { "Default", "None", "Short", "Medium", "Far" }; optsMax.Add(mc_list.ACTION_REACH + ";5");
            main1_sub1_opt1_lvl2_Combo[count_1122++] = new string[] { "Default", "None", "Slow", "Medium", "Fast" }; optsMax.Add(mc_list.ACTION_SPEED + ";5");
            main1_sub1_opt1_lvl2_Combo[count_1122++] = new string[] { "4" }; optsMax.Add(ult_list.SOURCE_KILL + ";4");
            main1_sub1_opt1_lvl2_Combo[count_1122++] = new string[] { "3" }; optsMax.Add(ult_list.DAMAGE_COLOR + ";3");
            #endregion

            #region explore
            string[] main1_sub1_opt2_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Fly", MF_SubMenu + "World View", MF_SubMenu + "ESP", MF_SubMenu + "Movement" };
            string[] main1_sub1_opt2_lvl2 = { MF_Trackbar + mc_list.X_RAY, MF_Trackbar + mc_list.BODY_LIGHT, MF_Trackbar + mc_list.TIME_OF_DAY, MF_Trackbar + mc_list.ENTITIY_GRAVITY, MF_Trackbar + mc_list.ENTITIY_SPEED, MF_Trackbar + mc_list.EXIT_WATER, MF_Trackbar + mc_list.VERTICAL_SWIM, MF_Trackbar + mc_list.SWIM_SPEED };
            string[] main1_sub1_opt2_lvl3 = { MF_CheckBox + ult_list.UFO_MODE, MF_CheckBox + mc_list.GLIDE, MF_CheckBox + mc_list.SWIM_MODE, MF_CheckBox + mc_list.SKY_MODE, MF_CheckBox + ult_list.CAN_FLY, MF_CheckBox + mc_list.FAST_FLY, MF_CheckBox + ult_list.FLOAT_UP, MF_CheckBox + ult_list.FLY_MODE_X, MF_CheckBox + ult_list.FLY_OR_RUN_ON_CROUCH, MF_CheckBox + ult_list.LEVITATION, MF_CheckBox + ult_list.OLD_FLY_OPTIONS, MF_CheckBox + ult_list.UFO_MODE, MF_CheckBox + ult_list.MULTI_JUMP, MF_CheckBox + ult_list.MULTI_JUMP_V2 };
            string[] main1_sub1_opt2_lvl4 = { MF_CheckBox + mc_list.INVISIBLE_BLOCKS, MF_CheckBox + mc_list.TRANSPARENT_LEVEL, MF_CheckBox + ult_list.CAN_SEE_UNDER_WORLD, MF_CheckBox + ult_list.NO_COLISSION, MF_CheckBox + ult_list.NO_COLISSION_BYPASS, MF_CheckBox + ult_list.NO_COLISSION_ENTITY, MF_CheckBox + ult_list.SEE_OUTSIDE_MAP, MF_CheckBox + ult_list.WALL_HACK_V1, MF_CheckBox + ult_list.WALL_HACK_V2, MF_CheckBox + ult_list.WALL_HACK_V3, MF_CheckBox + ult_list.X_RAY, MF_CheckBox + mc_list.UNDER_WATER_VIEW, MF_CheckBox + ult_list.NETHER_VISION, MF_CheckBox + ult_list.NIGHT_VISION, MF_CheckBox + mc_list.NEAR_BY_SOUNDS };
            string[] main1_sub1_opt2_lvl5 = { MF_CheckBox + ult_list.EPS_CHEST_V3, MF_CheckBox + ult_list.ESP_CHESTS_V1, MF_CheckBox + ult_list.ESP_CHESTS_V2, MF_CheckBox + ult_list.ESP_ENTITY_BLUE, MF_CheckBox + ult_list.ESP_ENTITY_RED, MF_CheckBox + ult_list.ESP_PLAYERS };
            string[] main1_sub1_opt2_lvl6 = { MF_CheckBox + ult_list.FROST_WALKER, MF_CheckBox + mc_list.SPACE_JUMP, MF_CheckBox + ult_list.SUPER_JUMP, MF_CheckBox + ult_list.SUPER_JUMP_V2, MF_CheckBox + ult_list.SUPER_SPEED, MF_CheckBox + ult_list.SUPER_SPEED_LEGIT, MF_CheckBox + ult_list.SUPER_SPEED_V3, MF_CheckBox + ult_list.SUPER_SPEED_V4, MF_CheckBox + ult_list.SUPER_SPEED_V5, MF_CheckBox + ult_list.SUPER_SPEED_V6, MF_CheckBox + ult_list.SUPER_SPEED_V7, MF_CheckBox + ult_list.TOGGLE_SPRINT, MF_CheckBox + ult_list.TOGGLE_SPRINT_V2, MF_CheckBox + ult_list.NEW_SUPER_SPEED, MF_CheckBox + ult_list.NO_SLOW_DOWN, MF_CheckBox + ult_list.AUTO_JUMP, MF_CheckBox + ult_list.AUTO_LADDER, MF_CheckBox + mc_list.NORMALIZE_CROUCH };
            addMenuOpt(1, 2, 1, main1_sub1_opt2_lvl1);
            addMenuOpt(1, 2, 2, main1_sub1_opt2_lvl2);
            addMenuOpt(1, 2, 3, main1_sub1_opt2_lvl3);
            addMenuOpt(1, 2, 4, main1_sub1_opt2_lvl4);
            addMenuOpt(1, 2, 5, main1_sub1_opt2_lvl5);
            addMenuOpt(1, 2, 6, main1_sub1_opt2_lvl6);
            int count_1112 = 0;
            string[][] main1_sub1_opt2_lvl2_Combo = new string[100][];
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "16" }; optsMax.Add(mc_list.X_RAY + ";16");
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "7" }; optsMax.Add(mc_list.BODY_LIGHT + ";7");
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "6" }; optsMax.Add(mc_list.TIME_OF_DAY + ";6");

            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "5" }; optsMax.Add(mc_list.ENTITIY_GRAVITY + ";5");
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "5" }; optsMax.Add(mc_list.ENTITIY_SPEED + ";5");
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "6" }; optsMax.Add(mc_list.EXIT_WATER + ";6");
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "6" }; optsMax.Add(mc_list.VERTICAL_SWIM + ";6");
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "6" }; optsMax.Add(mc_list.SWIM_SPEED + ";6");

            #endregion

            #region menu
            string[] _main1_sub3_opt1_lvl1 = { MF_Trackbar + "Aimbot Command", MF_Trackbar + "Entity Filter", MF_Trackbar + "Entity Radius", MF_Trackbar + "Aim Key", MF_Trackbar + "Aim Reset Key", MF_Trackbar + "Aim Position", MF_CheckBox + "Auto Hit Proximity", MF_CheckBox + "Target Info", MF_CheckBox + "Target Locator" };
            string[] _main1_sub3_opt2_lvl1 = { MF_CheckBox + "Radar", MF_Trackbar + "Compass Pointer", MF_Trackbar + "Entity Filter", MF_Trackbar + "Entity Radius", MF_CheckBox + "Depth Indicator", MF_Trackbar + "Compass Radius", MF_CheckBox + "Self Info" };
            // addMenuOpt(3, 1, 1, _main1_sub3_opt1_lvl1);
            // addMenuOpt(3, 2, 1, _main1_sub3_opt2_lvl1);
            #endregion

            #region action
            string[] main1_sub1_opt3_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Mine", MF_SubMenu + "Build", MF_SubMenu + "Auto", MF_SubMenu + "Arms", MF_SubMenu + "Swim", MF_SubMenu + "Movement" };
            string[] main1_sub1_opt3_lvl2 = { MF_Trackbar + mc_list.CONTRAST, MF_ComboBox + mc_list.PLAYER_DIMENSION };
            string[] main1_sub1_opt3_lvl3 = { MF_CheckBox + ult_list.INSTANT_MINE, MF_CheckBox + ult_list.MINE_IN_ADVENTURE, MF_CheckBox + ult_list.WATER_SLOW_DOWN };
            string[] main1_sub1_opt3_lvl4 = { MF_CheckBox + ult_list.FAST_BUILD, MF_CheckBox + ult_list.PLACE_BLOCKS_IN_BATTLE_WORLDS, MF_CheckBox + ult_list.INSTANT_PLACE_SURVIVAL, MF_CheckBox + ult_list.AUTO_BUILD_IN_SURVIVAL, };
            string[] main1_sub1_opt3_lvl5 = { MF_CheckBox + ult_list.AUTO_TOSS_ITEMS, MF_CheckBox + ult_list.AUTO_CROUCH, MF_CheckBox + ult_list.AUTO_VIEW, MF_CheckBox + ult_list.AUTO_CROUCH_ON_MOVEMENT, MF_CheckBox + ult_list.AUTO_MINE, };
            string[] main1_sub1_opt3_lvl6 = { MF_CheckBox + ult_list.ARMS_HIT_SPEED, MF_CheckBox + ult_list.ARMS_AND_LEGS_WEIRD, MF_CheckBox + ult_list.FUNNY_ARMS_LEGS, MF_CheckBox + ult_list.HIDE_ARMS, MF_CheckBox + ult_list.ARMS_BROKEN_V2, };
            string[] main1_sub1_opt3_lvl7 = { MF_CheckBox + ult_list.REMOVE_SWIM, MF_CheckBox + ult_list.ANIM_SWIM_FLY, MF_CheckBox + ult_list.DISABLE_SWIM, MF_CheckBox + ult_list.SWIM_GLITCH, };
            string[] main1_sub1_opt3_lvl8 = { MF_CheckBox + ult_list.STATIC_MOVEMENT, MF_CheckBox + ult_list.WALK_ALONE, MF_CheckBox + ult_list.WALK_IN_SKY, MF_CheckBox + ult_list.STOP_WALK_ANIMATIONS, MF_CheckBox + ult_list.FAST_MOVE_LEGS_ARMS, MF_CheckBox + ult_list.FOOT_STEP_FAST, MF_CheckBox + ult_list.FOOT_STEP_SLOW, MF_CheckBox + ult_list.VIBRATE_WALK, MF_CheckBox + ult_list.INSTANT_JUMP_IN_SKY, MF_CheckBox + ult_list.JUMP_FORWARD, MF_CheckBox + ult_list.JUMP_FOR_BUILD, MF_CheckBox + ult_list.JUMP_IN_LAVA, MF_CheckBox + ult_list.JUMP_SPEED, MF_CheckBox + ult_list.LEGS_IN_AIR, MF_CheckBox + ult_list.REMOVE_JUMP, MF_CheckBox + ult_list.REMOVE_ANIMATION_RUN, MF_CheckBox + ult_list.REAL_JUMP_ANIMATION, MF_CheckBox + ult_list.ANIMATION_RUNNING, MF_CheckBox + ult_list.MOVEMENT_SWIM, MF_CheckBox + ult_list.DISABLE_FLY_CREATIVE, MF_CheckBox + ult_list.DISABLE_RUN, MF_CheckBox + ult_list.VELOCITY_BIG, MF_CheckBox + ult_list.VELOCITY_SMALL, MF_CheckBox + ult_list.STOP_SHOW_LOGS_NOTIFS, };

            addMenuOpt(1, 3, 1, main1_sub1_opt3_lvl1);
            addMenuOpt(1, 3, 2, main1_sub1_opt3_lvl2);
            addMenuOpt(1, 3, 3, main1_sub1_opt3_lvl3);
            addMenuOpt(1, 3, 4, main1_sub1_opt3_lvl4);
            addMenuOpt(1, 3, 5, main1_sub1_opt3_lvl5);
            addMenuOpt(1, 3, 6, main1_sub1_opt3_lvl6);
            addMenuOpt(1, 3, 7, main1_sub1_opt3_lvl7);
            addMenuOpt(1, 3, 8, main1_sub1_opt3_lvl8);

            int count_1132 = 0;
            string[][] main1_sub1_opt3_lvl1_Combo = new string[100][];
            main1_sub1_opt3_lvl1_Combo[count_1132++] = new string[] { "11" }; optsMax.Add(mc_list.CONTRAST + ";11");
            main1_sub1_opt3_lvl1_Combo[count_1132++] = new string[] { "Default", "2D", "Big", "Huge" }; optsMax.Add(mc_list.PLAYER_DIMENSION + ";4");

            #endregion

            #region Entites
            string[] main1_sub1_opt4_lvl1 = { MF_SubMenu + "All", MF_SubMenu + "Players", MF_SubMenu + "Mobs", MF_SubMenu + "Character", MF_SubMenu + "Anti", MF_SubMenu + "Skins", MF_SubMenu + "Misc." };
            string[] main1_sub1_opt4_lvl2 = { MF_CheckBox + mc_list.SLIDING, MF_CheckBox + mc_list.UPSIDE_DOWN_ENTITIES, MF_CheckBox + ult_list.ENTITY_INVISIBLE, MF_CheckBox + ult_list.ENTITY_RENDER, MF_CheckBox + ult_list.ENTITY_SKINS_RED, MF_CheckBox + ult_list.ENTITY_TO_BABY, MF_CheckBox + ult_list.ELYTRA_ON_ALL_ENTITY, MF_CheckBox + mc_list.UPSIDE_DOWN_ENTITIES, MF_CheckBox + mc_list.FIRE_ANIMATION, MF_CheckBox + mc_list.SWIM_ANIMATION, };
            string[] main1_sub1_opt4_lvl3 = { MF_CheckBox + mc_list.IMITATE_HOST, MF_CheckBox + ult_list.REMOVE_POINTER_AIM, MF_CheckBox + ult_list.IRON_HELMET_EVERYONE, MF_CheckBox + ult_list.FIRE_INSTANT_REMOVED, MF_CheckBox + ult_list.NAME_AND_SHADOW_BLACK, MF_CheckBox + ult_list.NAME_OVER_HEAD, MF_CheckBox + ult_list.NAME_OVER_HEAD_DOUBLE, MF_CheckBox + ult_list.NAME_OVER_HEAD_GO_UP_DOWN, };
            string[] main1_sub1_opt4_lvl4 = { MF_CheckBox + ult_list.MAKE_CREEPER_BIG, MF_CheckBox + ult_list.FIRE_CREEPER_EXPLODE, MF_CheckBox + ult_list.ENDERMAN_AND_CHORUS_FRUIT_CANT_BE_TELEPORTED, };
            string[] main1_sub1_opt4_lvl5 = { MF_CheckBox + ult_list.ROTATION_BODY, MF_CheckBox + ult_list.ROTATION_HEAD_360_DEGRES, MF_CheckBox + ult_list.REMOVE_ANIMATION_DETAILED_SKINS, MF_CheckBox + ult_list.REMOVE_HANDS, MF_CheckBox + ult_list.PLAYERS_BIG_MODELS, MF_CheckBox + ult_list.PLAYERS_BODY_LIGHT, MF_CheckBox + ult_list.PLAYERS_LISTS, MF_CheckBox + ult_list.PLAYERS_ON_ELYTRA, MF_CheckBox + ult_list.PLAYERS_PAPER_MODELS, MF_CheckBox + ult_list.PLAYERS_SKATE_MODE, MF_CheckBox + ult_list.PLAYERS_SLIDE, MF_CheckBox + ult_list.MOVE_HEAD_BUT_NOT_BODY, MF_CheckBox + ult_list.BIG_ANIMATION_CHARACTER, MF_CheckBox + ult_list.ANIMATION_CHARACTER, };
            string[] main1_sub1_opt4_lvl6 = { MF_CheckBox + ult_list.ANTI_AFK, MF_CheckBox + ult_list.ANTI_AFK_V2, MF_CheckBox + ult_list.ANTI_AFK_V3, MF_CheckBox + ult_list.ANTI_KICK_PREMIUM, MF_CheckBox + ult_list.ANTI_TELEPORT_BY_HOST, };
            string[] main1_sub1_opt4_lvl7 = { MF_CheckBox + ult_list.CAN_SEE_REAL_SKINS_IN_SPECTATOR, MF_CheckBox + ult_list.DEBUG_SKINS_TEXTURE, MF_CheckBox + ult_list.SHADOW_SKINS_PLAYERS, MF_CheckBox + ult_list.SHADOW_SKINS_V2, MF_CheckBox + ult_list.ROBLOX_ANIMATION, };
            string[] main1_sub1_opt4_lvl8 = { MF_CheckBox + ult_list.RAYMAN_MODE, MF_CheckBox + ult_list.LABYMOD_SETTINGS, MF_CheckBox + ult_list.SHOW_ARMOR, MF_CheckBox + ult_list.PLAYERS_POSITION, MF_CheckBox + ult_list.DISABLE_PLAYERS, MF_CheckBox + ult_list.GHOST_PLAYERS, MF_CheckBox + ult_list.ENABLE_AIM_ON_3TH_PRESON, };
            addMenuOpt(1, 4, 1, main1_sub1_opt4_lvl1);
            addMenuOpt(1, 4, 2, main1_sub1_opt4_lvl2);
            addMenuOpt(1, 4, 3, main1_sub1_opt4_lvl3);
            addMenuOpt(1, 4, 4, main1_sub1_opt4_lvl4);
            addMenuOpt(1, 4, 5, main1_sub1_opt4_lvl5);
            addMenuOpt(1, 4, 6, main1_sub1_opt4_lvl6);
            addMenuOpt(1, 4, 7, main1_sub1_opt4_lvl7);
            addMenuOpt(1, 4, 8, main1_sub1_opt4_lvl8);

            #endregion

            #region weather
            string[] main1_sub1_opt5_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Misc.", };
            string[] main1_sub1_opt5_lvl2 = { MF_Trackbar + ult_list.CLOUD_COLORS, MF_Trackbar + ult_list.SUN_MOON_SIZE, MF_Trackbar + ult_list.WEATHER_STATE, };
            string[] main1_sub1_opt5_lvl3 = { MF_CheckBox + ult_list.WEATHER_RAIN, MF_CheckBox + ult_list.WEATHER_SNOW, MF_CheckBox + ult_list.SMALL_RAIN, MF_CheckBox + ult_list.WEATHER_TO_RAIN_ANYTIME, MF_CheckBox + ult_list.DISABLE_CHANGING_WEATHER, MF_CheckBox + ult_list.DAYS_NIGHT, MF_CheckBox + ult_list.DISABLE_FOG, MF_CheckBox + mc_list.FOG, MF_CheckBox + mc_list.BLACK_HORIZON, MF_CheckBox + mc_list.BRIGHT_STARS, MF_CheckBox + ult_list.REMOVE_STARS_IN_SKY, MF_CheckBox + ult_list.FLASH_STARS_IN_SKY, MF_CheckBox + mc_list.HIDE_CLOUDS, MF_CheckBox + mc_list.DUSK, };
            addMenuOpt(1, 5, 1, main1_sub1_opt5_lvl1);
            addMenuOpt(1, 5, 2, main1_sub1_opt5_lvl2);
            addMenuOpt(1, 5, 3, main1_sub1_opt5_lvl3);

            string[][] main1_sub1_opt5_lvl2_Combo = new string[100][];
            int count_1152 = 0;
            main1_sub1_opt5_lvl2_Combo[count_1152++] = new string[] { "9" }; optsMax.Add(ult_list.CLOUD_COLORS + ";9");
            main1_sub1_opt5_lvl2_Combo[count_1152++] = new string[] { "9" }; optsMax.Add(ult_list.SUN_MOON_SIZE + ";9");
            main1_sub1_opt5_lvl2_Combo[count_1152++] = new string[] { "10" }; optsMax.Add(ult_list.WEATHER_STATE + ";10");
            #endregion

            #region visuals
            string[] main1_sub1_opt6_lvl1 = { MF_SubMenu + "Editors", MF_CheckBox + ult_list.TEXTURE_BLACK, MF_CheckBox + ult_list.TEXTURE_PLASTIC, MF_CheckBox + ult_list.RAINBOW_LIGHT, MF_CheckBox + ult_list.RAINBOW_STORM, MF_CheckBox + ult_list.SMOKE_LOBBY, MF_CheckBox + ult_list.SKY_TO_NETHER, MF_CheckBox + ult_list.SKY_TO_RAINBOW_WITH_SNOW, MF_CheckBox + ult_list.FOG_BLACK, MF_CheckBox + ult_list.FOG_BLUE, MF_CheckBox + ult_list.LIGHT_EYES_ENDERMAN, MF_CheckBox + ult_list.LIGHT_MAKE_MORE_POWER, MF_CheckBox + ult_list.HORROR_VIEW, };
            string[] main1_sub1_opt6_lvl2 = { MF_ComboBox + mc_list.SKY_COLOR, MF_ComboBox + mc_list.LIGHT_COLOR, MF_ComboBox + mc_list.BLOCK_CRACK_COLOR, MF_Seperator + mc_list.HUD_COLOR, MF_ComboBox + mc_list.HUD_COLOR, MF_button + mc_list.HUD_COLOR, };
            addMenuOpt(1, 6, 1, main1_sub1_opt6_lvl1);
            addMenuOpt(1, 6, 2, main1_sub1_opt6_lvl2);

            int count_1162 = 0;
            string[][] main1_sub1_opt6_lvl2_Combo = new string[100][];
            main1_sub1_opt6_lvl2_Combo[count_1162++] = new string[] { "Default", "Red", "Green", "Blue", "Dark" }; optsMax.Add(mc_list.SKY_COLOR + ";5");
            main1_sub1_opt6_lvl2_Combo[count_1162++] = new string[] { "Default", "None", "Bright", "Dark", "Green" }; optsMax.Add(mc_list.LIGHT_COLOR + ";5");
            main1_sub1_opt6_lvl2_Combo[count_1162++] = new string[] { "Default", "Rainbow", "Black", "None" }; optsMax.Add(mc_list.BLOCK_CRACK_COLOR + ";4");
            main1_sub1_opt6_lvl2_Combo[4] = new string[] { "Off", "Rainbow", "Flashing" }; optsMax.Add(mc_list.HUD_COLOR + ";3");
            #endregion

            #region camera
            string[] main1_sub1_opt7_lvl1 = { MF_SubMenu + "Editors", MF_CheckBox + mc_list.CAMERA_ROTATION, MF_CheckBox + ult_list.ZOOM_WITHOUT_HAND, MF_CheckBox + ult_list.FOV_WITHOUT_HAND, MF_CheckBox + ult_list.SHAKE_CAMERA, MF_CheckBox + ult_list.CAMERA_LEFT_POSITION, MF_CheckBox + ult_list.CAMERA_RIGHT_POSITION, MF_CheckBox + ult_list.CAM_DOWN, MF_CheckBox + ult_list.CAM_DOWN_R3, MF_CheckBox + ult_list.FREE_CAM, MF_CheckBox + ult_list.POSITIONS_PLACE, MF_CheckBox + ult_list.POSITION_VIEW, MF_CheckBox + ult_list.LOOK_FORBACK };
            string[] main1_sub1_opt7_lvl2 = { MF_Trackbar + mc_list.FIELD_OF_VIEW, MF_Trackbar + mc_list.CAMERA_ZOOM, MF_Trackbar + ult_list.HAND_POSITION };
            addMenuOpt(1, 7, 1, main1_sub1_opt7_lvl1);
            addMenuOpt(1, 7, 2, main1_sub1_opt7_lvl2);

            int count_1172 = 0;
            string[][] main1_sub1_opt7_lvl1_Combo = new string[100][];
            main1_sub1_opt7_lvl1_Combo[count_1172++] = new string[] { "20" }; optsMax.Add(mc_list.FIELD_OF_VIEW + ";20");
            main1_sub1_opt7_lvl1_Combo[count_1172++] = new string[] { "7" }; optsMax.Add(mc_list.CAMERA_ZOOM + ";7");
            main1_sub1_opt7_lvl1_Combo[count_1172++] = new string[] { "10" }; optsMax.Add(ult_list.HAND_POSITION + ";10");

            #endregion

            #region hud
            string[] main1_sub1_opt8_lvl1 = { MF_CheckBox + ult_list.SIZE_HUD, MF_CheckBox + ult_list.POSITIONS_HUD, MF_CheckBox + ult_list.DISALBE_HUD_TEXT, MF_CheckBox + ult_list.SMALL_TEXT, MF_CheckBox + ult_list.REMOVE_ALL_TEXT, MF_CheckBox + ult_list.TEXT_TO_ALIEN, MF_CheckBox + ult_list.REMOVE_HURT_CAM, MF_CheckBox + ult_list.REMOVE_INVENTORY_HUD, MF_CheckBox + mc_list.HIDE_HOT_BAR, MF_CheckBox + ult_list.SCREEN_DEAD, MF_CheckBox + ult_list.SEMI_BLACKSCREEN, MF_CheckBox + ult_list.HUD_HIDE_EVERYTHING, MF_CheckBox + ult_list.HUD_INVENTORY_DOWN_ON_SCREEN, MF_CheckBox + ult_list.HUD_MINI_GAME, MF_CheckBox + ult_list.HUD_SHOW_PLAYERS_AROUND_YOU, MF_CheckBox + ult_list.DRAW_MODE, MF_CheckBox + ult_list.bunifuImage1, MF_CheckBox + ult_list.bunifuImage2, };
            addMenuOpt(1, 8, 1, main1_sub1_opt8_lvl1);

            #endregion

            #region blocks
            string[] main1_sub1_opt9_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Misc.", MF_SubMenu + "Frosted Ice", MF_SubMenu + "Eggs" };
            string[] main1_sub1_opt9_lvl2 = { MF_Trackbar + ult_list.SELECTED_BLOCKS, MF_Trackbar + ult_list.ITEMS_IN_HAND, MF_Trackbar + ult_list.ITEMS_SIZE, MF_Trackbar + ult_list.ITEMS_2TH_HAND, };
            string[] main1_sub1_opt9_lvl3 = { MF_CheckBox + mc_list.BLACK_BOXES, MF_CheckBox + mc_list.NO_BOXES, MF_CheckBox + ult_list.IDS_ITEMS, MF_CheckBox + ult_list.CREATIVE_INVENTORY_IN_LOBBY, MF_CheckBox + ult_list.ENABLE_SPECIAL_BLOCK, MF_CheckBox + ult_list.ENABLE_TAKE_EVERYTHING_IN_CHESTS, MF_CheckBox + ult_list.GET_64_ITEMS_BLOCKS, MF_CheckBox + ult_list.GET_CRAFTING_IN_BATTLE_WORLD, MF_CheckBox + ult_list.INFINITE_BLOCK, MF_CheckBox + ult_list.INFINITE_CRAFT, MF_CheckBox + ult_list.STUCK_IN_BLOCKS, MF_CheckBox + ult_list.SCAFFOLD_BETA, MF_CheckBox + ult_list.BLOCKS_HAND_UP, MF_CheckBox + ult_list.BLOCKS_STATIC_CRACK, MF_CheckBox + ult_list.FLAT_BLOCKS, MF_CheckBox + ult_list.ARROWS_BLOCKS_ITEMS, MF_CheckBox + ult_list.LINES_BLOCKS_MOVE, MF_CheckBox + ult_list.NETHER_PORTAL_WITH_DIRT, MF_CheckBox + ult_list.FAST_BROKEN_BLOCKS_IN_CREATIVE, MF_CheckBox + ult_list.GET_IDS_PLAYERS_ON_HEAD, MF_CheckBox + ult_list.INVENTORY_SPECIAL_BLOCKS, MF_CheckBox + ult_list.PERMISSIONS_DESTROY_BLOCKS };
            string[] main1_sub1_opt9_lvl4 = { MF_CheckBox + ult_list.FROSTED_ICE_TO_BARRIERE, MF_CheckBox + ult_list.FROSTED_ICE_TO_EGGS_DRAGON, MF_CheckBox + ult_list.FROSTED_ICE_TO_REAPETING_COMMAND_BLOCK, MF_CheckBox + ult_list.FROSTED_ICE_TO_GREEN_COMMAND_BLOCK, MF_CheckBox + ult_list.FROSTED_ICE_TO_COMMAND_BLOCK, MF_CheckBox + ult_list.FROSTED_ICE_TO_DEFAULT, MF_CheckBox + ult_list.FROSTED_ICE_TO_MAGMA, MF_CheckBox + ult_list.FROSTED_ICE_TO_ENDER_GATEWAY, MF_CheckBox + ult_list.FROSTED_ICE_TO_DAIMOND_ORE, MF_CheckBox + ult_list.FROSTED_ICE_TO_SIGN, };
            string[] main1_sub1_opt9_lvl5 = { MF_CheckBox + ult_list.SPAWN_DRAGON_EGGS, MF_CheckBox + ult_list.SPAWN_WHITER_EGGS, MF_CheckBox + ult_list.SPAWN_BUNNY_KILLER_EGGS, MF_CheckBox + ult_list.SPAWN_GIANT_EGGS, MF_CheckBox + ult_list.SPAWN_IRON_GOLEM_EGGS, MF_CheckBox + ult_list.SPAWN_SNOWBALL_EGGS, MF_CheckBox + ult_list.SPAWN_ARMOR_STAND_EGGS, };
            addMenuOpt(1, 9, 1, main1_sub1_opt9_lvl1);
            addMenuOpt(1, 9, 2, main1_sub1_opt9_lvl2);
            addMenuOpt(1, 9, 3, main1_sub1_opt9_lvl3);
            addMenuOpt(1, 9, 4, main1_sub1_opt9_lvl4);
            addMenuOpt(1, 9, 5, main1_sub1_opt9_lvl5);

            string[][] main1_sub1_opt9_lvl2_Combo = new string[100][];
            int count_1192 = 0;
            main1_sub1_opt9_lvl2_Combo[count_1192++] = new string[] { "12" }; optsMax.Add(ult_list.SELECTED_BLOCKS + ";12");
            main1_sub1_opt9_lvl2_Combo[count_1192++] = new string[] { "7" }; optsMax.Add(ult_list.ITEMS_IN_HAND + ";7");
            main1_sub1_opt9_lvl2_Combo[count_1192++] = new string[] { "8" }; optsMax.Add(ult_list.ITEMS_SIZE + ";8");
            main1_sub1_opt9_lvl2_Combo[count_1192++] = new string[] { "4" }; optsMax.Add(ult_list.ITEMS_2TH_HAND + ";4");

            #endregion

            #region game settings
            string[] main1_sub1_opt10_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Settings", MF_SubMenu + "Game Ending", MF_SubMenu + "Visuals", MF_SubMenu + "Particals", MF_SubMenu + "Misc." };
            string[] main1_sub1_opt10_lvl2 = { MF_Trackbar + ult_list.XP_LEVELV2, MF_Trackbar + ult_list.FPS_VALUES, MF_Trackbar + ult_list.TIME_SPEED, MF_Trackbar + ult_list.TIMECYCLE, MF_Trackbar + ult_list.TIMECYCLE_V2, MF_Trackbar + ult_list.WORLD_DIMENSION, MF_Trackbar + ult_list.NETHER_DIMENSION, MF_Trackbar + ult_list.THE_END_DIMENSION, };
            string[] main1_sub1_opt10_lvl3 = { MF_CheckBox + ult_list.SENSIBILITY_FAST, MF_CheckBox + ult_list.SENSIBILITY_MAX, MF_CheckBox + ult_list.GAMMA_TO_MAX, MF_CheckBox + ult_list.SWITCH_GAME_TO_OFFLINE, MF_CheckBox + ult_list.SURVIVAL_IN_LOBBY, MF_CheckBox + ult_list.SPLIT_SCREEN, MF_CheckBox + ult_list.STOP_CHUNKS_LOAD, MF_CheckBox + ult_list.OPTIMIZE_CHUNKS_LOAD, };
            string[] main1_sub1_opt10_lvl4 = { MF_CheckBox + ult_list.KICK_TO_XMB_HUD, MF_CheckBox + ult_list.RETURN_TO_XMB, MF_CheckBox + ult_list.DESTROY_GAME, MF_CheckBox + ult_list.CORRUPT_WORLD, MF_CheckBox + ult_list.FREEZE_THE_WORLD_WITH_EGG, };
            string[] main1_sub1_opt10_lvl5 = { MF_CheckBox + ult_list.LOBBY_MESSAGES, MF_CheckBox + ult_list.LOBBY_MESSAGES_SPAM, MF_CheckBox + ult_list.FUNNY_SCREEN, MF_CheckBox + ult_list.SMALL_GRAPHIC, MF_CheckBox + ult_list.SHOCKWAVE_EFFECT, };
            string[] main1_sub1_opt10_lvl6 = { MF_CheckBox + ult_list.BIG_PARTICLES, MF_CheckBox + ult_list.BREAK_PARTICLES_FLY, MF_CheckBox + ult_list.BROKEN_TEXTURES, MF_CheckBox + ult_list.FREEZE_PARTICLES, MF_CheckBox + ult_list.REMOVE_PARTICLES, MF_CheckBox + ult_list.PARTICLES_DAMAGE_NO_STOP, MF_CheckBox + ult_list.PARTICLES_FLY_V2, MF_CheckBox + ult_list.PARTICLES_TORNADO, MF_CheckBox + ult_list.RUNNING_PARTICLES_SPECTRAL, MF_CheckBox + ult_list.RUNNING_PARTICLES_WEIRD, };
            string[] main1_sub1_opt10_lvl7 = { MF_CheckBox + ult_list.DRIFT_BOAT, MF_CheckBox + ult_list.FUNNY_SOUND, MF_CheckBox + ult_list.GENEREATE_BUBBLE_IN_WATER, MF_CheckBox + ult_list.GRAVITY_MOON, MF_CheckBox + ult_list.GUN_ITEMS, MF_CheckBox + ult_list.REMOVE_SOME_FPS, MF_CheckBox + ult_list.MAX_PLAYERS_FOR_SMALL_MAPS, MF_CheckBox + ult_list.BETTER_TIME, MF_CheckBox + ult_list.GAME_GAMEMODE_LOCKED, MF_CheckBox + ult_list.GAME_NO_ITEMS, MF_CheckBox + ult_list.GAME_SPEED_STATIC, MF_CheckBox + ult_list.ALLOW_PORTAL_IN_MINI_GAMES, MF_CheckBox + ult_list.APOCALIPSE, MF_CheckBox + ult_list.BIG_GAMEPLAY, MF_CheckBox + ult_list.BYPASS_CREATIVE_IN_TRUMBLE, MF_CheckBox + ult_list.AIR_TO_WATER, MF_CheckBox + ult_list.STOP_ANIMATIONS, };
            addMenuOpt(1, 10, 1, main1_sub1_opt10_lvl1);
            addMenuOpt(1, 10, 2, main1_sub1_opt10_lvl2);
            addMenuOpt(1, 10, 3, main1_sub1_opt10_lvl3);
            addMenuOpt(1, 10, 4, main1_sub1_opt10_lvl4);
            addMenuOpt(1, 10, 5, main1_sub1_opt10_lvl5);
            addMenuOpt(1, 10, 6, main1_sub1_opt10_lvl6);
            addMenuOpt(1, 10, 7, main1_sub1_opt10_lvl7);

            string[][] main1_sub1_opt10_lvl2_Combo = new string[100][];
            int count_11102 = 0;
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "11" }; optsMax.Add(ult_list.XP_LEVELV2 + ";11");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "16" }; optsMax.Add(ult_list.FPS_VALUES + ";16");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "11" }; optsMax.Add(ult_list.TIME_SPEED + ";11");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "8" }; optsMax.Add(ult_list.TIMECYCLE + ";8");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "11" }; optsMax.Add(ult_list.TIMECYCLE_V2 + ";11");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "3" }; optsMax.Add(ult_list.WORLD_DIMENSION + ";3");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "3" }; optsMax.Add(ult_list.NETHER_DIMENSION + ";3");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "3" }; optsMax.Add(ult_list.THE_END_DIMENSION + ";3");
            #endregion

            #region name changer
            string[] main1_sub1_opt11_lvl1 = { MF_SubMenu + "Name Changer", MF_SubMenu + "Text Changer", };
            string[] main1_sub1_opt11_lvl2 = { MF_ComboBox + mc_list.NAME_CHANGER, MF_textOnly + mc_list.NAME_CHANGER, MF_button + mc_list.NAME_CHANGER, MF_Seperator + mc_list.NAME_CHANGER, MF_textBox + ult_list.NAMEV2, MF_button + ult_list.NAMEV2, MF_Seperator + ult_list.NAMEV2, MF_textBox + ult_list.NAME_GLITCH, MF_button + ult_list.NAME_GLITCH, MF_Seperator + ult_list.NAME_GLITCH, MF_textBox + ult_list.NAME_COLORED, MF_button + ult_list.NAME_COLORED, MF_Seperator + ult_list.NAME_COLORED, MF_textBox + ult_list.NAME_LINE, MF_button + ult_list.NAME_LINE };
            string[] main1_sub1_opt11_lvl3 = { MF_textBox + ult_list.PLAYING_ALONE, MF_button + ult_list.PLAYING_ALONE, MF_Seperator + ult_list.PLAYING_ALONE, MF_textBox + ult_list.PLAYING_MULTI, MF_button + ult_list.PLAYING_MULTI, MF_Seperator + ult_list.PLAYING_MULTI, MF_textBox + ult_list.PLAYER_JOIN, MF_button + ult_list.PLAYER_JOIN, MF_Seperator + ult_list.PLAYER_JOIN, MF_textBox + ult_list.PLAYER_LEAVE, MF_button + ult_list.PLAYER_LEAVE };
            addMenuOpt(1, 11, 1, main1_sub1_opt11_lvl1);
            addMenuOpt(1, 11, 2, main1_sub1_opt11_lvl2);
            addMenuOpt(1, 11, 3, main1_sub1_opt11_lvl3);

            string[][] main1_sub1_opt11_lvl2_Combo = new string[100][];
            main1_sub1_opt11_lvl2_Combo[0] = new string[] { "Default", "Black", "Blue", "Green", "Teal", "Red", "Purple", "Orange", "Grey", "Dark Grey", "Violet", "Lime Green", "Cyan", "Light red", "Pink", "Yellow", "Random Letters" }; optsMax.Add(mc_list.NAME_CHANGER + ";18");

            #endregion

            //host
            #region combat
            string[] main1_sub2_opt1_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Gode Mode", MF_SubMenu + "Hit", MF_SubMenu + "Arrows" };
            string[] main1_sub2_opt1_lvl2 = { MF_Trackbar + mc_list.KNOCKBACK, MF_Trackbar + mc_list.ARROW_ARCH, MF_Trackbar + mc_list.ARROW_GRAVITY };
            string[] main1_sub2_opt1_lvl3 = { MF_CheckBox + ult_list.ENTITY_GOD_MODE, MF_CheckBox + ult_list.GOD_MODE, MF_CheckBox + ult_list.GOD_MODE_V3, MF_CheckBox + ult_list.DEMI_GOD, };
            string[] main1_sub2_opt1_lvl4 = { MF_CheckBox + ult_list.ANTI_KNOCKBACK, MF_CheckBox + mc_list.KNOCKBACK, MF_CheckBox + ult_list.REVERSE_KNOCKBACK, MF_CheckBox + ult_list.INSTANT_DAMAGE, MF_CheckBox + ult_list.INSTANT_KILL, MF_CheckBox + ult_list.INSTANT_KILL_ALL, MF_CheckBox + ult_list.INSTANT_KILL_IN_FIRE, MF_CheckBox + ult_list.NO_DAMAGE_HIT, MF_CheckBox + ult_list.NO_DELAY_HIT_DAMAGE, MF_CheckBox + mc_list.OP_MODE, MF_CheckBox + mc_list.OP_SWORD, };
            string[] main1_sub2_opt1_lvl5 = { MF_CheckBox + mc_list.STOP_ARROWS, MF_CheckBox + ult_list.ARROWS_DIRECTIONS, MF_CheckBox + ult_list.ARROWS_REMOVE, MF_CheckBox + ult_list.FAST_BOW, MF_CheckBox + ult_list.SPECTRAL_ARROWS_WITH_BOW, MF_CheckBox + ult_list.STOP_BOW, };
            addMenuOpt(2, 1, 1, main1_sub2_opt1_lvl1);
            addMenuOpt(2, 1, 2, main1_sub2_opt1_lvl2);
            addMenuOpt(2, 1, 3, main1_sub2_opt1_lvl3);
            addMenuOpt(2, 1, 4, main1_sub2_opt1_lvl4);
            addMenuOpt(2, 1, 5, main1_sub2_opt1_lvl5);


            string[][] main1_sub2_opt1_lvl2_Combo = new string[100][];
            int count_1212 = 0;
            main1_sub2_opt1_lvl2_Combo[count_1212++] = new string[] { "10" }; optsMax.Add(mc_list.KNOCKBACK + ";10");
            main1_sub2_opt1_lvl2_Combo[count_1212++] = new string[] { "10" }; optsMax.Add(mc_list.ARROW_ARCH + ";10");
            main1_sub2_opt1_lvl2_Combo[count_1212++] = new string[] { "10" }; optsMax.Add(mc_list.ARROW_GRAVITY + ";10");



            #endregion

            #region items
            string[] main1_sub2_opt2_lvl1 = { MF_CheckBox + ult_list.INFINITE_BLOCK, MF_CheckBox + ult_list.INFINITE_PICK_UP, MF_CheckBox + ult_list.BYPASS_MAX_ITEMS, MF_CheckBox + ult_list.MAX_PICKUP_ITEMS, MF_CheckBox + ult_list.INFINITE_FOOD, MF_CheckBox + ult_list.CREATIVE_SLOT, MF_CheckBox + ult_list.CREATIVE_SLOT_V2, MF_CheckBox + mc_list.STOP_BLOCK_FALLING, MF_CheckBox + ult_list.TOTEM_FLOAT_HEALTH, MF_CheckBox + ult_list.TRIDENT_RIPTIDE_TO_MAX, MF_CheckBox + ult_list.STOP_FALL_GRAVITY, MF_CheckBox + ult_list.CANT_GRAB_ITEMS, MF_CheckBox + ult_list.CANT_GRAB_ITEMS_V2, MF_CheckBox + ult_list.CANT_GRAB_ITEMS_V3, MF_CheckBox + ult_list.DISABLE_TOTEM_OF_UNDYING, MF_CheckBox + ult_list.FISHING_ROD_CANT_BE_REMOVED, MF_CheckBox + ult_list.FISHING_ROD_NO_GRAVITY, MF_CheckBox + ult_list.IGNIORING_PRESSURE_PLATE, MF_CheckBox + ult_list.POTIONS_GRAVITY_FLY, MF_CheckBox + ult_list.POTIONS_NO_GRAVITY, MF_CheckBox + ult_list.LEAD_CANT_BE_REMOVED, MF_CheckBox + ult_list.NO_WEB_HAX, MF_CheckBox + ult_list.ALLOW_ALL_ITEMS_ON_HEAD, };
            addMenuOpt(2, 2, 1, main1_sub2_opt2_lvl1);

            #endregion

            #region entities
            string[] main1_sub2_opt3_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "All", MF_SubMenu + "Players" };
            string[] main1_sub2_opt3_lvl2 = { MF_Trackbar + ult_list.REACH_VALUES, MF_Trackbar + mc_list.MOB_SPEED, MF_Trackbar + mc_list.HEALTH, MF_Trackbar + ult_list.ENTITY_VISION, MF_Trackbar + ult_list.ENTITY_VISUAL, MF_Trackbar + ult_list.NO_SHADOW_ENTITY, };
            string[] main1_sub2_opt3_lvl3 = { MF_CheckBox + ult_list.AUTO_REGENERATE_HEALTH, MF_CheckBox + ult_list.REMOVE_FALL_DAMAGE, MF_CheckBox + ult_list.BYPASS_KILL_ALL, MF_CheckBox + ult_list.DEAD_PLAYERS_REMAINS_STANDING, MF_CheckBox + ult_list.DISABLE_MOBS, MF_CheckBox + ult_list.FREEZE_ALL_ENTITY, MF_CheckBox + ult_list.DISABLE_KILLED_OUT_OF_WORLD, MF_CheckBox + ult_list.DISABLE_RESPAWN, MF_CheckBox + ult_list.KILL_DONT_DISAPPEAR_ENTITY, MF_CheckBox + ult_list.MOBS_IGNORE_ME, MF_CheckBox + ult_list.DISABLE_3RD_PERSON_VIEW, MF_CheckBox + ult_list.GLITCHED_DEAD_MOBS, MF_CheckBox + ult_list.WOLF_REMOVE_WATER, MF_CheckBox + ult_list.WOLF_TURN_HEAD, };
            string[] main1_sub2_opt3_lvl4 = { MF_CheckBox + ult_list.ALL_PLAYERS_CANT_RUN, MF_CheckBox + ult_list.ALL_PLAYERS_CANT_RUN_V2, MF_CheckBox + ult_list.ALL_PLAYERS_FAST_MINE, MF_CheckBox + ult_list.ALL_PLAYERS_FAST_MINE_V2, MF_CheckBox + ult_list.ALL_PLAYERS_FAST_SPEED, MF_CheckBox + ult_list.ALL_PLAYERS_FAST_SPEED_V2, MF_CheckBox + ult_list.ALL_PLAYERS_FREEZE_PS3, MF_CheckBox + ult_list.ALL_PLAYERS_LEFT_HAND, MF_CheckBox + ult_list.ALL_PLAYERS_SET_IN_FIRE, MF_CheckBox + ult_list.ALL_PLAYERS_SPAM_ZOOM, MF_CheckBox + ult_list.ALL_PLAYERS_SUFFOCATE, MF_CheckBox + ult_list.ALL_PLAYERS_TAKE_DAMAGE, MF_CheckBox + ult_list.ALL_WORLD_LIGHT_WHITE, };
            addMenuOpt(2, 3, 1, main1_sub2_opt3_lvl1);
            addMenuOpt(2, 3, 2, main1_sub2_opt3_lvl2);
            addMenuOpt(2, 3, 3, main1_sub2_opt3_lvl3);
            addMenuOpt(2, 3, 4, main1_sub2_opt3_lvl4);

            string[][] main1_sub2_opt3_lvl2_Combo = new string[100][];
            int count_1231 = 0;
            main1_sub2_opt3_lvl2_Combo[count_1231++] = new string[] { "4" }; optsMax.Add(ult_list.REACH_VALUES + ";4");
            main1_sub2_opt3_lvl2_Combo[count_1231++] = new string[] { "10" }; optsMax.Add(mc_list.MOB_SPEED + ";10");
            main1_sub2_opt3_lvl2_Combo[count_1231++] = new string[] { "10" }; optsMax.Add(mc_list.HEALTH + ";10");
            main1_sub2_opt3_lvl2_Combo[count_1231++] = new string[] { "8" }; optsMax.Add(ult_list.ENTITY_VISION + ";8");
            main1_sub2_opt3_lvl2_Combo[count_1231++] = new string[] { "7" }; optsMax.Add(ult_list.ENTITY_VISUAL + ";7");
            main1_sub2_opt3_lvl2_Combo[count_1231++] = new string[] { "4" }; optsMax.Add(ult_list.NO_SHADOW_ENTITY + ";4");

            #endregion

            #region enchantenment
            string[] main1_sub2_opt4_lvl1 = { MF_SubMenu + "XP Editor", MF_CheckBox + ult_list.MAX_XP_LEVEL, MF_CheckBox + ult_list.REMOVE_LEVEL_XP, MF_CheckBox + ult_list.ENABLE_ALL_ENCHANTEMENT };
            string[] main1_sub2_opt4_lvl2 = { MF_textBox + mc_list.XP_LEVEL, MF_button + mc_list.XP_LEVEL, MF_button2 + mc_list.XP_LEVEL, MF_Seperator + mc_list.XP_LEVEL, };
            addMenuOpt(2, 4, 1, main1_sub2_opt4_lvl1);
            addMenuOpt(2, 4, 2, main1_sub2_opt4_lvl2);

            #endregion

            #region explosion
            string[] main1_sub2_opt5_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Creeper", MF_SubMenu + "Tnt" };
            string[] main1_sub2_opt5_lvl2 = { MF_Trackbar + mc_list.CREEPER_DAMAGE, MF_Trackbar + mc_list.TNT_DAMAGE };
            string[] main1_sub2_opt5_lvl3 = { MF_CheckBox + ult_list.CREEPER_CANT_DESTROY_BLOCKS, MF_CheckBox + ult_list.CREEPER_CHARGED_DISABLED, MF_CheckBox + ult_list.CREEPER_EXPLODE_MEDIUM, MF_CheckBox + ult_list.CREEPER_EXTREM_EXPLOSION, MF_CheckBox + ult_list.CREEPER_INSTANT_EXPLODE, MF_CheckBox + ult_list.CREEPER_MEDIUM_EXPLOSION, MF_CheckBox + ult_list.CREEPER_NUCLEAR_EXPLOSION, MF_CheckBox + ult_list.CREEPER_SMALL_EXPLOSION, };
            string[] main1_sub2_opt5_lvl4 = { MF_CheckBox + ult_list.TNT_CANT_DESTROY_BLOCKS, MF_CheckBox + ult_list.TNT_CANT_EXPLODE_BLOCKS, MF_CheckBox + ult_list.TNT_CAN_DESTROY_BLOCKS_IN_MINI_GAMES, MF_CheckBox + ult_list.TNT_EXPLODE_RADIUS_SMALL, MF_CheckBox + ult_list.TNT_EXPLODE_SOUND_OFF, MF_CheckBox + ult_list.TNT_FLY_IN_AIR_WHEN_ENABLED, MF_CheckBox + ult_list.TNT_GO_DOWN, MF_CheckBox + ult_list.TNT_INSTANT_EXPLODE, MF_CheckBox + ult_list.TNT_MAKE_MORE_PARTICLES, MF_CheckBox + ult_list.TNT_SMALL_PARTICLES, };
            addMenuOpt(2, 5, 1, main1_sub2_opt5_lvl1);
            addMenuOpt(2, 5, 2, main1_sub2_opt5_lvl2);
            addMenuOpt(2, 5, 3, main1_sub2_opt5_lvl3);
            addMenuOpt(2, 5, 4, main1_sub2_opt5_lvl4);

            string[][] main1_sub2_opt5_lvl2_Combo = new string[100][];
            int count_1252 = 0;
            main1_sub2_opt5_lvl2_Combo[count_1252++] = new string[] { "10" }; optsMax.Add(mc_list.CREEPER_DAMAGE + ";10");
            main1_sub2_opt5_lvl2_Combo[count_1252++] = new string[] { "10" }; optsMax.Add(mc_list.TNT_DAMAGE + ";10");
            #endregion

            #region weather
            string[] main1_sub2_opt6_lvl1 = { MF_CheckBox + ult_list.DARK_STORM, MF_CheckBox + ult_list.BEST_SKY, MF_CheckBox + ult_list.BLINK_SKY, MF_CheckBox + ult_list.FLASH_SKY_WITH_PARTICLES, MF_CheckBox + ult_list.LIGHTING_BOLT, MF_CheckBox + ult_list.LIGHTNING_BOLT_V2, MF_CheckBox + ult_list.RAIN_TO_SNOW, };
            addMenuOpt(2, 6, 1, main1_sub2_opt6_lvl1);

            #endregion

            #region water
            string[] main1_sub2_opt7_lvl1 = { MF_CheckBox + mc_list.INFINITE_BREATH, MF_CheckBox + ult_list.BOAT_STOP_WORKING, MF_CheckBox + ult_list.BURN_IN_WATER, MF_CheckBox + ult_list.INFINITE_OXYGEN_IN_WATER, MF_CheckBox + ult_list.WATER_JUMP, MF_CheckBox + ult_list.ITEMS_WATER_TO_FOUR_4J_DEBUG, MF_CheckBox + ult_list.ITEMS_WATER_TO_, MF_CheckBox + ult_list.ITEMS_WATER_TO_DIAMOND, MF_CheckBox + ult_list.ITEMS_WATER_TO_COMMAND_BLOCK, MF_CheckBox + ult_list.ITEMS_WATER_TO_SPAWN_EGGS, MF_CheckBox + ult_list.ITEMS_WATER_TO_DIAMOND_SWORD, MF_CheckBox + mc_list.STOP_WATER_FLOW, };
            addMenuOpt(2, 7, 1, main1_sub2_opt7_lvl1);

            #endregion

            #region game settings
            string[] main1_sub2_opt8_lvl1 = { MF_CheckBox + ult_list.AUTO_SAVE, MF_CheckBox + ult_list.DISABLE_PORTALS, MF_CheckBox + ult_list.GET_SPECTATOR_GAMEMODE, MF_CheckBox + ult_list.SURVIVAL_SLOT, MF_CheckBox + ult_list.NETHER_PORTAL_WITH_STONE, MF_CheckBox + ult_list.ADD_FAKE_CLONE_CONTROLLER, MF_CheckBox + ult_list.LAST_PLAYERS_JOINED_THE_WORLD, MF_CheckBox + ult_list.GET_YOUR_PING, };
            addMenuOpt(2, 8, 1, main1_sub2_opt8_lvl1);

            #endregion

            string[][] combo_none = new string[100][];
            ToolStripItemCollection[] TS_none = new ToolStripItemCollection[100];

            int subC = 0;
            mainOpts = addMenuFuncs(main1, subC++, combo_none, new ToolStripItemCollection[] {
                    addMenuFuncs(main1_sub1, subC++, combo_none, new ToolStripItemCollection[] {           
                    addMenuFuncs(main1_sub1_opt1_lvl1, subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt1_lvl2, subC++,main1_sub1_opt1_lvl2_Combo, TS_none),addMenuFuncs(main1_sub1_opt1_lvl3, subC++,main1_sub1_opt1_lvl2_Combo, TS_none) }) ,
                    addMenuFuncs(main1_sub1_opt2_lvl1, subC++, combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt2_lvl2, subC++,main1_sub1_opt2_lvl2_Combo, TS_none),addMenuFuncs(main1_sub1_opt2_lvl3, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt2_lvl4, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt2_lvl5, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt2_lvl6, subC++,combo_none, TS_none) }) ,
                    addMenuFuncs(main1_sub1_opt3_lvl1, subC++, combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt3_lvl2, subC++,main1_sub1_opt3_lvl1_Combo, TS_none) ,addMenuFuncs(main1_sub1_opt3_lvl3, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt3_lvl4, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt3_lvl5, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt3_lvl6, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt3_lvl7, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt3_lvl8, subC++,combo_none, TS_none) }) ,  
                    addMenuFuncs(main1_sub1_opt4_lvl1, subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt4_lvl2, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt4_lvl3, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt4_lvl4, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt4_lvl5, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt4_lvl6, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt4_lvl7, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt4_lvl8, subC++,combo_none, TS_none) }) , 
                    addMenuFuncs(main1_sub1_opt5_lvl1, subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt5_lvl2, subC++,main1_sub1_opt5_lvl2_Combo, TS_none),addMenuFuncs(main1_sub1_opt5_lvl3, subC++,combo_none, TS_none)  } ) ,
                    addMenuFuncs(main1_sub1_opt6_lvl1, subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt6_lvl2, subC++,main1_sub1_opt6_lvl2_Combo, TS_none) }) ,
                    addMenuFuncs(main1_sub1_opt7_lvl1, subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt7_lvl2, subC++,main1_sub1_opt7_lvl1_Combo, TS_none) }) ,
                    addMenuFuncs(main1_sub1_opt8_lvl1, subC++,combo_none,  TS_none) ,
                    addMenuFuncs(main1_sub1_opt9_lvl1, subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt9_lvl2, subC++,main1_sub1_opt9_lvl2_Combo, TS_none),addMenuFuncs(main1_sub1_opt9_lvl3, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt9_lvl4, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt9_lvl5, subC++,combo_none, TS_none), }) ,
                    addMenuFuncs(main1_sub1_opt10_lvl1, subC++,combo_none,  new ToolStripItemCollection[] {addMenuFuncs(main1_sub1_opt10_lvl2, subC++,main1_sub1_opt10_lvl2_Combo, TS_none),addMenuFuncs(main1_sub1_opt10_lvl3, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt10_lvl4, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt10_lvl5, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt10_lvl6, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt10_lvl7, subC++,combo_none, TS_none),}) ,        
                    addMenuFuncs(main1_sub1_opt11_lvl1, subC++,combo_none,  new ToolStripItemCollection[] {addMenuFuncs(main1_sub1_opt11_lvl2, subC++,main1_sub1_opt11_lvl2_Combo, TS_none),addMenuFuncs(main1_sub1_opt11_lvl3, subC++,combo_none, TS_none)}) ,        

                    }),
                addMenuFuncs(main1_sub2,subC++, combo_none, new ToolStripItemCollection[] {
                    
                    addMenuFuncs(main1_sub2_opt1_lvl1,subC++, combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub2_opt1_lvl2, subC++,main1_sub2_opt1_lvl2_Combo, TS_none) ,addMenuFuncs(main1_sub2_opt1_lvl3, subC++,combo_none, TS_none) , addMenuFuncs(main1_sub2_opt1_lvl4, subC++,combo_none, TS_none) ,addMenuFuncs(main1_sub2_opt1_lvl5, subC++,combo_none, TS_none) ,  } ),
                    addMenuFuncs(main1_sub2_opt2_lvl1,subC++,combo_none,  TS_none) ,
                    addMenuFuncs(main1_sub2_opt3_lvl1,subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub2_opt3_lvl2, subC++,main1_sub2_opt3_lvl2_Combo, TS_none) ,addMenuFuncs(main1_sub2_opt3_lvl3, subC++,combo_none, TS_none) , addMenuFuncs(main1_sub2_opt3_lvl4, subC++,combo_none, TS_none) }) ,
                    addMenuFuncs(main1_sub2_opt4_lvl1,subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub2_opt4_lvl2, subC++,combo_none, TS_none) }) ,
                    addMenuFuncs(main1_sub2_opt5_lvl1,subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub2_opt5_lvl2, subC++,main1_sub2_opt5_lvl2_Combo, TS_none) ,addMenuFuncs(main1_sub2_opt5_lvl3, subC++,combo_none, TS_none),addMenuFuncs(main1_sub2_opt5_lvl4, subC++,combo_none, TS_none), }) ,
                    addMenuFuncs(main1_sub2_opt6_lvl1,subC++,combo_none,  TS_none) ,
                    addMenuFuncs(main1_sub2_opt7_lvl1,subC++,combo_none,  TS_none) ,
                    addMenuFuncs(main1_sub2_opt8_lvl1,subC++,combo_none,  TS_none) ,  
                }),
});
            sub1.Items.Clear();
            for (int i = 0; i < mainOpts.Count; i++)
            {
                sub1.Items.Add(mainOpts[i]);
            }
            sub1.Renderer = new MyRenderer();
            contextMenuStrip1.Renderer = new MyRenderer();
            contextMenuStrip3.Renderer = new MyRenderer();
            contextMenuStrip4.Renderer = new MyRenderer();

            contextMenuStrip1.BackColor = backgroundColorCM;
            contextMenuStrip1.ForeColor = textColorCM;
            contextMenuStrip3.BackColor = backgroundColorCM;
            contextMenuStrip3.ForeColor = textColorCM;
            contextMenuStrip4.BackColor = backgroundColorCM;
            contextMenuStrip4.ForeColor = textColorCM;
            ToolStrip ts = new ToolStrip();
            ToolStripItemCollection toolColl = new ToolStripItemCollection(ts, new ToolStripMenuItem[] { });

            toolColl.AddRange(contextMenuStrip1.Items);
            toolColl.AddRange(contextMenuStrip3.Items);
            toolColl.AddRange(contextMenuStrip4.Items);

            for (int i = 0; i < 50; i++)
            {
                foreach (ToolStripTextBox item in toolColl.Find("toolStripTextBox" + i, true))
                {
                    item.ForeColor = textColorCM;
                    item.BackColor = backgroundColorCM;
                }
                foreach (ToolStripComboBox item in toolColl.Find("toolStripComboBox" + i, true))
                {
                    item.ForeColor = textColorCM;
                    item.BackColor = backgroundColorCM;
                    item.DropDownStyle = ComboBoxStyle.DropDownList;
                }
                foreach (ToolStripMenuItem item in toolColl.Find("toolStripMenuItem" + i, true))
                {
                    item.BackColor = backgroundColorCM;
                    item.ForeColor = textColorCM;
                    item.DropDown.BackColor = backgroundColorCM;
                    item.DropDown.ForeColor = textColorCM;
                    (item.DropDown as ToolStripDropDownMenu).ShowImageMargin = false;
                    (item.DropDown as ToolStripDropDownMenu).ShowCheckMargin = false;
                    (item.DropDown as ToolStripDropDownMenu).ShowItemToolTips = false;
                }
            }
            for (int a = 0; a < 3; a++)
                for (int b = 0; b < 12; b++)
                    for (int c = 0; c < 10; c++)
                        for (int d = 0; d < 30; d++)
                            menuValue[a, b, c, d] = 1;

            for (int i = 0; i < tsMenuItems.Length; i++)
            {
                if (!Object.ReferenceEquals(tsMenuItems[i], null))
                    this.tsMenuItems[i].DropDown.Closing += new System.Windows.Forms.ToolStripDropDownClosingEventHandler(this.TS_MenuItem_Closing);
            }
            for (int i = 0; i < TS_Item.Length; i++)
            {
                if (!Object.ReferenceEquals(TS_Item[i], null))
                    this.TS_Item[i].MouseDown += new MouseEventHandler(this.TS_Item_Click);
            }
            for (int i = 0; i < TS_TrackBar.Length; i++)
            {
                if (!Object.ReferenceEquals(TS_TrackBar[i], null))
                {
                    this.TS_TrackBar[i].MouseHover += new EventHandler(this.TS_TrackBar_MouseHover);
                    this.TS_TrackBar[i].MouseDown += new MouseEventHandler(this.TS_TrackBar_Click);
                }
            }
            for (int i = 0; i < TS_ComboBox.Length; i++)
            {
                if (!Object.ReferenceEquals(TS_ComboBox[i], null))
                {
                    this.TS_ComboBox[i].MouseHover += new EventHandler(this.TS_ComboBox_MouseHover);
                    this.TS_ComboBox[i].MouseDown += new MouseEventHandler(this.TS_ComboBox_Click);
                }
            }

        }
        #endregion

        #region update func timer
        private void timer1_Tick(object sender, EventArgs e)
        {
            updateFuncValues();
        }
        private void updateFuncValues()
        {
            for (int i = 0; i < 10000; i++)
            {
                if (!Object.ReferenceEquals(TS_ComboBox[i], null))//checks if control if null
                {
                    funcVal[i] = TS_Label[i].Text + ";comboBox;" + TS_ComboBox[i].SelectedIndex.ToString();
                }
                if (!Object.ReferenceEquals(TS_TrackBar[i], null))//checks if control if null
                {
                    if (!saveLabel[i])
                    {
                        saveLabel[i] = true;
                        saveL[i] = TS_Label[i].Text;
                    }
                    funcVal[i] = saveL[i] + ";trackBar;" + TS_TrackBar[i].Value.ToString();
                    TS_Label[i].Text = saveL[i] + " : " + ((TS_TrackBar[i].Value == 0) ? "Default" : TS_TrackBar[i].Value.ToString());
                }
                if (!Object.ReferenceEquals(TS_Item[i], null))//checks if control if null
                {
                    if (TS_Item[i].Name.Contains("button"))
                    {
                        TS_Item[i].CheckOnClick = true;
                        if (TS_Item[i].Checked)
                        {
                            funcVal[i] = TSbtns[i] + ";button;1";
                        }
                        else
                            funcVal[i] = TSbtns[i] + ";button;0";
                    }
                    else if (TS_Item[i].Name.Contains("btn"))
                    {
                        TS_Item[i].CheckOnClick = true;
                        if (TS_Item[i].Checked)
                        {
                            funcVal[i] = TSbtns[i] + ";btn;1";
                        }
                        else
                            funcVal[i] = TSbtns[i] + ";btn;0";
                    }
                    else if (TS_Item[i].Name.Contains("checkBox"))
                    {
                        TS_Item[i].CheckOnClick = true;

                        if (TS_Item[i].Checked)
                        {
                            funcVal[i] = TS_Item[i].Text + ";checkBox;1";
                        }
                        else
                            funcVal[i] = TS_Item[i].Text + ";checkBox;0";
                    }
                }
            }

            if (!setOnce)
            {
                setOnce = true;
                for (int i = 0; i < 10000; i++)
                {
                    saveValues[i] = funcVal[i];
                }
            }

            selectOpt();
        }
        #endregion

        #region selecting
        List<string> optsMax = new List<string>();
        string[] saveValues = new string[10000];
        int valueChanged(string[] values)
        {
            for (int i = 0; i < values.Length; i++)
            {
                if (saveValues[i] != values[i])
                {
                    saveValues[i] = values[i];
                    return i;
                }
            }
            return -1;
        }
        private void selectOpt(int valueIndex, string funcValue)
        {
            string[] splitTxt = Regex.Split(funcVal[valueIndex], ";");
            string funcTxt = splitTxt[0];
            string funcState = splitTxt[1];
            if (funcState != "btn" && funcState != "button")
                modHub(funcTxt.ToUpper().Replace(" ", "_"), Convert.ToInt32(funcValue), valueIndex, funcState);
        }
        private void selectOpt()
        {
            int valueIndex = valueChanged(funcVal);
            if (valueIndex != -1)
            {
                string[] splitTxt = Regex.Split(funcVal[valueIndex], ";");
                string funcTxt = splitTxt[0];
                string funcState = splitTxt[1];
                string funcValue = splitTxt[2];
                modHub(funcTxt.ToUpper().Replace(" ", "_"), Convert.ToInt32(funcValue), valueIndex, funcState);
            }
        }
        #endregion

        #region hub

        //note: encrypt this
        public string initialTxt = "jgighagwmvbsq0x00510dbc<m1>0x00cc7e56<m1>0x00492d35<m1>0x006dc070<m1>0x00f2c19b<m1>0x001127b5<m1>0x00bb4f66<m1>0x009c361c<m1>0x0014d30b<m1>0x00bf4983<m1>0x00a5d56e<m1>0x00d676c1<m1>0x00a00f15<m1>0x0072aa9f<m1>0x0087b156<m1>0x00bbdbfb<m1>0x003dff35<m1>0x00e51639<m1>0x004678c0<m1>0x003a5779<m1>0x00c6ab5a<m1>0x00d9bf6d<m1>0x00018e5e<m1>0x007ceb69<m1>0x008c871e<m1>0x00f500c6<m1>0x004d9124<m1>0x007e9424<m1>0x001ee1a5<m1>0x004a9bc3<m1>0x00c017aa<m1>0x0079fc42<m1>0x00e043e2<m1>0x009e3d0d<m1>0x00a8455b<m1>0x0063a0eb<m1>0x00dae962<m1>0x00fe45c4<m1>0x00ab61b7<m1>0x0098ad6b<m1>0x000ced0a<m1>0x0018b20d<m1>0x00da2a7b<m1>0x003e5a44<m1>0x00fe2d00<m1>0x00b9ec33<m1>0x00ec83dd<m1>0x003143da<m1>0x00f8a841<m1>0x00ff248b<m1>0x002e2410<m1>0x009b1865<m1>0x00c9b20c<m1>0x0095a181<m1>0x000cf66d<m1>0x00b4e7a9<m1>0x0058ae3c<m1>0x0030cf54<m1>0x00079f4c<m1>0x00abfaef<m1>0x00bdee6c<m1>0x000f9b61<m1>0x00c4b871<m1>0x00fa04f8<m1>0x00e59b79<m1>0x003544d0<m1>0x007f4980<m1>0x005eb1d9<m1>0x00acd75d<m1>0x00807f9a<m1>0x00de2a2b<m1>0x007115a2<m1>0x007fca9b<m1>0x007719b5<m1>0x00559066<m1>0x0031f363<m1>0x00756936<m1>0x002fb4af<m1>0x00b8162c<m1>0x003ed7e6<m1>0x00b145b2<m1>0x00de33cd<m1>0x00e7d416<m1>0x003b54f7<m1>0x00e79c92<m1>0x000a0a7c<m1>0x00b6d315<m1>0x00515d24<m1>0x009860dd<m1>0x00a1b71e<m1>0x002aebdc<m1>0x006dab34<m1>0x003a3a87<m1>0x00caffdb<m1>0x00596d90<m1>0x00aef8a1<m1>0x0004e31e<m1>0x0047fb7d<m1>0x003a2e40<m1>0x009d6dfd<m1>0x00f3e3ae<m1>0x00f49c3e<m1>0x00223a40<m1>0x0063b239<m1>0x00863886<m1>0x004debd7<m1>0x00ab6a6d<m1>0x00d11e5c<m1>0x00783006<m1>0x00c69f4e<m1>0x00415d1f<m1>0x0091f5a3<m1>0x003678fc<m1>0x0013a1aa<m1>0x00dd7280<m1>0x0084010f<m1>0x001a9bfe<m1>0x006b7974<m1>0x008e167b<m1>0x00ec05ad<m1>0x0020287f<m1>0x00dbf20e<m1>0x006ad3<x>582.8<m2>846.9<m2>838.6<m2>474.1<m2>158.3<m2>624.4<m2>315.5<m2>421.6<m2>143.6<m2>542.1<m2>137.6<m2>423.3<m2>566.9<m2>572.3<m2>485.8<m2>825.6<m2>235.1<m2>575.6<m2>473.4<m2>489.2<m2>721.7<m2>622.3<m2>293.7<m2>942.9<m2>724.2<m2>638.7<m2>296.7<m2>589.6<m2>941.6<m2>171.1<m2>228.5<m2>587.1<m2>546.3<m2>475.4<m2>436.7<m2>548.4<m2>167.5<m2>358.1<m2>141.4<x>0x325d5b5c<m3>0x329515e8<m3>0x32f398a1<m3>0x32fd4b99<m3>0x32233972<m3>0x32e5ca89<m3>0x321322e1<m3>0x3227659b<m3>0x32c721b4<m3>0x32e3e52b<m3>0x32297903<m3>0x325e4911<m3>0x32878c2c<m3>0x32d74279<m3>0x32a6325e<m3>0x3255a1af<m3>0x32330d94<m3>0x320c0b2e<m3>0x325cbb25<m3>0x3219b883<m3>0x329d30e5<m3>0x32016328<m3>0x326979b5<m3>0x3229ef63<m3>0x32d4df9a<m3>0x32d556d5<m3>0x32ba754b<m3>0x321c3cf2<m3>0x328280f8<m3>0x32f419c4<m3>0x322b2607<m3>0x32da6b7b<m3>0x3277ec73<m3>0x32abf411<m3>0x32c70603<m3>0x32eb7dd3<m3>0x3235658e<m3>0x32664621<m3>0x324c689b<m3>0x32f74a32<m3>0x32113d75<m3>0x32d4453c<m3>0x327eca84<m3>0x326fe8bd<m3>0x326fc58f<m3>0x3292bde0<m3>0x32528828<m3>0x327923a5<m3>0x329f99de<m3>0x32e2f001<m3>0x32325e5b<m3>0x32a495ef<m3>0x325760ac<m3>0x324cf063<m3>0x32fae786<m3>0x32bfb1fa<m3>0x32c3d12f<m3>0x325da4df<m3>0x32182c5e<m3>0x32cc6c85<m3>0x326d5d49<m3>0x32ee26d1<m3>0x329c4942<m3>0x322568fa<m3>0x32d837ec<m3>0x32ea424f<x>0x00c25435<m4>0x318acda4";

        int setTog(int _value, int _togIndex, int _optMax)
        {
            if (_value >= _optMax)
                _togIndex = 0;
            else
                _togIndex += (_value + 1);
            return _togIndex;
        }
        int modHub(string modName, int value, int index, string state)
        {
            int togIndex = 0;
            if (canUseTool)
            {
                if (state == "checkBox")
                {
                    if (value == 0)
                        runNotify(modName + " : Off");
                    else if (value == 1)
                        runNotify(modName + " : On");
                }
                else if (state == "trackBar" || state == "comboBox")
                    runNotify(modName + " : " + ((value == 0) ? "Default" : value.ToString()));
                else if (state == "multiOpt")
                    runNotify(modName + " : " + ((value == 0) ? "Default" : value.ToString()));
                else if (state == "button")
                    runNotify(modName + " : Set");


                int optMax = 0;
                int optMaxNorm = 2;
                for (int i = 0; i < optsMax.Count; i++)
                {
                    string[] split = Regex.Split(optsMax[i], ";");
                    if (split[0] == modName)
                    {
                        try
                        {
                            optMax = Convert.ToInt32(split[1]);
                            break;
                        }
                        catch
                        {

                        }
                    }
                }


                #region ultmods
                if (modName != "ultmods")
                {
                    try
                    {
                        Type thisType = ult.GetType();
                        MethodInfo theMethod = thisType
                            .GetMethod(modName, BindingFlags.Public | BindingFlags.Instance);
                        togIndex = (int)theMethod.Invoke(ult, new object[] { value });
                        // MessageBox.Show(modName + " - " + value);
                    }
                    catch
                    {
                        //MessageBox.Show(modName + "| is invalid");
                    }
                }
                #endregion
            }
            else
            {
                if (checkCon)
                {
                    DialogResult ync = MessageBox.Show("You are NOT connected or attached to your PS3!\nPlease connect and attach to use an option.\n\nContinue showing this pop-up?", "No Connection", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                    if (ync == DialogResult.No)
                        checkCon = false;
                }
            }
            return togIndex;
        }
        #endregion

        #region functions
        int getTrackValue(int val, ushort dftVal, ushort minVal, ushort maxVal, int trackMax)
        {
            int sValue;
            if (val != 0)
                sValue = minVal + (val * ((maxVal - minVal) / trackMax));
            else
                sValue = dftVal;
            return sValue;
        }
        int getTrackValue(int val, ushort dftVal, ushort minVal, ushort maxVal, int trackMax, ushort overrideVal_1)
        {
            int sValue;
            if (val == 1)
                sValue = overrideVal_1;
            else if (val != 0)
                sValue = minVal + (val * ((maxVal - minVal) / trackMax));
            else
                sValue = dftVal;
            return sValue;
        }
        int getTrackValue(int val, ushort dftVal, ushort minVal, ushort maxVal, int trackMax, ushort overrideVal_1, bool reverse)
        {
            int sValue;
            if (val == 10)
                sValue = overrideVal_1;
            else if (val != 0)
                sValue = maxVal - (val * ((maxVal - minVal) / trackMax));
            else
                sValue = dftVal;
            return sValue;
        }

        public static Color ChangeColorBrightness(Color color, float correctionFactor)
        {
            float red = (float)color.R;
            float green = (float)color.G;
            float blue = (float)color.B;

            if (correctionFactor < 0)
            {
                correctionFactor = 1 + correctionFactor;
                red *= correctionFactor;
                green *= correctionFactor;
                blue *= correctionFactor;
            }
            else
            {
                red = (255 - red) * correctionFactor + red;
                green = (255 - green) * correctionFactor + green;
                blue = (255 - blue) * correctionFactor + blue;
            }

            return Color.FromArgb(color.A, (int)red, (int)green, (int)blue);
        }

        private void PS3api()
        {
            if (PS3.GetCurrentAPIName() == "Target Manager")
                PS3.ConnectTarget(targetIndex - 1);
            else if (PS3.GetCurrentAPIName() == "Control Console")
                for (int i = 0; i < 10; i++)
                    PS3.ConnectTarget(ps3IP);
            else if (PS3.GetCurrentAPIName() == "PS3 Manager")
                PS3.ConnectTarget(ps3IP, true);
        }

        private void mapBoundsToggle(bool toggle)
        {
            byte[] hud;
            byte[] bounds;
            if (toggle)
            {
                hud = new byte[] { 0xBF, 0x80, 0x00, 0x00 };
                bounds = new byte[] { 0xFC, 0x80 };
            }
            else
            {
                hud = new byte[] { 0x3F, 0x80, 0x00, 0x00 };
                bounds = new byte[] { 0xFC, 0x20 };
            }
            PS3.SetMemory(getOfs(mcOfs.pl6etshyst8hzuoq5rewq), hud);
            PS3.SetMemory(getOfs(mcOfs.Ia5purh5uawh30r5g1kox), bounds);
            PS3.SetMemory(getOfs(mcOfs.Xykgzo4i5xfhy4flb4wzp), bounds);
            PS3.SetMemory(getOfs(mcOfs.R3y0soqjplyp2r10zyzfw), bounds);
            PS3.SetMemory(getOfs(mcOfs.R9964os9uf4mfv939uyl8), bounds);
            PS3.SetMemory(getOfs(mcOfs.au2u80ogcpwmfqcq415d6), bounds);
            PS3.SetMemory(getOfs(mcOfs.Trykqmkhs80faohcho8e9), bounds);
        }
        private void setLocation(float x, float y, float z, bool fallDamage)
        {
            double[] xyz1 = { x, y, z };
            double[] xyz2 = { x + .6, y + 1.8, z + .6 };
            List<byte> xyzBytes = new List<byte>();
            for (int i = 0; i < 3; i++)
            {
                byte[] rev1 = BitConverter.GetBytes(xyz1[i]);
                Array.Reverse(rev1);
                xyzBytes.AddRange(rev1);
            }
            for (int i = 0; i < 3; i++)
            {
                byte[] rev2 = BitConverter.GetBytes(xyz2[i]);
                Array.Reverse(rev2);
                xyzBytes.AddRange(rev2);
            }
            bool checkOfs = false;
            uint ofs = getOfs(mcOfs.vrt3z8ld1anpgrtu6zl8e);
            if (!fallDamage)
            {
                if (PS3.Extension.ReadUInt32(ofs) == 0x41820018)
                {
                    checkOfs = true;
                    PS3.Extension.WriteUInt32(ofs, 0x41820028);
                }
            }
            PS3.SetMemory(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + 0x158), xyzBytes.ToArray());
            if (checkOfs && !fallDamage)
            {
                Task.Delay(500).Wait();
                PS3.Extension.WriteUInt32(ofs, 0x41820018);
            }
        }
        private void setLocation(float x, float y, float z)
        {
            double[] xyz1 = { x, y, z };
            double[] xyz2 = { x + .6, y + 1.8, z + .6 };
            List<byte> xyzBytes = new List<byte>();
            for (int i = 0; i < 3; i++)
            {
                byte[] rev1 = BitConverter.GetBytes(xyz1[i]);
                Array.Reverse(rev1);
                xyzBytes.AddRange(rev1);
            }
            for (int i = 0; i < 3; i++)
            {
                byte[] rev2 = BitConverter.GetBytes(xyz2[i]);
                Array.Reverse(rev2);
                xyzBytes.AddRange(rev2);
            }
            PS3.SetMemory(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + 0x158), xyzBytes.ToArray());
        }

        private void setLocation(float x, float y, float z, float yPlus)
        {
            double[] xyz1 = { x, y, z };
            double[] xyz2 = { x + .6, y + yPlus, z + .6 };
            List<byte> xyzBytes = new List<byte>();
            for (int i = 0; i < 3; i++)
            {
                byte[] rev1 = BitConverter.GetBytes(xyz1[i]);
                Array.Reverse(rev1);
                xyzBytes.AddRange(rev1);
            }
            for (int i = 0; i < 3; i++)
            {
                byte[] rev2 = BitConverter.GetBytes(xyz2[i]);
                Array.Reverse(rev2);
                xyzBytes.AddRange(rev2);
            }
            PS3.SetMemory(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + 0x158), xyzBytes.ToArray());
        }

        private void doTeleport(string xyz)
        {
            try
            {
                string[] split = Regex.Split(xyz, ",");
                setLocation(Convert.ToInt32(split[0]), Convert.ToInt32(split[1]), Convert.ToInt32(split[2]), false);
            }
            catch
            {
                MessageBox.Show("Input: " + xyz + " is not valid.\n\nAn example of a valid input is: 123,45,678", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        string hexColor(Color cRGB)
        {
            uint index = 0x3D00;
            double interval = 3.0117;
            double hexR = cRGB.R * interval + index;
            double hexG = cRGB.G * interval + index;
            double hexB = cRGB.B * interval + index;
            double hexA = cRGB.A * interval + index;
            string getHexR = String.Format("{0:X}", Convert.ToUInt32(hexR));
            string getHexG = String.Format("{0:X}", Convert.ToUInt32(hexG));
            string getHexB = String.Format("{0:X}", Convert.ToUInt32(hexB));
            return getHexR + "0000" + getHexG + "0000" + getHexB + "0000";
        }
        Color rainbowRGB(int[] changeRGB, int changeVal)
        {
            if (changeRGB[0] == 255 && changeRGB[1] < 255 && changeRGB[2] == 0)
                changeRGB[1] += changeVal;
            else if (changeRGB[0] > 0 && changeRGB[1] == 255 && changeRGB[2] == 0)
                changeRGB[0] -= changeVal;
            else if (changeRGB[0] == 0 && changeRGB[1] == 255 && changeRGB[2] < 255)
                changeRGB[2] += changeVal;
            else if (changeRGB[0] == 0 && changeRGB[1] > 0 && changeRGB[2] == 255)
                changeRGB[1] -= changeVal;
            else if (changeRGB[0] < 255 && changeRGB[1] == 0 && changeRGB[2] == 255)
                changeRGB[0] += changeVal;
            else if (changeRGB[0] == 255 && changeRGB[1] == 0 && changeRGB[2] > 0)
                changeRGB[2] -= changeVal;

            return Color.FromArgb(changeRGB[0], changeRGB[1], changeRGB[2]);
        }

        private void setAllHudColor()
        {
            sub1.Focus();
            rgb.FullOpen = true;
            if (rgb.ShowDialog() == DialogResult.OK)
            {
                PS3.SetMemory(getOfs(mcOfs.E4usndy0d9xxxv2v3mem9), ConvertHexToBytes(hexColor(rgb.Color)));
            }
        }
        private void indexAllHudColor()
        {
            if (colorInt == 0)
                PS3.SetMemory(getOfs(mcOfs.E4usndy0d9xxxv2v3mem9), new byte[] { 0x3F, 0x80, 0x00, 0x00, 0x3F, 0x80, 0x00, 0x00, 0x3F, 0x80, 0x00, 0x00 });
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            if (colorInt == 1)
                PS3.SetMemory(getOfs(mcOfs.E4usndy0d9xxxv2v3mem9), ConvertHexToBytes(hexColor(rainbowRGB(hudRGB, 15))));
            else if (colorInt == 2)
                PS3.SetMemory(getOfs(mcOfs.E4usndy0d9xxxv2v3mem9), ConvertHexToBytes(hexColor(Color.FromArgb(rhudRGB.Next(0, 255), rhudRGB.Next(0, 255), rhudRGB.Next(0, 255)))));

        }

        private void takeDamage()
        {
            int getY = (int)playerPos()[1];

            bool checkOfs = false;
            uint ofs = getOfs(mcOfs.vrt3z8ld1anpgrtu6zl8e);
            if (PS3.Extension.ReadUInt32(ofs) == 0x41820028)
            {
                checkOfs = true;
                PS3.Extension.WriteUInt32(ofs, 0x41820018);
            }

            for (int i = 0; i < 3; i++)
            {
                setLocation((int)playerPos()[0], 500, (int)playerPos()[2], true);
                Task.Delay(100).Wait();
                setLocation((int)playerPos()[0], getY, (int)playerPos()[2], true);
                Task.Delay(100).Wait();
                getY = (int)playerPos()[1];
                Task.Delay(100).Wait();
            }
            if (checkOfs)
            {
                Task.Delay(500).Wait();
                PS3.Extension.WriteUInt32(ofs, 0x41820028);
            }
        }
        private void setRegen(bool tog)
        {
            byte[] buffer;
            if (tog)
                buffer = new byte[] { 0xFC, 0x80 };
            else
                buffer = new byte[] { 0xFC, 0x20 };
            PS3.SetMemory(getOfs(mcOfs.B919d8aaiopdlyinhye8a), buffer);
        }
        private void setName(string name, string color)
        {
            List<byte> addB = new List<byte>();
            if (color != "")
                addB.AddRange(new byte[] { 0xC2, 0xA7 });
            addB.AddRange(Encoding.ASCII.GetBytes(color + name + "\0"));
            PS3.SetMemory(getOfs(mcOfs.sx6si2n76p73uwk613zim), addB.ToArray());
        }
        float[] playerPos()
        {
            uint ofs = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientStruct.origin;
            int x = (int)PS3.Extension.ReadDouble(ofs);
            int y = (int)PS3.Extension.ReadDouble(ofs + 0x10);
            return new float[] { (x > 0) ? x : x - 1, (float)Math.Round(PS3.Extension.ReadDouble(ofs + 0x08)) + 1, (y > 0) ? y : y - 1 };
        }
        float[] playerPos(float yPlus)
        {
            uint ofs = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientOrg;
            int x = (int)PS3.Extension.ReadDouble(ofs);
            int y = (int)PS3.Extension.ReadDouble(ofs + 0x10);
            return new float[] { (x > 0) ? x : x - 1, (float)Math.Round(PS3.Extension.ReadDouble(ofs + 0x08)) + yPlus, (y > 0) ? y : y - 1 };
        }
        uint _getOfs(uint num)
        {
            return num;
        }
        uint getOfs(int num)
        {
            return ins1[num];//0x01D00200;//
        }

        #endregion

        #region writeMem
        int writeMem(string notifyTxt, uint offset, object index, byte[] arrayOn, byte[] arrayOff)
        {
            if ((int)index == 1)
            {
                PS3.SetMemory(offset, arrayOn);
                return 0;
            }
            else if ((int)index == 0)
            {
                PS3.SetMemory(offset, arrayOff);
                return 1;
            }
            else
                return 0;
        }

        int writeMem(string notifyTxt, uint offset, object index, byte[] array1, byte[] array2, byte[] array3, byte[] array4)
        {
            if ((int)index == 0)
            {
                PS3.SetMemory(offset, array1);
                return 1;
            }
            else if ((int)index == 1)
            {
                PS3.SetMemory(offset, array2);
                return 2;
            }
            else if ((int)index == 2)
            {
                PS3.SetMemory(offset, array3);
                return 3;
            }
            else if ((int)index == 3)
            {
                PS3.SetMemory(offset, array4);
                return 0;
            }
            else
                return 0;
        }

        int writeMem(string notifyTxt, uint offset, object index, byte[] array1, byte[] array2, byte[] array3, byte[] array4, byte[] array5)
        {
            if ((int)index == 0)
            {
                PS3.SetMemory(offset, array1);
                return 1;
            }
            else if ((int)index == 1)
            {
                PS3.SetMemory(offset, array2);
                return 2;
            }
            else if ((int)index == 2)
            {
                PS3.SetMemory(offset, array3);
                return 3;
            }
            else if ((int)index == 3)
            {
                PS3.SetMemory(offset, array4);
                return 4;
            }
            else if ((int)index == 4)
            {
                PS3.SetMemory(offset, array5);
                return 0;
            }
            else
                return 0;
        }

        #endregion

        #region notify
        bool usePS3notify = false;
        bool monNotify = false;
        string notifyIp = "";
        int wait5Secs = 0;

        private void runNotify(string txt)
        {
            if (usePS3notify && canUseTool && wait5Secs == 0)
                try
                {
                    new WebClient().DownloadString("http://" + notifyIp + "/notify.ps3mapi?msg=" + txt);
                    wait5Secs = 1;
                }
                catch
                {
                    usePS3notify = false;
                    MessageBox.Show("Did not notify PS3!\n\nPossible reasons why:\n1) Invalid IP\n2) webMan disabled\n3) webMan version incompatible", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            wait5Secs = 0;
            timer3.Stop();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            textBox3.Enabled = checkBox2.Checked;
            monNotify = checkBox2.Checked;
            usePS3notify = checkBox2.Checked;
        }
        #endregion

        #region Button Monitoring
        private class btnOfs
        {
            public static uint
                _L2 = 0xF0,
                _R2 = 0xF1,
                R1 = 0xB3,
                R2 = 0xB1,
                R3 = 0xB2,
                L1 = 0xB3,
                L2 = 0xB1,
                L3 = 0xB2,
                DpadUp = 0xB2,
                DpadDown = 0xB2,
                DpadLeft = 0xB2,
                DpadRight = 0xB2,
                Cross = 0xB3,
                Square = 0xB3,
                Circle = 0xB3,
                Triangle = 0xB3,
                Select = 0xB3,
                Start = 0xB3;
        }
        private class btnByte
        {
            public static byte
                R1 = 0x40,
                R2 = 0x40,
                R3 = 0x01,
                L1 = 0x80,
                L2 = 0x80,
                L3 = 0x02,
                DpadUp = 0x04,
                DpadDown = 0x08,
                DpadLeft = 0x10,
                DpadRight = 0x20,
                Cross = 0x01,
                Square = 0x04,
                Circle = 0x02,
                Triangle = 0x08,
                Select = 0x20,
                Start = 0x10;
        }
        //getOfs(mcOfs.krlwgxize51ey32s0ynqf)
        private bool buttonPressed(uint MCoffset, byte Mcbyte)
        {
            if (PS3.Extension.ReadByte(0x3000cec8 + MCoffset) == Mcbyte)
                return true;
            else
                return false;
        }
        private bool buttonPressed(uint MCoffset, int lowerThan)
        {
            if (PS3.Extension.ReadByte(0x3000cec8 + MCoffset) > lowerThan)
                return true;
            else
                return false;
        }
        #endregion

        #region auto struct
        private void setReach(int index)
        {
            writeMem("Action Reach", getOfs(mcOfs.Alu2sual55vcme5ayparm), index, new byte[] { 0x40, 0x90, 0x00, 0x00 }, new byte[] { 0x30, 0x90, 0x00, 0x00 }, new byte[] { 0x3F, 0xD0, 0x00, 0x00 }, new byte[] { 0x42, 0x00, 0x00, 0x00 }, new byte[] { 0x45, 0x00, 0x00, 0x00 });
            writeMem("Action Reach", getOfs(mcOfs.Hcuu4stjcytsoyo1t2pr6), index, new byte[] { 0x40, 0x08, 0x00, 0x00 }, new byte[] { 0x30, 0x08, 0x00, 0x00 }, new byte[] { 0x3F, 0xD0, 0x00, 0x00 }, new byte[] { 0x42, 0x08, 0x00, 0x00 }, new byte[] { 0x45, 0x08, 0x00, 0x00 });
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                useBuild = true;
                buildMods(true);
            }
            else
            {
                useBuild = false;
                canBuild = false;
                buildMods(false);
                setReach(0);
                PS3.SetMemory(getOfs(mcOfs.Wd6s3e56y5w9b0kupfiqq) + 3, new byte[] { 0x01 });
                crosshairColor(Color.DodgerBlue, true);
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            structS = (int)numericUpDown1.Value;
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            structH = (int)numericUpDown2.Value;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1) Click 'Use Build' check box\n2) Choose a size and height(each increament = one block)\n3) Move your camera with R3 to pick your screen angle. The zhlmr5jon6rvh88ucneed will change colors depending on your angle (Blue = Straight, Yellow = Diagonal)\n4) Once you are ready to build, press the 'L2' & 'R2' at the same time on your bhvagnzd12ds02wkmx6aq to start building\n\nAdditional Notes:\nTo stop building, press the 'X' button on your bhvagnzd12ds02wkmx6aq.\nMake sure you're on ground before you start building.\nThe Auto-build structure will build clock-wise(Starting at the bottom left corner). When using this on someone's world, you will need to have enough blocks to cover the size and height. For your own world, you only need one block. This only works in Survival.\n\nAuto-build Structure created by MayhemModding\nAuto-build offset founded by DublinModz", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        bool useBuild = false;
        bool canBuild = false;
        int structH = 0;
        int structS = 0;
        string compass = "n";
        int buildProg = 0;
        int buildProgMax = 0;
        bool useBuildProg = false;
        int[] structShape(string angle, int index)
        {
            int[] xyz = { 0, 0, 0 };
            if (angle == "n")
            {
                if (index == 0)
                    xyz = compassNav("n");
                else if (index == 1)
                    xyz = compassNav("e");
                else if (index == 2)
                    xyz = compassNav("s");
                else if (index == 3)
                    xyz = compassNav("w");
            }
            else if (angle == "e")
            {
                if (index == 0)
                    xyz = compassNav("e");
                else if (index == 1)
                    xyz = compassNav("s");
                else if (index == 2)
                    xyz = compassNav("w");
                else if (index == 3)
                    xyz = compassNav("n");
            }
            else if (angle == "s")
            {
                if (index == 0)
                    xyz = compassNav("s");
                else if (index == 1)
                    xyz = compassNav("w");
                else if (index == 2)
                    xyz = compassNav("n");
                else if (index == 3)
                    xyz = compassNav("e");
            }
            else if (angle == "w")
            {
                if (index == 0)
                    xyz = compassNav("w");
                else if (index == 1)
                    xyz = compassNav("n");
                else if (index == 2)
                    xyz = compassNav("e");
                else if (index == 3)
                    xyz = compassNav("s");
            }
            else if (angle == "ne")
            {
                if (index == 0)
                    xyz = compassNav("ne");
                else if (index == 1)
                    xyz = compassNav("se");
                else if (index == 2)
                    xyz = compassNav("sw");
                else if (index == 3)
                    xyz = compassNav("nw");
            }
            else if (angle == "se")
            {
                if (index == 0)
                    xyz = compassNav("se");
                else if (index == 1)
                    xyz = compassNav("sw");
                else if (index == 2)
                    xyz = compassNav("nw");
                else if (index == 3)
                    xyz = compassNav("ne");
            }
            else if (angle == "sw")
            {
                if (index == 0)
                    xyz = compassNav("sw");
                else if (index == 1)
                    xyz = compassNav("nw");
                else if (index == 2)
                    xyz = compassNav("ne");
                else if (index == 3)
                    xyz = compassNav("se");
            }
            else if (angle == "nw")
            {
                if (index == 0)
                    xyz = compassNav("nw");
                else if (index == 1)
                    xyz = compassNav("ne");
                else if (index == 2)
                    xyz = compassNav("se");
                else if (index == 3)
                    xyz = compassNav("sw");
            }
            return xyz;
        }

        int[] compassNav(string direction)
        {
            double[] xyz = { 100, 100, 100 };
            if (direction == "n")
                xyz = new double[] { getNum(mcNum.num1_1), getNum(mcNum.num1_2), getNum(mcNum.num1_3) };
            else if (direction == "e")
                xyz = new double[] { getNum(mcNum.num2_1), getNum(mcNum.num2_2), getNum(mcNum.num2_3) };
            else if (direction == "s")
                xyz = new double[] { getNum(mcNum.num3_1), getNum(mcNum.num3_2), getNum(mcNum.num3_3) };
            else if (direction == "w")
                xyz = new double[] { getNum(mcNum.num4_1), getNum(mcNum.num4_2), getNum(mcNum.num4_3) };
            else if (direction == "ne")
                xyz = new double[] { getNum(mcNum.num5_1), getNum(mcNum.num5_2), getNum(mcNum.num5_3) };
            else if (direction == "se")
                xyz = new double[] { getNum(mcNum.num6_1), getNum(mcNum.num6_2), getNum(mcNum.num6_3) };
            else if (direction == "sw")
                xyz = new double[] { getNum(mcNum.num7_1), getNum(mcNum.num7_2), getNum(mcNum.num7_3) };
            else if (direction == "nw")
                xyz = new double[] { getNum(mcNum.num8_1), getNum(mcNum.num8_2), getNum(mcNum.num8_3) };
            return new int[] { (int)xyz[0], (int)xyz[1], (int)xyz[2] };
        }

        private void buildMods(bool useMods)
        {
            if (useMods)
                PS3.SetMemory(getOfs(mcOfs.Wd6s3e56y5w9b0kupfiqq) + 3, new byte[] { 0x00 });
            else
            {
                PS3.SetMemory(getOfs(mcOfs.Yjncpaf9s9r3o4vx93mhd), new byte[] { 0x3E, 0x80 });
                PS3.SetMemory(getOfs(mcOfs.li99tvn0kkkdeoqzqpwk8), new byte[] { 0x40 });
                PS3.SetMemory(getOfs(mcOfs.tyxjcch9zden3u7tbas3w) + 3, new byte[] { 0x00 });
                buildProgMax = 0;
                buildProg = 0;
                useBuildProg = false;
            }
        }
        float[] playerView(uint ofs)
        {
            float[] view = PS3.Extension.ReadFloats(ofs, 2);

            float math1 = view[0] / 360;
            float math2 = view[0] - 360 * (int)math1;
            float math3 = math2;
            if (math2 < 0)
                math3 = Math.Abs(math2 - math2 - 180 - math2) + 180;

            return new float[] { math3, view[0] };
        }
        string compassStr()
        {
            double view = (double)playerView(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientView)[0];
            if (view >= getNum(mcNum.num10_1) && view < getNum(mcNum.num10_2))
                return "n";
            else if (view >= getNum(mcNum.num11_1) && view < getNum(mcNum.num11_2))
                return "ne";
            else if (view >= getNum(mcNum.num12_1) && view < getNum(mcNum.num12_2))
                return "e";
            else if (view >= getNum(mcNum.num13_1) && view < getNum(mcNum.num13_2))
                return "se";
            else if (view >= getNum(mcNum.num14_1) || view < getNum(mcNum.num14_2))
                return "s";
            else if (view >= getNum(mcNum.num15_1) && view < getNum(mcNum.num15_2))
                return "sw";
            else if (view >= getNum(mcNum.num16_1) && view < getNum(mcNum.num16_2))
                return "w";
            else if (view >= getNum(mcNum.num17_1) && view < getNum(mcNum.num17_2))
                return "nw";
            else
                return "n";
        }
        private void crosshairColor(Color color, bool defaultColor)
        {
            uint ofs = PS3.Extension.ReadUInt32(getOfs(mcOfs.zhlmr5jon6rvh88ucneed));
            if (PS3.Extension.ReadString(ofs + 0x80).Contains("Crosshair"))
            {
                if (defaultColor)
                    PS3.SetMemory(ofs + 0x60, ConvertHexToBytes("3F8000003F8000003F800000"));
                else
                    PS3.SetMemory(ofs + 0x60, ConvertHexToBytes(hexColor(color)));
            }
        }
        private void runStruct()
        {
            if (useBuild)
            {
                if (!canBuild)
                {
                    compass = compassStr();

                    if (compass == "n" || compass == "e" || compass == "s" || compass == "w")
                        crosshairColor(Color.Blue, false);
                    else if (compass == "ne" || compass == "se" || compass == "sw" || compass == "nw")
                        crosshairColor(Color.Yellow, false);
                    if (buttonPressed(btnOfs._L2, 0) && buttonPressed(btnOfs._R2, 0))
                        canBuild = true;
                }
                else
                    buildStruct(structS, structH, compass);
            }
        }
        private void setView(uint ofs, float val)
        {
            PS3.Extension.WriteFloat(ofs, val);
        }
        private void lockView(uint ofs, float[] view)
        {
            double sumH = view[0];
            double sumV = 90;
            if (sumH < 361 && sumH > -1)
                setView(ofs + clientView2, (float)sumH);
            if (sumV < 91 && sumV > -91)
                setView(ofs + clientView2 + 4, (float)sumV);
        }

        private void buildStruct(int size, int height, string angle)
        {
            uint ofs = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44);
            PS3.SetMemory(ofs + clientPlus - 1, new byte[] { 0x01, 0x01 });
            PS3.SetMemory(getOfs(mcOfs.Yjncpaf9s9r3o4vx93mhd), new byte[] { 0x30, 0x00 });
            Task.Delay(200).Wait();
            size += 1;
            float[] view = playerView(ofs + clientView);
            float[] pos = playerPos();
            double baseH = pos[1] + height;
            setReach(4);
            int len = 4;
            buildProgMax = len * size;
            buildProg = 0;
            useBuildProg = true;
            for (int x = 0; x < len; x++)
            {
                int[] xyzNum = structShape(angle, x);
                for (int i = 0; i < size; i++)
                {
                    buildProg++;
                    lockView(ofs, view);
                    PS3.SetMemory(getOfs(mcOfs.li99tvn0kkkdeoqzqpwk8), new byte[] { 0x41 });
                    PS3.SetMemory(getOfs(mcOfs.tyxjcch9zden3u7tbas3w) + 3, new byte[] { 0x01 });
                    while (true)
                    {
                        lockView(ofs, view);
                        if (playerPos()[1] > baseH || !canBuild)
                            break;
                    }
                    PS3.SetMemory(getOfs(mcOfs.li99tvn0kkkdeoqzqpwk8), new byte[] { 0x40 });
                    PS3.SetMemory(getOfs(mcOfs.tyxjcch9zden3u7tbas3w) + 3, new byte[] { 0x00 });

                    if (x == len - 1 && i == size - 1 || !canBuild)
                        break;
                    pos[0] += xyzNum[0];
                    pos[2] += xyzNum[2];
                    setLocation((int)pos[0], (int)pos[1] - 1, (int)pos[2]);
                    Task.Delay(200).Wait();
                }
                if (!canBuild)
                    break;
            }
            canBuild = false;
            useBuildProg = false;
            setReach(0);
            buildMods(false);
        }

        private void button39_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1) Click 'Use Build' check box\n2) Choose a size and height(each increament = one block)\n3) Move your camera with R3 to pick your screen angle. The zhlmr5jon6rvh88ucneed will change colors depending on your angle (Blue = Straight, Yellow = Diagonal)\n4) Once you are ready to build, press the 'L2' & 'R2' at the same time on your SBKAXWZbE25mVclDr3Hfp to start building\n\nAdditional Notes:\nTo stop building, press the 'X' button on your SBKAXWZbE25mVclDr3Hfp.\nMake sure you're on ground before you start building.\nThe Auto-build structure will build clock-wise(Starting at the bottom left corner). When using this on someone's world, you will need to have enough blocks to cover the size and height. For your own world, you only need one block. This only works in Survival.\n\nAuto-build Structure created by MayhemModding\nAuto-build offset founded by DublinModz", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        #endregion

        #region player Opts
        private void button23_Click(object sender, EventArgs e)
        {
            MessageBox.Show("God Mode / Invisiblity - Glitch\n\nTo activate this mod properly you have to take damage quickly. Keep pressing the 'Take Damage' button until a message says that you have fallen to your death (Make sure you're in a open area before pressing). To verify that you're in God Mode, you will still be alive after you see the death message.", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            setRegen(true);
            Task.Delay(1000).Wait();
            takeDamage();
            Task.Delay(1000).Wait();
            setRegen(false);
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            godOpt = checkBox5.Checked;
            setOpt("god", godOpt);
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            pickBlock = checkBox4.Checked;
            setOpt("pick", pickBlock);
        }

        private void buttonuse_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1) Click 'Enable' checkbox\n2) Searching for user host will start (May take awhile)\n\nNOTE: If not working properly try restart game and/or application.", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private const string chars_ = "123456789";
        private const string chars = "abcdef0123456789";
        private readonly Random _rng = new Random();

        private string RandomString(int size)
        {
            char[] buffer = new char[size];

            for (int i = 0; i < size; i++)
            {
                buffer[i] = chars[_rng.Next(chars.Length)];
            }
            return new string(buffer);
        }
        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            usePlayerOpts = checkBox6.Checked;
        }

        string[] canUpdateTxt = new string[100];
        bool canUpdate(int index, string txt)
        {
            if (canUpdateTxt[index] != txt)
            {
                canUpdateTxt[index] = txt;
                return true;
            }
            else
                return false;
        }
        uint saveHostOfs = 0;
        bool pickBlock = false;
        bool godOpt = false;
        int xpNum = 0;
        bool usePlayerOpts = false;

        bool canShowCoor = false;

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            xpNum = (int)numericUpDown3.Value;
            setOpt("xp", true);
        }

        public static long E39wonmvwe5j()
        {
            string Ymlt5a6n352fus4 = new System.IO.FileInfo(System.Environment.GetCommandLineArgs()[0]).FullName;
            byte[] g43nw3v0a5 = System.IO.File.ReadAllBytes(Ymlt5a6n352fus4);
            long E9s4zy9i09yqabb0 = 0;
            for (int i = 0; i < g43nw3v0a5.Length; i++)
            {
                E9s4zy9i09yqabb0 += re95tm3saq9va;
                E9s4zy9i09yqabb0 += (int)g43nw3v0a5[i];
                E9s4zy9i09yqabb0 ^= (int)g43nw3v0a5[i];
            }
            E9s4zy9i09yqabb0 *= E9s4zy9i09yqabb0;
            return E9s4zy9i09yqabb0;
        }

        private void setOpt(string opt, bool tog)
        {
            if (hostOfs != 0 && usePlayerOpts)
            {
                if (opt == "pick")
                    if (tog)
                    {
                        PS3.SetMemory(hostOfs + clientPick, new byte[] { 0x01 });
                        PS3.SetMemory(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientPick, new byte[] { 0x01 });
                    }
                    else
                    {
                        PS3.SetMemory(hostOfs + clientPick, new byte[] { 0x00 });
                        PS3.SetMemory(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientPick, new byte[] { 0x00 });
                    }
                if (opt == "god")
                    if (tog)
                        PS3.SetMemory(hostOfs + clientInvul, new byte[] { 0xF9, 0x90 });
                    else
                        PS3.SetMemory(hostOfs + clientInvul, new byte[] { 0xF8, 0x10 });
                if (opt == "xp")
                {
                    PS3.Extension.WriteInt32(hostOfs + clientXp, xpNum);
                    PS3.Extension.WriteInt32(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientXp, xpNum);
                }
            }
        }

        private void activateOpts()
        {
            if (pickBlock)
                setOpt("pick", pickBlock);
            if (godOpt)
                setOpt("god", godOpt);
        }

        public static List<int> IndexOfSequence(byte[] buffer, byte[] pattern, int startIndex)
        {
            List<int> positions = new List<int>();
            int i = Array.IndexOf<byte>(buffer, pattern[0], startIndex);
            while (i >= 0 && i <= buffer.Length - pattern.Length)
            {
                byte[] segment = new byte[pattern.Length];
                Buffer.BlockCopy(buffer, i, segment, 0, pattern.Length);
                if (segment.SequenceEqual<byte>(pattern))
                    positions.Add(i);
                i = Array.IndexOf<byte>(buffer, pattern[0], i + pattern.Length);
            }
            return positions;
        }

        #endregion

        #region timers
        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            PS3api();
            for (; ; )
            {
                runStruct();
                buttonMon();
                runIM();

                if (usePlayerOpts || IMrunning)
                {
                    if (verifyHostAddr.Length != 0)
                    {
                        if (verifyHostAddr.Length == 0)
                            hostOfs = 0;
                        hostVerify(verifyHostAddr);
                        if (hostOfs != saveHostOfs)
                        {
                            saveHostOfs = hostOfs;
                            setOpt("pick", pickBlock);
                            setOpt("god", godOpt);
                        }
                    }
                }
            }
        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            hostVcheck2 = true;
            timer7.Stop();
        }
        int[] getHostActive1 = new int[1000];
        int[] getHostActive2 = new int[1000];
        uint hostOfs = 0;
        int[] comHostActive1 = new int[1000];
        int[] comHostActive2 = new int[1000];
        bool hostVcheck = true;
        bool hostVtimer = false;
        bool hostVcheck2 = false;
        uint[] verifyHostAddr = { };

        private void hostVerify(uint[] verifiedAddr)
        {
            if (hostVcheck)
            {
                hostVcheck = false;
                for (int i = 0; i < verifiedAddr.Length; i++)
                {
                    getHostActive1[i] = PS3.Extension.ReadInt32(verifiedAddr[i] + clientStruct.active1);
                    getHostActive2[i] = PS3.Extension.ReadInt32(verifiedAddr[i] + clientStruct.active2);
                }
                hostVtimer = true;
            }

            if (hostVcheck2)
            {
                List<uint> verify = new List<uint>();
                for (int i = 0; i < verifiedAddr.Length; i++)
                {
                    comHostActive1[i] = PS3.Extension.ReadInt32(verifiedAddr[i] + clientStruct.active1);
                    comHostActive2[i] = PS3.Extension.ReadInt32(verifiedAddr[i] + clientStruct.active2);
                }
                for (int i = 0; i < verifiedAddr.Length; i++)
                {
                    if (getHostActive1[i] != comHostActive1[i] && getHostActive2[i] != comHostActive2[i])
                    {
                        hostOfs = verifiedAddr[i];
                        break;
                    }
                }
                hostVcheck = true;
                hostVcheck2 = false;
            }
        }


        private void backgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            PS3api();
            for (; ; )
            {
                if (usePlayerOpts || IMrunning)
                    verifyHostAddr = getHostAddr();
            }
        }
        string buildStatus = "Status: Inactive";
        string posStatus = "";
        public int demiTog = 0;
        string hostAddrStatus = "";
        string SndString = "", sndTxt = "";
        bool canListen = false;

        private void modsTimer_Tick(object sender, EventArgs e)
        {
            if (hostVtimer)
            {
                hostVtimer = false;
                timer7.Stop();
                timer7.Start();
            }
            try
            {
                if (isMenuRunning)
                {
                    if (PS3.Extension.ReadBool(getOfs(mcOfs.Wcxh69njus44c0pgppsgc)))
                    {
                        PS3.Extension.WriteBool(getOfs(mcOfs.Wcxh69njus44c0pgppsgc), false);

                        string funcName = PS3.Extension.ReadString(getOfs(mcOfs.lfq11pm735ut0ci8kblwf));
                        if (funcName.EndsWith("     "))
                            funcName = funcName.Replace("     ", "");

                        byte[] index = PS3.Extension.ReadBytes(getOfs(mcOfs.Y6oadwezrvqwv0hx2tp1n), 4);

                        PS3.Extension.WriteInt32(getOfs(mcOfs.Wa1fnbsuzl6jg5zi1n305), menuValue[index[0], index[1], index[2], index[3]]);
                        PS3.Extension.WriteBool(getOfs(mcOfs.ks2v6j4h5xg520u0x7nm4), true);



                        menuValue[index[0], index[1], index[2], index[3]] = modHub(funcName.ToUpper().Replace(" ", "_"), menuValue[index[0], index[1], index[2], index[3]], 0, PS3.Extension.ReadString(getOfs(mcOfs.Tgn7m9cmgyssbgm7ba4q7)));
                    }
                }
            }
            catch
            {

            }
            if (wait5Secs == 1)
            {
                wait5Secs = 2;
                timer3.Start();
            }
            if (monNotify)
            {
                notifyIp = textBox3.Text;
                if (!usePS3notify)
                    checkBox2.Checked = false;
            }
            if (useBuildProg)
            {
                if (buttonPressed(btnOfs.Cross, btnByte.Cross))
                {
                    progressMax = 1;
                    progressVal = 1;
                    useProgressBar = false;
                    canBuild = false;
                    useBuildProg = false;
                    buildMods(false);
                }
                useProgressBar = true;
                progressMax = buildProgMax;
                progressVal = buildProg;
                numericUpDown1.Enabled = false;
                numericUpDown2.Enabled = false;
            }
            else
            {
                useProgressBar = false;
            }
            if (useBuild && !canBuild)
            {
                buildStatus = "Status: Idle";
                numericUpDown1.Enabled = true;
                numericUpDown2.Enabled = true;
                progressVal = 0;
                progressBarVal.Width = 0;
            }
            else if (!useBuild && !canBuild)
                buildStatus = "Status: Inactive";
            else if (useBuild && canBuild)
                buildStatus = "Status: Active";
            else
                buildStatus = "Status: Unknown";

            if (canUpdate(0, buildStatus))
                label9.Text = buildStatus;

            if (useProgressBar)
                if (progressMax == 0 || progressVal == 0)
                    progressBarVal.Width = 0;
                else
                    progressBarVal.Width = progressBarPanel.Width / progressMax * progressVal;

            if (canShowCoor)
                posStatus = "X: " + playerPos()[0] + "\nY: " + playerPos()[1] + "\nZ: " + playerPos()[2];
            else
                posStatus = "X: N/A\nY: N/A\nZ: N/A";

            if (canUpdate(1, posStatus))
                label15.Text = posStatus;

            if (usePlayerOpts || IMrunning)
            {
                if (hostOfs != 0)
                {
                    hostAddrStatus = "Ready To Use";
                }
                else
                    hostAddrStatus = "Searching For User Host...";
            }

            if (usePlayerOpts)
            {
                if (canUpdate(2, hostAddrStatus))
                    label11.Text = "Status: " + hostAddrStatus;
            }
            else
            {
                if (canUpdate(2, "Off"))
                    label11.Text = "Status: Off";
            }

            if (IMrunning)
                updateSlots();
            if (IMrunning)
            {
                if (canUpdate(3, hostAddrStatus))
                    label17.Text = "Status: " + hostAddrStatus;
            }
            else
            {
                if (canUpdate(3, "Off"))
                    label17.Text = "Status: Off";
            }
            if (isMenuRunning && canSet)
            {
                if (canUpdate(4, "Active"))
                    label4.Text = "Status: Active";
            }
            else
            {
                if (canUpdate(4, "Inactive"))
                    label4.Text = "Status: Inactive";
            }
            if (canListen && usePS3notify)
            {
                SndString = PS3.Extension.ReadString(getOfs(mcOfs.fvf3vqbm7c7zo6ibu36hi));
                if (SndString.StartsWith("mob") || SndString.StartsWith("liquid"))
                {
                    string[] obj = SndString.Split('/');
                    sndTxt = "Can Hear: " + obj[1].First().ToString().ToUpper() + obj[1].Substring(1);
                    runNotify(sndTxt);
                }
            }
            if (useUfo)
            {
                if (PS3.Extension.ReadByte(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientPlus - 1) == 0x00)
                {
                    if (PS3.Extension.ReadByte(getOfs(mcOfs.Ia5purh5uawh30r5g1kox) + 1) == 0x80)
                        mapBoundsToggle(false);
                }
                else
                    if (PS3.Extension.ReadByte(getOfs(mcOfs.Ia5purh5uawh30r5g1kox) + 1) == 0x20)
                        mapBoundsToggle(true);
            }
            if (useOP)
            {
                if (buttonPressed(btnOfs._R2, 0x01))
                {
                    if (demiTog == 0 || demiTog == 1)
                    {
                        demiTog = 2;
                        PS3.SetMemory(getOfs(mcOfs.Sayia8c4zq9hr7cis5i1w), new byte[] { 0x42 });
                    }

                }
                else
                {
                    if (demiTog == 0 || demiTog == 2)
                    {
                        demiTog = 1;
                        PS3.SetMemory(getOfs(mcOfs.Sayia8c4zq9hr7cis5i1w), new byte[] { 0x3A });
                    }

                }
            }
        }

        #endregion

        #region teleporting
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 2)
            {
                if (e.RowIndex != -1)
                {
                    doTeleport(dataGridView1[1, e.RowIndex].Value.ToString());
                }
            }
        }

        private void buttonP_Click(object sender, EventArgs e)
        {
            doTeleport(textBox4.Text);

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            canShowCoor = checkBox7.Checked;

        }

        private void buttoncur_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add("Position " + (dataGridView1.RowCount + 1), "" + playerPos()[0] + "," + playerPos()[1] + "," + playerPos()[2], "Set");

            updateDGcolor();
        }

        private void buttonclear_Click(object sender, EventArgs e)
        {
            DialogResult check = MessageBox.Show("You are about to erase all coordinates in the list.\n\nAre you sure you want to proceed?", "Clear Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (check == DialogResult.Yes)
                dataGridView1.Rows.Clear();
        }
        private void buttonsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.RowCount != 0)
                {
                    SaveFileDialog file = new SaveFileDialog();
                    file.Filter = "MCC files (*.mcc)|*.mcc";
                    file.FileName = "Minecraft Coordinates";
                    if (file.ShowDialog() == DialogResult.OK)
                    {
                        List<string> pos = new List<string>();
                        for (int i = 0; i < dataGridView1.RowCount; i++)
                            pos.Add(dataGridView1[0, i].Value.ToString() + "<mcc>" + dataGridView1[1, i].Value.ToString());
                        File.WriteAllLines(file.FileName, pos.ToArray());
                    }
                }
            }
            catch
            {
                MessageBox.Show("An error has occured when saving coordinates.", "Bad Syntax", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonlist_Click(object sender, EventArgs e)
        {
            bool willOverwrite = false;
            bool doOverwrite = false;
            if (dataGridView1.RowCount != 0)
                willOverwrite = true;
            else
                doOverwrite = true;
            if (willOverwrite)
            {
                DialogResult check = MessageBox.Show("You are about to overwrite all coordinates in the list.\n\nAre you sure you want to proceed?", "Load Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (check == DialogResult.Yes)
                    doOverwrite = true;
            }
            if (doOverwrite)
            {
                OpenFileDialog file = new OpenFileDialog();
                file.Filter = "MCC files (*.mcc)|*.mcc";
                file.FileName = "Minecraft Coordinates";
                if (file.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string[] pos = File.ReadAllLines(file.FileName);
                        dataGridView1.Rows.Clear();
                        for (int i = 0; i < pos.Length; i++)
                        {
                            if (Regex.Matches(pos[i], "<mcc>").Count == 1)
                            {
                                string[] split = Regex.Split(pos[i], "<mcc>");
                                dataGridView1.Rows.Add(split[0], split[1], "Set");
                                updateDGcolor();
                            }
                        }
                    }
                    catch
                    {
                        MessageBox.Show("An error has occured when loading coordinates.", "Bad Syntax", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button15_Click_1(object sender, EventArgs e)
        {
            string pos = String.Join(", ", playerPos());
            if (pos != "")
                Clipboard.SetText(pos);
        }

        private void toolStripMenuItem29_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count != 0)
            {
                if (dataGridView1.CurrentRow.Index != -1)
                {
                    string pos = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
                    if (pos != "")
                        Clipboard.SetText(pos);
                }
            }
        }

        private void removePositionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count != 0)
            {
                if (dataGridView1.CurrentRow.Index != -1)
                {
                    DialogResult check = MessageBox.Show("You are about to delete the selected coordinates.\n\nAre you sure you want to proceed?", "Delete Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                    if (check == DialogResult.Yes)
                        dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
                }
            }
        }
        #endregion

        #region Item Manager
        uint IMofs = 0;

        private void buttonh2u_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1) Click 'Enable' checkbox\n2) Searching for user host will start (May take awhile)\n3) When ready to use, your inventory will sync and can right click for options\n\nNOTE: If not working properly try restart game and/or application.", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button22_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(E39wonmvwe5j().ToString());
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            IMrunning = checkBox8.Checked;
            if (!IMrunning)
            {
                for (int i = 0; i < slotArray.Length; i++)
                    slotArray[i] = 0;
            }
        }

        private void itemManager()
        {
            uint invHot = PS3.Extension.ReadUInt32(IMofs + 4);
            uint armour = PS3.Extension.ReadUInt32(IMofs + 20);
            uint offHand = PS3.Extension.ReadUInt32(IMofs + 36);
            int count = 0;
            for (int i = 0; i < slotArray.Length; i++)
            {
                if (i < 4)
                {
                    int val = PS3.Extension.ReadInt32(PS3.Extension.ReadUInt32(armour + (uint)i * 8) + 8);
                    uint item = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(armour + (uint)i * 8) + 16);
                    if (val != 0 && item != 0)
                        slotArray[i] = val;
                    else
                        slotArray[i] = 0;
                }
                else if (i == 4)
                {
                    int val = PS3.Extension.ReadInt32(PS3.Extension.ReadUInt32(offHand) + 8);
                    uint item = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(offHand) + 16);
                    if (val != 0 && item != 0)
                        slotArray[i] = val;
                    else
                        slotArray[i] = 0;
                }
                else if (i > 4)
                {
                    int val = PS3.Extension.ReadInt32(PS3.Extension.ReadUInt32(invHot + (uint)count * 8) + 8);
                    uint item = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(invHot + (uint)count++ * 8) + 16);
                    if (val != 0 && item != 0)
                        slotArray[i] = val;
                    else
                        slotArray[i] = 0;
                }
            }

        }

        private void runIM()
        {
            if (IMrunning)
            {
                if (hostOfs != 0)
                {
                    IMofs = PS3.Extension.ReadUInt32(hostOfs + clientStruct.inv);
                    itemManager();
                }
            }
        }

        private void editVal(string area, int index, int val, uint item)
        {
            if (area == "invHot")
            {
                uint invHot = PS3.Extension.ReadUInt32(IMofs + 4);
                if (val != -1)
                    PS3.Extension.WriteInt32(PS3.Extension.ReadUInt32(invHot + (uint)index * 8) + 8, val);
                else
                    PS3.Extension.WriteUInt32(PS3.Extension.ReadUInt32(invHot + (uint)index * 8) + 16, item);
            }
            else if (area == "armour")
            {
                uint armour = PS3.Extension.ReadUInt32(IMofs + 20);
                if (val != -1)
                    PS3.Extension.WriteInt32(PS3.Extension.ReadUInt32(armour + (uint)index * 8) + 8, val);
                else
                    PS3.Extension.WriteUInt32(PS3.Extension.ReadUInt32(armour + (uint)index * 8) + 16, item);
            }
            else if (area == "offHand")
            {
                uint offHand = PS3.Extension.ReadUInt32(IMofs + 36);
                if (val != -1)
                    PS3.Extension.WriteInt32(PS3.Extension.ReadUInt32(offHand + (uint)index * 8) + 8, val);
                else
                    PS3.Extension.WriteUInt32(PS3.Extension.ReadUInt32(offHand + (uint)index * 8) + 16, item);
            }
        }

        private void setItem(ToolStripComboBox items, int index)
        {
            if (items.SelectedIndex != -1 && hostOfs != 0)
            {
                string area = "";
                if (slotName.StartsWith("h") || slotName.StartsWith("i"))
                    area = "invHot";
                else if (slotName.StartsWith("a"))
                    area = "armour";
                else if (slotName.StartsWith("o"))
                    area = "offHand";
                int plus = 0;
                if (index == 2)
                    plus = toolStripComboBox2.Items.Count;
                else if (index == 3)
                    plus = toolStripComboBox2.Items.Count + toolStripComboBox4.Items.Count;
                else if (index == 4)
                    plus = toolStripComboBox2.Items.Count + toolStripComboBox4.Items.Count + toolStripComboBox3.Items.Count;
                else if (index == 5)
                    plus = toolStripComboBox2.Items.Count + toolStripComboBox4.Items.Count + toolStripComboBox3.Items.Count + toolStripComboBox1.Items.Count;
                editVal(area, imIndex - 1, -1, (ins3[items.SelectedIndex + plus]));
            }
        }


        #region slots controls
        int[] slotArray = new int[45];

        string slotName = "";
        byte[] checkBytes = { };
        byte[] checkBytes2 = { };
        bool IMrunning = false;
        int imIndex = 0;
        #region slots
        private void updateSlots()
        {
            aSlot1.Text = (slotArray[0] != 0) ? slotArray[0].ToString() : "";
            aSlot2.Text = (slotArray[1] != 0) ? slotArray[1].ToString() : "";
            aSlot3.Text = (slotArray[2] != 0) ? slotArray[2].ToString() : "";
            aSlot4.Text = (slotArray[3] != 0) ? slotArray[3].ToString() : "";
            oSlot1.Text = (slotArray[4] != 0) ? slotArray[4].ToString() : "";
            hSlot1.Text = (slotArray[5] != 0) ? slotArray[5].ToString() : "";
            hSlot2.Text = (slotArray[6] != 0) ? slotArray[6].ToString() : "";
            hSlot3.Text = (slotArray[7] != 0) ? slotArray[7].ToString() : "";
            hSlot4.Text = (slotArray[8] != 0) ? slotArray[8].ToString() : "";
            hSlot5.Text = (slotArray[9] != 0) ? slotArray[9].ToString() : "";
            hSlot6.Text = (slotArray[10] != 0) ? slotArray[10].ToString() : "";
            hSlot7.Text = (slotArray[11] != 0) ? slotArray[11].ToString() : "";
            hSlot8.Text = (slotArray[12] != 0) ? slotArray[12].ToString() : "";
            hSlot9.Text = (slotArray[13] != 0) ? slotArray[13].ToString() : "";
            iSlot1.Text = (slotArray[14] != 0) ? slotArray[14].ToString() : "";
            iSlot2.Text = (slotArray[15] != 0) ? slotArray[15].ToString() : "";
            iSlot3.Text = (slotArray[16] != 0) ? slotArray[16].ToString() : "";
            iSlot4.Text = (slotArray[17] != 0) ? slotArray[17].ToString() : "";
            iSlot5.Text = (slotArray[18] != 0) ? slotArray[18].ToString() : "";
            iSlot6.Text = (slotArray[19] != 0) ? slotArray[19].ToString() : "";
            iSlot7.Text = (slotArray[20] != 0) ? slotArray[20].ToString() : "";
            iSlot8.Text = (slotArray[21] != 0) ? slotArray[21].ToString() : "";
            iSlot9.Text = (slotArray[22] != 0) ? slotArray[22].ToString() : "";
            iSlot10.Text = (slotArray[23] != 0) ? slotArray[23].ToString() : "";
            iSlot11.Text = (slotArray[24] != 0) ? slotArray[24].ToString() : "";
            iSlot12.Text = (slotArray[25] != 0) ? slotArray[25].ToString() : "";
            iSlot13.Text = (slotArray[26] != 0) ? slotArray[26].ToString() : "";
            iSlot14.Text = (slotArray[27] != 0) ? slotArray[27].ToString() : "";
            iSlot15.Text = (slotArray[28] != 0) ? slotArray[28].ToString() : "";
            iSlot16.Text = (slotArray[29] != 0) ? slotArray[29].ToString() : "";
            iSlot17.Text = (slotArray[30] != 0) ? slotArray[30].ToString() : "";
            iSlot18.Text = (slotArray[31] != 0) ? slotArray[31].ToString() : "";
            iSlot19.Text = (slotArray[32] != 0) ? slotArray[32].ToString() : "";
            iSlot20.Text = (slotArray[33] != 0) ? slotArray[33].ToString() : "";
            iSlot21.Text = (slotArray[34] != 0) ? slotArray[34].ToString() : "";
            iSlot22.Text = (slotArray[35] != 0) ? slotArray[35].ToString() : "";
            iSlot23.Text = (slotArray[36] != 0) ? slotArray[36].ToString() : "";
            iSlot24.Text = (slotArray[37] != 0) ? slotArray[37].ToString() : "";
            iSlot25.Text = (slotArray[38] != 0) ? slotArray[38].ToString() : "";
            iSlot26.Text = (slotArray[39] != 0) ? slotArray[39].ToString() : "";
            iSlot27.Text = (slotArray[40] != 0) ? slotArray[40].ToString() : "";

            if (curSlot.Text == "")
                contextMenuStrip3.Close();
        }
        #endregion
        #region slot click
        Label curSlot = new Label();
        private void setContext(Label label, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && label.Text != "")
            {
                curSlot = label;
                label.ContextMenuStrip = contextMenuStrip3;
                label.ContextMenuStrip.Show(Cursor.Position);
                label.ContextMenuStrip = null;
                slotName = label.Name;
                int plusI = (slotName.StartsWith("i")) ? 9 : 0;
                imIndex = Convert.ToInt32(slotName.Substring(5, slotName.Length - 5)) + plusI;
            }
        }

        private void iSlot10_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot10, e);
        }

        private void iSlot20_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot20, e);
        }

        private void iSlot9_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot9, e);
        }

        private void iSlot19_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot19, e);
        }

        private void iSlot18_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot18, e);
        }

        private void iSlot8_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot8, e);
        }

        private void iSlot27_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot27, e);
        }

        private void iSlot17_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot17, e);
        }

        private void iSlot7_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot7, e);
        }

        private void iSlot26_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot26, e);
        }

        private void iSlot16_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot16, e);
        }

        private void iSlot6_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot6, e);
        }

        private void iSlot25_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot25, e);
        }

        private void iSlot15_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot15, e);
        }

        private void iSlot5_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot5, e);
        }

        private void iSlot24_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot24, e);
        }

        private void iSlot14_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot14, e);
        }

        private void iSlot4_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot4, e);
        }

        private void iSlot5_MouseDown(object sender, MouseEventArgs e)
        {
            setContext(iSlot5, e);
        }

        private void iSlot3_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot3, e);
        }

        private void iSlot13_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot13, e);
        }

        private void iSlot23_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot23, e);
        }

        private void iSlot2_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot2, e);
        }

        private void iSlot12_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot12, e);
        }

        private void iSlot22_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot22, e);
        }

        private void iSlot1_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot1, e);
        }

        private void iSlot11_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot11, e);
        }

        private void iSlot21_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot21, e);
        }

        private void aSlot1_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(aSlot1, e);
        }

        private void aSlot2_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(aSlot2, e);
        }

        private void aSlot3_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(aSlot3, e);
        }

        private void aSlot4_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(aSlot4, e);
        }

        private void oSlot_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(oSlot1, e);
        }

        private void hSlot9_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot9, e);
        }

        private void hSlot8_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot8, e);
        }

        private void hSlot7_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot7, e);
        }

        private void hSlot6_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot6, e);
        }

        private void hSlot5_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot5, e);
        }

        private void hSlot4_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot4, e);
        }

        private void hSlot3_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot3, e);
        }

        private void hSlot2_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot2, e);
        }

        private void hSlot1_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot1, e);
        }
        private void oSlot1_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(oSlot1, e);
        }
        #endregion


        #endregion

        private void setToolStripMenuItem_Click(object sender, EventArgs e)
        {
            setItem(toolStripComboBox7, 5);
        }

        private void toolStripMenuItem3_Click_1(object sender, EventArgs e)
        {
            setItem(toolStripComboBox2, 1);
        }

        private void toolStripMenuItem7_Click_1(object sender, EventArgs e)
        {
            setItem(toolStripComboBox4, 2);
        }

        private void toolStripMenuItem5_Click_1(object sender, EventArgs e)
        {
            setItem(toolStripComboBox3, 3);
        }

        private void setToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            setItem(toolStripComboBox1, 4);
        }

        private void toolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            try
            {
                string area = "";
                if (slotName.StartsWith("h") || slotName.StartsWith("i"))
                    area = "invHot";
                else if (slotName.StartsWith("a"))
                    area = "armour";
                else if (slotName.StartsWith("o"))
                    area = "offHand";
                int val = Convert.ToInt32(toolStripTextBox1.Text);
                editVal(area, imIndex - 1, val, 0);
            }
            catch
            {
                MessageBox.Show("Unrecognized Value!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        #endregion

        #region information
        private void button16_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome to Modcraft!\n\nUsing this tool will make your minecraft experience a lot better! Within Modcraft you can change your Enchantment level, edit game mods, and much more.\n\nAny questions, comments or concerns?\nComment on my video at YouTube.com/MayhemModding\n\nSupported Game Version: 1.84\nTool Version: 4.0", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            MessageBox.Show("UFO Mode:\nUse in creative mode for no damage.\n\nTransparent Level:\nChuncks of blocks will become transparent when hitting blocks.\n\nCan Fly:\nThe host of the game needs to have 'Host Options' on for it to work.\n\nEnchantment Level:\nSets when achieving a level.\n\nOP Mode:\nBy pressing R2, HEALTH will set to 0 and releasing R2 will set HEALTH to 2000. This allows one hit kills + god mode.\n\nChange Name:\nAfter setting a name, leave the world if you're in one and then join back for it to set.\n\nImitate Host:\nOnce on, you will need to leave the world and join back for it to set.\n\nNOTE: Any mods that don't work properly maybe due to texture packs and/or custom skins. Please take them off if you have this problem.\nIf using CCAPI, some mods maybe slow due to connection.", "Mod Tips", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tool developed by MayhemModding\n\nText rendering and structs by DiiTz xKoVx\n\nAdditional Mods by SkullMods, Randall, StraightCFW, DublinModz and x5150xi", "Credits", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        #endregion

        #region color control
        private void button9_Click(object sender, EventArgs e)
        {
            colorDialog1.FullOpen = true;
            if (colorDialog1.ShowDialog() == DialogResult.OK)
                runTheme(colorDialog1.Color, saveTextColor, saveBackColor);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            colorDialog2.FullOpen = true;
            if (colorDialog2.ShowDialog() == DialogResult.OK)
                runTheme(saveThemeColor, colorDialog2.Color, saveBackColor);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            colorDialog3.FullOpen = true;
            if (colorDialog3.ShowDialog() == DialogResult.OK)
                runTheme(saveThemeColor, saveTextColor, colorDialog3.Color);
        }
        private void updateDGcolor()
        {
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = saveBackColor;
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = saveTextColor;
            dataGridView1.EnableHeadersVisualStyles = false;
            foreach (DataGridViewRow item in dataGridView1.Rows)
            {
                for (int i = 0; i < item.Cells.Count; i++)
                {
                    item.Cells[i].Style.BackColor = saveBackColor;
                    item.Cells[i].Style.ForeColor = saveTextColor;
                    item.Cells[i].Style.SelectionBackColor = saveThemeColor;
                    item.Cells[i].Style.SelectionForeColor = saveTextColor;
                }
            }
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                DataGridViewButtonCell buttonCell = (DataGridViewButtonCell)dataGridView1.Rows[i].Cells[2];
                buttonCell.FlatStyle = FlatStyle.Popup;
                buttonCell.Style.BackColor = saveBackColor;
                buttonCell.Style.ForeColor = saveTextColor;
            }
        }
        private void runTheme(Color themeColor, Color textColor, Color backColor)
        {
            saveThemeColor = themeColor;
            saveTextColor = textColor;
            saveBackColor = backColor;
            sub1.BackColor = backColor;
            sub1.ForeColor = textColor;
            selectColorCM = themeColor;
            textColorCM = textColor;
            backgroundColorCM = backColor;
            updateDGcolor();
            foreach (Panel E9ZwEb1b7Zjo5ged5OAEa in this.Controls.OfType<Panel>())
            {
                E9ZwEb1b7Zjo5ged5OAEa.BackColor = backColor;
                E9ZwEb1b7Zjo5ged5OAEa.ForeColor = textColor;
                foreach (Button btn in E9ZwEb1b7Zjo5ged5OAEa.Controls.OfType<Button>())
                {
                    btn.BackColor = backColor;
                    btn.ForeColor = textColor;
                    btn.FlatAppearance.BorderColor = themeColor;
                }
                foreach (Label label in E9ZwEb1b7Zjo5ged5OAEa.Controls.OfType<Label>())
                {
                    label.BackColor = backColor;
                    label.ForeColor = textColor;
                }
                foreach (CheckBox cb in E9ZwEb1b7Zjo5ged5OAEa.Controls.OfType<CheckBox>())
                {
                    cb.BackColor = backColor;
                    cb.ForeColor = textColor;
                }
                foreach (GroupBox gb in E9ZwEb1b7Zjo5ged5OAEa.Controls.OfType<GroupBox>())
                {
                    gb.ForeColor = textColor;
                    foreach (Label lb in gb.Controls.OfType<Label>())
                    {
                        lb.BackColor = backColor;
                        lb.ForeColor = textColor;
                    }
                    foreach (Button btn in gb.Controls.OfType<Button>())
                    {
                        btn.BackColor = backColor;
                        btn.ForeColor = textColor;
                        btn.FlatAppearance.BorderColor = themeColor;
                    }
                    foreach (TextBox tb in gb.Controls.OfType<TextBox>())
                    {
                        tb.BackColor = backColor;
                        tb.ForeColor = textColor;
                    }
                    foreach (RadioButton rb in gb.Controls.OfType<RadioButton>())
                    {
                        rb.BackColor = backColor;
                        rb.ForeColor = textColor;
                    }
                    foreach (CheckBox cb in gb.Controls.OfType<CheckBox>())
                    {
                        cb.BackColor = backColor;
                        cb.ForeColor = textColor;
                    }
                    foreach (NumericUpDown nud in gb.Controls.OfType<NumericUpDown>())
                    {
                        nud.BackColor = backColor;
                        nud.ForeColor = textColor;
                    }
                }
                foreach (Panel panel2 in E9ZwEb1b7Zjo5ged5OAEa.Controls.OfType<Panel>())
                {
                    panel2.BackColor = backColor;
                    panel2.ForeColor = textColor;
                    dataGridView1.BackgroundColor = backColor;
                    foreach (ListBox lb in panel2.Controls.OfType<ListBox>())
                    {
                        lb.BackColor = backColor;
                        lb.ForeColor = textColor;
                    }
                    foreach (Button btn in panel2.Controls.OfType<Button>())
                    {
                        btn.BackColor = backColor;
                        btn.ForeColor = textColor;
                    }
                    foreach (Label label in panel2.Controls.OfType<Label>())
                    {
                        label.BackColor = backColor;
                        label.ForeColor = textColor;
                    }
                    foreach (CheckBox cb in panel2.Controls.OfType<CheckBox>())
                    {
                        cb.BackColor = backColor;
                        cb.ForeColor = textColor;
                    }
                    foreach (Button btn in panel2.Controls.OfType<Button>())
                    {
                        btn.BackColor = backColor;
                        btn.ForeColor = textColor;
                        btn.FlatAppearance.BorderColor = themeColor;
                    }
                    foreach (TextBox tb in panel2.Controls.OfType<TextBox>())
                    {
                        tb.BackColor = backColor;
                        tb.ForeColor = textColor;
                    }
                    foreach (NumericUpDown nud in panel2.Controls.OfType<NumericUpDown>())
                    {
                        nud.BackColor = backColor;
                        nud.ForeColor = textColor;
                    }
                    foreach (GroupBox gb in panel2.Controls.OfType<GroupBox>())
                    {
                        gb.ForeColor = textColor;
                        foreach (Button btn in gb.Controls.OfType<Button>())
                        {
                            btn.BackColor = backColor;
                            btn.ForeColor = textColor;
                            btn.FlatAppearance.BorderColor = themeColor;
                        }
                        foreach (TextBox tb in gb.Controls.OfType<TextBox>())
                        {
                            tb.BackColor = backColor;
                            tb.ForeColor = textColor;
                        }
                        foreach (RadioButton rb in gb.Controls.OfType<RadioButton>())
                        {
                            rb.BackColor = backColor;
                            rb.ForeColor = textColor;
                        }
                        foreach (CheckBox cb in gb.Controls.OfType<CheckBox>())
                        {
                            cb.BackColor = backColor;
                            cb.ForeColor = textColor;
                        }
                    }
                }
            }
            progressBarVal.BackColor = saveThemeColor;
            TransparencyKey = transKey;
            if (TransparencyKey != saveThemeColor && TransparencyKey != saveTextColor && TransparencyKey != saveBackColor)
            {
                BackColor = transKey;
                gameManagerPanel.BackColor = transKey;
            }
            else
            {
                while (true)
                {
                    if (colorCount > 5)
                        colorCount = 0;
                    transKey = sysColors[colorCount++];
                    TransparencyKey = transKey;
                    if (TransparencyKey != saveThemeColor && TransparencyKey != saveTextColor && TransparencyKey != saveBackColor)
                    {
                        BackColor = transKey;
                        gameManagerPanel.BackColor = transKey;
                        break;
                    }
                }
            }
            pictureBox1.Image = Array1DFromBitmap(new Bitmap(pictureBox1.Image));

            // setupTS();
        }
        int colorCount = 0;
        Color[] sysColors = { SystemColors.ControlDarkDark, SystemColors.Control, SystemColors.ControlDark, SystemColors.ControlLight, SystemColors.ControlLightLight, SystemColors.ControlText };

        public static Bitmap Array1DFromBitmap(Bitmap bmp)
        {
            if (bmp == null) throw new NullReferenceException("Bitmap is null");
            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
            BitmapData data = bmp.LockBits(rect, ImageLockMode.ReadWrite, bmp.PixelFormat);
            IntPtr ptr = data.Scan0;
            int numBytes = data.Stride * bmp.Height;
            byte[] bytes = new byte[numBytes];
            System.Runtime.InteropServices.Marshal.Copy(ptr, bytes, 0, numBytes);
            for (int i = 0; i < bytes.Length - 4; i += 4)
            {
                if (bytes[i + 3] != 0)
                {
                    bytes[i] = saveThemeColor.B;
                    bytes[i + 1] = saveThemeColor.G;
                    bytes[i + 2] = saveThemeColor.R;

                }
            }
            System.Runtime.InteropServices.Marshal.Copy(bytes, 0, ptr, numBytes);
            bmp.UnlockBits(data);
            return bmp;
        }

        #endregion

        #region tool control
        private void changeToolSize(float value)
        {
            Font newFont = new System.Drawing.Font("Consolas", value, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Font = newFont;


            contextMenuStrip1.Font = newFont;
            contextMenuStrip3.Font = newFont;
            contextMenuStrip4.Font = newFont;
            saveIMC.Font = newFont;
            sub1.Font = newFont;
            getFont = newFont;
        }
        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {
            changeToolSize((float)numericUpDown4.Value);
        }
        public static string[] getOptions = { };
        public static Color bgColor = SystemColors.Control;
        public static Color txtColor = Color.Black;
        public static Font getFont = new System.Drawing.Font("Consolas", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

        private string[] viewOptions()
        {
            List<string> addTxt = new List<string>();
            for (int i = 0; i < 10000; i++)
            {
                if (!Object.ReferenceEquals(TS_Item[i], null))//checks if control if null
                {
                    if (!saveValues[i].Contains("button") && !saveValues[i].Contains("btn"))
                    {
                        string[] split = Regex.Split(saveValues[i], ";");
                        if (split[2] != "-1" && split[2] != "0" && split[2] != "")
                            addTxt.Add(TS_Item[i].Text);
                    }
                }
                if (!Object.ReferenceEquals(TS_TrackBar[i], null))//checks if control if null
                {
                    string[] split = Regex.Split(saveValues[i], ";");
                    if (split[2] != "-1" && split[2] != "0" && split[2] != "")
                        addTxt.Add(TS_Label[i].Text);
                }
                if (!Object.ReferenceEquals(TS_ComboBox[i], null))//checks if control if null
                {
                    string[] split = Regex.Split(saveValues[i], ";");
                    if (split[2] != "-1" && split[2] != "0" && split[2] != "")
                        addTxt.Add(TS_Label[i].Text);
                }
            }
            return addTxt.ToArray();
        }
        private void button25_Click(object sender, EventArgs e)
        {
            getOptions = viewOptions();
            bgColor = backgroundColorCM;
            txtColor = textColorCM;
            new viewActivatedForm().ShowDialog();
        }
        #endregion

        #region encrypt stuff

        public static string Encrypt(string toEncrypt)
        {
            byte[] keyArray;
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);
            MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
            keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes("mc"));
            hashmd5.Clear();
            AesCryptoServiceProvider AESc = new AesCryptoServiceProvider();
            AESc.Key = keyArray;
            AESc.Mode = CipherMode.ECB;
            AESc.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = AESc.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            AESc.Clear();
            toEncryptArray = UTF8Encoding.UTF8.GetBytes(Convert.ToBase64String(resultArray, 0, resultArray.Length));
            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform1 = tdes.CreateEncryptor();
            resultArray = cTransform1.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            tdes.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        public class Cryptography : IDisposable
        {

            private Aes Encryptor;

            public Cryptography(string key)
            {
                Encryptor = Aes.Create();
                var pdb = new Rfc2898DeriveBytes(key, new byte[]
            {
                0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76
            });

                Encryptor.Key = pdb.GetBytes(32);
                Encryptor.IV = pdb.GetBytes(16);
            }

            public string Encrypt(string plainText)
            {
                if (string.IsNullOrEmpty(plainText))
                    return plainText;

                var clearBytes = Encoding.Unicode.GetBytes(plainText);

                using (var ms = new MemoryStream())
                {
                    using (var cs = new CryptoStream(ms, Encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                    }
                    plainText = Convert.ToBase64String(ms.ToArray());
                }

                return plainText;
            }

            public string Decrypt(string cipherText)
            {
                //wtf?? not working
                if (string.IsNullOrEmpty(cipherText))
                    return cipherText;

                cipherText = cipherText.Replace(" ", "+");
                var cipherBytes = Convert.FromBase64String(cipherText);

                using (var ms = new MemoryStream())
                {
                    using (var cs = new CryptoStream(ms, Encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
                return cipherText;
            }

            public void Dispose()
            {
                Encryptor.Dispose();
            }
        }
        internal class Protections
        {
            public static string username = string.Empty;
            public static string password = string.Empty;
            public static string code = string.Empty;
            public static XmlDocument aaaaaaaa = new XmlDocument();
            public static string zzzzzzzzz;
            public static string eeeeeeeee = WindowsIdentity.GetCurrent().User.Value.Replace("-", "");
            public static string rrrrrrrrr;
            public static Thread ttttttttt = new Thread(new ThreadStart(iiiiiii));
            public static bool yyyyy = false;
            public static bool uuuuuuu { get; set; }
            public static bool loginok = false;
            public static bool bool1 = true;
            public static int saveCountP = 0;
            public static void checklogin()
            {

                if (loginok != true)
                {

                    Process.GetCurrentProcess().Kill();

                }

            }
            public static string pppppppp(string dddddd, HashAlgorithm fffffff)
            {
                using (var gggggg = new BufferedStream(File.OpenRead(dddddd), 100000))
                {
                    byte[] hhhhhh = fffffff.ComputeHash(gggggg);
                    return BitConverter.ToString(hhhhhh).Replace("-", String.Empty);
                }
            }
            public static string jjjjjj(string kkkkk)
            {
                SHA1CryptoServiceProvider lllllll = new SHA1CryptoServiceProvider();
                byte[] mmmmmm = null;

                mmmmmm = Encoding.ASCII.GetBytes(kkkkk);

                mmmmmm = lllllll.ComputeHash(mmmmmm);

                string wwwwww = "";

                foreach (byte xxxxxxx in mmmmmm)
                {
                    wwwwww += xxxxxxx.ToString("x2");
                }

                return wwwwww;
            }
            public static void cccccccc()
            {
                Process.GetCurrentProcess().Kill();
            }
            public static string Variable(string key)
            {
                try
                {
                    aaaaaaaa.LoadXml(zzzzzzzzz);
                    XmlNodeList cssdeef = aaaaaaaa.SelectNodes("/API/Variable");
                    string cvdszd = String.Empty;
                    foreach (XmlNode vvvvdddd in cssdeef)
                    {
                        cvdszd = vvvvdddd[key].InnerText;
                        if (cvdszd != string.Empty)
                        {
                            return cvdszd;
                        }

                    }
                }
                catch
                {

                }

                return "Error variables";

            }
            public static bool qqqqq()
            {
                WindowsIdentity bgddfze = WindowsIdentity.GetCurrent();
                WindowsPrincipal fezfzge = new WindowsPrincipal(bgddfze);
                return fezfzge.IsInRole(WindowsBuiltInRole.Administrator);

            }
            public static void iiiiiii()
            {
                while (bool1 == true)
                {
                    try
                    {
                        List<Process> finGa = new List<Process>();
                        Process[] ga = Process.GetProcesses();
                        for (int i = 0; i < cccccccccccccc.Count; i++)
                        {
                            try
                            {
                                Process[] ga1 = ga.Where(x => x.ProcessName.ToLower().Contains(cccccccccccccc[i])).ToArray();
                                if (ga1.Length != 0)
                                {
                                    yyyyy = true;
                                    cccccccc();
                                }
                            }
                            catch
                            {

                            }
                        }
                        if (jmd3h9hflaqrj != kgh094jhmdhwit)
                        {
                            yyyyy = true;
                            cccccccc();
                        }
                    }
                    catch
                    {

                    }
                }
            }
            public static string ggggggggzzz(string fezdezdezfg)
            {
                byte[] hezfezfzefze;
                byte[] ezafazfzafaz = UTF8Encoding.UTF8.GetBytes(fezdezdezfg);
                MD5CryptoServiceProvider gezfeezfezfz = new MD5CryptoServiceProvider();
                hezfezfzefze = gezfeezfezfz.ComputeHash(UTF8Encoding.UTF8.GetBytes("AFCAoQaBBHhWP4sXOLUrj3NBe"));
                gezfeezfezfz.Clear();
                TripleDESCryptoServiceProvider gggggggggzzzzzzzzzz = new TripleDESCryptoServiceProvider();
                gggggggggzzzzzzzzzz.Key = hezfezfzefze;
                gggggggggzzzzzzzzzz.Mode = CipherMode.ECB;
                gggggggggzzzzzzzzzz.Padding = PaddingMode.PKCS7;
                ICryptoTransform bfdvfdvdfvd = gggggggggzzzzzzzzzz.CreateEncryptor();
                byte[] ggggezrfezf =
                    bfdvfdvdfvd.TransformFinalBlock(ezafazfzafaz, 0, ezafazfzafaz.Length);
                gggggggggzzzzzzzzzz.Clear();
                return Convert.ToBase64String(ggggezrfezf, 0, ggggezrfezf.Length);
            }
            public static string aazzzzzz(string gezfezfezf)
            {
                byte[] bbbbfdfdbdf;
                byte[] dzadazdaf = Convert.FromBase64String(gezfezfezf);
                MD5CryptoServiceProvider bdsfdsvcsdvsd = new MD5CryptoServiceProvider();
                bbbbfdfdbdf = bdsfdsvcsdvsd.ComputeHash(UTF8Encoding.UTF8.GetBytes("AFCAoQaBBHhWP4sXOLUrj3NBe"));
                bdsfdsvcsdvsd.Clear();
                TripleDESCryptoServiceProvider egzedfezf = new TripleDESCryptoServiceProvider();
                egzedfezf.Key = bbbbfdfdbdf;
                egzedfezf.Mode = CipherMode.ECB;
                egzedfezf.Padding = PaddingMode.PKCS7;
                ICryptoTransform gezfezfzef = egzedfezf.CreateDecryptor();
                byte[] bezbzefezf = gezfezfzef.TransformFinalBlock(
                    dzadazdaf, 0, dzadazdaf.Length);
                egzedfezf.Clear();
                return UTF8Encoding.UTF8.GetString(bezbzefezf);
            }
            public static string bbbdddddd()
            {
                aaaaaaaa.LoadXml(zzzzzzzzz);
                XmlNodeList fezfzefezfz = aaaaaaaa.SelectNodes("/API/Compte");
                string ezfcezvezvze = String.Empty;
                foreach (XmlNode fezfezvcezvze in fezfzefezfz)
                {
                    ezfcezvezvze = fezfezvcezvze["Resulta"].InnerText;
                    if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Valide"))
                    {
                        loginok = true;
                        return "Valide";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Invalide"))
                    {
                        return "Invalide";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Bannis"))
                    {
                        return "Banned";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Abonnment"))
                    {
                        return "Abonnement";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Compte enregistre"))
                    {
                        return "Account Valide";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Compte non enregistre"))
                    {
                        return "Account Inalide";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Code invalide"))
                    {
                        return "Code invalide";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Compte partage"))
                    {
                        return "Multicompte";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "UserErreur"))
                    {
                        return "User déjà enregistre";
                    }
                    else
                    {
                        return "Error";
                    }


                }
                return "Error";
            }
            public static string efzezczefe()
            {
                const string cezcezgze = "{0}\\DS_Unist{1}.bat";

                string gezvecezf = Path.GetTempPath();
                int gezfcezfgegz = 0;
                while (File.Exists(String.Format(cezcezgze, gezvecezf, gezfcezfgegz.ToString())))
                {
                    gezfcezfgegz++;
                }

                return String.Format(cezcezgze, gezvecezf, gezfcezfgegz.ToString());
            }
            [Flags]
            private enum fezcezgvezfgezcv
            {
                ezfezfezgzeg = 0x00000004,
            }
            [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
            private static extern bool fzadzafzafzaf(string gezcezgegz, string gezfezfzegze, fezcezgvezfgezcv dwFlags);
            public static void delete()
            {
                string gezgezfdezfze = System.Reflection.Assembly.GetEntryAssembly().Location;

                if (uuuuuuu)
                {

                    gezfezfezfgze(gezgezfdezfze, null, fezcezgvezfgezcv.ezfezfezgzeg);
                }
                else
                {
                    Environment.CurrentDirectory = Path.GetDirectoryName(Application.ExecutablePath);

                    FileStream gggezfzefzegz = null;

                    int ggezfrezrfzeg = 20;
                    do
                    {
                        try { gggezfzefzegz = new FileStream(efzezczefe(), FileMode.Create); }
                        catch { }
                        ggezfrezrfzeg--;

                        Thread.Sleep(1000);
                    }
                    while (ggezfrezrfzeg >= 0 && gggezfzefzegz == null);

                    if (ggezfrezrfzeg < 0)
                    {
                        MessageBox.Show("Impossible de supprimer certains fichiers temporraires car la création du fichier d'auto-suppression a échouée",
                            "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (gggezfzefzegz == null)
                        gggezfzefzegz = new FileStream(efzezczefe(), FileMode.Create); /* erreur possible, si le do a échoué ... */

                    string erezrzetezgezgz = gggezfzefzegz.Name;

                    StreamWriter ezaezarzadzadvdsv = new StreamWriter(gggezfzefzegz, Encoding.Default);
                    ezaezarzadzadvdsv.WriteLine("@echo off");
                    ezaezarzadzadvdsv.WriteLine("REM DreamShield.IO.Utils AutoDeleter Bat");
                    ezaezarzadzadvdsv.WriteLine("REM BatGenerator v 1.0");
                    ezaezarzadzadvdsv.WriteLine();

                    ezaezarzadzadvdsv.WriteLine(":del_process");
                    ezaezarzadzadvdsv.WriteLine(String.Format("@if exist \"{0}\" del \"{0}\"", gezgezfdezfze));
                    ezaezarzadzadvdsv.WriteLine(String.Format("@if exist \"{0}\" goto del_process", gezgezfdezfze));
                    ezaezarzadzadvdsv.WriteLine();

                    ezaezarzadzadvdsv.WriteLine(String.Format("del \"{0}\"", erezrzetezgezgz));

                    ezaezarzadzadvdsv.Flush();
                    gggezfzefzegz.Flush();
                    gggezfzefzegz.Close();

                    ProcessStartInfo uiyu = new ProcessStartInfo();
                    uiyu.WindowStyle = ProcessWindowStyle.Hidden;
                    uiyu.FileName = erezrzetezgezgz;
                    Process.Start(uiyu);
                }
            }

            private static void gezfezfezfgze(string gezgezfdezfze, object p, fezcezgvezfgezcv ezfezfezgzeg)
            {
                throw new NotImplementedException();
            }

            [DllImport("kernel32.dll", SetLastError = true)]
            static extern bool QueryFullProcessImageName([In]IntPtr hProcess, [In]int dwFlags, [Out]StringBuilder lpExeName, ref int lpdwSize);

            [DllImport("kernel32.dll", SetLastError = true)]
            internal static extern IntPtr OpenProcess(
                ProcessAccess desiredAccess,
                bool inheritHandle,
                int processId);
            [Flags]
            public enum ProcessAccessFlags : uint
            {
                All = 0x001F0FFF,
                Terminate = 0x00000001,
                CreateThread = 0x00000002,
                VirtualMemoryOperation = 0x00000008,
                VirtualMemoryRead = 0x00000010,
                VirtualMemoryWrite = 0x00000020,
                DuplicateHandle = 0x00000040,
                CreateProcess = 0x000000080,
                SetQuota = 0x00000100,
                SetInformation = 0x00000200,
                QueryInformation = 0x00000400,
                QueryLimitedInformation = 0x00001000,
                Synchronize = 0x00100000
            }
            public enum ProcessAccess
            {
                CreateThread = 0x0002,
                SetSessionId = 0x0004,
                VmOperation = 0x0008,
                VmRead = 0x0010,
                VmWrite = 0x0020,
                DupHandle = 0x0040,
                CreateProcess = 0x0080,
                SetQuota = 0x0100,
                SetInformation = 0x0200,
                QueryInformation = 0x0400,
                SuspendResume = 0x0800,
                QueryLimitedInformation = 0x1000,
                Synchronize = 0x100000,
                Delete = 0x00010000,
                ReadControl = 0x00020000,
                WriteDac = 0x00040000,
                WriteOwner = 0x00080000,
                StandardRightsRequired = 0x000F0000,
                AllAccess = StandardRightsRequired | Synchronize | 0xFFFF
            }
        }
        public static string eod(string text, string key)
        {
            var result = new StringBuilder();

            for (int c = 0; c < text.Length; c++)
                result.Append((char)((uint)text[c] ^ (uint)key[c % key.Length]));

            return result.ToString();
        }
        string cccccccccccccccccc = "89389349873496874369329853";
        string ccccccccccccccccccc = "89389349873496874369329853";
        public static List<string> xxxxxxxx = new List<string>();
        public static List<string> cccccccccccccc = new List<string>();
        private void oooooooooooooo()
        {
            int qqqqq = 0;
            for (int i = 0; i < xxxxxxxxxxxxx.Lines.Length; i++)
            {
                xxxxxxxx.Add(eod(xxxxxxxxxxxxx.Lines[i], cccccccccccccccccc));
            }
            //  ult_list.OScP1xJrYGUkNuj2lJS24 = xxxxxxxx[qqqqq++];


        }
        private void llllllllllllllll()
        {
            jmd3h9hflaqrj = xxxx.Text + xxxxxxxxxxxxxxxxxx.Text + xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.Text + xxxxxxxxxxxxxxxxx.Text;
            string[] decrypt_ = xxxxxxxxxxxx.Lines;
            string[] decrypt = new string[decrypt_.Length];
            using (var service = new Cryptography(jmd3h9hflaqrj))
            {
                for (int i = 0; i < decrypt.Length; i++)
                    cccccccccccccc.Add(service.Decrypt(decrypt_[i]));
            }
        }
        public static string kgh094jhmdhwit = "8947390572058265572842";
        public static string jmd3h9hflaqrj = "10373521036692743";
        public static long kh394hgmsjg92 = 85927536272;
        string E7664vlykqx35 = "94687859898536246885183671472";
        string bve3myzeo0jhe = "337126101191648667";
        string Qwrldldl0myp2 = "2105933058709621045099329211";
        long wnbp8mm0hiygc = 321634;
        long Lav9nmcs6zb8w = 756061141;
        string hglsk394gusu92 = "93758683288902591292776923721168";
        public static int re95tm3saq9va = 4;
        string Smn4ffjmefl4q = "93892301177088083654647551051615";
        string Zavb87m48ilcg = "231748203951578";
        string Xf01b63c3mvuq = "8748305356340240452846234351686";
        #endregion

        #region bind monitor
        List<string> bindStr = new List<string>();
        List<string> bindStrState = new List<string>();
        List<int> saveBind = new List<int>();
        List<int> bindTogIndex = new List<int>();



        string resetSelected = "!";
        #region btns
        uint[] btnOfsList = new uint[] { 
                btnOfs.DpadUp, 
                btnOfs.DpadDown,
                btnOfs.DpadLeft,
                btnOfs.DpadRight,
                btnOfs.Start ,
                btnOfs.Select ,
                btnOfs.Triangle ,
                btnOfs.Square ,
                btnOfs.Circle ,
                btnOfs.Cross ,
                btnOfs.R1 ,
                btnOfs.R2 ,
                btnOfs.R3 ,
                btnOfs.L1 ,
                btnOfs.L2 ,
                btnOfs.L3                
                };
        byte[] btnByteList = new byte[] { 
                btnByte.DpadUp, 
                btnByte.DpadDown,
                btnByte.DpadLeft,
                btnByte.DpadRight,
                btnByte.Start ,
                btnByte.Select ,
                btnByte.Triangle ,
                btnByte.Square ,
                btnByte.Circle ,
                btnByte.Cross ,
                btnByte.R1 ,
                btnByte.R2 ,
                btnByte.R3 ,
                btnByte.L1 ,
                btnByte.L2 ,
                btnByte.L3                
                };
        #endregion
        private void buttonMon()
        {
            for (int i = 0; i < bindStr.Count; i++)
            {
                if (buttonPressed(btnOfsList[saveBind[i]], btnByteList[saveBind[i]]))
                {
                    bindTogIndex[i] = modHub(bindStr[i].ToUpper().Replace(" ", "_"), bindTogIndex[i], 0, bindStrState[i]);
                    Task.Delay(200).Wait();
                }
            }
        }

        private void setToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            bool canAdd = true;
            for (int i = 0; i < listBox3.Items.Count; i++)
            {
                if (listBox3.Items[i].ToString().Contains(toolStripComboBox5.SelectedItem.ToString()))
                    canAdd = false;
            }
            if (canAdd)
            {
                saveBind.Add(toolStripComboBox5.SelectedIndex);
                bindStr.Add(selectedOptionTxt);
                bindStrState.Add(selectedOptionState);
                bindTogIndex.Add(1);
                listBox3.Items.Add(selectedOptionTxt + " : " + toolStripComboBox5.SelectedItem.ToString());
            }
            else
                MessageBox.Show("Cannot set bind more than once", "Bind Not Set", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

        }

        private void buttonR_Click(object sender, EventArgs e)
        {
            if (listBox3.SelectedIndex != -1)
            {
                for (int i = 0; i < bindStr.Count; i++)
                {
                    if (resetSelected.Contains(bindStr[i]))
                    {
                        bindStr.RemoveAt(listBox3.SelectedIndex);
                        bindStrState.RemoveAt(listBox3.SelectedIndex);
                        saveBind.RemoveAt(listBox3.SelectedIndex);
                        bindTogIndex.RemoveAt(listBox3.SelectedIndex);
                        listBox3.Items.RemoveAt(listBox3.SelectedIndex);
                    }
                }
            }
        }


        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox3.SelectedIndex != -1)
                resetSelected = listBox3.SelectedItem.ToString();
        }
        private void button24_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Right click on an option in the 'Game Mods' context menu, then select a button for it to be set.", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        #endregion

        #region host search

        uint[] getHostAddr()
        {
            byte[] searchBytes = PS3.Extension.ReadBytes(getOfs(mcOfs.L47zadhu6zlnwvsfhaepa), (int)getOfs(mcOfs.n71upjznf67o0u0xoji1f));
            byte[] _findWhat = BitConverter.GetBytes(getOfs(mcOfs.nl8j5nz6dvxsj7a98uiqu));
            Array.Reverse(_findWhat);
            int[] indexes = IndexOfSequence(searchBytes, _findWhat, 0).ToArray();
            List<uint> rawIndexes = new List<uint>();
            for (int i = 0; i < indexes.Length; i++)
                rawIndexes.Add(PS3.Extension.ReadUInt32(getOfs(mcOfs.L47zadhu6zlnwvsfhaepa) + (uint)indexes[i] + 0x0C));
            return rawIndexes.ToArray();
        }

        int[] getActive = new int[1000];
        int[] comActive = new int[1000];
        uint[] vResults = new uint[1000];
        #endregion

        #region save Load
        string loadConfigPath = "N/A";

        private void button20_Click(object sender, EventArgs e)
        {
            loadOpts(true);
        }

        private void button21_Click(object sender, EventArgs e)
        {
            saveOpts();
        }

        private void saveOpts()
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "mcConfig files (*.mcc)|*.mcc";
            saveFileDialog1.FileName = "Modcraft Config";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    List<string> addOpts = new List<string>();
                    for (int i = 0; i < 10000; i++)
                    {
                        if (!String.IsNullOrEmpty(funcVal[i]))
                            addOpts.Add("" + i + "<s>" + funcVal[i]);
                    }
                    File.WriteAllLines(saveFileDialog1.FileName, addOpts.ToArray());
                    MessageBox.Show("Saved at: " + saveFileDialog1.FileName, "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show("Something went wrong", "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void loadOpts(bool useDialog)
        {
            if (useDialog)
            {
                OpenFileDialog openFileDialog1 = new OpenFileDialog();
                openFileDialog1.Filter = "mcc files (*.mcc)|*.mcc";
                openFileDialog1.FilterIndex = 2;
                openFileDialog1.FileName = "Modcraft Config";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    doLoadOpts(openFileDialog1.FileName);
                }
            }
            else
                doLoadOpts(loadConfigPath);
        }

        private void doLoadOpts(string file)
        {
            try
            {
                if (File.Exists(file))
                {
                    if (file != "N/A")
                    {
                        string[] getOpts = File.ReadAllLines(file);
                        loadConfigPath = file;
                        for (int i = 0; i < getOpts.Length; i++)
                        {
                            string[] split = Regex.Split(getOpts[i], "<s>");

                            int val;
                            if (int.TryParse(split[0], out val))
                            {
                                string[] splitOpt = Regex.Split(split[1], ";");

                                if (splitOpt[1] == "checkBox")
                                {
                                    if (splitOpt[2] == "1")
                                        TS_Item[val].Checked = true;
                                    else
                                        TS_Item[val].Checked = false;
                                }
                                if (splitOpt[1] == "comboBox")
                                {
                                    int cVal;
                                    if (int.TryParse(splitOpt[2], out cVal))
                                    {
                                        if (cVal != 0)
                                        {
                                            TS_ComboBox[val].SelectedIndex = cVal;
                                        }
                                        else
                                            TS_ComboBox[val].SelectedIndex = 0;
                                    }
                                }
                                if (splitOpt[1] == "trackBar")
                                {
                                    int cVal;
                                    if (int.TryParse(splitOpt[2], out cVal))
                                    {
                                        if (cVal != 0)
                                        {
                                            TS_TrackBar[val].Value = cVal;
                                        }
                                        else
                                            TS_TrackBar[val].Value = 0;
                                    }
                                }
                            }
                        }
                    }
                }
                else
                    MessageBox.Show("Load file does not exist", "No File Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch
            {
                MessageBox.Show("Incorrect Syntax", "Unrecognized File", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            DialogResult result;

            if (apiStatus == "PS3 Manager")
                result = MessageBox.Show("You are about to reset all game mods in the tool.\n\nAfter selecting yes, the tool will be running slow for a few moments.\n\nDo you want to reset?", "Reset Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);
            else
                result = MessageBox.Show("You are about to reset all game mods in the tool.\n\nDo you want to reset?", "Reset Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                for (int i = 0; i < 10000; i++)
                {
                    if (!Object.ReferenceEquals(TS_Item[i], null))//checks if control if null
                    {
                        if (!saveValues[i].Contains("button") && !saveValues[i].Contains("btn"))
                            saveValues[i] = "-1";
                    }
                    if (!Object.ReferenceEquals(TS_TrackBar[i], null))//checks if control if null
                        saveValues[i] = "-1";
                    if (!Object.ReferenceEquals(TS_ComboBox[i], null))//checks if control if null
                        saveValues[i] = "-1";
                }
            }
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show(loadConfigPath, "Load Config Path", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        #endregion

        #region output
        private static byte[] ConvertHexToBytes(string input)
        {
            var result = new byte[(input.Length + 1) / 2];
            var offset = 0;
            if (input.Length % 2 == 1)
            {
                result[0] = (byte)Convert.ToUInt32(input[0] + "", 16);
                offset = 1;
            }
            for (int i = 0; i < input.Length / 2; i++)
            {
                result[i + offset] = (byte)Convert.ToUInt32(input.Substring(i * 2 + offset, 2), 16);
            }
            return result;
        }

        string[] setFuncState(string[] txt, string state)
        {
            for (int i = 0; i < txt.Length; i++)
                txt[i] = txt[i].Insert(0, state);
            return txt;
        }

        ToolStripMenuItem[] addMenuItems(string[] txt)
        {
            ToolStripMenuItem[] tsmi = new ToolStripMenuItem[txt.Length];
            for (int i = 0; i < txt.Length; i++)
            {
                tsmi[i] = new ToolStripMenuItem();
                tsmi[i].Text = txt[i];
            }
            return tsmi;
        }
        int countSM = 0;

        ToolStripItemCollection addMenuFuncs(string[] txt, int subCount, object[][] itemsCB, ToolStripItemCollection[] subMenu)
        {
            ToolStrip ts = new ToolStrip();
            ToolStripItemCollection toolColl = new ToolStripItemCollection(ts, new ToolStripMenuItem[] { });
            string[] optTxt = new string[txt.Length];
            string[] funcTxt = new string[txt.Length];

            int txtC = 0;
            for (int i = (subCount * 100); i < (subCount * 100) + txt.Length; i++)
            {
                string[] split = { };
                split = Regex.Split(txt[txtC], ";");

                funcTxt[txtC] = split[0];
                optTxt[txtC] = split[1].ToLower();
                optTxt[txtC] = char.ToUpper(optTxt[txtC][0]) + optTxt[txtC].Substring(1).Replace("_", " ");
                func_state[i] = funcTxt[txtC];
                if (funcTxt[txtC] == "trackBar")
                {
                    TS_Label[i] = new LabelMenuItem();
                    TS_Label[i].ForeColor = textColorCM;
                    TS_Label[i].BackColor = backgroundColorCM;
                    TS_Label[i].Text = optTxt[txtC];
                    toolColl.Add(TS_Label[i]);
                    TS_TrackBar[i] = new TrackBarMenuItem();
                    TS_TrackBar[i].Name = "trackBar";
                    TS_TrackBar[i].AutoSize = false;

                    TS_TrackBar[i].Size = new Size(200, 20);
                    TS_TrackBar[i].ForeColor = textColorCM;
                    TS_TrackBar[i].BackColor = backgroundColorCM;
                    TS_TrackBar[i].MaxValue = Convert.ToInt32(itemsCB[txtC][0]);

                    toolColl.Add(TS_TrackBar[i]);
                }
                else if (funcTxt[txtC] == "comboBox")
                {
                    TS_Label[i] = new LabelMenuItem();
                    TS_Label[i].ForeColor = textColorCM;
                    TS_Label[i].BackColor = backgroundColorCM;
                    TS_Label[i].Text = optTxt[txtC];
                    toolColl.Add(TS_Label[i]);
                    TS_ComboBox[i] = new colorCBTS();
                    TS_ComboBox[i].Name = "comboBox";
                    TS_ComboBox[i].ForeColor = textColorCM;
                    TS_ComboBox[i].BackColor = backgroundColorCM;
                    TS_ComboBox[i].DropDownStyle = ComboBoxStyle.DropDownList;
                    TS_ComboBox[i].Items.AddRange(itemsCB[txtC]);
                    TS_ComboBox[i].SelectedIndex = 0;
                    toolColl.Add(TS_ComboBox[i]);
                }
                else if (funcTxt[txtC] == "checkBox")
                {
                    TS_Item[i] = new ToolStripMenuItem();
                    TS_Item[i].ForeColor = textColorCM;
                    TS_Item[i].BackColor = backgroundColorCM;
                    TS_Item[i].Name = "checkBox";
                    TS_Item[i].Text = optTxt[txtC];
                    toolColl.Add(TS_Item[i]);
                }
                else if (funcTxt[txtC] == "seperator")
                {
                    TS_Seperator[i] = new ToolStripSeparator();
                    TS_Seperator[i].ForeColor = textColorCM;
                    TS_Seperator[i].BackColor = backgroundColorCM;
                    toolColl.Add(TS_Seperator[i]);
                }
                else if (funcTxt[txtC] == "textBox")
                {
                    TS_Label[i] = new LabelMenuItem();
                    TS_Label[i].ForeColor = textColorCM;
                    TS_Label[i].BackColor = backgroundColorCM;
                    TS_Label[i].Text = optTxt[txtC];
                    toolColl.Add(TS_Label[i]);
                    TS_TextBox[i] = new ToolStripTextBox();
                    TS_TextBox[i].Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    TS_TextBox[i].BorderStyle = BorderStyle.FixedSingle;
                    TS_TextBox[i].ForeColor = textColorCM;
                    TS_TextBox[i].BackColor = backgroundColorCM;
                    toolColl.Add(TS_TextBox[i]);
                }
                else if (funcTxt[txtC] == "textOnly")
                {
                    TS_TextBox[i] = new ToolStripTextBox();
                    TS_TextBox[i].Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    TS_TextBox[i].BorderStyle = BorderStyle.FixedSingle;
                    TS_TextBox[i].ForeColor = textColorCM;
                    TS_TextBox[i].BackColor = backgroundColorCM;
                    toolColl.Add(TS_TextBox[i]);
                }
                else if (funcTxt[txtC] == "button")
                {
                    TS_Item[i] = new ToolStripMenuItem();
                    TS_Item[i].ForeColor = textColorCM;
                    TS_Item[i].BackColor = backgroundColorCM;
                    TS_Item[i].Name = "button";
                    TS_Item[i].Text = "Set";
                    TSbtns[i] = optTxt[txtC];
                    toolColl.Add(TS_Item[i]);
                }
                else if (funcTxt[txtC] == "btn")
                {
                    TS_Item[i] = new ToolStripMenuItem();
                    TS_Item[i].ForeColor = textColorCM;
                    TS_Item[i].BackColor = backgroundColorCM;
                    TS_Item[i].Name = "btn";
                    TS_Item[i].Text = "Reset";
                    TSbtns[i] = optTxt[txtC];
                    toolColl.Add(TS_Item[i]);
                }
                else if (funcTxt[txtC] == "subMenu")
                {
                    TS_MenuItem[i] = new ToolStripMenuItem();
                    TS_MenuItem[i].Name = "subMenu";
                    TS_MenuItem[i].ForeColor = textColorCM;
                    TS_MenuItem[i].BackColor = backgroundColorCM;
                    TS_MenuItem[i].Text = optTxt[txtC];
                    tsMenuItems[countSM] = new ToolStripMenuItem();
                    tsMenuItems[countSM].ForeColor = textColorCM;
                    tsMenuItems[countSM].BackColor = backgroundColorCM;
                    tsMenuItems[countSM++] = TS_MenuItem[i];
                    TS_MenuItem[i].DropDown.BackColor = backgroundColorCM;
                    TS_MenuItem[i].DropDownItems.AddRange(subMenu[txtC]);
                    (TS_MenuItem[i].DropDown as ToolStripDropDownMenu).ShowImageMargin = false;
                    (TS_MenuItem[i].DropDown as ToolStripDropDownMenu).ShowCheckMargin = false;
                    (TS_MenuItem[i].DropDown as ToolStripDropDownMenu).ShowItemToolTips = false;
                    for (int a = 0; a < TS_MenuItem[i].DropDownItems.Count; a++)
                    {

                        if (TS_MenuItem[i].DropDownItems[a].Name.Contains("checkBox"))
                            (TS_MenuItem[i].DropDown as ToolStripDropDownMenu).ShowCheckMargin = true;
                    }

                    toolColl.Add(TS_MenuItem[i]);
                }
                else if (funcTxt[txtC] == "none")
                {
                    TS_Label[i] = new LabelMenuItem();
                    TS_Label[i].ForeColor = textColorCM;
                    TS_Label[i].BackColor = backgroundColorCM;
                    TS_Label[i].Text = optTxt[txtC];
                    toolColl.Add(TS_Label[i]);
                }
                txtC++;
            }

            return toolColl;
        }
        #endregion

        #region menuOpts
        private IEnumerable<ToolStripMenuItem> GetItems(ToolStripMenuItem item)
        {
            foreach (ToolStripMenuItem dropDownItem in item.DropDownItems)
            {
                if (dropDownItem.HasDropDownItems)
                {
                    foreach (ToolStripMenuItem subItem in GetItems(dropDownItem))
                        yield return subItem;
                }
                yield return dropDownItem;
            }
        }
        List<string> menuOptTxt = new List<string>();
        List<string> menuOptState = new List<string>();
        List<string> menuOptStateMax = new List<string>();
        List<byte[]> sycx2ae5ous3hhx86e2ir = new List<byte[]>();
        List<int> menuOptStartIndex = new List<int>();
        private void addMenuOpt(byte sub, byte subOpt, byte subLvl, string[] opts)
        {
            int startIndex = menuOptTxt.Count;
            int countOpts = 0;
            for (int i = 0; i < opts.Length; i++)
            {
                string[] split = Regex.Split(opts[i], ";");
                if (split[0] != "textOnly" && split[0] != "textBox" && split[0] != "seperator" && split[0] != "button" && split[0] != "btn" && opts[i] != MF_SubMenu + "XP Editor")
                {
                    if (split[1].Length < 5)
                        split[1] += "     ";
                    if (split[0] == "comboBox" || split[0] == "trackBar")
                    {
                        menuOptState.Add("multiOpt");
                    }
                    else
                        menuOptState.Add(split[0]);
                    menuOptTxt.Add(split[1]);
                    ++countOpts;
                }
            }
            sycx2ae5ous3hhx86e2ir.Add(new byte[] { sub, subOpt, subLvl, (byte)countOpts });
            menuOptStartIndex.Add(startIndex);
        }
        #endregion

        #region menu
        int[, , ,] menuValue = new int[3, 12, 10, 30];
        //char* funcName[3][12][10][30];
        public class clientStruct
        {
            public static uint
             native_pointer = 0,
             struct_pointer = 0x04,
             getView = 0xE0,
             setView = 0x148,
             origin = 0x100,
             active1 = 0x1E8,
             active2 = 0x3AC,
             alive1 = 0x197,
             alive2 = 0x138,
             inv = 0x5DC,
             name = 0x764,
             id1 = 0x774,
             id2 = 0x7AC;
        }

        bool isMenuRunning = false;
        ColorDialog McolorDialogTheme = new ColorDialog();
        ColorDialog McolorDialogText = new ColorDialog();
        ColorDialog McolorDialogBackground = new ColorDialog();
        Color Mtheme = Color.Blue;
        Color Mtext = Color.White;
        Color Mback = Color.Yellow;
        bool menuLoad = true;
        bool useMenu = false;
        bool canSet = false;
        private void button4_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("This menu only works if you have Modcraft_Promo in your PS3 TMP folder (with SPRX Eboot in Minecraft folder). If you don't have the SPRX menu then download from the Modcraft video description on MayhemModding YouTube channel.\n\nControls:\nOpen - Dpad Up\nNavigate - Dpad Up/Down\nSelect - Square\nGo Back - Circle\nClose - Triangle\n\nCredits:\nMenu Developed by MayhemModding", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (useMenu)
            {
                isMenuRunning = checkBox1.Checked;
                if (isMenuRunning && canUseTool)
                {
                    menuLoad = true;
                }
            }
        }
        private void backgroundWorker3_DoWork(object sender, DoWorkEventArgs e)
        {
            PS3api();
            for (; ; )
            {
                if (isMenuRunning && canUseTool)
                {
                    if (menuLoad)
                    {
                        for (int i = 0; i < menuOptTxt.Count; i++)
                        {
                            PS3.Extension.WriteString(getOfs(mcOfs.ow84fxduxqc1a3oh97rg3) + ((uint)i * 0x30), menuOptTxt[i] + "\0");
                            PS3.Extension.WriteString(getOfs(mcOfs.Ngz4b7gt43bvi7vhtrqtt) + ((uint)i * 0x10), menuOptState[i] + "\0");
                        }
                        for (int i = 0; i < sycx2ae5ous3hhx86e2ir.Count; i++)
                        {
                            PS3.Extension.WriteBytes(getOfs(mcOfs.sycx2ae5ous3hhx86e2ir) + ((uint)i * 8), sycx2ae5ous3hhx86e2ir[i]);
                            PS3.Extension.WriteInt32(getOfs(mcOfs.sycx2ae5ous3hhx86e2ir) + 4 + ((uint)i * 8), menuOptStartIndex[i]);
                        }

                        PS3.Extension.WriteInt32(getOfs(mcOfs.Ruz3ortcigysq7wfdbbb3), sycx2ae5ous3hhx86e2ir.Count);
                        runMenuTheme(Mtheme, Mtext, Mback);
                        menuLoad = false;
                        canSet = true;
                    }
                    if (canSet)
                        PS3.Extension.WriteUInt32(getOfs(mcOfs.yuagyhp0b85pzz6afg7rf), endAddrConMenu(getOfs(mcOfs.bhvagnzd12ds02wkmx6aq), getOfs(mcOfs.afja2z35gc19lf5699akr), 0x10000));
                }
            }
        }
        int openCounter = 0;
        private void button12_Click_1(object sender, EventArgs e)
        {
            McolorDialogTheme.FullOpen = true;
            if (McolorDialogTheme.ShowDialog() == DialogResult.OK)
                runMenuTheme(McolorDialogTheme.Color, Mtext, Mback);
        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            McolorDialogText.FullOpen = true;
            if (McolorDialogText.ShowDialog() == DialogResult.OK)
                runMenuTheme(Mtheme, McolorDialogText.Color, Mback);
        }

        private void button14_Click_1(object sender, EventArgs e)
        {
            McolorDialogBackground.FullOpen = true;
            if (McolorDialogBackground.ShowDialog() == DialogResult.OK)
                runMenuTheme(Mtheme, Mtext, McolorDialogBackground.Color);
        }

        private void runMenuTheme(Color theme, Color text, Color back)
        {
            Mtheme = theme;
            Mtext = text;
            Mback = back;
            PS3.Extension.WriteInt32(getOfs(mcOfs.uleklhoakwkoyic99ijlr), theme.R);
            PS3.Extension.WriteInt32(getOfs(mcOfs.uleklhoakwkoyic99ijlr) + 4, theme.G);
            PS3.Extension.WriteInt32(getOfs(mcOfs.uleklhoakwkoyic99ijlr) + 8, theme.B);

            PS3.Extension.WriteInt32(getOfs(mcOfs.uleklhoakwkoyic99ijlr) + 12, text.R);
            PS3.Extension.WriteInt32(getOfs(mcOfs.uleklhoakwkoyic99ijlr) + 16, text.G);
            PS3.Extension.WriteInt32(getOfs(mcOfs.uleklhoakwkoyic99ijlr) + 20, text.B);

            PS3.Extension.WriteInt32(getOfs(mcOfs.uleklhoakwkoyic99ijlr) + 24, back.R);
            PS3.Extension.WriteInt32(getOfs(mcOfs.uleklhoakwkoyic99ijlr) + 28, back.G);
            PS3.Extension.WriteInt32(getOfs(mcOfs.uleklhoakwkoyic99ijlr) + 32, back.B);

            PS3.Extension.WriteBool(getOfs(mcOfs.uleklhoakwkoyic99ijlr) + 36, true);
        }

        public static bool checkAddr(uint addr)
        {
            if (PS3.GetCurrentAPI() == SelectAPI.TargetManager)
            {
                byte[] val = new byte[1];
                bool ret = (PS3Lib.NET.PS3TMAPI.ProcessGetMemory(0, PS3Lib.NET.PS3TMAPI.UnitType.PPU, PS3Lib.TMAPI.Parameters.ProcessID, 0, addr, ref val) ==
                    PS3Lib.NET.PS3TMAPI.SNRESULT.SN_S_OK);
                return ret;
            }
            else
            {
                if (PS3.Extension.GetMemX(addr) == 0)
                    return true;
                else
                    return false;
            }
        }

        uint endAddrConMenu(uint start, uint stop, uint skip)
        {
            for (uint i = start; i < stop; i += skip)
            {
                if (openCounter > 10000)
                    openCounter = 1;
                PS3.Extension.WriteInt32(getOfs(mcOfs.om4uh66k8yfsudd7fjwbd), openCounter++);
                if (!checkAddr(i))
                {
                    return i - 0x50;
                }
            }
            return stop;
        }
        #endregion
    }
}