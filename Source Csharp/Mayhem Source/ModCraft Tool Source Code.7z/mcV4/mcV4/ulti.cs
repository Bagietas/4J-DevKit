﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PS3Lib;

namespace mcV4
{
    public class ulti
    {
        /*
         Credit: Creator of Downcraft (most of the options)
                 Class edited by MayhemModding        
        */
        #region bool
        public int GOD_MODE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B2021U, new byte[] { 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4B2021U, new byte[] { 0x20 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int INSTANT_DAMAGE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A3FF0U, new byte[] { 0x40, 0x80 });
            }
            else 
            { 
                PS3API ps = Form1.PS3; uint offset = 0x3A3FF0U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            } 
            if (toggle == 1) return 0; else return 1;
        }
        public int KNOCKBACK_ULT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4018U, new byte[] { 0x40, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4018U, new byte[] { 0x3E, 0xCC });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ANTI_KNOCKBACK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4018U, new byte[2]);
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4018U, new byte[] { 0x3E, 0xCC });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int INSTANT_KILL(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1AC411U, new byte[] { 0xE0, 0x28, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1AC411U, new byte[] { 0xE0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int WATER_JUMP(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD68U, new byte[] { 0x3F, 0xF9, 0x99, 0x99 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD68U, new byte[] { 0x3F, 0xE9, 0x99, 0x99 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int INFINITE_PICK_UP(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x224B13U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x224B13U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FAST_BOW(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xFB4C5U, new byte[] { 0xE0, 0x18, 0x18 });
            }
            else
            {
                Form1.PS3.SetMemory(0xFB4C5U, new byte[] { 0xE0, 8, 0x18 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_PLAYERS_FAST_MINE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x10E0C4U, new byte[] { byte.MaxValue, 0xE0, 0x28, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x10E0C4U, new byte[] { byte.MaxValue, 0xE0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_PLAYERS_FAST_SPEED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x18CE4U, new byte[] { byte.MaxValue, 0xE0, 0, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x18CE4U, new byte[] { byte.MaxValue, 0xE0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_SAVE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEEE54U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEEE54U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SUPER_SPEED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD49U, new byte[] { byte.MaxValue, byte.MaxValue, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD49U, new byte[] { 0x26, 0xAD, 0x89 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DISABLE_MOBS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4619E4U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4619E4U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FIRE_CREEPER_EXPLODE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC894U, new byte[] { 0x39, 0x40, 0, 0x10 });
            }
            else 
            {
                PS3API ps = Form1.PS3; uint offset = 0x1CC894U; byte[] array = new byte[4]; array[0] = 0x39; array[1] = 0x40; ps.SetMemory(offset, array);
            } 
            if (toggle == 1) return 0; else return 1;
        }
        public int JUMP_SPEED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA999U, new byte[] { 0xA0 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA999U, new byte[] { 0x68 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int MULTI_JUMP(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x22790BU, new byte[] { 0x14 });
            }
            else
            {
                Form1.PS3.SetMemory(0x22790BU, new byte[] { 0x18 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SUPER_JUMP(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA77CU, new byte[] { 0x3F, 0x47, 0x7F, 0x42 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA77CU, new byte[] { 0x3E, 0xD7, 0xA, 0x3D });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_JUMP(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB01BACU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB01BACU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REACH_ATTACK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA95FB9U, new byte[] { 0x80 }); Form1.PS3.SetMemory(0xA95FC1U, new byte[] { 0x80 }); PS3API ps = Form1.PS3; uint offset = 0xB351D8U; byte[] array = new byte[4]; array[0] = 0x43; array[1] = 0xA0; ps.SetMemory(offset, array); PS3API ps2 = Form1.PS3; uint offset2 = 0xB351DCU; byte[] array2 = new byte[4]; array2[0] = 0x43; array2[1] = 0xA0; ps2.SetMemory(offset2, array2);
            }
            else
            { 
                Form1.PS3.SetMemory(0xA95FB9U, new byte[] { 0x18 }); Form1.PS3.SetMemory(0xA95FC1U, new byte[] { 8 }); PS3API ps3 = Form1.PS3; uint offset3 = 0xB351D8U; byte[] array3 = new byte[4]; array3[0] = 0x40; array3[1] = 0xA0; ps3.SetMemory(offset3, array3); PS3API ps4 = Form1.PS3; uint offset4 = 0xB351DCU; byte[] array4 = new byte[4]; array4[0] = 0x40; array4[1] = 0x90; ps4.SetMemory(offset4, array4); 
            } 
            if (toggle == 1) return 0; else return 1;
        }
        public int INSTANT_MINE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEB090U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEB090U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int INFINITE_CRAFT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x98871FU, new byte[] { 1 });
            }
            else
            { 
                Form1.PS3.SetMemory(0x98871FU, new byte[1]); 
            } 
            if (toggle == 1) return 0; else return 1;
        }
        public int ANTI_TELEPORT_BY_HOST(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AFB60U, new byte[] { byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AFB60U, new byte[] { 0x3F, 0x7A, 0xE1, 0x48 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int UFO_MODE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, 0, 0x7A, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, 0xEF, 0x5C, 0x29 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int JUMP_FORWARD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA999U, new byte[] { 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA999U, new byte[] { 0x68 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CAM_DOWN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B1CE0U, new byte[] { 0xFC, 2, 0x10 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4B1CE0U, new byte[] { 0xFC, 1, 0x10 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CAM_DOWN_R3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B1D60U, new byte[] { 0xFC, 0, 0xF8, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4B1D60U, new byte[] { 0xFC, 0x20, 0xF8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TOGGLE_SPRINT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB01DECU, new byte[] { 0x40, 0x82 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB01DECU, new byte[] { 0x41, 0x82 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NAME_OVER_HEAD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD8158U, new byte[] { 0x4C });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD8158U, new byte[] { 0x2C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int X_RAY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA99154U, new byte[] { 0xFC, 0x80, 0x30, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA99154U, new byte[] { 0xFC, 0x60, 0x30, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int HUD_MINI_GAME(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD8480U, new byte[] { 0x41, 0x82 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD8480U, new byte[] { 0x40, 0x82 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SHOW_ARMOR(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x90B5F0U, new byte[] { 0x38, 0x80, 0, 1 });
            }
            else
            { 
                PS3API ps = Form1.PS3; uint offset = 0x90B5F0U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x80; ps.SetMemory(offset, array);
            } 
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_VIEW(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEF56CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEF56CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_JUMP(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDC9U, new byte[] { 0xF4 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDC9U, new byte[] { 0xB4 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_CROUCH(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEF514U, new byte[] { 0x40, 0x82, 0, 0x1C });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEF514U, new byte[] { 0x41, 0x82, 0, 0x1C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DISABLE_SWIM(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x34B8F4U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x34B8F4U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_MINE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEC42CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEC42CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_HIT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEC34CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEC34CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ANIM_SWIM_FLY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x390410U, new byte[] { 0x3B, 0x40, 0, 0x10 }); Form1.PS3.SetMemory(0x3ABD44U, new byte[] { 0x3D });
            }
            else
            {
                PS3API ps = Form1.PS3; uint offset = 0x390410U; byte[] array = new byte[4]; array[0] = 0x3B; array[1] = 0x40; ps.SetMemory(offset, array); Form1.PS3.SetMemory(0x3ABD44U, new byte[] { 0x3C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int LEVITATION(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_ALL_TEXT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7865ECU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7865ECU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int POSITION_VIEW(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA99420U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA99420U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_SWIM(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD40U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD40U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int MOVEMENT_SWIM(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD44U, new byte[] { 0xBC });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD44U, new byte[] { 0x3C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SEE_OUTSIDE_MAP(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA97F34U, new byte[] { 0xDF });
            }
            else
            {
                Form1.PS3.SetMemory(0xA97F34U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int LOOK_FORBACK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA97F2CU, new byte[] { 0x23 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA97F2CU, new byte[] { 0x43 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int INSTANT_HIT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEBED4U, new byte[] { byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEBED4U, new byte[] { 0x3E });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NO_COLISSION(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x11230U, new byte[] { byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue });
            }
            else
            { 
                Form1.PS3.SetMemory(0x11230U, new byte[8]);
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int APOCALIPSE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5EC8U, new byte[] { 0xBF, byte.MaxValue }); PS3API ps = Form1.PS3; uint offset = 0x410734U; byte[] array = new byte[4]; array[0] = 0xCD; array[1] = 0xC0; ps.SetMemory(offset, array);
            }
            else
            { 
                Form1.PS3.SetMemory(0xAD5EC8U, new byte[] { 0xBF, 0x80 }); PS3API ps2 = Form1.PS3; uint offset2 = 0x410734U; byte[] array2 = new byte[4]; array2[0] = 0x40; array2[1] = 0xC0; ps2.SetMemory(offset2, array2); 
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FUNNY_SCREEN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5EC8U, new byte[] { 0x50, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5EC8U, new byte[] { 0xBF, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int PLAYERS_POSITION(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5EC8U, new byte[] { 0x3F, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5EC8U, new byte[] { 0xBF, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int HORROR_VIEW(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xA9A6C8U; byte[] array = new byte[4]; array[0] = 0x4F; array[1] = 0x80; ps.SetMemory(offset, array);
            }
            else 
            { 
                PS3API ps2 = Form1.PS3; uint offset2 = 0xA9A6C8U; byte[] array2 = new byte[4]; array2[0] = 0x3F; array2[1] = 0x80; ps2.SetMemory(offset2, array2);
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ANIMATION_RUNNING(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ACEF4U, new byte[] { 0xBF, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ACEF4U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SPLIT_SCREEN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEF9F0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEF9F0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FUNNY_SOUND(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEB090U, new byte[] { byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEB090U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SIZE_HUD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x90FAC8U, new byte[] { 0x41, 0x82 });
            }
            else
            {
                Form1.PS3.SetMemory(0x90FAC8U, new byte[] { 0x40, 0x82 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BURN_IN_WATER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x225EA8U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x225EA8U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int MAX_PICKUP_ITEMS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x310AD4U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x310AD4U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TEXT_TO_ALIEN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7865D0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7865D0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int KICK_TO_XMB_HUD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x785DBCU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x785DBCU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BROKEN_TEXTURES(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98F4CU, new byte[] { 0xAF });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F4CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SHOCKWAVE_EFFECT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98F40U, new byte[] { byte.MaxValue });
            }
            else { Form1.PS3.SetMemory(0xA98F40U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int NIGHT_VISION(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9A6C8U, new byte[] { 0x7F });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9A6C8U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int KILL_AURA(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x233290U, new byte[] { byte.MaxValue });
            }
            else 
            { 
                Form1.PS3.SetMemory(0x233290U, new byte[1]); 
            } if (toggle == 1) return 0; else return 1;
        }
        public int FLY_MODE_X(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB023ECU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB023ECU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int WALL_HACK_V1(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x30012913U, new byte[] { 5 });
            }
            else
            {
                Form1.PS3.SetMemory(0x30012913U, new byte[] { 7 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int GHOST_PLAYERS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x30012913U, new byte[] { 2 });
            }
            else
            {
                Form1.PS3.SetMemory(0x30012913U, new byte[] { 7 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TEXTURE_PLASTIC(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x30012913U, new byte[] { 1 });
            }
            else
            {
                Form1.PS3.SetMemory(0x30012913U, new byte[] { 7 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SUICIDE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, 0xEF });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int GUN_ITEMS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_PARTICLES(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x14C6880U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BIG_PARTICLES(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FAST_BUILD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAECE70U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAECE70U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CAN_FLY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB02378U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB02378U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int GAME_SPEED_STATIC(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEFE64U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEFE64U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DARK_STORM(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int HUD_LOADING(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14CE214U, new byte[] { 1 });
            }
            else
            { 
                Form1.PS3.SetMemory(0x14CE214U, new byte[1]); 
            } 
            if (toggle == 1) return 0; else return 1;
        }
        public int RAINBOW_STORM(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x4F, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int RAIN_TO_SNOW(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1310954U, new byte[] { 0x7E });
            }
            else
            {
                Form1.PS3.SetMemory(0x1310954U, new byte[] { 0x3E });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SKY_TO_RAINBOW_WITH_SNOW(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1310954U, new byte[] { 0x7E }); Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x4F });
            }
            else
            {
                Form1.PS3.SetMemory(0x1310954U, new byte[] { 0x3E }); Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FLASH_STARS_IN_SKY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x38C658U, new byte[] { 0x7F });
            }
            else
            {
                Form1.PS3.SetMemory(0x38C658U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_STARS_IN_SKY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x38C658U, new byte[] { byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x38C658U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int IDS_ITEMS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3097C8U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3097B8U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3097C8U, new byte[] { 0x41 }); Form1.PS3.SetMemory(0x3097B8U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BYPASS_MAX_ITEMS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x310AFCU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x310AFCU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_TOSS_ITEMS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEF428U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEF428U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FREEZE_PARTICLES(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEE7E8U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEE7E8U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SEMI_BLACKSCREEN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAF0354U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAF0354U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DISABLE_FLY_CREATIVE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB02368U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB02368U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int INSTANT_PLACE_SURVIVAL(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAECF10U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAECF10U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NO_DAMAGE_HIT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A3FF0U, new byte[] { byte.MaxValue, byte.MaxValue });
            }
            else 
            { 
                PS3API ps = Form1.PS3; uint offset = 0x3A3FF0U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BREAK_PARTICLES_FLY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB52100U, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0xB52100U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int STUCK_IN_BLOCKS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x389B3CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x389B3CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SMALL_RAIN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3E });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FLASH_SKY_WITH_PARTICLES(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { byte.MaxValue, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NEW_SUPER_SPEED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA999U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA999U, new byte[] { 0x68 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int PLAYERS_PAPER_MODELS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5ECCU, new byte[] { 0x1F });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5ECCU, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int PLAYERS_BIG_MODELS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5ECCU, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5ECCU, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int INFINITE_BLOCK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x10673FU, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x10673FU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BEST_SKY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x410738U, new byte[] { 0x3F, 0x10 }); Form1.PS3.SetMemory(0x38C658U, new byte[] { 0x7F });
            }
            else
            {
                Form1.PS3.SetMemory(0x410738U, new byte[] { 0x3F, 0x80 }); Form1.PS3.SetMemory(0x38C658U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DISABLE_RUN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB022F8U, new byte[] { 0x4C });
            }
            else
            {
                Form1.PS3.SetMemory(0xB022F8U, new byte[] { 0x2C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int PLAYERS_SKATE_MODE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA857D8U, new byte[] { 0x50 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA857D8U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ARMS_AND_LEGS_WEIRD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA857D8U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0xA857D8U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int RAYMAN_MODE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA857C8U, new byte[] { 0x44 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA857C8U, new byte[] { 0xC0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ARMS_HIT_SPEED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA857D0U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0xA857D0U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CREATIVE_SLOT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2F0348U, new byte[] { 0x38, 0x80, 0, 1 }); PS3API ps = Form1.PS3; uint offset = 0x2F0398U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x80; ps.SetMemory(offset, array);
            }
            else
            {
                PS3API ps2 = Form1.PS3; uint offset2 = 0x2F0348U; byte[] array2 = new byte[4]; array2[0] = 0x38; array2[1] = 0x80; ps2.SetMemory(offset2, array2); Form1.PS3.SetMemory(0x2F0398U, new byte[] { 0x38, 0x80, 0, 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SURVIVAL_SLOT(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x2F0368U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x80; ps.SetMemory(offset, array); Form1.PS3.SetMemory(0x2F0378U, new byte[] { 0x38, 0x80, 0, 1 });
            }
            else { Form1.PS3.SetMemory(0x2F0368U, new byte[] { 0x38, 0x80, 0, 1 }); PS3API ps2 = Form1.PS3; uint offset2 = 0x2F0378U; byte[] array2 = new byte[4]; array2[0] = 0x38; array2[1] = 0x80; ps2.SetMemory(offset2, array2); }
            if (toggle == 1) return 0; else return 1;
        }
        public int SUPER_SPEED_V3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3F, 0x10, 0x23, 0x50 }); Form1.PS3.SetMemory(0x3AA999U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3E, 0x26, 0xAD, 0x89 }); Form1.PS3.SetMemory(0x3AA999U, new byte[] { 0x68 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CRITICAL_HIT_V1(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, 0xAF });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, 0xEF });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DRIFT_BOAT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2278E4U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2278E4U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_ANIMATION_RUN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x227BDCU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x227BDCU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int GAME_GAMEMODE_LOCKED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2F03D0U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2F03D0U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FLOAT_UP(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDC8U, new byte[] { 0x3F });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDC8U, new byte[] { 0xBF });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int PRESS_X_FOR_HIT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEEB83U, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEEB83U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ESP_CHESTS_V1(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98F4CU, new byte[] { 0x50 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F4CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SMALL_GRAPHIC(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98EF4U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98EF4U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SUPER_SPEED_V4(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3F, byte.MaxValue, 0, 1 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3E, 0x26, 0xAD, 0x89 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CAMERA_RIGHT_POSITION(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA99050U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA99050U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CAMERA_LEFT_POSITION(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA991ACU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA991ACU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TNT_CANT_DESTROY_BLOCKS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x245DEBU, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x245DEBU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BIG_GAMEPLAY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98EBCU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98EBCU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int KNOCKBACK_V1(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABF3CU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABF3CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_INVENTORY_HUD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x90FCC0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x90FCC0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_POINTER_AIM(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x90FDFFU, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x90FDFFU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int HUD_SHOW_PLAYERS_AROUND_YOU(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x910298U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x910298U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CREEPER_EXPLODE_MEDIUM(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC85CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC85CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CREEPER_CANT_DESTROY_BLOCKS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC827U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC827U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int MAKE_CREEPER_BIG(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC81CU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC81CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NO_SLOW_DOWN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AFB60U, new byte[] { 0x4F });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AFB60U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int HUD_INVENTORY_DOWN_ON_SCREEN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x90FB6CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x90FB6CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FAST_BROKEN_BLOCKS_IN_CREATIVE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEB11CU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEB11CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CANT_GRAB_ITEMS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x310B0CU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x310B0CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_SOME_FPS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEFE18U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEFE18U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DISABLE_CHANGING_WEATHER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393E84U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E84U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FUNNY_ARMS_LEGS(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xA857D0U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0xA857D0U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BYPASS_CREATIVE_IN_TRUMBLE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD8480U, new byte[] { 0x41, 0x82 }); Form1.PS3.SetMemory(0x98871FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x2F0348U, new byte[] { 0x38, 0x80, 0, 1 }); PS3API ps = Form1.PS3; uint offset = 0x2F0398U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x80; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0xAD8480U, new byte[] { 0x40, 0x82 }); Form1.PS3.SetMemory(0x98871FU, new byte[1]); PS3API ps2 = Form1.PS3; uint offset2 = 0x2F0348U; byte[] array2 = new byte[4]; array2[0] = 0x38; array2[1] = 0x80; ps2.SetMemory(offset2, array2); Form1.PS3.SetMemory(0x2F0398U, new byte[] { 0x38, 0x80, 0, 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int HIDE_ARMS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA996C8U, new byte[] { 0x4D });
            }
            else
            {
                Form1.PS3.SetMemory(0xA996C8U, new byte[] { 0x3D });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BETTER_TIME(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9A6DCU, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9A6DCU, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int STOP_BOW(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xFB4C5U, new byte[] { 0xE0, 0x58 });
            }
            else
            {
                Form1.PS3.SetMemory(0xFB4C5U, new byte[] { 0xE0, 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NO_COLISSION_BYPASS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2271B0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2271B0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NO_KNOCKBACK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x11ACCU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x11ACCU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ROTATION_BODY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C6728U, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C6728U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FOG_BLUE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C67D8U, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C67D8U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DAYS_NIGHT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x2F });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CREEPER_SMALL_EXPLOSION(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x1CC7E0U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CREEPER_MEDIUM_EXPLOSION(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CREEPER_EXTREM_EXPLOSION(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x40, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CREEPER_NUCLEAR_EXPLOSION(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x42, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int INSTANT_KILL_IN_FIRE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2258F8U, new byte[] { 0x4F, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2258F8U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_PLAYERS_SET_IN_FIRE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x225FA0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x225FA0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int INSTANT_JUMP_IN_SKY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x11ADCU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x11ADCU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int PLAYERS_BODY_LIGHT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD66C0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD66C0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int JUMP_FOR_BUILD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2271F4U, new byte[] { 0xFC, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2271F4U, new byte[] { 0xFC, 0x20 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CREEPER_INSTANT_EXPLODE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CCC2CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CCC2CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int WOLF_TURN_HEAD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x6C0610U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x6C0610U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int WOLF_REMOVE_WATER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x6C0630U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x6C0630U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TNT_CANT_EXPLODE_BLOCKS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x245DF0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x245DF0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TNT_MAKE_MORE_PARTICLES(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x245E58U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x245E58U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CANT_GRAB_ITEMS_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4A3FB8U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4A3FB8U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TNT_FLY_IN_AIR_WHEN_ENABLED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x51E558U, new byte[] { 0x2F, 0xA4 });
            }
            else
            {
                Form1.PS3.SetMemory(0x51E558U, new byte[] { 0x3F, 0xA4 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TNT_INSTANT_EXPLODE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x51E6A0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x51E6A0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_PLAYERS_FREEZE_PS3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEE434U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x393E34U, new byte[] { 0xCF, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x4F, 0x80 }); Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x2F, 0x80 }); Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F, 0x80 }); Form1.PS3.SetMemory(0xAEE434U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ANTI_KICK_PREMIUM(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEE434U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEE434U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ANTI_AFK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2267B0U, new byte[] { 0x3F, 0x80 });
            }
            else { Form1.PS3.SetMemory(0x2267B0U, new byte[2]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int FOOT_STEP_FAST(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2267F0U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x2267F0U, new byte[] { 0x3F, 0x19 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FOOT_STEP_SLOW(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x2267F0U; byte[] array = new byte[2]; array[0] = 0x2F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x2267F0U, new byte[] { 0x3F, 0x19 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SENSIBILITY_FAST(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xABA948U, new byte[] { 0x42, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xABA948U, new byte[] { 0x42, 0x48 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SENSIBILITY_MAX(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xABA948U, new byte[] { 0x44, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xABA948U, new byte[] { 0x42, 0x48 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SWIM_GLITCH(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB0229CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB0229CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_HURT_CAM(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA972B0U, new byte[2]);
            }
            else
            {
                Form1.PS3.SetMemory(0xA972B0U, new byte[] { 0x40, 0x49 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_FALL_DAMAGE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A409CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A409CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int MAX_XP_LEVEL(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B0094U, new byte[] { 0x7C, 0xA5, 0x10, 0x14 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4B0094U, new byte[] { 0x7C, 0xA5, 0x20, 0x14 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SUPER_SPEED_V5(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x41, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3E, 0x26 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_PLAYERS_FAST_MINE_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x10E0C4U, new byte[] { byte.MaxValue, 0xE0, 0x18, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x10E0C4U, new byte[] { byte.MaxValue, 0xE0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int WALL_HACK_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98F50U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F50U, new byte[] { 0x3D });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SUPER_SPEED_V6(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA998U, new byte[] { 0x3E });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA998U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int PLAYERS_SLIDE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AAA98U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AAA98U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ENTITY_INVISIBLE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x11ADCU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x11ADCU, new byte[] { 0x41 }); Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, 0xEF });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CRITICAL_HIT_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA77CU, new byte[] { 0x3E, 0x27 }); Form1.PS3.SetMemory(0x233290U, new byte[] { byte.MaxValue }); Form1.PS3.SetMemory(0xAEBED4U, new byte[] { byte.MaxValue, byte.MaxValue }); Form1.PS3.SetMemory(0xB01BACU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA77CU, new byte[] { 0x3E, 0xD7 }); Form1.PS3.SetMemory(0x233290U, new byte[1]); Form1.PS3.SetMemory(0xAEBED4U, new byte[] { 0x3E, 0x80 }); Form1.PS3.SetMemory(0xB01BACU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REVERSE_KNOCKBACK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4018U, new byte[] { 0xBF, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4018U, new byte[] { 0x3E, 0xCC });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TNT_SMALL_PARTICLES(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x245C4CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x245C4CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DEBUG_SKINS_TEXTURE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x30012AB3U, new byte[] { 3 });
            }
            else
            {
                Form1.PS3.SetMemory(0x30012AB3U, new byte[] { 4 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_WORLD_LIGHT_WHITE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x300136D3U, new byte[] { 2 });
            }
            else
            {
                Form1.PS3.SetMemory(0x300136D3U, new byte[] { 6 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int RAINBOW_LIGHT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9A6C8U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9A6C8U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TNT_GO_DOWN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x51E558U, new byte[] { 0x4F });
            }
            else
            {
                Form1.PS3.SetMemory(0x51E558U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ESP_CHESTS_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9C2B4U, new byte[] { 0x3E, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9C2B4U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int EPS_CHEST_V3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A7654U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A7654U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SHADOW_SKINS_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AD910U, new byte[] { 0xFC, 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AD910U, new byte[] { 0xFC, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int WALK_ALONE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABE18U, new byte[] { byte.MaxValue, 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABE18U, new byte[] { byte.MaxValue, 0x20 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SHADOW_SKINS_PLAYERS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AD388U, new byte[] { 0x2F });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AD388U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ANTI_AFK_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDC8U, new byte[] { 0x3F });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDC8U, new byte[] { 0xBF });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_PLAYERS_CANT_RUN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x18CE4U, new byte[] { byte.MaxValue, 0xE0, 0x28, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x18CE4U, new byte[] { byte.MaxValue, 0xE0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int RETURN_TO_XMB(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD8320U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD8320U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int LIGHT_MAKE_MORE_POWER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9A6D8U, new byte[] { 0x4F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9A6D8U, new byte[] { 0x3F, 0xC0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TNT_EXPLODE_SOUND_OFF(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x245BE4U, new byte[] { byte.MaxValue, 0x60, 0x18, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x245BE4U, new byte[] { byte.MaxValue, 0x60, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NAME_OVER_HEAD_GO_UP_DOWN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD8110U, new byte[] { byte.MaxValue, 0xC0, 0xE0, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD8110U, new byte[] { byte.MaxValue, 0xC0, 0x10, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int STATIC_MOVEMENT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98FA4U, new byte[] { byte.MaxValue, 0xA0, 0x18, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98FA4U, new byte[] { byte.MaxValue, 0xA0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int LOBBY_MESSAGES(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABE28U, new byte[] { byte.MaxValue, 0x60, 0x88, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABE28U, new byte[] { byte.MaxValue, 0x60, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SHAKE_CAMERA(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98FA4U, new byte[] { byte.MaxValue, 0xA, 0x28, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98FA4U, new byte[] { byte.MaxValue, 0xA0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DEMI_GOD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4064U, new byte[] { byte.MaxValue, 0x40, 0x88, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4064U, new byte[] { byte.MaxValue, 0x40, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int INSTANT_KILL_ALL(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4064U, new byte[] { byte.MaxValue, 0x40, 0x28, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4064U, new byte[] { byte.MaxValue, 0x40, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ENTITY_SKINS_RED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int GLITCHED_DEAD_MOBS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xEA89E2U, new byte[] { 0x18 });
            }
            else
            {
                Form1.PS3.SetMemory(0xEA89E2U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FIRE_INSTANT_REMOVED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x225E80U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x225E80U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int WALK_IN_SKY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x11B00U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x11B00U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BYPASS_KILL_ALL(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x226168U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x226168U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SUPER_JUMP_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA77CU, new byte[] { 0x3F });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA77CU, new byte[] { 0x3E });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_LEVEL_XP(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B00ACU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4B00ACU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_REGENERATE_HEALTH(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x2ADCE8U; byte[] array = new byte[4]; array[0] = 0x68; array[1] = 0x63; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x2ADCE8U, new byte[] { 0x68, 0x63, 0, 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CANT_GRAB_ITEMS_V3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3105F4U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3105F4U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int GRAVITY_MOON(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABF88U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABF88U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FLAT_BLOCKS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x924FFU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x924FFU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int BLOCKS_HAND_UP(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x92507U, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x92507U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int SUPER_SPEED_V7(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3F, byte.MaxValue, 0, 1 }); Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x41, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3E, 0x26, 0xAD, 0x89 }); Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3E, 0x26 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int POTIONS_GRAVITY_FLY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x65FB60U, new byte[] { 0x2D });
            }
            else
            {
                Form1.PS3.SetMemory(0x65FB60U, new byte[] { 0x3D });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int POTIONS_NO_GRAVITY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x65FB60U, new byte[] { 0x4D });
            }
            else
            {
                Form1.PS3.SetMemory(0x65FB60U, new byte[] { 0x3D });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TOGGLE_SPRINT_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB01EEFU, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0xB01EEFU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ARROWS_BLOCKS_ITEMS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xFB55CU, new byte[] { 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0xFB55CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ARROWS_REMOVE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xFB644U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xFB644U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ARROWS_DIRECTIONS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xFB55CU, new byte[] { 0x45 });
            }
            else
            {
                Form1.PS3.SetMemory(0xFB55CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int VIBRATE_WALK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4A3D99U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4A3D99U, new byte[] { 0x20 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int PARTICLES_FLY_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB52100U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0xB52100U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int POSITIONS_PLACE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x22C85AU, new byte[] { 0x28 });
            }
            else
            {
                Form1.PS3.SetMemory(0x22C85AU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DESTROY_GAME(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB21C96U, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB21C96U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int LINES_BLOCKS_MOVE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB259DEU, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB259DEU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DISABLE_PLAYERS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1D3BF2U, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1D3BF2U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int LOBBY_MESSAGES_SPAM(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4A36U, new byte[] { 0x48 }); Form1.PS3.SetMemory(0x3A7BB6U, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4A36U, new byte[] { 8 }); Form1.PS3.SetMemory(0x3A7BB6U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_PLAYERS_FAST_SPEED_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4668B6U, new byte[] { 0x58 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4668B6U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int PLAYERS_LISTS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7151AAU, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7151AAU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SMALL_TEXT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x79E326U, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0x79E326U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int POSITIONS_HUD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x79E8DEU, new byte[] { 0x58 });
            }
            else
            {
                Form1.PS3.SetMemory(0x79E8DEU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ARMS_BROKEN_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD6172U, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD6172U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_KILL_MOBS_SPAWNED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x5BF34EU, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0x5BF34EU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int WEATHER_SNOW(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9B23EU, new byte[] { 0x48 }); Form1.PS3.SetMemory(0xA9B986U, new byte[] { 0x58 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9B23EU, new byte[] { 8 }); Form1.PS3.SetMemory(0xA9B986U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int WEATHER_RAIN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9B23EU, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9B23EU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FOG_BLACK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAA1B76U, new byte[] { 0x28 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAA1B76U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int LIGHTING_BOLT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x98871FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x98871FU, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int LIGHTNING_BOLT_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x98871FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x393E34U, new byte[] { byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x98871FU, new byte[1]); Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SUPER_SPEED_LEGIT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD49U, new byte[] { 0x86 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD49U, new byte[] { 0x26 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SCAFFOLD_BETA(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x22C7FCU, new byte[] { 0x50 });
            }
            else
            {
                Form1.PS3.SetMemory(0x22C7FCU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_PLAYERS_CANT_RUN_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4668B6U, new byte[] { 0x78 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4668B6U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BLINK_SKY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int STOP_FALL_GRAVITY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x246A2CU, new byte[] { byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x246A2CU, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_PLAYERS_SPAM_ZOOM(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4668B6U, new byte[] { 0x78 }); Form1.PS3.SetMemory(0x4668B6U, new byte[] { 0x78 }); Form1.PS3.SetMemory(0x4668B6U, new byte[] { 8 }); Form1.PS3.SetMemory(0x4668B6U, new byte[] { 8 });
            }
            else { } if (toggle == 1) return 0; else return 1;
        }
        public int ANTI_AFK_V3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2267B0U, new byte[] { 0x3F, 0xF0 });
            }
            else { Form1.PS3.SetMemory(0x2267B0U, new byte[4]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int SKY_TO_NETHER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB22050U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB22050U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SMOKE_LOBBY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB24177U, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0xB24177U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int CAN_SEE_UNDER_WORLD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98A91U, new byte[] { 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98A91U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FREE_CAM(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98A95U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98A95U, new byte[] { 0x30 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CORRUPT_WORLD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x98871FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x98871FU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int LIGHT_EYES_ENDERMAN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA68148U, new byte[] { 0x4F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xA68148U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_HANDS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAF10A8U, new byte[] { 0x38, 0x60, 0, 1 });
            }
            else { PS3API ps = Form1.PS3; uint offset = 0xAF10A8U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x60; ps.SetMemory(offset, array); } if (toggle == 1) return 0; else return 1;
        }
        public int LABYMOD_SETTINGS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD14ECU, new byte[] { 0xBF, 0xF }); Form1.PS3.SetMemory(0xAD0274U, new byte[] { 0xBF, 0x23 }); Form1.PS3.SetMemory(0xAD8158U, new byte[] { 0x4C }); Form1.PS3.SetMemory(0xB01DECU, new byte[] { 0x40, 0x82 }); Form1.PS3.SetMemory(0x3097C8U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3097B8U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x90B5F0U, new byte[] { 0x38, 0x80, 0, 1 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x3F, byte.MaxValue }); Form1.PS3.SetMemory(0x227BDCU, new byte[] { 0x40 }); Form1.PS3.CCAPI.Notify(CCAPI.NotifyIcon.CAUTION, "Ultimatecraft Notification\nLabymod ON");
            }
            else { Form1.PS3.SetMemory(0xAD14ECU, new byte[] { 0x3F, 0xF }); Form1.PS3.SetMemory(0xAD0274U, new byte[] { 0x3F, 0x23 }); Form1.PS3.SetMemory(0xAD8158U, new byte[] { 0x2C }); Form1.PS3.SetMemory(0xB01DECU, new byte[] { 0x41, 0x82 }); Form1.PS3.SetMemory(0x3097C8U, new byte[] { 0x41 }); Form1.PS3.SetMemory(0x3097B8U, new byte[] { 0x41 }); PS3API ps = Form1.PS3; uint offset = 0x90B5F0U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x80; ps.SetMemory(offset, array); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x3F, 0x80 }); Form1.PS3.SetMemory(0x227BDCU, new byte[] { 0x41 }); Form1.PS3.CCAPI.Notify(CCAPI.NotifyIcon.CAUTION, "Ultimatecraft Notification\nLabymod OFF"); } if (toggle == 1) return 0; else return 1;
        }
        public int PARTICLES_TORNADO(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB50B32U, new byte[] { 0x58 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB50B32U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FAST_MOVE_LEGS_ARMS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB5A62EU, new byte[] { 0x98 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB5A62EU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int LEGS_IN_AIR(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB5A62EU, new byte[] { 0xC8 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB5A62EU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DAMAGE_HIT_RED_BLUE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5B7AU, new byte[] { 0xD0 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5B7AU, new byte[] { 0xC0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NO_DELAY_HIT_DAMAGE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A3FF0U, new byte[] { 0x20 });
            }
            else { Form1.PS3.SetMemory(0x3A3FF0U, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int DISABLE_FOG(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x3A3FF0U; byte[] array = new byte[2]; array[0] = byte.MaxValue; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x3A3FF0U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ESP_ENTITY_RED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x41 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x6F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ESP_ENTITY_BLUE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x41 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { byte.MaxValue, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FOV_WITHOUT_HAND(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x987502U, new byte[] { 0x68 });
            }
            else
            {
                Form1.PS3.SetMemory(0x987502U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ZOOM_WITHOUT_HAND(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x987502U, new byte[] { 0xF8 });
            }
            else
            {
                Form1.PS3.SetMemory(0x987502U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_PLAYERS_TAKE_DAMAGE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x39E2D4U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x39E2D4U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int INFINITE_FOOD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x43E9F7U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x43E9F7U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int UNFAIR_ATTACK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEBED4U, new byte[] { 0xBE });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEBED4U, new byte[] { 0x3E });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_BUILD_IN_SURVIVAL(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAECF10U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAECF10U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ESP_PLAYERS(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xA98F50U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array); Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x41 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x6F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F50U, new byte[] { 0x3D, 0x8C }); Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int HITBOX_BETA(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AE03U, new byte[] { 1 }); Form1.PS3.SetMemory(0x233290U, new byte[] { byte.MaxValue }); Form1.PS3.SetMemory(0xB25998U, new byte[] { 0x41 }); Form1.PS3.SetMemory(0xB25A59U, new byte[] { 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AE03U, new byte[1]); Form1.PS3.SetMemory(0x233290U, new byte[1]); Form1.PS3.SetMemory(0xB25998U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0xB25A59U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int WEATHER_TO_RAIN_ANYTIME(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393F8FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x393F8FU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int WALL_HACK_V3(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xA98F50U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F50U, new byte[] { 0x3D, 0x8C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int OLD_FLY_OPTIONS(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xA98F50U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F50U, new byte[] { 0x3D, 0x8C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int MOBS_IGNORE_ME(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xA98F50U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F50U, new byte[] { 0x3D, 0x8C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DISALBE_HUD_TEXT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x8FC4B4U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x8FC4B4U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int MINE_IN_ADVENTURE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2F0273U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x2F0273U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NAME_OVER_HEAD_DOUBLE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x979BCFU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x979BCFU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int BOAT_STOP_WORKING(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xE0F90U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xE0F90U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int HUD_HIDE_EVERYTHING(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x884148U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x884148U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int GAME_NO_ITEMS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2FE98BU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x2FE98BU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int IRON_HELMET_EVERYONE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2FE983U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x2FE983U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TEXTURE_BLACK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA73854U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA73854U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int GAMMA_TO_MAX(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9C2B4U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9C2B4U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NAME_AND_SHADOW_BLACK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA73878U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA73878U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TRIDENT_RIPTIDE_TO_MAX(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x217DCFU, new byte[] { 8 });
            }
            else { Form1.PS3.SetMemory(0x217DCFU, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int ALLOW_ALL_ITEMS_ON_HEAD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x428704U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x428704U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NO_COLISSION_ENTITY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x108ACU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x108ACU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ENABLE_ALL_ENCHANTEMENT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x218A4FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x218A4FU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int FROST_WALKER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x218A4FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x218A4FU, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int NO_WEB_HAX(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x234F9FU, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x234F9FU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FLY_OR_RUN_ON_CROUCH(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB0142BU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0xB0142BU, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_LADDER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A74F3U, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x3A74F3U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int ANIMATION_CHARACTER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA89AC8U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA89AC8U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BIG_ANIMATION_CHARACTER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA8919DU, new byte[] { 0xF0 }); Form1.PS3.SetMemory(0xA891A1U, new byte[] { 0xF0 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA8919DU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0xA891A1U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NETHER_VISION(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB018D0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB018D0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ENTITY_GOD_MODE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A3F6CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A3F6CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ENABLE_SPECIAL_BLOCK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x218A4FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x218A4FU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int SPECTRAL_ARROWS_WITH_BOW(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C90D4U, new byte[] { 0x32, 0x20, 0x8D, 0xA0 });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C90D4U, new byte[] { 0x32, 0x1E, 0xAD, 0xA0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int AIR_TO_WATER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1D7FCCU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1D7FCCU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int MULTI_JUMP_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3B000AU, new byte[] { 2 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3B000AU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_PLAYERS_LEFT_HAND(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x151F2F0U, new byte[] { 0x30, 1, 0x87, 0xF0 });
            }
            else
            {
                Form1.PS3.SetMemory(0x151F2F0U, new byte[] { 0x30, 1, 0x87, 0xF8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int PARTICLES_DAMAGE_NO_STOP(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB520F7U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0xB520F7U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ROBLOX_ANIMATION(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2341D0U, new byte[] { 0xC3 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2341D0U, new byte[] { 0xC0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int INFINITE_OXYGEN_IN_WATER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x39DE28U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x39DE28U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ENTITY_TO_BABY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x39F52FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x39F52FU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int GET_SPECTATOR_GAMEMODE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C9048U, new byte[] { 0x32, 0x3A, 0x84, 0xC0 });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C9048U, new byte[] { 0x32, 0x39, 0x4B, 0xD0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int BLOCKS_STATIC_CRACK(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAE3C3FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0xAE3C3FU, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int KILL_DISAPPEAR_ENTITY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x39F587U, new byte[] { 1 });
            }
            else
            {
                Form1.PS3.SetMemory(0x39F587U, new byte[] { 0x14 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int KILL_DONT_DISAPPEAR_ENTITY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x39F587U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x39F587U, new byte[] { 0x14 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int GET_IDS_PLAYERS_ON_HEAD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B5DF3U, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x4B5DF3U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int GET_64_ITEMS_BLOCKS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B5DF3U, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BB9DFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BBACFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BBBBFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BBCAFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BBD9FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BBEEFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC07FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC16FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC25FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC34FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC43FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC52FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC61FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC70FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC75FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC84FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC93FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BCA2FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BCB1FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BCC0FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BCCFFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BCE8FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BCF7FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD06FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD15FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD24FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD33FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD42FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD51FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD6BFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD7AFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD89FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD98FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BDA7FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BDB6FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BDC5FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BDD4FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BDE3FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BDF2FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE01FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE10FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE1FFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE2EFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE3DFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE4DFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE5CFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE6BFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE7AFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE89FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE98FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BEA7FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BEB6FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BEC5FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BED4FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BEE3FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BEF2FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF01FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF10FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF1FFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF2EFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF3DFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF4CFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF5BFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF6AFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF79FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF88FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF8DFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BFA0FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BFAFFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BFBEFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BFCDFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BFDCFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323F1EEFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323F1F3FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FBEEFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FBFDFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC0CFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC1BFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC2AFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC39FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC48FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC57FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC66FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC75FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC84FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC93FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCA2FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCB1FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCC0FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCCFFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCDEFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCEDFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCFCFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD0BFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD1AFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD29FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD47FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD66FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD75FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD84FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32412D8FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32414C5FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32414D4FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32414E3FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32414F2FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241501FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241525FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241534FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241543FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241552FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241561FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241570FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x324157FFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x324158EFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x324159DFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32415ACFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32415FDFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x324160CFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x324161BFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x324162AFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241639FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241648FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241657FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241666FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241684FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32416B1FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32416C0FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241710FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241D95FU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x323BB9DFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BBACFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BBBBFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BBCAFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BBD9FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BBEEFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC07FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC16FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC25FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC34FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC43FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC52FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC61FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC70FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC75FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC84FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC93FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BCA2FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BCB1FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BCC0FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BCCFFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BCE8FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BCF7FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD06FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD15FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD24FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD33FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD42FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD51FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD6BFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD7AFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD89FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD98FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BDA7FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BDB6FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BDC5FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BDD4FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BDE3FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BDF2FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE01FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE10FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE1FFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE2EFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE3DFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE4DFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE5CFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE6BFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE7AFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE89FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE98FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BEA7FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BEB6FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BEC5FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BED4FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BEE3FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BEF2FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF01FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF10FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF1FFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF2EFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF3DFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF4CFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF5BFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF6AFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF79FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF88FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF8DFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BFA0FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BFAFFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BFBEFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BFCDFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BFDCFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323F1EEFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323F1F3FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FBEEFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FBFDFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC0CFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC1BFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC2AFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC39FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC48FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC57FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC66FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC75FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC84FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC93FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCA2FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCB1FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCC0FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCCFFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCDEFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCEDFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCFCFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD0BFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD1AFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD29FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD47FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD66FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD75FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD84FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32412D8FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32414C5FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32414D4FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32414E3FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32414F2FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241501FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241525FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241534FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241543FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241552FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241561FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241570FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x324157FFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x324158EFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x324159DFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32415ACFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32415FDFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x324160CFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x324161BFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x324162AFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241639FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241648FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241657FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241666FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241684FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32416B1FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32416C0FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241710FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241D95FU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SWITCH_GAME_TO_OFFLINE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x324193B9U, new byte[] { 8 });
            }
            else { Form1.PS3.SetMemory(0x324193B9U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int FREEZE_THE_WORLD_WITH_EGG(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x324193B9U, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x324193B9U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int FISHING_ROD_CANT_BE_REMOVED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2C0D98U, new byte[] { 0x3B, 0xA0, 0, 1 });
            }
            else { PS3API ps = Form1.PS3; uint offset = 0x2C0D98U; byte[] array = new byte[4]; array[0] = 0x3B; array[1] = 0xA0; ps.SetMemory(offset, array); } if (toggle == 1) return 0; else return 1;
        }
        public int FISHING_ROD_NO_GRAVITY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2C2948U, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0x2C2948U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REMOVE_ANIMATION_DETAILED_SKINS(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x4B2468U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x60; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x4B2468U, new byte[] { 0x38, 0x60, 0, 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CREEPER_CHARGED_DISABLED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CDB98U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CDB98U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x71 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int LEAD_CANT_BE_REMOVED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x23B240U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x23B240U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x21 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int IGNIORING_PRESSURE_PLATE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x237BC8U, new byte[] { 0x38, 0x60, 0, 1 });
            }
            else { PS3API ps = Form1.PS3; uint offset = 0x237BC8U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x60; ps.SetMemory(offset, array); } if (toggle == 1) return 0; else return 1;
        }
        public int DEAD_PLAYERS_REMAINS_STANDING(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x39F548U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x39F548U, new byte[] { 0xF8, 0x21, 0xFE, 0xE1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DISABLE_KILLED_OUT_OF_WORLD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A9350U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A9350U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x91 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DISABLE_TOTEM_OF_UNDYING(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A52B8U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A52B8U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ENABLE_AIM_ON_3TH_PRESON(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x90FA30U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x90FA30U, new byte[] { 0xF8, 0x21, 0xF5, 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TOTEM_FLOAT_HEALTH(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A52B0U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else { PS3API ps = Form1.PS3; uint offset = 0x3A52B0U; byte[] array = new byte[4]; array[0] = 0x3F; array[1] = 0x80; ps.SetMemory(offset, array); } if (toggle == 1) return 0; else return 1;
        }
        public int ENDERMAN_AND_CHORUS_FRUIT_CANT_BE_TELEPORTED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3B30A8U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3B30A8U, new byte[] { 0xF8, 0x21, 0xFE, 0xB1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int PLAYERS_ON_ELYTRA(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3B3008U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3B3008U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x91 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int WATER_SLOW_DOWN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA964U, new byte[] { 0x3F, 0x7C, 0xCC, 0xCD });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA964U, new byte[] { 0x3F, 0x4C, 0xCC, 0xCD });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int JUMP_IN_LAVA(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA940U, new byte[] { 0x3F, 0xF4, 0x7A, 0xE1 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA940U, new byte[] { 0x3F, 0xBA, 0xCC, 0xCD });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int FREEZE_ALL_ENTITY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A9FE8U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A9FE8U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_KILL_PLAYERS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A8678U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A8678U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DISABLE_PORTALS(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x2379E4U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x60; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x2379E4U, new byte[] { 0x38, 0x60, 0, 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALL_PLAYERS_SUFFOCATE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x22FDC8U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x22FDC8U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x11 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ENTITY_RENDER(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x22CE40U; byte[] array = new byte[4]; array[0] = 0x48; array[1] = byte.MaxValue; ps.SetMemory(offset, array);
            }
            else { PS3API ps2 = Form1.PS3; uint offset2 = 0x22CE40U; byte[] array2 = new byte[4]; array2[0] = 0x40; array2[1] = 0x48; ps2.SetMemory(offset2, array2); } if (toggle == 1) return 0; else return 1;
        }
        public int NETHER_PORTAL_WITH_STONE(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C89FCU, new byte[] { 0x32, 0x18, 0x11, 0xC0 });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C89FCU, new byte[] { 0x32, 0x18, 0x5E, 0x70 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DETECT_IF_PLAYERS_HAS_BEEN_ALREADY_DAMAGED(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4A3CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4A3CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int RUNNING_PARTICLES_SPECTRAL(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1550AA0U, new byte[] { 0x30, 0xAF, 0x25, 0xB8 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1550AA0U, new byte[] { 0x30, 0xAF, 0x23, 0x10 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int RUNNING_PARTICLES_WEIRD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1550AA0U, new byte[] { 0x30, 0xAF, 0x21, 0xA8 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1550AA0U, new byte[] { 0x30, 0xAF, 0x23, 0x10 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int AUTO_CROUCH_ON_MOVEMENT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB0143FU, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0xB0143FU, new byte[] { 0xE });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ROTATION_HEAD_360_DEGRES(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x224FD4U, new byte[] { 0xC3 }); Form1.PS3.SetMemory(0x224FD8U, new byte[] { 0x43 });
            }
            else
            {
                Form1.PS3.SetMemory(0x224FD4U, new byte[] { 0xC2 }); Form1.PS3.SetMemory(0x224FD8U, new byte[] { 0x42 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int PLACE_BLOCKS_IN_BATTLE_WORLDS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D75A3U, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x7D75A3U, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int CREATIVE_INVENTORY_IN_LOBBY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAED18FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0xAED18FU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int PERMISSIONS_DESTROY_BLOCKS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D75FFU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x7D75FFU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int INVENTORY_SPECIAL_BLOCKS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3241B6B4U, new byte[] { 0x32, 0x1B, 0xB4, 0x20 }); Form1.PS3.SetMemory(0x3241B7A4U, new byte[] { 0x32, 0x1B, 0xB7, 0xF0 }); Form1.PS3.SetMemory(0x3241B894U, new byte[] { 0x32, 0x1D, 0x45, 0x90 }); Form1.PS3.SetMemory(0x3241B984U, new byte[] { 0x32, 0x1D, 0x9B, 0x10 }); Form1.PS3.SetMemory(0x3241BA74U, new byte[] { 0x32, 0x1D, 0x9D, 0xE0 }); Form1.PS3.SetMemory(0x3241BB64U, new byte[] { 0x32, 0x1D, 0x70, 0 }); Form1.PS3.SetMemory(0x3241BC54U, new byte[] { 0x32, 0x20, 0x8D, 0xA0 }); Form1.PS3.SetMemory(0x3241BD44U, new byte[] { 0x32, 0x1B, 0xE3, 0xA0 }); Form1.PS3.SetMemory(0x3241BE34U, new byte[] { 0x32, 0x1B, 0xE9, 0xF0 }); Form1.PS3.SetMemory(0x3241BF24U, new byte[] { 0x32, 0x1B, 0xEC, 0xE0 }); Form1.PS3.SetMemory(0x3241C014U, new byte[] { 0x32, 0x1B, 0xEF, 0xD0 }); Form1.PS3.SetMemory(0x3241C104U, new byte[] { 0x32, 0x1B, 0xF2, 0xC0 }); Form1.PS3.SetMemory(0x3241B3D4U, new byte[] { 0x32, 0x1B, 0xF5, 0x10 }); Form1.PS3.SetMemory(0x3241B284U, new byte[] { 0x32, 0x1B, 0xF7, 0x60 }); Form1.PS3.SetMemory(0x3241B134U, new byte[] { 0x32, 0x1B, 0xF9, 0xB0 }); Form1.PS3.SetMemory(0x3241AFE4U, new byte[] { 0x32, 0x1B, 0xFC, 0 }); Form1.PS3.SetMemory(0x3241AE94U, new byte[] { 0x32, 0x1B, 0xFE, 0x50 }); Form1.PS3.SetMemory(0x3241AD44U, new byte[] { 0x32, 0x1C, 0, 0xA0 }); Form1.PS3.SetMemory(0x3241ABF4U, new byte[] { 0x32, 0x1C, 0x84, 0xF0 }); Form1.PS3.SetMemory(0x3241AAA4U, new byte[] { 0x32, 0x1C, 0x89, 0x90 }); Form1.PS3.SetMemory(0x3241A954U, new byte[] { 0x32, 0x1D, 0x2B, 0x90 }); Form1.PS3.SetMemory(0x3241A804U, new byte[] { 0x32, 0x1D, 0xA7, 0xA0 }); Form1.PS3.SetMemory(0x3241A6B4U, new byte[] { 0x32, 0x1D, 0xC0, 0x70 }); Form1.PS3.SetMemory(0x3241A564U, new byte[] { 0x32, 0x1E, 0x8D, 0x20 }); Form1.PS3.SetMemory(0x3241A414U, new byte[] { 0x32, 0x1E, 0x8F, 0x70 }); Form1.PS3.SetMemory(0x3241A2C4U, new byte[] { 0x32, 0x1E, 0x91, 0xC0 }); Form1.PS3.SetMemory(0x3241A174U, new byte[] { 0x32, 0x1E, 0x94, 0x10 }); Form1.PS3.SetMemory(0x3241A024U, new byte[] { 0x32, 0x1E, 0x96, 0x60 }); Form1.PS3.SetMemory(0x32419ED4U, new byte[] { 0x32, 0x1E, 0x98, 0xB0 }); Form1.PS3.SetMemory(0x32419D84U, new byte[] { 0x32, 0x20, 0x8F, 0xF0 }); Form1.PS3.SetMemory(0x324199F4U, new byte[] { 0x32, 0x1B, 0xC1, 0x60 }); Form1.PS3.SetMemory(0x324198A4U, new byte[] { 0x32, 0x1B, 0xDA, 0x60 }); Form1.PS3.SetMemory(0x32419754U, new byte[] { 0x32, 0x1B, 0xDC, 0xB0 }); Form1.PS3.SetMemory(0x32419604U, new byte[] { 0x32, 0x1B, 0xDF, 0 }); Form1.PS3.SetMemory(0x324194B4U, new byte[] { 0x32, 0x1F, 0xB4, 0xC0 }); Form1.PS3.SetMemory(0x32419364U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419214U, new byte[] { 0x32, 0x20, 0xB, 0xE0 }); Form1.PS3.SetMemory(0x324190C4U, new byte[] { 0x32, 0x20, 0x32, 0x80 }); Form1.PS3.SetMemory(0x32418F74U, new byte[] { 0x32, 0x20, 0x64, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3241B6B4U, new byte[] { 0x32, 0x1E, 0x58, 0x70 }); Form1.PS3.SetMemory(0x3241B7A4U, new byte[] { 0x32, 0x1E, 0x5B, 0x30 }); Form1.PS3.SetMemory(0x3241B894U, new byte[] { 0x32, 0x1E, 0x5D, 0xA0 }); Form1.PS3.SetMemory(0x3241B984U, new byte[] { 0x32, 0x1E, 0x60, 0x10 }); Form1.PS3.SetMemory(0x3241BA74U, new byte[] { 0x32, 0x1E, 0x62, 0x80 }); Form1.PS3.SetMemory(0x3241BB64U, new byte[] { 0x32, 0x1E, 0x64, 0xF0 }); Form1.PS3.SetMemory(0x3241BC54U, new byte[] { 0x32, 0x1E, 0x67, 0x60 }); Form1.PS3.SetMemory(0x3241BD44U, new byte[] { 0x32, 0x1E, 0x69, 0xD0 }); Form1.PS3.SetMemory(0x3241BE34U, new byte[] { 0x32, 0x1E, 0x6C, 0x40 }); Form1.PS3.SetMemory(0x3241BF24U, new byte[] { 0x32, 0x1E, 0x6E, 0xB0 }); Form1.PS3.SetMemory(0x3241C014U, new byte[] { 0x32, 0x21, 3, 0x60 }); Form1.PS3.SetMemory(0x3241C104U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241B3D4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241B284U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241B134U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241AFE4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241AE94U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241AD44U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241ABF4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241AAA4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A954U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A804U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A6B4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A564U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A414U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A2C4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A174U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A024U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419ED4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419D84U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x324199F4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x324198A4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419754U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419604U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x324194B4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419364U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419214U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x324190C4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32418F74U, new byte[] { 0x32, 0x20, 1, 0xC0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int GET_CRAFTING_IN_BATTLE_WORLD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAED18FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x98871FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x7D75A3U, new byte[] { 1 }); Form1.PS3.SetMemory(0x7D767CU, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAED18FU, new byte[1]); Form1.PS3.SetMemory(0x98871FU, new byte[1]); Form1.PS3.SetMemory(0x7D75A3U, new byte[] { 1 }); Form1.PS3.SetMemory(0x7D767CU, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ENABLE_TAKE_EVERYTHING_IN_CHESTS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D79D0U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7D79D0U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int GOD_MODE_V3(int toggle)
        {
            if (toggle == 1)
            {
                MessageBox.Show("You will take damage for are in god mode, don't move and wait !", "How to use ?", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x14C93F0U, new byte[] { 0x32, 0x1C, 0xA, 0x60 });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C93F0U, new byte[] { 0x32, 0x20, 0xA4, 0xF0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CAN_SEE_REAL_SKINS_IN_SPECTATOR(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D86A0U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7D86A0U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DISABLE_RESPAWN(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAF1EE0U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAF1EE0U, new byte[] { 0xF8, 0x21, 0xFD, 0x21 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int GENEREATE_BUBBLE_IN_WATER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4A0A60U, new byte[] { 0x38, 0x60, 0, 1 });
            }
            else { PS3API ps = Form1.PS3; uint offset = 0x4A0A60U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x60; ps.SetMemory(offset, array); }
            if (toggle == 1) return 0; else return 1;
        }
        public int ELYTRA_ON_ALL_ENTITY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C93D8U, new byte[] { 0x32, 0x1C, 0xA, 0x60 });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C93D8U, new byte[] { 0x32, 0x20, 0x94, 0x50 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int MOVE_HEAD_BUT_NOT_BODY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AF338U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AF338U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x71 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int STOP_ANIMATIONS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ACF00U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ACF00U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x71 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int STOP_WALK_ANIMATIONS(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x7D8B0CU; byte[] array = new byte[4]; array[0] = 0x4F; array[1] = 0x80; ps.SetMemory(offset, array);
            }
            else { Form1.PS3.SetMemory(0x7D8B0CU, new byte[4]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int ALLOW_PORTAL_IN_MINI_GAMES(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x7DC3BCU; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x60; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x7DC3BCU, new byte[] { 0x38, 0x60, 0, 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int CREATIVE_SLOT_V2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAACEDCU, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAACEDCU, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x71 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int STARVED_ALL_PLAYERS_IN_BATTLE_WORLD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D7AA0U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7D7AA0U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x71 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int OPTIMIZE_CHUNKS_LOAD(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xB21C60U; byte[] array = new byte[4]; array[0] = 0x40; array[1] = 0xD7; ps.SetMemory(offset, array);
            }
            else { PS3API ps2 = Form1.PS3; uint offset2 = 0xB21C60U; byte[] array2 = new byte[4]; array2[0] = 0x40; array2[1] = 0x30; ps2.SetMemory(offset2, array2); } if (toggle == 1) return 0; else return 1;
        }
        public int STOP_CHUNKS_LOAD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB2437CU, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB2437CU, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x71 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int DISABLE_3RD_PERSON_VIEW(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAFB458U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAFB458U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x11 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int NETHER_PORTAL_WITH_DIRT(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C89FCU, new byte[] { 0x32, 0x18, 0x14, 0x70 });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C89FCU, new byte[] { 0x32, 0x18, 0x5E, 0x70 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TNT_CAN_DESTROY_BLOCKS_IN_MINI_GAMES(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D8FB8U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7D8FB8U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SURVIVAL_IN_LOBBY(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D88C0U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7D88C0U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int VELOCITY_SMALL(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2335C8U, new byte[] { 0xD3, 0x23, 1, 0x30 }); Form1.PS3.SetMemory(0x2335CCU, new byte[] { 0xD8, 0x43, 1, 0x38 }); Form1.PS3.SetMemory(0x2335D0U, new byte[] { 0xD3, 0x63, 1, 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2335C8U, new byte[] { 0xD8, 0x23, 1, 0x30 }); Form1.PS3.SetMemory(0x2335CCU, new byte[] { 0xD8, 0x43, 1, 0x38 }); Form1.PS3.SetMemory(0x2335D0U, new byte[] { 0xD8, 0x63, 1, 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int VELOCITY_BIG(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2335C8U, new byte[] { 0xD9, 0x23, 1, 0x30 }); Form1.PS3.SetMemory(0x2335CCU, new byte[] { 0xD8, 0x43, 1, 0x38 }); Form1.PS3.SetMemory(0x2335D0U, new byte[] { 0xD9, 0x63, 1, 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2335C8U, new byte[] { 0xD8, 0x23, 1, 0x30 }); Form1.PS3.SetMemory(0x2335CCU, new byte[] { 0xD8, 0x43, 1, 0x38 }); Form1.PS3.SetMemory(0x2335D0U, new byte[] { 0xD8, 0x63, 1, 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int TNT_EXPLODE_RADIUS_SMALL(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x51E0D0U; byte[] array = new byte[4]; array[0] = 0x42; array[1] = 0x80; ps.SetMemory(offset, array);
            }
            else { PS3API ps2 = Form1.PS3; uint offset2 = 0x51E0D0U; byte[] array2 = new byte[4]; array2[0] = 0x40; array2[1] = 0x80; ps2.SetMemory(offset2, array2); }
            if (toggle == 1) return 0; else return 1;
        }
        public int STOP_SHOW_LOGS_NOTIFS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x912D08U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x912D08U, new byte[] { 0xF8, 0x21, 0xFE, 0x51 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ADD_FAKE_CLONE_CONTROLLER(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEFA74U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEFA74U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int REAL_JUMP_ANIMATION(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C6728U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C6728U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int SCREEN_DEAD(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A7654U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A7654U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int MAX_PLAYERS_FOR_SMALL_MAPS(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D7984U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7D7984U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }

        #endregion
        #region bool2
        public int ITEMS_WATER_TO_FOUR_4J_DEBUG(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int ITEMS_WATER_TO_(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x1F, 0x5F, 0x80 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int ITEMS_WATER_TO_DIAMOND(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x1E, 0xB2, 0x40 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int ITEMS_WATER_TO_COMMAND_BLOCK(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x20, 0x64, 0x20 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int ITEMS_WATER_TO_SPAWN_EGGS(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x20, 1, 0xC0 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int ITEMS_WATER_TO_DIAMOND_SWORD(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x1E, 0xD5, 0x20 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int bunifuImage1(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x1E, 0xDB, 0x50 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int bunifuImage2(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x20, 0x8D, 0xA0 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int FROSTED_ICE_TO_BARRIERE(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0x93, 0xC0 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int FROSTED_ICE_TO_EGGS_DRAGON(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0x2E, 0x10 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int FROSTED_ICE_TO_REAPETING_COMMAND_BLOCK(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0xED, 0xB0 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int FROSTED_ICE_TO_GREEN_COMMAND_BLOCK(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0xEF, 0x30 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int FROSTED_ICE_TO_COMMAND_BLOCK(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0x4F, 0x20 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int FROSTED_ICE_TO_DEFAULT(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int FROSTED_ICE_TO_MAGMA(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0xF4, 0xC0 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int FROSTED_ICE_TO_ENDER_GATEWAY(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0xEC, 0 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int FROSTED_ICE_TO_DAIMOND_ORE(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x18, 0xB4, 0x60 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int FROSTED_ICE_TO_SIGN(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x18, 0xBE, 0 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int SPAWN_DRAGON_EGGS(int toggle)
        {
            MessageBox.Show("Eggs of Elder Guardian has been changed to the Ender Dragon eggs, you can spawn it with a Monster Spawner", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xE7, 0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xC }); return 0;
            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xE });
            else
                Form1.PS3.SetMemory(0x32418D18, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xE });
            if (toggle == 1) return 0; else return 1;
        }
        public int SPAWN_WHITER_EGGS(int toggle)
        {
            MessageBox.Show("Eggs of Shulker has been changed to the Wither eggs, you can spawn it with a Monster Spawner", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418A79U, new byte[] { 0x77, 0, 0x69, 0, 0x74, 0, 0x68, 0, 0x65, 0, 0x72, 0, 0, 0, 0, 0, 0, 0, 6 }); 
            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418A79U, new byte[] { 0x73, 0, 0x68, 0, 0x75, 0, 0x6C, 0, 0x6B, 0, 0x65, 0, 0x72, 0, 0, 0, 0, 0, 7 });
            else
                Form1.PS3.SetMemory(0x32418A79, new byte[] { 0x73, 0x0, 0x68, 0x0, 0x75, 0x0, 0x6C, 0x0, 0x6B, 0x0, 0x65, 0x0, 0x72, 0x0, 0x0, 0x0, 0x0, 0x0, 0x7, 0x0 });
            if (toggle == 1) return 0; else return 1;

        }
        public int SPAWN_BUNNY_KILLER_EGGS(int toggle)
        {
            MessageBox.Show("Eggs of Shulker has been changed to the Bunny Killer eggs, you can spawn it with a Monster Spawner", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418A79U, new byte[] { 0x77, 0, 0x69, 0, 0x74, 0, 0x68, 0, 0x65, 0, 0x72, 0, 0, 0, 0, 0, 0, 0, 6 }); 
            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418A79U, new byte[] { 0x73, 0, 0x68, 0, 0x75, 0, 0x6C, 0, 0x6B, 0, 0x65, 0, 0x72, 0, 0, 0, 0, 0, 7 });
            else
                Form1.PS3.SetMemory(0x32418A79, new byte[] { 0x73, 0x0, 0x68, 0x0, 0x75, 0x0, 0x6C, 0x0, 0x6B, 0x0, 0x65, 0x0, 0x72, 0x0, 0x0, 0x0, 0x0, 0x0, 0x7, 0x0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int SPAWN_GIANT_EGGS(int toggle)
        {
            MessageBox.Show("Eggs of Shulker has been changed to the Giant Zombie eggs, you can spawn it with a Monster Spawner", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418A79U, new byte[] { 0x67, 0, 0x69, 0, 0x61, 0, 0x6E, 0, 0x74, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5 }); 
            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418A79U, new byte[] { 0x73, 0, 0x68, 0, 0x75, 0, 0x6C, 0, 0x6B, 0, 0x65, 0, 0x72, 0, 0, 0, 0, 0, 7 });
            else
                Form1.PS3.SetMemory(0x32418A79, new byte[] { 0x73, 0x0, 0x68, 0x0, 0x75, 0x0, 0x6C, 0x0, 0x6B, 0x0, 0x65, 0x0, 0x72, 0x0, 0x0, 0x0, 0x0, 0x0, 0x7, 0x0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int SPAWN_IRON_GOLEM_EGGS(int toggle)
        {
            MessageBox.Show("Eggs of Elder Guardian has been changed to the Iron Golem eggs, you can spawn it with a Monster Spawner", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xF6, 0xA0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xE }); 

            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xE });
            else
                Form1.PS3.SetMemory(0x32418D18, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xE });
            if (toggle == 1) return 0; else return 1;
        }
        public int SPAWN_SNOWBALL_EGGS(int toggle)
        {
            MessageBox.Show("Eggs of Elder Guardian has been changed to Snowball, you can spawn it with a Monster Spawner (YOU CAN FREEZE)", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x9D, 0xA4, 0xC0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8 }); 
            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xE });
            else
                Form1.PS3.SetMemory(0x32418D18, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xE });
            if (toggle == 1) return 0; else return 1;
        }
        public int SPAWN_ARMOR_STAND_EGGS(int toggle)
        {
            MessageBox.Show("Eggs of Elder Guardian has been changed to Armor Stand, you can spawn it with a Monster Spawner (YOU CAN FREEZE)", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xE3, 0x60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xB }); 
            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xE });
            else
                Form1.PS3.SetMemory(0x32418D18, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xE });
            if (toggle == 1) return 0; else return 1;
        }
        public int DRAW_MODE(int toggle)
        {
            bool flag = toggle == 0; if (flag)
            {
                MessageBox.Show("Use a diamond hoe on the grass and you will see the block you have select. With that you can draw :p", "How to use ?", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x14C8A28U, new byte[] { 0x32, 0x18, 0xB9, 0xE0 }); return 0;
            }
            else
            {
                bool flag2 = toggle == 1; if (flag2)
                {
                    MessageBox.Show("Use a diamond hoe on the grass and you will see the block you have select. With that you can draw :p", "How to use ?", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x14C8A28U, new byte[] { 0x32, 0x19, 0xAE, 0x10 }); return 0;
                }
            }
            if (toggle == 1) return 0; else return 1;
        }
#endregion
        #region track
        public int HUD_NEW_COLORS(int toggle)
        {
            uint offset = 0x14CB898U; uint offset2 = 0x14CB898U; uint offset3 = 0x14CB89CU; uint offset4 = 0x14CB8A0U; uint offset5 = 0x14CB8A4U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[2]; byte[] buffer2 = new byte[2]; byte[] buffer3 = new byte[2]; byte[] buffer4 = new byte[2]; byte[] buffer5 = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer); Form1.PS3.SetMemory(offset2, buffer2); Form1.PS3.SetMemory(offset3, buffer3); Form1.PS3.SetMemory(offset4, buffer4); Form1.PS3.SetMemory(offset5, buffer5); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer6 = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer7 = new byte[] { 0x42 }; Form1.PS3.SetMemory(offset2, buffer7); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer8 = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset3, buffer8); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer9 = new byte[] { 0xF0 }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer10 = new byte[] { 0xF0 }; Form1.PS3.SetMemory(offset3, buffer10); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer11 = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset4, buffer11); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer12 = new byte[] { 0xF0 }; Form1.PS3.SetMemory(offset4, buffer12); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer13 = new byte[] { 0x3F, 0x60 }; Form1.PS3.SetMemory(offset5, buffer13); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer14 = new byte[] { 0x3F, 0x90 }; Form1.PS3.SetMemory(offset5, buffer14); } } } } } } } } } }
            return (++toggle >= 10) ? 0 : toggle;
        }
        public int TIME_SPEED(int toggle)
        {
            uint offset = 0xC202C8U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x50 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x3F, 0x60 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x3F, 0x70 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x3F, 0x90 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x3F, 0xF0 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x3F, 0x40 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0x3F, 0x30 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer9 = new byte[] { 0x3F, 0x20 }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer10 = new byte[] { 0x3F, 0x10 }; Form1.PS3.SetMemory(offset, buffer10); } else { bool flag11 = toggle == 10; if (flag11) { byte[] array = new byte[2]; array[0] = 0x3F; byte[] buffer11 = array; Form1.PS3.SetMemory(offset, buffer11); } } } } } } } } } } }
            return (++toggle >= 11) ? 0 : toggle;
        }
        public int DAMAGE_COLOR(int toggle)
        {
            uint offset = 0xAD5A5CU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x6F, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { byte.MaxValue, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer3); } } }
            return (++toggle >= 3) ? 0 : toggle;
        }
        public int TIMECYCLE(int toggle)
        {
            uint offset = 0x1DA1D4U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x43 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x44 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x45 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x46 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x47 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x48 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer8); } } } } } } } }
            return (++toggle >= 8) ? 0 : toggle;
        }
        public int TIMECYCLE_V2(int toggle)
        {
            uint offset = 0x1DA1D4U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x41 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x42 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x43 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x44 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x45 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x46 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0x47 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer9 = new byte[] { 0x48 }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer10 = new byte[] { 0x49 }; Form1.PS3.SetMemory(offset, buffer10); } else { bool flag11 = toggle == 10; if (flag11) { byte[] buffer11 = new byte[] { byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer11); } } } } } } } } } } }
            return (++toggle >= 11) ? 0 : toggle;
        }
        public int ITEMS_SIZE(int toggle)
        {
            uint offset = 0xAF6B9CU; uint offset2 = 0xAF6B98U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x41, 0x80 }; byte[] buffer2 = new byte[] { 0xBF, 0x80 }; Form1.PS3.SetMemory(offset, buffer); Form1.PS3.SetMemory(offset2, buffer2); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer3 = new byte[] { 0xAF }; Form1.PS3.SetMemory(offset2, buffer3); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer4 = new byte[] { 0xBF, byte.MaxValue }; Form1.PS3.SetMemory(offset2, buffer4); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer5 = new byte[] { 0xEF }; Form1.PS3.SetMemory(offset2, buffer5); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer6 = new byte[] { 0x40, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer7 = new byte[] { 0x41, 0xF0 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer8 = new byte[] { 0x42, 0x80 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer9 = new byte[] { 0x43, 0x80 }; Form1.PS3.SetMemory(offset, buffer9); } } } } } } } }
            return (++toggle >= 8) ? 0 : toggle;
        }
        public int FOV_VALUE(int toggle)
        {
            uint offset = 0x14C670CU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x3F, 0x70 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x3F, 0x60 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x3F, 0x50 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x3F, 0x40 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x3F, 0x30 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x3F, 0x25 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0x3F, 0x20 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer9 = new byte[] { 0x3F, 0x15 }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer10 = new byte[] { 0x3F, 0x10 }; Form1.PS3.SetMemory(offset, buffer10); } else { bool flag11 = toggle == 10; if (flag11) { byte[] buffer11 = new byte[] { 0x1F, 0x80 }; Form1.PS3.SetMemory(offset, buffer11); } else { bool flag12 = toggle == 11; if (flag12) { byte[] buffer12 = new byte[] { 0x3F, byte.MaxValue, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer12); } } } } } } } } } } } }
            return (++toggle >= 12) ? 0 : toggle;
        }
        public int SKY_COLORS(int toggle)
        {
            uint offset = 0x410734U; uint offset2 = 0x410738U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x40, 0xC0 }; byte[] buffer2 = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer); Form1.PS3.SetMemory(offset2, buffer2); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer3 = new byte[] { 0x40, 0x50 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer4 = new byte[] { 0xBF, 0x80 }; Form1.PS3.SetMemory(offset2, buffer4); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer5 = new byte[] { 0x49, 0xC0 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer6 = new byte[] { 0x42, 0xC0 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer7 = new byte[] { 0x43, 0xC0 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer8 = new byte[] { 0xF0, 0xC0 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer9 = new byte[] { 0x3F, 0xF0 }; Form1.PS3.SetMemory(offset2, buffer9); } } } } } } } }
            return (++toggle >= 8) ? 0 : toggle;
        }
        public int HUD_COLORS(int toggle)
        {
            uint offset = 0x30DBAD64U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x3F, 0x80, 0, 0, 0x4F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x3F, 0x80, 0, 0, 0x1F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x3F, byte.MaxValue, 0, 0, 0x1F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x5F, 0x80, 0, 0, 0x5F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x8F, 0x80, 0, 0, 0x8F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[0x10]; Form1.PS3.SetMemory(offset, buffer7); } } } } } } }
            return (++toggle >= 7) ? 0 : toggle;
        }
        public int ENTITY_VISION(int toggle)
        {
            uint offset = 0xAD5EC8U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0xBF, 0x80 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] array = new byte[2]; array[0] = 0xBF; byte[] buffer2 = array; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0xBF, 0xAA }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0xBF, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0xC0, 0x50 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0xC0, 0x99 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0xC0, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0xC1, 0x80 }; Form1.PS3.SetMemory(offset, buffer8); } } } } } } } }
            return (++toggle >= 8) ? 0 : toggle;
        }
        public int ENTITY_VISUAL(int toggle)
        {
            uint offset = 0xAD5ECCU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x2F, 0x80 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x40, 0x80 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x40, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x41, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x43, 0x80 }; Form1.PS3.SetMemory(offset, buffer7); } } } } } } }
            return (++toggle >= 7) ? 0 : toggle;
        }
        public int FPS_VALUES(int toggle)
        {
            uint offset = 0xAF0443U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[1]; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x10 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x20 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x30 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x50 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x60 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0x70 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer9 = new byte[] { 0x80 }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer10 = new byte[] { 0x90 }; Form1.PS3.SetMemory(offset, buffer10); } else { bool flag11 = toggle == 10; if (flag11) { byte[] buffer11 = new byte[] { 0xA0 }; Form1.PS3.SetMemory(offset, buffer11); } else { bool flag12 = toggle == 11; if (flag12) { byte[] buffer12 = new byte[] { 0xB0 }; Form1.PS3.SetMemory(offset, buffer12); } else { bool flag13 = toggle == 12; if (flag13) { byte[] buffer13 = new byte[] { 0xC0 }; Form1.PS3.SetMemory(offset, buffer13); } else { bool flag14 = toggle == 13; if (flag14) { byte[] buffer14 = new byte[] { 0xD0 }; Form1.PS3.SetMemory(offset, buffer14); } else { bool flag15 = toggle == 14; if (flag15) { byte[] buffer15 = new byte[] { 0xE0 }; Form1.PS3.SetMemory(offset, buffer15); } else { bool flag16 = toggle == 15; if (flag16) { byte[] buffer16 = new byte[] { 0xF0 }; Form1.PS3.SetMemory(offset, buffer16); } } } } } } } } } } } } } } } }
            return (++toggle >= 16) ? 0 : toggle;
        }
        public int GAMEPLAY_COLORS(int toggle)
        {
            uint offset = 0x3000AAF8U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x3F, byte.MaxValue, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x3F, 0, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x4F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, 0, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, byte.MaxValue, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x3F, 0x80, 0, 0, 0x4F, 0x80, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer9 = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer10 = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x4F, 0x80 }; Form1.PS3.SetMemory(offset, buffer10); } else { bool flag11 = toggle == 10; if (flag11) { byte[] buffer11 = new byte[] { 0x3F, 0x80, 0, 0, 0x4F, 0x80, 0, 0, 0x4F, 0x80 }; Form1.PS3.SetMemory(offset, buffer11); } else { bool flag12 = toggle == 11; if (flag12) { byte[] buffer12 = new byte[] { 0x4F, 0x80, 0, 0, 0x4F, 0x80, 0, 0, 0x4F, 0x80 }; Form1.PS3.SetMemory(offset, buffer12); } else { bool flag13 = toggle == 12; if (flag13) { byte[] buffer13 = new byte[] { 0x4F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x4F, 0x80 }; Form1.PS3.SetMemory(offset, buffer13); } } } } } } } } } } } } }
            return (++toggle >= 13) ? 0 : toggle;
        }
        public int CLOUD_COLORS(int toggle)
        {
            uint offset = 0x38B964U; uint offset2 = 0x38B968U; uint offset3 = 0xB230ACU; uint offset4 = 0xB230D0U; uint offset5 = 0xB230FCU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3E, 0xCC }; byte[] buffer2 = new byte[] { 0x3F, 0x59 }; byte[] buffer3 = new byte[] { 0xBF, 0x80 }; byte[] buffer4 = new byte[] { 0x3F, 0x60 }; byte[] buffer5 = new byte[] { 0x41, 0x80 }; Form1.PS3.SetMemory(offset, buffer); Form1.PS3.SetMemory(offset2, buffer2); Form1.PS3.SetMemory(offset3, buffer3); Form1.PS3.SetMemory(offset4, buffer4); Form1.PS3.SetMemory(offset5, buffer5); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer6 = new byte[] { byte.MaxValue, 0xCC }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer7 = new byte[] { 0x3F, 0xCC }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer8 = new byte[] { 0x8E, 0xCC }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer9 = new byte[] { byte.MaxValue }; Form1.PS3.SetMemory(offset2, buffer9); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer10 = new byte[] { 0xBF, 0x70 }; Form1.PS3.SetMemory(offset3, buffer10); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer11 = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset4, buffer11); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer12 = new byte[] { 0x43 }; Form1.PS3.SetMemory(offset5, buffer12); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer13 = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset, buffer13); } } } } } } } } }
            return (++toggle >= 9) ? 0 : toggle;
        }
        public int NO_SHADOW_ENTITY(int toggle)
        {
            uint offset = 0x300040FFU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 5 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[1]; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 2 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 1 }; Form1.PS3.SetMemory(offset, buffer4); } } } }
            return (++toggle >= 4) ? 0 : toggle;
        }
        public int SELECTED_BLOCKS(int toggle)
        {
            uint offset = 0xB25990U; uint offset2 = 0xB25994U; uint offset3 = 0xB25998U; uint offset4 = 0xB259A0U; uint offset5 = 0xB25A58U; uint offset6 = 0xB25A59U; uint offset7 = 0xB259A0U; uint blue = 0xB25A5EU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[2]; byte[] buffer2 = new byte[] { 0x3E, 0xCC }; byte[] array = new byte[2]; array[0] = 0x40; byte[] buffer3 = array; byte[] buffer4 = new byte[] { 0x3F, 0x60 }; byte[] buffer5 = new byte[] { 0xFC, 0x40 }; byte[] buffer6 = new byte[] { 8 }; Form1.PS3.SetMemory(offset, buffer); Form1.PS3.SetMemory(offset2, buffer2); Form1.PS3.SetMemory(offset3, buffer3); Form1.PS3.SetMemory(offset4, buffer4); Form1.PS3.SetMemory(offset5, buffer5); Form1.PS3.SetMemory(blue, buffer6); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer7 = new byte[] { 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer8 = new byte[] { 0x4E }; Form1.PS3.SetMemory(offset2, buffer8); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer9 = new byte[] { 0x7E }; Form1.PS3.SetMemory(offset6, buffer9); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer10 = new byte[] { 0x48 }; Form1.PS3.SetMemory(blue, buffer10); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer11 = new byte[] { 0x41 }; Form1.PS3.SetMemory(offset3, buffer11); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer12 = new byte[] { 0x42 }; Form1.PS3.SetMemory(offset3, buffer12); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer13 = new byte[] { 0x60 }; Form1.PS3.SetMemory(offset3, buffer13); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer14 = new byte[] { 0xA0 }; Form1.PS3.SetMemory(offset7, buffer14); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer15 = new byte[] { 0xB0 }; Form1.PS3.SetMemory(offset7, buffer15); } else { bool flag11 = toggle == 10; if (flag11) { byte[] buffer16 = new byte[] { 0xD0 }; Form1.PS3.SetMemory(offset7, buffer16); } else { bool flag12 = toggle == 11; if (flag12) { byte[] buffer17 = new byte[] { byte.MaxValue }; Form1.PS3.SetMemory(offset7, buffer17); } } } } } } } } } } } }
            return (++toggle >= 12) ? 0 : toggle;
        }
        public int SUN_MOON_SIZE(int toggle)
        {
            uint remove = 0xB21F1CU; uint size = 0xB21F28U; uint change = 0xB21F5CU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80 }; byte[] buffer2 = new byte[] { 0x42, 0xC8 }; byte[] buffer3 = new byte[] { 0x43, 0xB4 }; Form1.PS3.SetMemory(remove, buffer); Form1.PS3.SetMemory(size, buffer2); Form1.PS3.SetMemory(change, buffer3); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer4 = new byte[] { 0x2F, 0x80 }; Form1.PS3.SetMemory(remove, buffer4); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer5 = new byte[] { 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(remove, buffer5); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer6 = new byte[] { 0x4F, byte.MaxValue }; Form1.PS3.SetMemory(remove, buffer6); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer7 = new byte[] { 0x43, 0xC8 }; Form1.PS3.SetMemory(size, buffer7); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer8 = new byte[] { 0x41, 0xC8 }; Form1.PS3.SetMemory(size, buffer8); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer9 = new byte[] { 0x40, 0xC8 }; Form1.PS3.SetMemory(size, buffer9); } else { bool flag8 = toggle == 7; if (flag8) { byte[] array = new byte[2]; array[0] = 0x40; byte[] buffer10 = array; Form1.PS3.SetMemory(size, buffer10); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer11 = new byte[] { 0x43, 0x84 }; Form1.PS3.SetMemory(change, buffer11); } } } } } } } } }
            return (++toggle >= 9) ? 0 : toggle;
        }
        public int HAND_POSITION(int toggle)
        {
            uint normal = 0xAD14ECU; uint normal2 = 0xAD14F0U; uint normal3 = 0xAD14F4U; uint normal4 = 0xAD14F8U; uint normal5 = 0xAD0274U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0xF }; byte[] buffer2 = new byte[] { 0xBF, 0x19 }; byte[] buffer3 = new byte[] { 0xBF, 5 }; byte[] buffer4 = new byte[] { 0xBF, 0x38 }; byte[] buffer5 = new byte[] { 0x3F, 0x23 }; Form1.PS3.SetMemory(normal, buffer); Form1.PS3.SetMemory(normal2, buffer2); Form1.PS3.SetMemory(normal3, buffer3); Form1.PS3.SetMemory(normal4, buffer4); Form1.PS3.SetMemory(normal5, buffer5); } bool flag2 = toggle == 1; if (flag2) { byte[] buffer6 = new byte[] { 0x3F, 0xF }; Form1.PS3.SetMemory(normal, buffer6); } bool flag3 = toggle == 2; if (flag3) { byte[] buffer7 = new byte[] { 0xBF, 0xF }; byte[] buffer8 = new byte[] { 0xBF, 0x23 }; Form1.PS3.SetMemory(normal, buffer7); Form1.PS3.SetMemory(normal5, buffer8); } bool flag4 = toggle == 3; if (flag4) { byte[] buffer9 = new byte[] { 0x8F, 0xF }; byte[] buffer10 = new byte[] { 0x8F, 0x23 }; Form1.PS3.SetMemory(normal, buffer9); Form1.PS3.SetMemory(normal5, buffer10); } bool flag5 = toggle == 4; if (flag5) { byte[] buffer11 = new byte[] { 0x8F, 5 }; Form1.PS3.SetMemory(normal3, buffer11); } bool flag6 = toggle == 5; if (flag6) { byte[] buffer12 = new byte[] { 0xBF, 0x25 }; Form1.PS3.SetMemory(normal3, buffer12); } bool flag7 = toggle == 6; if (flag7) { byte[] buffer13 = new byte[] { 0xBF, 0x68 }; Form1.PS3.SetMemory(normal4, buffer13); } bool flag8 = toggle == 7; if (flag8) { byte[] buffer14 = new byte[] { 0xBF, 0x98 }; Form1.PS3.SetMemory(normal4, buffer14); } bool flag9 = toggle == 8; if (flag9) { byte[] buffer15 = new byte[] { 0xBF, 0xB8 }; Form1.PS3.SetMemory(normal4, buffer15); } bool flag10 = toggle == 9; if (flag10) { byte[] buffer16 = new byte[] { 0xBF, byte.MaxValue }; Form1.PS3.SetMemory(normal4, buffer16); }
            return (++toggle >= 10) ? 0 : toggle;
        }
        public int ITEMS_IN_HAND(int toggle)
        {
            uint offset = 0xACA524U; bool flag = toggle == 0; if (flag) { byte[] array = new byte[2]; array[0] = 0xBF; byte[] buffer = array; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0xAF, 0x80 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0xBF, 0x80 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] array2 = new byte[2]; array2[0] = 0x3F; byte[] buffer4 = array2; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0xBF, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x4F, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer7); } } } } } } }
            return (++toggle >= 7) ? 0 : toggle;
        }
        public int WEATHER_STATE(int toggle)
        {
            uint normal = 0xA9B140U; uint normal2 = 0xA9B144U; uint normal3 = 0xA9B150U; uint normal4 = 0xA9B158U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80 }; byte[] array = new byte[2]; array[0] = 0x3F; byte[] buffer2 = array; byte[] buffer3 = new byte[] { 0xBF, 5 }; byte[] buffer4 = new byte[] { 0x3F, 0xA0 }; byte[] array2 = new byte[] { 0x3F, 0x23 }; Form1.PS3.SetMemory(normal, buffer); Form1.PS3.SetMemory(normal2, buffer2); Form1.PS3.SetMemory(normal3, buffer3); Form1.PS3.SetMemory(normal4, buffer4); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer5 = new byte[] { 0x1F, 0x80 }; Form1.PS3.SetMemory(normal, buffer5); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer6 = new byte[] { 0x4F, 0x80 }; Form1.PS3.SetMemory(normal, buffer6); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer7 = new byte[] { 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(normal, buffer7); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer8 = new byte[] { 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(normal2, buffer8); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer9 = new byte[] { byte.MaxValue, 0x80 }; Form1.PS3.SetMemory(normal3, buffer9); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer10 = new byte[] { 0x4E, 0x80 }; Form1.PS3.SetMemory(normal3, buffer10); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer11 = new byte[] { 0x8E, 0x80 }; Form1.PS3.SetMemory(normal3, buffer11); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer12 = new byte[] { 0x1F, 0xA0 }; Form1.PS3.SetMemory(normal4, buffer12); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer13 = new byte[] { 0xBF, 0x90 }; Form1.PS3.SetMemory(normal4, buffer13); } } } } } } } } } }
            return (++toggle >= 10) ? 0 : toggle;
        }
        public int REACH_VALUES(int toggle)
        {
            uint offset = 0xA95FB9U; uint offset2 = 0xA95FC1U; uint offset3 = 0xB351D8U; uint offset4 = 0xB351DCU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x18 }; byte[] buffer2 = new byte[] { 8 }; byte[] array = new byte[4]; array[0] = 0x40; array[1] = 0xA0; byte[] buffer3 = array; byte[] array2 = new byte[4]; array2[0] = 0x40; array2[1] = 0x90; byte[] buffer4 = array2; Form1.PS3.SetMemory(offset, buffer); Form1.PS3.SetMemory(offset2, buffer2); Form1.PS3.SetMemory(offset3, buffer3); Form1.PS3.SetMemory(offset4, buffer4); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer5 = new byte[] { 0x80 }; byte[] buffer6 = new byte[] { 0x80 }; byte[] array3 = new byte[4]; array3[0] = 0x41; array3[1] = 0xA0; byte[] buffer7 = array3; byte[] array4 = new byte[4]; array4[0] = 0x41; array4[1] = 0xA0; byte[] buffer8 = array4; Form1.PS3.SetMemory(offset, buffer5); Form1.PS3.SetMemory(offset2, buffer6); Form1.PS3.SetMemory(offset3, buffer7); Form1.PS3.SetMemory(offset4, buffer8); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer9 = new byte[] { 0x80 }; byte[] buffer10 = new byte[] { 0x80 }; byte[] array5 = new byte[4]; array5[0] = 0x42; array5[1] = 0xA0; byte[] buffer11 = array5; byte[] array6 = new byte[4]; array6[0] = 0x42; array6[1] = 0xA0; byte[] buffer12 = array6; Form1.PS3.SetMemory(offset, buffer9); Form1.PS3.SetMemory(offset2, buffer10); Form1.PS3.SetMemory(offset3, buffer11); Form1.PS3.SetMemory(offset4, buffer12); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer13 = new byte[] { 0x80 }; byte[] buffer14 = new byte[] { 0x80 }; byte[] array7 = new byte[4]; array7[0] = 0x45; array7[1] = 0xA0; byte[] buffer15 = array7; byte[] array8 = new byte[4]; array8[0] = 0x45; array8[1] = 0xA0; byte[] buffer16 = array8; Form1.PS3.SetMemory(offset, buffer13); Form1.PS3.SetMemory(offset2, buffer14); Form1.PS3.SetMemory(offset3, buffer15); Form1.PS3.SetMemory(offset4, buffer16); } } } }
            return (++toggle >= 4) ? 0 : toggle;
        }
        public int XP_LEVELV2(int toggle)
        {
            uint offset = 0x218A4FU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[1]; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 1 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 2 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 3 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 4 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 5 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x10 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0x20 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer9 = new byte[] { 0x30 }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer10 = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset, buffer10); } else { bool flag11 = toggle == 10; if (flag11) { byte[] buffer11 = new byte[] { byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer11); } } } } } } } } } } }
            return (++toggle >= 11) ? 0 : toggle;
        }
        public int SOURCE_KILL(int toggle)
        {
            bool flag = toggle == 0; if (flag)
            {
                Form1.PS3.SetMemory(0x15118BCU, new byte[] { 0x30, 0x8B, 0xC4, 0xEC }); 
                Form1.PS3.SetMemory(0x15118C4U, new byte[] { 0x30, 0x8B, 0xC5, 0x24 }); 
            }

            bool flag2 = toggle == 1; if (flag2)
            {
                Form1.PS3.SetMemory(0x15118BCU, new byte[] { 0x30, 0x8B, 0xC5, 0x24 }); 
            }

            bool flag3 = toggle == 2; if (flag3)
            {
                Form1.PS3.SetMemory(0x15118C4U, new byte[] { 0x30, 0x8B, 0xC4, 0xEC }); 
            }

            bool flag4 = toggle == 3; if (flag4)
            {
                Form1.PS3.SetMemory(0x15118BCU, new byte[] { 0x30, 0x8B, 0xC5, 8 }); 
            }
            return (++toggle >= 4) ? 0 : toggle;
        }
        public int WORLD_DIMENSION(int toggle)
        {
            bool flag = toggle == 0; if (flag)
            {
                Form1.PS3.SetMemory(0x151DBECU, new byte[] { 0x30, 0xDC, 0x40, 0x50 });
            }

            bool flag2 = toggle == 1; if (flag2)
            {
                Form1.PS3.SetMemory(0x151DBECU, new byte[] { 0x30, 0xDC, 0x41, 0xD0 });
            }

            bool flag3 = toggle == 2; if (flag3)
            {
                Form1.PS3.SetMemory(0x151DBECU, new byte[] { 0x30, 0xDC, 0x41, 0x90 });
            }

            return (++toggle >= 3) ? 0 : toggle;
        }
        public int NETHER_DIMENSION(int toggle)
        {
            bool flag = toggle == 0; if (flag)
            {
                Form1.PS3.SetMemory(0x151DBF0U, new byte[] { 0x30, 0xDC, 0x41, 0x90 });
            }

            bool flag2 = toggle == 1; if (flag2)
            {
                Form1.PS3.SetMemory(0x151DBF0U, new byte[] { 0x30, 0xDC, 0x40, 0x50 });
            }

            bool flag3 = toggle == 2; if (flag3)
            {
                Form1.PS3.SetMemory(0x151DBF0U, new byte[] { 0x30, 0xDC, 0x41, 0xD0 });
            }
            return (++toggle >= 3) ? 0 : toggle;
        }
        public int THE_END_DIMENSION(int toggle)
        {
            bool flag = toggle == 0; if (flag)
            {
                Form1.PS3.SetMemory(0x151DBECU, new byte[] { 0x30, 0xDC, 0x41, 0xD0 });
            }

            bool flag2 = toggle == 1; if (flag2)
            {
                Form1.PS3.SetMemory(0x151DBECU, new byte[] { 0x30, 0xDC, 0x40, 0x50 });
            }

            bool flag3 = toggle == 2; if (flag3)
            {
                Form1.PS3.SetMemory(0x151DBECU, new byte[] { 0x30, 0xDC, 0x41, 0x90 });
            }

            return (++toggle >= 3) ? 0 : toggle;
        }
        public int ITEMS_2TH_HAND(int toggle)
        {
            bool flag = toggle == 0; if (flag)
            {
                Form1.PS3.SetMemory(0x14C93F0U, new byte[] { 0x32, 0x20, 0xA4, 0xF0 });
            }

            bool flag2 = toggle == 1; if (flag2)
            {
                Form1.PS3.SetMemory(0x14C93F0U, new byte[] { 0x32, 0x1F, 0x97, 0xC0 });
            }

            bool flag3 = toggle == 2; if (flag3)
            {
                Form1.PS3.SetMemory(0x14C93F0U, new byte[] { 0x32, 0x1E, 0xA1, 0x40 });
            }

            bool flag4 = toggle == 3; if (flag4)
            {
                Form1.PS3.SetMemory(0x14C93F0U, new byte[] { 0x32, 0x1E, 0xD5, 0x20 });
            }
            return (++toggle >= 4) ? 0 : toggle;
        }
        #endregion
        #region get
        public int GET_YOUR_PING(int toogle)
        {
            byte[] data = Form1.PS3.Extension.ReadBytes(0x14CF38FU, 1);
            string VALUES = BitConverter.ToString(data);
            GetPingz = VALUES;
            return 0;
        }
        public int LAST_PLAYERS_JOINED_THE_WORLD(int toggle)
        {
            LastPlayersJoinedPSN = Form1.PS3.Extension.ReadString(0x30F46AC4U);
            LastPlayersRegion = Form1.PS3.Extension.ReadString(0x30F46AD8U);
            LastPlayersAvatar = Form1.PS3.Extension.ReadString(0x30F46B80U);
            return 0;
        }
        #endregion
        #region set string
        public int PLAYING_ALONE(string text)
        {
            Form1.PS3.SetMemory(0x320E8410U, Encoding.ASCII.GetBytes(fixText(text))); return 0;
        }
        public int PLAYING_MULTI(string text)
        {
            Form1.PS3.SetMemory(0x320E89E0U, Encoding.ASCII.GetBytes(fixText(text))); return 0;
        }
        public int PLAYER_JOIN(string text)
        {
            Form1.PS3.SetMemory(0x30FAA197U, Encoding.ASCII.GetBytes(fixText(text))); return 0;
        }
        public int PLAYER_LEAVE(string text)
        {
            Form1.PS3.SetMemory(0x30FAA1D7U, Encoding.ASCII.GetBytes(fixText(text))); return 0;
        }
        public int NAMEV2(string text)
        {
            string PSN = Form1.PS3.Extension.ReadString(0x3000AD34U); Form1.PS3.SetMemory(0x3000ABE4U, new byte[0x18]); byte[] bytes = Encoding.ASCII.GetBytes(text ?? ""); Form1.PS3.SetMemory(0x3000ABE4U, bytes); Form1.PS3.CCAPI.Notify(CCAPI.NotifyIcon.CAUTION, "Ultimatecraft Notification\nName Changed, rejoin the world for see your new name!"); return 0;
        }
        public int NAME_GLITCH(string text)
        {
            string PSN = Form1.PS3.Extension.ReadString(0x3000AD34U); Form1.PS3.SetMemory(0x3000ABE4U, new byte[0x18]); byte[] bytes = Encoding.ASCII.GetBytes(text); byte[] buffer = new byte[] { 0x20, 0xC2, 0xA7, 0x33 }; Form1.PS3.SetMemory(0x3000ABE4U, bytes); Form1.PS3.SetMemory(0x3000ABF7U, buffer); Form1.PS3.CCAPI.Notify(CCAPI.NotifyIcon.CAUTION, "Ultimatecraft Notification\nName Changed To Glitched, rejoin the world for see your new name!"); return 0;
        }
        public int NAME_COLORED(string text)
        {
            string PSN = Form1.PS3.Extension.ReadString(0x3000AD34U); PS3API ps = Form1.PS3; uint offset = 0x3000ABE4U; byte[] array = new byte[0x18]; array[0] = 0xC2; array[1] = 0xA7; ps.SetMemory(offset, array); byte[] bytes = Encoding.ASCII.GetBytes(text ?? ""); Form1.PS3.SetMemory(0x3000ABE6U, bytes); Form1.PS3.CCAPI.Notify(CCAPI.NotifyIcon.CAUTION, "Ultimatecraft Notification\nName Changed To Colored, rejoin the world for see your new name!"); return 0;
        }
        public int NAME_LINE(string text)
        {
            string PSN = Form1.PS3.Extension.ReadString(0x3000AD34U); Form1.PS3.SetMemory(0x3000ABE4U, new byte[0x18]); byte[] bytes = Encoding.ASCII.GetBytes(text ?? ""); Form1.PS3.SetMemory(0x3000ABE4U, bytes); Form1.PS3.CCAPI.Notify(CCAPI.NotifyIcon.CAUTION, "Ultimatecraft Notification\nName Changed To Lines, rejoin the world for see your new name!"); return 0;
        }
        #endregion
        public string getLocation()
        { string xyz = " "; for (int i = 0; i < 3; i++) { xyz = xyz + Math.Round(Form1.PS3.Extension.ReadDouble(Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(0x14CF2E4U) + 0x44U) + 0x84U) + (uint)(8 * i))).ToString() + ","; } return xyz; }
        public void setLocation(int x, int y, int z)
        { double[] xyz = new double[] { (double)x, (double)y, (double)z }; double[] xyz2 = new double[] { (double)x + 0.6, (double)y + 1.8, (double)z + 0.6 }; List<byte> xyzBytes = new List<byte>(); for (int i = 0; i < 3; i++) { byte[] rev = BitConverter.GetBytes(xyz[i]); Array.Reverse(rev); xyzBytes.AddRange(rev); } for (int j = 0; j < 3; j++) { byte[] rev2 = BitConverter.GetBytes(xyz2[j]); Array.Reverse(rev2); xyzBytes.AddRange(rev2); } Form1.PS3.SetMemory(Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(0x14CF2E4U) + 0x44U) + 0x158U), xyzBytes.ToArray()); }
        public double[] playerPos()
        { uint memRegion = 0U; uint clientOrg = 0x100U; uint num = memRegion + Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(0x14CF2E4U) + 0x44U) + clientOrg; int num2 = (int)Form1.PS3.Extension.ReadDouble(num); int num3 = (int)Form1.PS3.Extension.ReadDouble(num + 0x10U); return new double[] { (double)((num2 > 0) ? num2 : (num2 - 1)), Math.Round(Form1.PS3.Extension.ReadDouble(num + 8U)) + 1.0, (double)((num3 > 0) ? num3 : (num3 - 1)) }; }
        public string fixText(string fixStr)
        {
            int length = fixStr.Length;
            int startIndex = 1;
            int num3 = 0;
            for (; ; )
            {
                bool flag = num3 >= length;
                if (flag)
                {
                    break;
                }
                fixStr = fixStr.Insert(startIndex, ".");
                startIndex += 2;
                num3++;
            }
            fixStr = fixStr.Replace(".", "\0");
            return fixStr + "\0\0\0";
        }
        public void setLocation(int x, int y, int z, bool fallDamage)
        {
            double[] array = new double[] { (double)x, (double)y, (double)z }; double[] array2 = new double[] { (double)x + 0.6, (double)y + 1.8, (double)z + 0.6 }; List<byte> list = new List<byte>(); for (int i = 0; i < 3; i++) { byte[] bytes = BitConverter.GetBytes(array[i]); Array.Reverse(bytes); list.AddRange(bytes); } for (int j = 0; j < 3; j++) { byte[] bytes2 = BitConverter.GetBytes(array2[j]); Array.Reverse(bytes2); list.AddRange(bytes2); } bool flag = false; bool flag2 = !fallDamage; if (flag2)
            {
                Form1.PS3.SetMemory(0x227908U, new byte[] { 0x41, 0x82, 0, 0x18 }); flag = true; Form1.PS3.SetMemory(0x227908U, new byte[] { 0x41, 0x82, 0, 0x28 });
            } Form1.PS3.SetMemory(Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(0x14CF2E4U) + 0x44U) + 0x158U), list.ToArray()); bool flag3 = flag && !fallDamage; if (flag3)
            {
                Task.Delay(0x1F4).Wait(); Form1.PS3.SetMemory(0x227908U, new byte[] { 0x41, 0x82, 0, 0x18 });
            }
        }
        public void CHANGING_EFFECT_REGENERATION(int toggle)
        { bool flag = toggle == 0; if (flag) { Form1.PS3.SetMemory(0x14C9B48U, ulti.ModEffectsSPEED); } else { bool flag2 = toggle == 1; if (flag2) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsSLOWNESS); } else { bool flag3 = toggle == 2; if (flag3) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsHASTE); } else { bool flag4 = toggle == 3; if (flag4) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsMINING_FATIGUE); } else { bool flag5 = toggle == 4; if (flag5) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsSTRENGTH); } else { bool flag6 = toggle == 5; if (flag6) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsINSTANT_HEALTH); } else { bool flag7 = toggle == 6; if (flag7) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsINSTANT_DAMAGE); } else { bool flag8 = toggle == 7; if (flag8) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsJUMP_BOOST); } else { bool flag9 = toggle == 8; if (flag9) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsNAUSEA); } else { bool flag10 = toggle == 9; if (flag10) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsREGENERATION); } else { bool flag11 = toggle == 10; if (flag11) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsRESISTANCE); } else { bool flag12 = toggle == 11; if (flag12) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsFIRE_RESISTANCE); } else { bool flag13 = toggle == 12; if (flag13) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsWATER_BREATHING); } else { bool flag14 = toggle == 13; if (flag14) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsINVISIBILITY); } else { bool flag15 = toggle == 14; if (flag15) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsBLINDNESS); } else { bool flag16 = toggle == 15; if (flag16) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsNIGHT_VISION); } else { bool flag17 = toggle == 16; if (flag17) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsHUNGER); } else { bool flag18 = toggle == 17; if (flag18) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsWEAKNESS); } else { bool flag19 = toggle == 18; if (flag19) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsPOISON); } else { bool flag20 = toggle == 19; if (flag20) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsWITHER); } else { bool flag21 = toggle == 20; if (flag21) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsHEALTH_BOOST); } else { bool flag22 = toggle == 21; if (flag22) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsABSORPTION); } else { bool flag23 = toggle == 22; if (flag23) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsSATURATION); } else { bool flag24 = toggle == 23; if (flag24) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsGLOWING); } else { bool flag25 = toggle == 24; if (flag25) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsLEVITATION); } else { bool flag26 = toggle == 25; if (flag26) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsLUCK); } else { bool flag27 = toggle == 26; if (flag27) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsUNLUCK); } else { bool flag28 = toggle == 27; if (flag28) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsCONDUIT_POWER); } else { bool flag29 = toggle == 28; if (flag29) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsSLOW_FALLING); } else { bool flag30 = toggle == 29; if (flag30) { MessageBox.Show("Change the regeneration effect to a another effect\n\nIf you eat a apple or use the totem of undying you will get the regeneration effect, so if you change this effec to a another you will get the new effect.", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } }
        public void CHANGING_EFFECT_REGENERATION_TIME(int toggle)
        { bool flag = toggle == 0; if (flag) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer1); } else { bool flag2 = toggle == 1; if (flag2) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer2); } else { bool flag3 = toggle == 2; if (flag3) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer3); } else { bool flag4 = toggle == 3; if (flag4) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer4); } else { bool flag5 = toggle == 4; if (flag5) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer5); } else { bool flag6 = toggle == 5; if (flag6) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer6); } else { bool flag7 = toggle == 6; if (flag7) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer7); } else { bool flag8 = toggle == 7; if (flag8) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer8); } else { bool flag9 = toggle == 8; if (flag9) { MessageBox.Show("Change duration of the regeneration effect\nWorking only if you using the totem of undying select the duration you want, use the totem and you will get the duration on the regeneration effect. If you change the effect of regeneration to a another it's working too.", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); } } } } } } } } } }
        public void CHANGING_ITEMS_SWAPPER_OFFSET(int toggle)
        { bool flag = toggle == 0; if (flag) { Offset_Default_Items = 0x14C90CCU; } else { bool flag2 = toggle == 1; if (flag2) { Offset_Default_Items = 0x14C9124U; } else { bool flag3 = toggle == 2; if (flag3) { Offset_Default_Items = 0x14C9140U; } else { bool flag4 = toggle == 3; if (flag4) { Offset_Default_Items = 0x14C91D0U; } else { bool flag5 = toggle == 4; if (flag5) { Offset_Default_Items = 0x14C91F0U; } else { bool flag6 = toggle == 5; if (flag6) { Offset_Default_Items = 0x14C9340U; } else { bool flag7 = toggle == 6; if (flag7) { Offset_Default_Items = 0x14C93F0U; } else { bool flag8 = toggle == 7; if (flag8) { Offset_Default_Items = 0x14C9298U; } } } } } } } } }
        public void CHANGING_ITEMS_SWAPPER_VALUES(int toggle)
        { bool flag = toggle == 0; if (flag) { Items_Default_Items = Items_air; } else { bool flag2 = toggle == 1; if (flag2) { Items_Default_Items = Items_flint_and_steel; } else { bool flag3 = toggle == 2; if (flag3) { Items_Default_Items = Items_string; } else { bool flag4 = toggle == 3; if (flag4) { Items_Default_Items = Items_bow; } else { bool flag5 = toggle == 4; if (flag5) { Items_Default_Items = Items_arrow; } else { bool flag6 = toggle == 5; if (flag6) { Items_Default_Items = Items_spectral_arrow; } else { bool flag7 = toggle == 6; if (flag7) { Items_Default_Items = Items_tipped_arrow; } else { bool flag8 = toggle == 7; if (flag8) { Items_Default_Items = Items_diamond_shovel; } else { bool flag9 = toggle == 8; if (flag9) { Items_Default_Items = Items_diamond_pickaxe; } else { bool flag10 = toggle == 9; if (flag10) { Items_Default_Items = Items_diamond_axe; } else { bool flag11 = toggle == 10; if (flag11) { Items_Default_Items = Items_diamond_sword; } else { bool flag12 = toggle == 11; if (flag12) { Items_Default_Items = Items_diamond_hoe; } else { bool flag13 = toggle == 12; if (flag13) { Items_Default_Items = Items_diamond; } else { bool flag14 = toggle == 13; if (flag14) { Items_Default_Items = Items_coocked_porkchop; } else { bool flag15 = toggle == 14; if (flag15) { Items_Default_Items = Items_golden_apple; } else { bool flag16 = toggle == 15; if (flag16) { Items_Default_Items = Items_air; } else { bool flag17 = toggle == 16; if (flag17) { Items_Default_Items = Items_armor_stand; } else { bool flag18 = toggle == 17; if (flag18) { Items_Default_Items = Items_banner; } else { bool flag19 = toggle == 18; if (flag19) { Items_Default_Items = Items_blazer_rood; } else { bool flag20 = toggle == 19; if (flag20) { Items_Default_Items = Items_bucket_lava; } else { bool flag21 = toggle == 20; if (flag21) { Items_Default_Items = Items_commande_block_minecraft; } else { bool flag22 = toggle == 21; if (flag22) { Items_Default_Items = Items_cooked_beef; } else { bool flag23 = toggle == 22; if (flag23) { Items_Default_Items = Items_debug_four_items; } else { bool flag24 = toggle == 23; if (flag24) { Items_Default_Items = Items_egg; } else { bool flag25 = toggle == 24; if (flag25) { Items_Default_Items = Items_emerald; } else { bool flag26 = toggle == 25; if (flag26) { Items_Default_Items = Items_enchanted_book; } else { bool flag27 = toggle == 26; if (flag27) { Items_Default_Items = Items_ender_perl; } else { bool flag28 = toggle == 27; if (flag28) { Items_Default_Items = Items_end_crystal; } else { bool flag29 = toggle == 28; if (flag29) { Items_Default_Items = Items_experience_bottle; } else { bool flag30 = toggle == 29; if (flag30) { Items_Default_Items = Items_snowball; } else { bool flag31 = toggle == 30; if (flag31) { Items_Default_Items = Items_spawn_egg; } else { bool flag32 = toggle == 31; if (flag32) { Items_Default_Items = Items_tnt_minecraft; } else { bool flag33 = toggle == 32; if (flag33) { Items_Default_Items = Items_totem_of_undying; } else { bool flag34 = toggle == 33; if (flag34) { Items_Default_Items = Items_trident; } else { bool flag35 = toggle == 34; if (flag35) { Items_Default_Items = Items_writen_booke; } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } }
        public void CHANGING_BLOCKS_SWAPPER_OFFSET(int toggle)
        { bool flag = toggle == 0; if (flag) { Offset_Default_Blocks = 0x14C893CU; } else { bool flag2 = toggle == 1; if (flag2) { Offset_Default_Blocks = 0x14C8940U; } else { bool flag3 = toggle == 2; if (flag3) { Offset_Default_Blocks = 0x14C8950U; } else { bool flag4 = toggle == 3; if (flag4) { Offset_Default_Blocks = 0x14C8C84U; } else { bool flag5 = toggle == 4; if (flag5) { Offset_Default_Blocks = 0x14C894CU; } else { bool flag6 = toggle == 5; if (flag6) { Offset_Default_Blocks = 0x14C8930U; } else { bool flag7 = toggle == 6; if (flag7) { Offset_Default_Blocks = 0x14C8A04U; } else { bool flag8 = toggle == 7; if (flag8) { Offset_Default_Blocks = 0x14C8A08U; } } } } } } } } }
        public void CHANGING_BLOCKS_SWAPPER_VALUES(int toggle)
        {
            bool flag = toggle == 0; if (flag) { Blocks_Default_Blocks = Blocks_air; }
        }
        public void ENABLE_SPRX()
        {
            Form1.PS3.SetMemory(0x3000D2FBU, new byte[] { 0x44, 0x6F, 0x77, 0x6E, 0x43, 0x72, 0x61, 0x66, 0x74 }); Form1.PS3.SetMemory(0x3000D343U, new byte[] { 0x53, 0x50, 0x52, 0x58 }); Form1.PS3.SetMemory(0x3000D3BBU, new byte[] { 0x50, 0x72, 0x65, 0x6D, 0x69, 0x75, 0x6D }); Form1.PS3.SetMemory(0x3000D44BU, new byte[] { 0x45, 0x6E, 0x61, 0x62, 0x6C, 0x65, 0x64 });
        }
        public string LastPlayersJoinedPSN = "";
        public string LastPlayersRegion = "";
        public string LastPlayersAvatar = "";
        public string GetPingz = "-1";
        public uint Offset_Default_Items = 0U;
        public byte[] Items_Default_Items = new byte[1];
        public uint Offset_Default_Blocks = 0U;
        public byte[] Blocks_Default_Blocks = new byte[1];
        public static byte[] ModEffectsSPEED = new byte[] { 0x32, 0x1B, 0x8C, 0xD0 };
        public static byte[] MobEffectsSLOWNESS = new byte[] { 0x32, 0x1B, 0x8D, 0x10 };
        public static byte[] MobEffectsHASTE = new byte[] { 0x32, 0x1B, 0x95, 0x40 };
        public static byte[] MobEffectsMINING_FATIGUE = new byte[] { 0x32, 0x1B, 0x96, 0x90 };
        public static byte[] MobEffectsSTRENGTH = new byte[] { 0x32, 0x1B, 0x97, 0xE0 };
        public static byte[] MobEffectsINSTANT_HEALTH = new byte[] { 0x32, 0x1B, 0x99, 0x40 };
        public static byte[] MobEffectsINSTANT_DAMAGE = new byte[] { 0x32, 0x1B, 0x9A, 0x40 };
        public static byte[] MobEffectsJUMP_BOOST = new byte[] { 0x32, 0x1B, 0x9B, 0x40 };
        public static byte[] MobEffectsNAUSEA = new byte[] { 0x32, 0x1B, 0x9C, 0x40 };
        public static byte[] MobEffectsREGENERATION = new byte[] { 0x32, 0x1B, 0x9D, 0x80 };
        public static byte[] MobEffectsRESISTANCE = new byte[] { 0x32, 0x1B, 0x9E, 0x80 };
        public static byte[] MobEffectsFIRE_RESISTANCE = new byte[] { 0x32, 0x1B, 0x9F, 0x80 };
        public static byte[] MobEffectsWATER_BREATHING = new byte[] { 0x32, 0x1B, 0xA0, 0x80 };
        public static byte[] MobEffectsINVISIBILITY = new byte[] { 0x32, 0x1B, 0x9C, 0x80 };
        public static byte[] MobEffectsBLINDNESS = new byte[] { 0x32, 0x1B, 0xA2, 0x90 };
        public static byte[] MobEffectsNIGHT_VISION = new byte[] { 0x32, 0x1B, 0xA3, 0x90 };
        public static byte[] MobEffectsHUNGER = new byte[] { 0x32, 0x1B, 0xA4, 0x90 };
        public static byte[] MobEffectsWEAKNESS = new byte[] { 0x32, 0x1B, 0xA5, 0x90 };
        public static byte[] MobEffectsPOISON = new byte[] { 0x32, 0x1B, 0x93, 0xE0 };
        public static byte[] MobEffectsWITHER = new byte[] { 0x32, 0x1B, 0xA0, 0xC0 };
        public static byte[] MobEffectsHEALTH_BOOST = new byte[] { 0x32, 0x1B, 0x93, 0x30 };
        public static byte[] MobEffectsABSORPTION = new byte[] { 0x32, 0x1B, 0xAB, 0x30 };
        public static byte[] MobEffectsSATURATION = new byte[] { 0x32, 0x1B, 0xAC, 0x30 };
        public static byte[] MobEffectsGLOWING = new byte[] { 0x32, 0x1B, 0xAD, 0x30 };
        public static byte[] MobEffectsLEVITATION = new byte[] { 0x32, 0x1B, 0xAE, 0x30 };
        public static byte[] MobEffectsLUCK = new byte[] { 0x32, 0x1B, 0xAF, 0x30 };
        public static byte[] MobEffectsUNLUCK = new byte[] { 0x32, 0x1B, 0xB0, 0x80 };
        public static byte[] MobEffectsCONDUIT_POWER = new byte[] { 0x32, 0x1B, 0xB1, 0xD0 };
        public static byte[] MobEffectsSLOW_FALLING = new byte[] { 0x32, 0x1B, 0xB3, 0x20 };
        public static byte[] MobEffectTimer1 = new byte[] { 0x38, 0xA0, 3, 0x20 };
        public static byte[] MobEffectTimer2 = new byte[] { 0x38, 0xA0, 8, 0x20 };
        public static byte[] MobEffectTimer3 = new byte[] { 0x38, 0xA0, 0x10, 0x20 };
        public static byte[] MobEffectTimer4 = new byte[] { 0x38, 0xA0, 0x20, 0x20 };
        public static byte[] MobEffectTimer5 = new byte[] { 0x38, 0xA0, 0x30, 0x20 };
        public static byte[] MobEffectTimer6 = new byte[] { 0x38, 0xA0, 0x40, 0x20 };
        public static byte[] MobEffectTimer7 = new byte[] { 0x38, 0xA0, 0x60, 0x20 };
        public static byte[] MobEffectTimer8 = new byte[] { 0x38, 0xA0, 0x70, 0x80 };
        public byte[] Items_air = new byte[] { 0x32, 0x1C, 0xA, 0x60 };
        public byte[] Items_flint_and_steel = new byte[] { 0x32, 0x1E, 0xA4, 0x60 };
        public byte[] Items_string = new byte[] { 0x32, 0x1E, 0xF5, 0 };
        public byte[] Items_bow = new byte[] { 0x32, 0x1E, 0xA9, 0xD0 };
        public byte[] Items_arrow = new byte[] { 0x32, 0x1E, 0xAD, 0xA0 };
        public byte[] Items_spectral_arrow = new byte[] { 0x32, 0x20, 0x8D, 0xA0 };
        public byte[] Items_tipped_arrow = new byte[] { 0x32, 0x20, 0x8F, 0xF0 };
        public byte[] Items_bucket_lava = new byte[] { 0x32, 0x1F, 0x6B, 0x20 };
        public byte[] Items_diamond = new byte[] { 0x32, 0x1E, 0xB2, 0x40 };
        public byte[] Items_diamond_shovel = new byte[] { 0x32, 0x1E, 0xD8, 0x30 };
        public byte[] Items_diamond_pickaxe = new byte[] { 0x32, 0x1E, 0xDB, 0x50 };
        public byte[] Items_diamond_axe = new byte[] { 0x32, 0x1E, 0xDE, 0x70 };
        public byte[] Items_diamond_sword = new byte[] { 0x32, 0x1E, 0xD5, 0x20 };
        public byte[] Items_diamond_hoe = new byte[] { 0x32, 0x1F, 5, 0x20 };
        public byte[] Items_apple = new byte[] { 0x32, 0x1E, 0xA7, 0x70 };
        public byte[] Items_coocked_porkchop = new byte[] { 0x32, 0x1F, 0x5A, 0xD0 };
        public byte[] Items_golden_apple = new byte[] { 0x32, 0x1F, 0x5F, 0x80 };
        public byte[] Items_snowball = new byte[] { 0x32, 0x1F, 0x76, 0xB0 };
        public byte[] Items_furnace = new byte[] { 0x32, 0x1F, 0x8F, 0xC0 };
        public byte[] Items_egg = new byte[] { 0x32, 0x1F, 0x91, 0x50 };
        public byte[] Items_cooked_beef = new byte[] { 0x32, 0x1F, 0xC3, 0x80 };
        public byte[] Items_blazer_rood = new byte[] { 0x32, 0x1D, 0xAC, 0x40 };
        public byte[] Items_ender_perl = new byte[] { 0x32, 0x1D, 0xA9, 0xF0 };
        public byte[] Items_spawn_egg = new byte[] { 0x32, 0x20, 1, 0xC0 };
        public byte[] Items_experience_bottle = new byte[] { 0x32, 0x20, 4, 0x10 };
        public byte[] Items_writen_booke = new byte[] { 0x32, 0x20, 0xB, 0xE0 };
        public byte[] Items_emerald = new byte[] { 0x32, 0x20, 0xE, 0x30 };
        public byte[] Items_enchanted_book = new byte[] { 0x32, 0x20, 0x32, 0x80 };
        public byte[] Items_tnt_minecraft = new byte[] { 0x32, 0x20, 0x3B, 0xC0 };
        public byte[] Items_armor_stand = new byte[] { 0x32, 0x20, 0x52, 0x70 };
        public byte[] Items_commande_block_minecraft = new byte[] { 0x32, 0x20, 0x64, 0x20 };
        public byte[] Items_banner = new byte[] { 0x32, 0x20, 0x6C, 0 };
        public byte[] Items_end_crystal = new byte[] { 0x32, 0x20, 0x6E, 0x50 };
        public byte[] Items_totem_of_undying = new byte[] { 0x32, 0x20, 0xA4, 0xF0 };
        public byte[] Items_trident = new byte[] { 0x32, 0x20, 0xB0, 0x30 };
        public byte[] Items_debug_four_items = new byte[] { 0x32, 0x20, 0xCF, 0xB0 };
        public byte[] Blocks_air = new byte[] { 0x32, 0x18, 0x10, 0x20 };
        public byte[] Blocks_stone = new byte[] { 0x32, 0x18, 0x11, 0xC0 };
        public byte[] Blocks_grass = new byte[] { 0x32, 0x18, 0x13, 0x10 };
        public byte[] Blocks_water = new byte[] { 0x32, 0x18, 0x1D, 0x70 };
        public byte[] Blocks_lava = new byte[] { 0x32, 0x18, 0x20, 0xF0 };
        public byte[] Blocks_sand = new byte[] { 0x32, 0x18, 0x22, 0xA0 };
        public byte[] Blocks_bed = new byte[] { 0x32, 0x18, 0x37, 0x80 };
    }
}