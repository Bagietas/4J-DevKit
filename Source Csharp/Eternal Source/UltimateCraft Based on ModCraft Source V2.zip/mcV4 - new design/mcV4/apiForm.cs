﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mcV4
{
    public partial class apiForm : Form
    {
        public apiForm()
        {
            InitializeComponent();
            TopMost = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (Form1.curAPI == "tm")
                    Form1.targetIndex = Convert.ToInt32(textBox1.Text);
                else if (Form1.curAPI == "cc")
                    Form1.ps3IP = textBox1.Text;

                Form1.apiForm_.DialogResult = DialogResult.OK;
                Close();
            }
            catch
            {
                MessageBox.Show("Invalid Entry!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1.apiForm_.DialogResult = DialogResult.Cancel;
            Close();
        }
        private void setColor()
        {
            BackColor = Form1.saveBackColor;
            button1.BackColor = Form1.saveBackColor;
            button1.ForeColor = Form1.saveTextColor;
            button1.FlatAppearance.BorderColor = Form1.saveThemeColor;

            button4.BackColor = Form1.saveBackColor;
            button4.ForeColor = Form1.saveTextColor;
            button4.FlatAppearance.BorderColor = Form1.saveThemeColor;

            listBox1.BackColor = Form1.saveBackColor;

            textBox1.BackColor = Form1.saveBackColor;
            textBox1.ForeColor = Form1.saveTextColor;

        }
        private void apiForm_Load(object sender, EventArgs e)
        {
            setColor();
            if (Form1.curAPI == "tm")
                textBox1.Text = "" + Form1.targetIndex;
            else if (Form1.curAPI == "cc")
                textBox1.Text = Form1.ps3IP;
                listBox1.Items.Clear();
            listBox1.Items.AddRange(Form1.listCT.ToArray());
            label10.Text = Form1.labelTxtCT;

            if (listBox1.Items.Count != 0)
                listBox1.SelectedIndex = 0;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Form1.curAPI == "tm")
                textBox1.Text = Convert.ToString(listBox1.SelectedIndex + 1);
            else if (Form1.curAPI == "cc")
                textBox1.Text = Form1.cList[listBox1.SelectedIndex].Ip;
        }

        private void listBox1_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                e = new DrawItemEventArgs(e.Graphics,
                                          e.Font,
                                          e.Bounds,
                                          e.Index,
                                          e.State ^ DrawItemState.Selected,
                                          Form1.saveTextColor,
                                          Form1.saveThemeColor);

            SolidBrush brush = new SolidBrush(Form1.saveTextColor);
            e.DrawBackground();
            e.Graphics.DrawString(listBox1.Items[e.Index].ToString(), e.Font, brush, e.Bounds, StringFormat.GenericDefault);
            e.DrawFocusRectangle();
        }
    }
}
