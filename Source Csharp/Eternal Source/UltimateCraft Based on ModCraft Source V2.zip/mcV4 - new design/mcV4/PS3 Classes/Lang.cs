﻿using System;

namespace PS3Lib
{
	public enum Lang
	{
		Null,
		French,
		English,
		German
	}
}
