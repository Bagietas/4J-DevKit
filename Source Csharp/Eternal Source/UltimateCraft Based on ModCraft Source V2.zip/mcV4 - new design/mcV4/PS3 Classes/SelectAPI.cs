﻿using System;

namespace PS3Lib
{
	public enum SelectAPI
	{
		ControlConsole,
		TargetManager,
		PS3Manager,
        PS3ManagerAPI
    }
}
