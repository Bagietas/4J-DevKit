﻿using System;

namespace PS3Lib
{
	public enum EndianType
	{
		LittleEndian,
		BigEndian
	}
}
