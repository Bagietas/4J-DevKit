﻿namespace mcV4.Tabs
{
    partial class PlayerPosition
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.posPanel = new System.Windows.Forms.Panel();
            this.button15 = new System.Windows.Forms.Button();
            this.buttonclear = new System.Windows.Forms.Button();
            this.buttonsave = new System.Windows.Forms.Button();
            this.buttonlist = new System.Windows.Forms.Button();
            this.buttoncur = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.buttonP = new System.Windows.Forms.Button();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.button7 = new System.Windows.Forms.Button();
            this.posPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // posPanel
            // 
            this.posPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.posPanel.Controls.Add(this.button7);
            this.posPanel.Controls.Add(this.button15);
            this.posPanel.Controls.Add(this.buttonclear);
            this.posPanel.Controls.Add(this.buttonsave);
            this.posPanel.Controls.Add(this.buttonlist);
            this.posPanel.Controls.Add(this.buttoncur);
            this.posPanel.Controls.Add(this.label16);
            this.posPanel.Controls.Add(this.label15);
            this.posPanel.Controls.Add(this.dataGridView1);
            this.posPanel.Controls.Add(this.textBox4);
            this.posPanel.Controls.Add(this.buttonP);
            this.posPanel.Controls.Add(this.checkBox7);
            this.posPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.posPanel.Location = new System.Drawing.Point(0, 0);
            this.posPanel.Name = "posPanel";
            this.posPanel.Size = new System.Drawing.Size(558, 369);
            this.posPanel.TabIndex = 34;
            // 
            // button15
            // 
            this.button15.AutoSize = true;
            this.button15.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button15.ForeColor = System.Drawing.SystemColors.Control;
            this.button15.Location = new System.Drawing.Point(26, 222);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(139, 27);
            this.button15.TabIndex = 39;
            this.button15.Text = "Copy Position";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // buttonclear
            // 
            this.buttonclear.AutoSize = true;
            this.buttonclear.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonclear.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttonclear.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonclear.Location = new System.Drawing.Point(445, 255);
            this.buttonclear.Name = "buttonclear";
            this.buttonclear.Size = new System.Drawing.Size(89, 27);
            this.buttonclear.TabIndex = 38;
            this.buttonclear.Text = "Clear List";
            this.buttonclear.UseVisualStyleBackColor = true;
            // 
            // buttonsave
            // 
            this.buttonsave.AutoSize = true;
            this.buttonsave.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonsave.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttonsave.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonsave.Location = new System.Drawing.Point(203, 255);
            this.buttonsave.Name = "buttonsave";
            this.buttonsave.Size = new System.Drawing.Size(89, 27);
            this.buttonsave.TabIndex = 37;
            this.buttonsave.Text = "Save List";
            this.buttonsave.UseVisualStyleBackColor = true;
            // 
            // buttonlist
            // 
            this.buttonlist.AutoSize = true;
            this.buttonlist.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonlist.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttonlist.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonlist.Location = new System.Drawing.Point(324, 255);
            this.buttonlist.Name = "buttonlist";
            this.buttonlist.Size = new System.Drawing.Size(89, 27);
            this.buttonlist.TabIndex = 36;
            this.buttonlist.Text = "Load List";
            this.buttonlist.UseVisualStyleBackColor = true;
            // 
            // buttoncur
            // 
            this.buttoncur.AutoSize = true;
            this.buttoncur.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttoncur.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttoncur.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttoncur.ForeColor = System.Drawing.SystemColors.Control;
            this.buttoncur.Location = new System.Drawing.Point(203, 222);
            this.buttoncur.Name = "buttoncur";
            this.buttoncur.Size = new System.Drawing.Size(331, 27);
            this.buttoncur.TabIndex = 34;
            this.buttoncur.Text = "Add Current Position To List";
            this.buttoncur.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label16.ForeColor = System.Drawing.SystemColors.Control;
            this.label16.Location = new System.Drawing.Point(23, 13);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(126, 15);
            this.label16.TabIndex = 33;
            this.label16.Text = "Enter Coordinates";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label15.ForeColor = System.Drawing.SystemColors.Control;
            this.label15.Location = new System.Drawing.Point(23, 136);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 45);
            this.label15.TabIndex = 32;
            this.label15.Text = "X: N/A\r\nY: N.A\r\nZ: N/A";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Consolas", 8.75F);
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dataGridView1.GridColor = System.Drawing.Color.Black;
            this.dataGridView1.Location = new System.Drawing.Point(203, 13);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Consolas", 8.75F);
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(331, 203);
            this.dataGridView1.TabIndex = 31;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Name";
            this.Column1.Name = "Column1";
            this.Column1.Width = 120;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Coordinates XYZ";
            this.Column2.Name = "Column2";
            this.Column2.Width = 140;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Set";
            this.Column3.Name = "Column3";
            this.Column3.Width = 50;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.ForeColor = System.Drawing.SystemColors.Control;
            this.textBox4.Location = new System.Drawing.Point(26, 31);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(139, 20);
            this.textBox4.TabIndex = 27;
            // 
            // buttonP
            // 
            this.buttonP.AutoSize = true;
            this.buttonP.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonP.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttonP.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonP.Location = new System.Drawing.Point(26, 59);
            this.buttonP.Name = "buttonP";
            this.buttonP.Size = new System.Drawing.Size(139, 27);
            this.buttonP.TabIndex = 26;
            this.buttonP.Text = "Set Position";
            this.buttonP.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox7.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox7.Location = new System.Drawing.Point(26, 197);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(138, 19);
            this.checkBox7.TabIndex = 25;
            this.checkBox7.Text = "Show Coordinates";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DimGray;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(12, 329);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(534, 32);
            this.button7.TabIndex = 40;
            this.button7.Text = "Done";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // PlayerPosition
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 369);
            this.Controls.Add(this.posPanel);
            this.Name = "PlayerPosition";
            this.Text = "tab4";
            this.posPanel.ResumeLayout(false);
            this.posPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel posPanel;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button buttonclear;
        private System.Windows.Forms.Button buttonsave;
        private System.Windows.Forms.Button buttonlist;
        private System.Windows.Forms.Button buttoncur;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewButtonColumn Column3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button buttonP;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.Button button7;
    }
}