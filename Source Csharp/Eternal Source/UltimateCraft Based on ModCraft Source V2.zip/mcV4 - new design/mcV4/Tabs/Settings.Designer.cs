﻿namespace mcV4.Tabs
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.settingsPanel = new System.Windows.Forms.Panel();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button25 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.xxxx = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.settingsPanel.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // settingsPanel
            // 
            this.settingsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.settingsPanel.Controls.Add(this.button7);
            this.settingsPanel.Controls.Add(this.groupBox9);
            this.settingsPanel.Controls.Add(this.groupBox6);
            this.settingsPanel.Controls.Add(this.groupBox5);
            this.settingsPanel.Controls.Add(this.groupBox4);
            this.settingsPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.settingsPanel.Font = new System.Drawing.Font("Consolas", 10F);
            this.settingsPanel.Location = new System.Drawing.Point(0, 0);
            this.settingsPanel.Name = "settingsPanel";
            this.settingsPanel.Size = new System.Drawing.Size(430, 336);
            this.settingsPanel.TabIndex = 10;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.checkBox12);
            this.groupBox9.Controls.Add(this.checkBox11);
            this.groupBox9.Controls.Add(this.checkBox10);
            this.groupBox9.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox9.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox9.Location = new System.Drawing.Point(145, 3);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(144, 132);
            this.groupBox9.TabIndex = 27;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Tool Settings";
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox12.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox12.Location = new System.Drawing.Point(9, 95);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(131, 19);
            this.checkBox12.TabIndex = 28;
            this.checkBox12.Text = "Selecting Sound";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox11.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox11.Location = new System.Drawing.Point(9, 60);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(82, 19);
            this.checkBox11.TabIndex = 27;
            this.checkBox11.Text = "x2 Scale";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox10.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox10.Location = new System.Drawing.Point(9, 26);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(75, 19);
            this.checkBox10.TabIndex = 26;
            this.checkBox10.Text = "Topmost";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button25);
            this.groupBox6.Controls.Add(this.button22);
            this.groupBox6.Controls.Add(this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx);
            this.groupBox6.Controls.Add(this.button8);
            this.groupBox6.Controls.Add(this.checkBox9);
            this.groupBox6.Controls.Add(this.xxxx);
            this.groupBox6.Controls.Add(this.button3);
            this.groupBox6.Controls.Add(this.button20);
            this.groupBox6.Controls.Add(this.button21);
            this.groupBox6.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox6.Location = new System.Drawing.Point(19, 145);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(394, 135);
            this.groupBox6.TabIndex = 13;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Game Mods Settings";
            // 
            // button25
            // 
            this.button25.AutoSize = true;
            this.button25.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button25.ForeColor = System.Drawing.SystemColors.Control;
            this.button25.Location = new System.Drawing.Point(15, 93);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(173, 27);
            this.button25.TabIndex = 28;
            this.button25.Text = "View Activated Options";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.AutoSize = true;
            this.button22.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button22.ForeColor = System.Drawing.SystemColors.Control;
            this.button22.Location = new System.Drawing.Point(426, 236);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(96, 27);
            this.button22.TabIndex = 10;
            this.button22.Text = "Test";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
            // 
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.Location = new System.Drawing.Point(68, 622);
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.Name = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.TabIndex = 15;
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.Text = "02158542626241";
            // 
            // button8
            // 
            this.button8.AutoSize = true;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button8.ForeColor = System.Drawing.SystemColors.Control;
            this.button8.Location = new System.Drawing.Point(262, 22);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(117, 27);
            this.button8.TabIndex = 27;
            this.button8.Text = "View Load Path";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox9.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox9.Location = new System.Drawing.Point(100, 62);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(208, 19);
            this.checkBox9.TabIndex = 25;
            this.checkBox9.Text = "Load Config on Game Attach";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // xxxx
            // 
            this.xxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxx.Location = new System.Drawing.Point(68, 347);
            this.xxxx.Name = "xxxx";
            this.xxxx.ReadOnly = true;
            this.xxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxx.TabIndex = 13;
            this.xxxx.Text = "1916280619523";
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button3.ForeColor = System.Drawing.SystemColors.Control;
            this.button3.Location = new System.Drawing.Point(194, 93);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(185, 27);
            this.button3.TabIndex = 26;
            this.button3.Text = "Reset Options";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.AutoSize = true;
            this.button20.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button20.ForeColor = System.Drawing.SystemColors.Control;
            this.button20.Location = new System.Drawing.Point(15, 22);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(117, 27);
            this.button20.TabIndex = 11;
            this.button20.Text = "Load Config";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.AutoSize = true;
            this.button21.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button21.ForeColor = System.Drawing.SystemColors.Control;
            this.button21.Location = new System.Drawing.Point(138, 22);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(118, 27);
            this.button21.TabIndex = 12;
            this.button21.Text = "Save Config";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button16);
            this.groupBox5.Controls.Add(this.button17);
            this.groupBox5.Controls.Add(this.button11);
            this.groupBox5.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox5.Location = new System.Drawing.Point(295, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(119, 132);
            this.groupBox5.TabIndex = 12;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Information";
            // 
            // button16
            // 
            this.button16.AutoSize = true;
            this.button16.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button16.ForeColor = System.Drawing.SystemColors.Control;
            this.button16.Location = new System.Drawing.Point(11, 23);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(96, 27);
            this.button16.TabIndex = 8;
            this.button16.Text = "About";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.AutoSize = true;
            this.button17.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button17.ForeColor = System.Drawing.SystemColors.Control;
            this.button17.Location = new System.Drawing.Point(11, 56);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(96, 27);
            this.button17.TabIndex = 9;
            this.button17.Text = "Mod Tips";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.AutoSize = true;
            this.button11.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button11.ForeColor = System.Drawing.SystemColors.Control;
            this.button11.Location = new System.Drawing.Point(11, 89);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(96, 27);
            this.button11.TabIndex = 7;
            this.button11.Text = "Credits";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button9);
            this.groupBox4.Controls.Add(this.button19);
            this.groupBox4.Controls.Add(this.button10);
            this.groupBox4.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox4.Location = new System.Drawing.Point(20, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(119, 132);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Color Settings";
            // 
            // button9
            // 
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button9.ForeColor = System.Drawing.SystemColors.Control;
            this.button9.Location = new System.Drawing.Point(11, 23);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(96, 27);
            this.button9.TabIndex = 5;
            this.button9.Text = "Theme";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.AutoSize = true;
            this.button19.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button19.ForeColor = System.Drawing.SystemColors.Control;
            this.button19.Location = new System.Drawing.Point(11, 56);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(96, 27);
            this.button19.TabIndex = 10;
            this.button19.Text = "Text";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.AutoSize = true;
            this.button10.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button10.ForeColor = System.Drawing.SystemColors.Control;
            this.button10.Location = new System.Drawing.Point(11, 89);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(96, 27);
            this.button10.TabIndex = 6;
            this.button10.Text = "Background";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DimGray;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(21, 294);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(393, 32);
            this.button7.TabIndex = 28;
            this.button7.Text = "Done";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 336);
            this.Controls.Add(this.settingsPanel);
            this.Name = "Settings";
            this.Text = "Settings";
            this.settingsPanel.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel settingsPanel;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.TextBox xxxxxxxxxxxxxxxxxxxxxxxxxxxxx;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.TextBox xxxx;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button7;
    }
}