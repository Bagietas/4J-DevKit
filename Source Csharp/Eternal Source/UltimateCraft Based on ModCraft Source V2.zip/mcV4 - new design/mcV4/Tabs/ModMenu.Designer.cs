﻿namespace mcV4.Tabs
{
    partial class ModMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.modMenuPanel = new System.Windows.Forms.Panel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.xxxxxxxxxxxxxxxxxx = new System.Windows.Forms.TextBox();
            this.xxxxxxxxxxxxxxxxx = new System.Windows.Forms.TextBox();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.modMenuPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // modMenuPanel
            // 
            this.modMenuPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.modMenuPanel.Controls.Add(this.button7);
            this.modMenuPanel.Controls.Add(this.checkBox1);
            this.modMenuPanel.Controls.Add(this.button4);
            this.modMenuPanel.Controls.Add(this.groupBox1);
            this.modMenuPanel.Controls.Add(this.label4);
            this.modMenuPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.modMenuPanel.Location = new System.Drawing.Point(0, 0);
            this.modMenuPanel.Name = "modMenuPanel";
            this.modMenuPanel.Size = new System.Drawing.Size(284, 276);
            this.modMenuPanel.TabIndex = 11;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox1.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox1.Location = new System.Drawing.Point(13, 37);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(68, 19);
            this.checkBox1.TabIndex = 27;
            this.checkBox1.Text = "Enable";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.AutoSize = true;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button4.ForeColor = System.Drawing.SystemColors.Control;
            this.button4.Location = new System.Drawing.Point(12, 62);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(260, 27);
            this.button4.TabIndex = 28;
            this.button4.Text = "How To Use";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.xxxxxxxxxxxxxxxxxx);
            this.groupBox1.Controls.Add(this.xxxxxxxxxxxxxxxxx);
            this.groupBox1.Controls.Add(this.button12);
            this.groupBox1.Controls.Add(this.button13);
            this.groupBox1.Controls.Add(this.button14);
            this.groupBox1.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Location = new System.Drawing.Point(13, 95);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(259, 133);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Color Settings";
            // 
            // xxxxxxxxxxxxxxxxxx
            // 
            this.xxxxxxxxxxxxxxxxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxxxxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxxxxxx.Location = new System.Drawing.Point(46, 612);
            this.xxxxxxxxxxxxxxxxxx.Name = "xxxxxxxxxxxxxxxxxx";
            this.xxxxxxxxxxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxxxxxxxxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxxxxxxxxxxxxxxxx.TabIndex = 14;
            this.xxxxxxxxxxxxxxxxxx.Text = "022677030247";
            // 
            // xxxxxxxxxxxxxxxxx
            // 
            this.xxxxxxxxxxxxxxxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxxxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxxxxx.Location = new System.Drawing.Point(15, 662);
            this.xxxxxxxxxxxxxxxxx.Name = "xxxxxxxxxxxxxxxxx";
            this.xxxxxxxxxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxxxxxxxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxxxxxxxxxxxxxxx.TabIndex = 16;
            this.xxxxxxxxxxxxxxxxx.Text = "43683878012";
            // 
            // button12
            // 
            this.button12.AutoSize = true;
            this.button12.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button12.ForeColor = System.Drawing.SystemColors.Control;
            this.button12.Location = new System.Drawing.Point(6, 24);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(247, 27);
            this.button12.TabIndex = 5;
            this.button12.Text = "Theme";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.AutoSize = true;
            this.button13.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button13.ForeColor = System.Drawing.SystemColors.Control;
            this.button13.Location = new System.Drawing.Point(6, 57);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(247, 27);
            this.button13.TabIndex = 10;
            this.button13.Text = "Text";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.AutoSize = true;
            this.button14.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button14.ForeColor = System.Drawing.SystemColors.Control;
            this.button14.Location = new System.Drawing.Point(6, 90);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(247, 27);
            this.button14.TabIndex = 6;
            this.button14.Text = "Background";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(10, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 15);
            this.label4.TabIndex = 29;
            this.label4.Text = "Status: Inactive";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DimGray;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(12, 234);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(260, 32);
            this.button7.TabIndex = 31;
            this.button7.Text = "Done";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // ModMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 276);
            this.Controls.Add(this.modMenuPanel);
            this.Name = "ModMenu";
            this.Text = "tab6";
            this.modMenuPanel.ResumeLayout(false);
            this.modMenuPanel.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel modMenuPanel;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox xxxxxxxxxxxxxxxxxx;
        private System.Windows.Forms.TextBox xxxxxxxxxxxxxxxxx;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button7;
    }
}