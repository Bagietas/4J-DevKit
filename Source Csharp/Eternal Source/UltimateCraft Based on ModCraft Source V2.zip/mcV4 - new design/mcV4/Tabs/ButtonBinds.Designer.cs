﻿namespace mcV4.Tabs
{
    partial class ButtonBinds
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBindsPanel = new System.Windows.Forms.Panel();
            this.button24 = new System.Windows.Forms.Button();
            this.buttonR = new System.Windows.Forms.Button();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.btnBindsPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBindsPanel
            // 
            this.btnBindsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnBindsPanel.Controls.Add(this.button7);
            this.btnBindsPanel.Controls.Add(this.button24);
            this.btnBindsPanel.Controls.Add(this.buttonR);
            this.btnBindsPanel.Controls.Add(this.listBox3);
            this.btnBindsPanel.Controls.Add(this.label13);
            this.btnBindsPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnBindsPanel.Location = new System.Drawing.Point(0, 0);
            this.btnBindsPanel.Name = "btnBindsPanel";
            this.btnBindsPanel.Size = new System.Drawing.Size(299, 323);
            this.btnBindsPanel.TabIndex = 32;
            // 
            // button24
            // 
            this.button24.AutoSize = true;
            this.button24.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button24.ForeColor = System.Drawing.SystemColors.Control;
            this.button24.Location = new System.Drawing.Point(23, 246);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(254, 27);
            this.button24.TabIndex = 20;
            this.button24.Text = "How To Use";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // buttonR
            // 
            this.buttonR.AutoSize = true;
            this.buttonR.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonR.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttonR.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonR.Location = new System.Drawing.Point(24, 213);
            this.buttonR.Name = "buttonR";
            this.buttonR.Size = new System.Drawing.Size(254, 27);
            this.buttonR.TabIndex = 19;
            this.buttonR.Text = "Remove Selected Bind";
            this.buttonR.UseVisualStyleBackColor = true;
            // 
            // listBox3
            // 
            this.listBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.listBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.listBox3.ForeColor = System.Drawing.SystemColors.Control;
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 15;
            this.listBox3.Location = new System.Drawing.Point(24, 26);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(254, 182);
            this.listBox3.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label13.ForeColor = System.Drawing.SystemColors.Control;
            this.label13.Location = new System.Drawing.Point(114, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 15);
            this.label13.TabIndex = 17;
            this.label13.Text = "Bind List";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DimGray;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(24, 281);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(253, 32);
            this.button7.TabIndex = 21;
            this.button7.Text = "Done";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // ButtonBinds
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(299, 323);
            this.Controls.Add(this.btnBindsPanel);
            this.Name = "ButtonBinds";
            this.Text = "tab3";
            this.btnBindsPanel.ResumeLayout(false);
            this.btnBindsPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel btnBindsPanel;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button buttonR;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button7;
    }
}