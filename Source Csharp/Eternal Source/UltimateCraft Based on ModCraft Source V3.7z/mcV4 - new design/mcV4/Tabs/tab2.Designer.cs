﻿namespace mcV4.Tabs
{
    partial class tab2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(tab2));
            this.hostOptsPanel = new System.Windows.Forms.Panel();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.mcL = new System.Windows.Forms.RichTextBox();
            this.ultL = new System.Windows.Forms.RichTextBox();
            this.xxxxxxxxxx = new System.Windows.Forms.TextBox();
            this.xxxxxxxxxxx = new System.Windows.Forms.TextBox();
            this.xxxxxxxxxxxxxx = new System.Windows.Forms.TextBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.buttonuse = new System.Windows.Forms.Button();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button18 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.hostOptsPanel.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // hostOptsPanel
            // 
            this.hostOptsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.hostOptsPanel.Controls.Add(this.groupBox8);
            this.hostOptsPanel.Controls.Add(this.groupBox7);
            this.hostOptsPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostOptsPanel.Location = new System.Drawing.Point(0, 0);
            this.hostOptsPanel.Name = "hostOptsPanel";
            this.hostOptsPanel.Size = new System.Drawing.Size(284, 261);
            this.hostOptsPanel.TabIndex = 31;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.mcL);
            this.groupBox8.Controls.Add(this.ultL);
            this.groupBox8.Controls.Add(this.xxxxxxxxxx);
            this.groupBox8.Controls.Add(this.xxxxxxxxxxx);
            this.groupBox8.Controls.Add(this.xxxxxxxxxxxxxx);
            this.groupBox8.Controls.Add(this.checkBox6);
            this.groupBox8.Controls.Add(this.numericUpDown3);
            this.groupBox8.Controls.Add(this.label10);
            this.groupBox8.Controls.Add(this.checkBox4);
            this.groupBox8.Controls.Add(this.buttonuse);
            this.groupBox8.Controls.Add(this.checkBox5);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox8.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox8.Location = new System.Drawing.Point(13, 18);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(306, 141);
            this.groupBox8.TabIndex = 26;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Server Player - Host Only";
            // 
            // mcL
            // 
            this.mcL.Location = new System.Drawing.Point(352, 525);
            this.mcL.Name = "mcL";
            this.mcL.ReadOnly = true;
            this.mcL.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.mcL.Size = new System.Drawing.Size(44, 40);
            this.mcL.TabIndex = 18;
            this.mcL.Text = resources.GetString("mcL.Text");
            this.mcL.WordWrap = false;
            // 
            // ultL
            // 
            this.ultL.Location = new System.Drawing.Point(422, 582);
            this.ultL.Name = "ultL";
            this.ultL.ReadOnly = true;
            this.ultL.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.ultL.Size = new System.Drawing.Size(36, 40);
            this.ultL.TabIndex = 19;
            this.ultL.Text = resources.GetString("ultL.Text");
            this.ultL.WordWrap = false;
            // 
            // xxxxxxxxxx
            // 
            this.xxxxxxxxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxx.Location = new System.Drawing.Point(426, 84);
            this.xxxxxxxxxx.Name = "xxxxxxxxxx";
            this.xxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxxxxxxxx.TabIndex = 27;
            this.xxxxxxxxxx.Text = "11798247788415868458496190753235";
            // 
            // xxxxxxxxxxx
            // 
            this.xxxxxxxxxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxx.Location = new System.Drawing.Point(426, 84);
            this.xxxxxxxxxxx.Name = "xxxxxxxxxxx";
            this.xxxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxxxxxxxxx.TabIndex = 26;
            this.xxxxxxxxxxx.Text = "448590002658602";
            // 
            // xxxxxxxxxxxxxx
            // 
            this.xxxxxxxxxxxxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxx.Location = new System.Drawing.Point(426, 84);
            this.xxxxxxxxxxxxxx.Name = "xxxxxxxxxxxxxx";
            this.xxxxxxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxxxxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxxxxxxxxxxxx.TabIndex = 25;
            this.xxxxxxxxxxxxxx.Text = "865328593944257997423333425";
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox6.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox6.Location = new System.Drawing.Point(19, 22);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(68, 19);
            this.checkBox6.TabIndex = 24;
            this.checkBox6.Text = "Enable";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.numericUpDown3.ForeColor = System.Drawing.SystemColors.Control;
            this.numericUpDown3.Location = new System.Drawing.Point(187, 72);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(94, 23);
            this.numericUpDown3.TabIndex = 19;
            this.numericUpDown3.Value = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label10.ForeColor = System.Drawing.SystemColors.Control;
            this.label10.Location = new System.Drawing.Point(125, 74);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 15);
            this.label10.TabIndex = 18;
            this.label10.Text = "RTM XP:";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox4.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox4.Location = new System.Drawing.Point(187, 47);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(96, 19);
            this.checkBox4.TabIndex = 20;
            this.checkBox4.Text = "Pick Block";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // buttonuse
            // 
            this.buttonuse.AutoSize = true;
            this.buttonuse.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonuse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonuse.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttonuse.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonuse.Location = new System.Drawing.Point(19, 62);
            this.buttonuse.Name = "buttonuse";
            this.buttonuse.Size = new System.Drawing.Size(89, 27);
            this.buttonuse.TabIndex = 23;
            this.buttonuse.Text = "How To Use";
            this.buttonuse.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox5.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox5.Location = new System.Drawing.Point(187, 22);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(110, 19);
            this.checkBox5.TabIndex = 21;
            this.checkBox5.Text = "Invulnerable";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label11.ForeColor = System.Drawing.SystemColors.Control;
            this.label11.Location = new System.Drawing.Point(16, 111);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 15);
            this.label11.TabIndex = 22;
            this.label11.Text = "Status: Off";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button18);
            this.groupBox7.Controls.Add(this.button23);
            this.groupBox7.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox7.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox7.Location = new System.Drawing.Point(12, 165);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(307, 73);
            this.groupBox7.TabIndex = 25;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "God Mode / Invisibility - Non-host Only";
            // 
            // button18
            // 
            this.button18.AutoSize = true;
            this.button18.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button18.ForeColor = System.Drawing.SystemColors.Control;
            this.button18.Location = new System.Drawing.Point(15, 26);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(96, 27);
            this.button18.TabIndex = 7;
            this.button18.Text = "Take Damage";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.AutoSize = true;
            this.button23.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button23.ForeColor = System.Drawing.SystemColors.Control;
            this.button23.Location = new System.Drawing.Point(195, 26);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(96, 27);
            this.button23.TabIndex = 6;
            this.button23.Text = "How To Use";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // tab2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.hostOptsPanel);
            this.Name = "tab2";
            this.Text = "tab2";
            this.hostOptsPanel.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel hostOptsPanel;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RichTextBox mcL;
        private System.Windows.Forms.RichTextBox ultL;
        private System.Windows.Forms.TextBox xxxxxxxxxx;
        private System.Windows.Forms.TextBox xxxxxxxxxxx;
        private System.Windows.Forms.TextBox xxxxxxxxxxxxxx;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Button buttonuse;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button23;
    }
}