﻿namespace mcV4.Tabs
{
    partial class tab5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.itemPanel = new System.Windows.Forms.Panel();
            this.buttonh2u = new System.Windows.Forms.Button();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.iSlot27 = new System.Windows.Forms.Label();
            this.iSlot26 = new System.Windows.Forms.Label();
            this.iSlot25 = new System.Windows.Forms.Label();
            this.iSlot24 = new System.Windows.Forms.Label();
            this.iSlot23 = new System.Windows.Forms.Label();
            this.iSlot22 = new System.Windows.Forms.Label();
            this.iSlot21 = new System.Windows.Forms.Label();
            this.iSlot20 = new System.Windows.Forms.Label();
            this.iSlot19 = new System.Windows.Forms.Label();
            this.iSlot18 = new System.Windows.Forms.Label();
            this.iSlot17 = new System.Windows.Forms.Label();
            this.iSlot16 = new System.Windows.Forms.Label();
            this.iSlot15 = new System.Windows.Forms.Label();
            this.iSlot14 = new System.Windows.Forms.Label();
            this.iSlot13 = new System.Windows.Forms.Label();
            this.iSlot12 = new System.Windows.Forms.Label();
            this.iSlot11 = new System.Windows.Forms.Label();
            this.iSlot10 = new System.Windows.Forms.Label();
            this.iSlot9 = new System.Windows.Forms.Label();
            this.iSlot8 = new System.Windows.Forms.Label();
            this.iSlot7 = new System.Windows.Forms.Label();
            this.iSlot6 = new System.Windows.Forms.Label();
            this.iSlot5 = new System.Windows.Forms.Label();
            this.iSlot4 = new System.Windows.Forms.Label();
            this.iSlot3 = new System.Windows.Forms.Label();
            this.iSlot2 = new System.Windows.Forms.Label();
            this.iSlot1 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.hSlot9 = new System.Windows.Forms.Label();
            this.hSlot8 = new System.Windows.Forms.Label();
            this.hSlot7 = new System.Windows.Forms.Label();
            this.hSlot6 = new System.Windows.Forms.Label();
            this.hSlot5 = new System.Windows.Forms.Label();
            this.hSlot4 = new System.Windows.Forms.Label();
            this.hSlot3 = new System.Windows.Forms.Label();
            this.hSlot2 = new System.Windows.Forms.Label();
            this.hSlot1 = new System.Windows.Forms.Label();
            this.oSlot1 = new System.Windows.Forms.Label();
            this.aSlot4 = new System.Windows.Forms.Label();
            this.aSlot3 = new System.Windows.Forms.Label();
            this.aSlot1 = new System.Windows.Forms.Label();
            this.aSlot2 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.itemPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // itemPanel
            // 
            this.itemPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.itemPanel.Controls.Add(this.buttonh2u);
            this.itemPanel.Controls.Add(this.checkBox8);
            this.itemPanel.Controls.Add(this.label17);
            this.itemPanel.Controls.Add(this.label52);
            this.itemPanel.Controls.Add(this.iSlot27);
            this.itemPanel.Controls.Add(this.iSlot26);
            this.itemPanel.Controls.Add(this.iSlot25);
            this.itemPanel.Controls.Add(this.iSlot24);
            this.itemPanel.Controls.Add(this.iSlot23);
            this.itemPanel.Controls.Add(this.iSlot22);
            this.itemPanel.Controls.Add(this.iSlot21);
            this.itemPanel.Controls.Add(this.iSlot20);
            this.itemPanel.Controls.Add(this.iSlot19);
            this.itemPanel.Controls.Add(this.iSlot18);
            this.itemPanel.Controls.Add(this.iSlot17);
            this.itemPanel.Controls.Add(this.iSlot16);
            this.itemPanel.Controls.Add(this.iSlot15);
            this.itemPanel.Controls.Add(this.iSlot14);
            this.itemPanel.Controls.Add(this.iSlot13);
            this.itemPanel.Controls.Add(this.iSlot12);
            this.itemPanel.Controls.Add(this.iSlot11);
            this.itemPanel.Controls.Add(this.iSlot10);
            this.itemPanel.Controls.Add(this.iSlot9);
            this.itemPanel.Controls.Add(this.iSlot8);
            this.itemPanel.Controls.Add(this.iSlot7);
            this.itemPanel.Controls.Add(this.iSlot6);
            this.itemPanel.Controls.Add(this.iSlot5);
            this.itemPanel.Controls.Add(this.iSlot4);
            this.itemPanel.Controls.Add(this.iSlot3);
            this.itemPanel.Controls.Add(this.iSlot2);
            this.itemPanel.Controls.Add(this.iSlot1);
            this.itemPanel.Controls.Add(this.label25);
            this.itemPanel.Controls.Add(this.label26);
            this.itemPanel.Controls.Add(this.hSlot9);
            this.itemPanel.Controls.Add(this.hSlot8);
            this.itemPanel.Controls.Add(this.hSlot7);
            this.itemPanel.Controls.Add(this.hSlot6);
            this.itemPanel.Controls.Add(this.hSlot5);
            this.itemPanel.Controls.Add(this.hSlot4);
            this.itemPanel.Controls.Add(this.hSlot3);
            this.itemPanel.Controls.Add(this.hSlot2);
            this.itemPanel.Controls.Add(this.hSlot1);
            this.itemPanel.Controls.Add(this.oSlot1);
            this.itemPanel.Controls.Add(this.aSlot4);
            this.itemPanel.Controls.Add(this.aSlot3);
            this.itemPanel.Controls.Add(this.aSlot1);
            this.itemPanel.Controls.Add(this.aSlot2);
            this.itemPanel.Controls.Add(this.label27);
            this.itemPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.itemPanel.Location = new System.Drawing.Point(0, 0);
            this.itemPanel.Name = "itemPanel";
            this.itemPanel.Size = new System.Drawing.Size(284, 261);
            this.itemPanel.TabIndex = 35;
            // 
            // buttonh2u
            // 
            this.buttonh2u.AutoSize = true;
            this.buttonh2u.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonh2u.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonh2u.Font = new System.Drawing.Font("Consolas", 10F);
            this.buttonh2u.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonh2u.Location = new System.Drawing.Point(241, 16);
            this.buttonh2u.Name = "buttonh2u";
            this.buttonh2u.Size = new System.Drawing.Size(100, 29);
            this.buttonh2u.TabIndex = 161;
            this.buttonh2u.Text = "How To Use";
            this.buttonh2u.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox8.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox8.Location = new System.Drawing.Point(159, 23);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(68, 19);
            this.checkBox8.TabIndex = 160;
            this.checkBox8.Text = "Enable";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.Control;
            this.label17.Location = new System.Drawing.Point(156, 56);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(57, 13);
            this.label17.TabIndex = 159;
            this.label17.Text = "Status: Off";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.ForeColor = System.Drawing.SystemColors.Control;
            this.label52.Location = new System.Drawing.Point(251, 79);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(51, 13);
            this.label52.TabIndex = 158;
            this.label52.Text = "Inventory";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot27
            // 
            this.iSlot27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot27.Location = new System.Drawing.Point(432, 178);
            this.iSlot27.Name = "iSlot27";
            this.iSlot27.Size = new System.Drawing.Size(42, 39);
            this.iSlot27.TabIndex = 157;
            this.iSlot27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot26
            // 
            this.iSlot26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot26.Location = new System.Drawing.Point(391, 178);
            this.iSlot26.Name = "iSlot26";
            this.iSlot26.Size = new System.Drawing.Size(42, 39);
            this.iSlot26.TabIndex = 156;
            this.iSlot26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot25
            // 
            this.iSlot25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot25.Location = new System.Drawing.Point(350, 178);
            this.iSlot25.Name = "iSlot25";
            this.iSlot25.Size = new System.Drawing.Size(42, 39);
            this.iSlot25.TabIndex = 155;
            this.iSlot25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot24
            // 
            this.iSlot24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot24.Location = new System.Drawing.Point(309, 178);
            this.iSlot24.Name = "iSlot24";
            this.iSlot24.Size = new System.Drawing.Size(42, 39);
            this.iSlot24.TabIndex = 154;
            this.iSlot24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot23
            // 
            this.iSlot23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot23.Location = new System.Drawing.Point(268, 178);
            this.iSlot23.Name = "iSlot23";
            this.iSlot23.Size = new System.Drawing.Size(42, 39);
            this.iSlot23.TabIndex = 153;
            this.iSlot23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot22
            // 
            this.iSlot22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot22.Location = new System.Drawing.Point(227, 178);
            this.iSlot22.Name = "iSlot22";
            this.iSlot22.Size = new System.Drawing.Size(42, 39);
            this.iSlot22.TabIndex = 152;
            this.iSlot22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot21
            // 
            this.iSlot21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot21.Location = new System.Drawing.Point(186, 178);
            this.iSlot21.Name = "iSlot21";
            this.iSlot21.Size = new System.Drawing.Size(42, 39);
            this.iSlot21.TabIndex = 151;
            this.iSlot21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot20
            // 
            this.iSlot20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot20.Location = new System.Drawing.Point(145, 178);
            this.iSlot20.Name = "iSlot20";
            this.iSlot20.Size = new System.Drawing.Size(42, 39);
            this.iSlot20.TabIndex = 150;
            this.iSlot20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot19
            // 
            this.iSlot19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot19.Location = new System.Drawing.Point(104, 178);
            this.iSlot19.Name = "iSlot19";
            this.iSlot19.Size = new System.Drawing.Size(42, 39);
            this.iSlot19.TabIndex = 149;
            this.iSlot19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot18
            // 
            this.iSlot18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot18.Location = new System.Drawing.Point(432, 140);
            this.iSlot18.Name = "iSlot18";
            this.iSlot18.Size = new System.Drawing.Size(42, 39);
            this.iSlot18.TabIndex = 148;
            this.iSlot18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot17
            // 
            this.iSlot17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot17.Location = new System.Drawing.Point(391, 140);
            this.iSlot17.Name = "iSlot17";
            this.iSlot17.Size = new System.Drawing.Size(42, 39);
            this.iSlot17.TabIndex = 147;
            this.iSlot17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot16
            // 
            this.iSlot16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot16.Location = new System.Drawing.Point(350, 140);
            this.iSlot16.Name = "iSlot16";
            this.iSlot16.Size = new System.Drawing.Size(42, 39);
            this.iSlot16.TabIndex = 146;
            this.iSlot16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot15
            // 
            this.iSlot15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot15.Location = new System.Drawing.Point(309, 140);
            this.iSlot15.Name = "iSlot15";
            this.iSlot15.Size = new System.Drawing.Size(42, 39);
            this.iSlot15.TabIndex = 145;
            this.iSlot15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot14
            // 
            this.iSlot14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot14.Location = new System.Drawing.Point(268, 140);
            this.iSlot14.Name = "iSlot14";
            this.iSlot14.Size = new System.Drawing.Size(42, 39);
            this.iSlot14.TabIndex = 144;
            this.iSlot14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot13
            // 
            this.iSlot13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot13.Location = new System.Drawing.Point(227, 140);
            this.iSlot13.Name = "iSlot13";
            this.iSlot13.Size = new System.Drawing.Size(42, 39);
            this.iSlot13.TabIndex = 143;
            this.iSlot13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot12
            // 
            this.iSlot12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot12.Location = new System.Drawing.Point(186, 140);
            this.iSlot12.Name = "iSlot12";
            this.iSlot12.Size = new System.Drawing.Size(42, 39);
            this.iSlot12.TabIndex = 142;
            this.iSlot12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot11
            // 
            this.iSlot11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot11.Location = new System.Drawing.Point(145, 140);
            this.iSlot11.Name = "iSlot11";
            this.iSlot11.Size = new System.Drawing.Size(42, 39);
            this.iSlot11.TabIndex = 141;
            this.iSlot11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot10
            // 
            this.iSlot10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot10.Location = new System.Drawing.Point(104, 140);
            this.iSlot10.Name = "iSlot10";
            this.iSlot10.Size = new System.Drawing.Size(42, 39);
            this.iSlot10.TabIndex = 140;
            this.iSlot10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot9
            // 
            this.iSlot9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot9.Location = new System.Drawing.Point(432, 102);
            this.iSlot9.Name = "iSlot9";
            this.iSlot9.Size = new System.Drawing.Size(42, 39);
            this.iSlot9.TabIndex = 139;
            this.iSlot9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot8
            // 
            this.iSlot8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot8.Location = new System.Drawing.Point(391, 102);
            this.iSlot8.Name = "iSlot8";
            this.iSlot8.Size = new System.Drawing.Size(42, 39);
            this.iSlot8.TabIndex = 138;
            this.iSlot8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot7
            // 
            this.iSlot7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot7.Location = new System.Drawing.Point(350, 102);
            this.iSlot7.Name = "iSlot7";
            this.iSlot7.Size = new System.Drawing.Size(42, 39);
            this.iSlot7.TabIndex = 137;
            this.iSlot7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot6
            // 
            this.iSlot6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot6.Location = new System.Drawing.Point(309, 102);
            this.iSlot6.Name = "iSlot6";
            this.iSlot6.Size = new System.Drawing.Size(42, 39);
            this.iSlot6.TabIndex = 136;
            this.iSlot6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot5
            // 
            this.iSlot5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot5.Location = new System.Drawing.Point(268, 102);
            this.iSlot5.Name = "iSlot5";
            this.iSlot5.Size = new System.Drawing.Size(42, 39);
            this.iSlot5.TabIndex = 135;
            this.iSlot5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot4
            // 
            this.iSlot4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot4.Location = new System.Drawing.Point(227, 102);
            this.iSlot4.Name = "iSlot4";
            this.iSlot4.Size = new System.Drawing.Size(42, 39);
            this.iSlot4.TabIndex = 134;
            this.iSlot4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot3
            // 
            this.iSlot3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot3.Location = new System.Drawing.Point(186, 102);
            this.iSlot3.Name = "iSlot3";
            this.iSlot3.Size = new System.Drawing.Size(42, 39);
            this.iSlot3.TabIndex = 133;
            this.iSlot3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot2
            // 
            this.iSlot2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot2.Location = new System.Drawing.Point(145, 102);
            this.iSlot2.Name = "iSlot2";
            this.iSlot2.Size = new System.Drawing.Size(42, 39);
            this.iSlot2.TabIndex = 132;
            this.iSlot2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot1
            // 
            this.iSlot1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot1.Location = new System.Drawing.Point(104, 102);
            this.iSlot1.Name = "iSlot1";
            this.iSlot1.Size = new System.Drawing.Size(42, 39);
            this.iSlot1.TabIndex = 131;
            this.iSlot1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.SystemColors.Control;
            this.label25.Location = new System.Drawing.Point(68, 64);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(15, 78);
            this.label25.TabIndex = 129;
            this.label25.Text = "A\r\nr\r\nm\r\no\r\nu\r\nr";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.SystemColors.Control;
            this.label26.Location = new System.Drawing.Point(262, 230);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(43, 13);
            this.label26.TabIndex = 128;
            this.label26.Text = "Hot Bar";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hSlot9
            // 
            this.hSlot9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot9.Location = new System.Drawing.Point(432, 254);
            this.hSlot9.Name = "hSlot9";
            this.hSlot9.Size = new System.Drawing.Size(42, 39);
            this.hSlot9.TabIndex = 127;
            this.hSlot9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hSlot8
            // 
            this.hSlot8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot8.Location = new System.Drawing.Point(391, 254);
            this.hSlot8.Name = "hSlot8";
            this.hSlot8.Size = new System.Drawing.Size(42, 39);
            this.hSlot8.TabIndex = 126;
            this.hSlot8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hSlot7
            // 
            this.hSlot7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot7.Location = new System.Drawing.Point(350, 254);
            this.hSlot7.Name = "hSlot7";
            this.hSlot7.Size = new System.Drawing.Size(42, 39);
            this.hSlot7.TabIndex = 125;
            this.hSlot7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hSlot6
            // 
            this.hSlot6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot6.Location = new System.Drawing.Point(309, 254);
            this.hSlot6.Name = "hSlot6";
            this.hSlot6.Size = new System.Drawing.Size(42, 39);
            this.hSlot6.TabIndex = 124;
            this.hSlot6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hSlot5
            // 
            this.hSlot5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot5.Location = new System.Drawing.Point(268, 254);
            this.hSlot5.Name = "hSlot5";
            this.hSlot5.Size = new System.Drawing.Size(42, 39);
            this.hSlot5.TabIndex = 123;
            this.hSlot5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hSlot4
            // 
            this.hSlot4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot4.Location = new System.Drawing.Point(227, 254);
            this.hSlot4.Name = "hSlot4";
            this.hSlot4.Size = new System.Drawing.Size(42, 39);
            this.hSlot4.TabIndex = 122;
            this.hSlot4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hSlot3
            // 
            this.hSlot3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot3.Location = new System.Drawing.Point(186, 254);
            this.hSlot3.Name = "hSlot3";
            this.hSlot3.Size = new System.Drawing.Size(42, 39);
            this.hSlot3.TabIndex = 121;
            this.hSlot3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hSlot2
            // 
            this.hSlot2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot2.Location = new System.Drawing.Point(145, 254);
            this.hSlot2.Name = "hSlot2";
            this.hSlot2.Size = new System.Drawing.Size(42, 39);
            this.hSlot2.TabIndex = 120;
            this.hSlot2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hSlot1
            // 
            this.hSlot1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot1.Location = new System.Drawing.Point(104, 254);
            this.hSlot1.Name = "hSlot1";
            this.hSlot1.Size = new System.Drawing.Size(42, 39);
            this.hSlot1.TabIndex = 119;
            this.hSlot1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // oSlot1
            // 
            this.oSlot1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.oSlot1.Location = new System.Drawing.Point(22, 254);
            this.oSlot1.Name = "oSlot1";
            this.oSlot1.Size = new System.Drawing.Size(42, 39);
            this.oSlot1.TabIndex = 118;
            this.oSlot1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // aSlot4
            // 
            this.aSlot4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aSlot4.Location = new System.Drawing.Point(22, 64);
            this.aSlot4.Name = "aSlot4";
            this.aSlot4.Size = new System.Drawing.Size(42, 39);
            this.aSlot4.TabIndex = 117;
            this.aSlot4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // aSlot3
            // 
            this.aSlot3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aSlot3.Location = new System.Drawing.Point(22, 102);
            this.aSlot3.Name = "aSlot3";
            this.aSlot3.Size = new System.Drawing.Size(42, 39);
            this.aSlot3.TabIndex = 116;
            this.aSlot3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // aSlot1
            // 
            this.aSlot1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aSlot1.Location = new System.Drawing.Point(22, 178);
            this.aSlot1.Name = "aSlot1";
            this.aSlot1.Size = new System.Drawing.Size(42, 39);
            this.aSlot1.TabIndex = 115;
            this.aSlot1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // aSlot2
            // 
            this.aSlot2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aSlot2.Location = new System.Drawing.Point(22, 140);
            this.aSlot2.Name = "aSlot2";
            this.aSlot2.Size = new System.Drawing.Size(42, 39);
            this.aSlot2.TabIndex = 114;
            this.aSlot2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.SystemColors.Control;
            this.label27.Location = new System.Drawing.Point(23, 219);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(36, 26);
            this.label27.TabIndex = 130;
            this.label27.Text = "Off\r\n Hand";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tab5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.itemPanel);
            this.Name = "tab5";
            this.Text = "tab5";
            this.itemPanel.ResumeLayout(false);
            this.itemPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel itemPanel;
        private System.Windows.Forms.Button buttonh2u;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label iSlot27;
        private System.Windows.Forms.Label iSlot26;
        private System.Windows.Forms.Label iSlot25;
        private System.Windows.Forms.Label iSlot24;
        private System.Windows.Forms.Label iSlot23;
        private System.Windows.Forms.Label iSlot22;
        private System.Windows.Forms.Label iSlot21;
        private System.Windows.Forms.Label iSlot20;
        private System.Windows.Forms.Label iSlot19;
        private System.Windows.Forms.Label iSlot18;
        private System.Windows.Forms.Label iSlot17;
        private System.Windows.Forms.Label iSlot16;
        private System.Windows.Forms.Label iSlot15;
        private System.Windows.Forms.Label iSlot14;
        private System.Windows.Forms.Label iSlot13;
        private System.Windows.Forms.Label iSlot12;
        private System.Windows.Forms.Label iSlot11;
        private System.Windows.Forms.Label iSlot10;
        private System.Windows.Forms.Label iSlot9;
        private System.Windows.Forms.Label iSlot8;
        private System.Windows.Forms.Label iSlot7;
        private System.Windows.Forms.Label iSlot6;
        private System.Windows.Forms.Label iSlot5;
        private System.Windows.Forms.Label iSlot4;
        private System.Windows.Forms.Label iSlot3;
        private System.Windows.Forms.Label iSlot2;
        private System.Windows.Forms.Label iSlot1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label hSlot9;
        private System.Windows.Forms.Label hSlot8;
        private System.Windows.Forms.Label hSlot7;
        private System.Windows.Forms.Label hSlot6;
        private System.Windows.Forms.Label hSlot5;
        private System.Windows.Forms.Label hSlot4;
        private System.Windows.Forms.Label hSlot3;
        private System.Windows.Forms.Label hSlot2;
        private System.Windows.Forms.Label hSlot1;
        private System.Windows.Forms.Label oSlot1;
        private System.Windows.Forms.Label aSlot4;
        private System.Windows.Forms.Label aSlot3;
        private System.Windows.Forms.Label aSlot1;
        private System.Windows.Forms.Label aSlot2;
        private System.Windows.Forms.Label label27;
    }
}