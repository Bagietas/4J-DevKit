﻿namespace mcV4.Tabs
{
    partial class tab1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.autoBuildStructurePanel = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.progressBarPanel = new System.Windows.Forms.Panel();
            this.progressBarVal = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.autoBuildStructurePanel.SuspendLayout();
            this.progressBarPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // autoBuildStructurePanel
            // 
            this.autoBuildStructurePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.autoBuildStructurePanel.Controls.Add(this.label7);
            this.autoBuildStructurePanel.Controls.Add(this.progressBarPanel);
            this.autoBuildStructurePanel.Controls.Add(this.button5);
            this.autoBuildStructurePanel.Controls.Add(this.label9);
            this.autoBuildStructurePanel.Controls.Add(this.checkBox3);
            this.autoBuildStructurePanel.Controls.Add(this.numericUpDown2);
            this.autoBuildStructurePanel.Controls.Add(this.numericUpDown1);
            this.autoBuildStructurePanel.Controls.Add(this.label8);
            this.autoBuildStructurePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.autoBuildStructurePanel.Location = new System.Drawing.Point(0, 0);
            this.autoBuildStructurePanel.Name = "autoBuildStructurePanel";
            this.autoBuildStructurePanel.Size = new System.Drawing.Size(284, 261);
            this.autoBuildStructurePanel.TabIndex = 23;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(34, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 15);
            this.label7.TabIndex = 15;
            this.label7.Text = "Size:";
            // 
            // progressBarPanel
            // 
            this.progressBarPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.progressBarPanel.Controls.Add(this.progressBarVal);
            this.progressBarPanel.Location = new System.Drawing.Point(23, 123);
            this.progressBarPanel.Name = "progressBarPanel";
            this.progressBarPanel.Size = new System.Drawing.Size(277, 19);
            this.progressBarPanel.TabIndex = 21;
            // 
            // progressBarVal
            // 
            this.progressBarVal.BackColor = System.Drawing.Color.Green;
            this.progressBarVal.Dock = System.Windows.Forms.DockStyle.Left;
            this.progressBarVal.Location = new System.Drawing.Point(0, 0);
            this.progressBarVal.Name = "progressBarVal";
            this.progressBarVal.Size = new System.Drawing.Size(0, 17);
            this.progressBarVal.TabIndex = 22;
            // 
            // button5
            // 
            this.button5.AutoSize = true;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button5.ForeColor = System.Drawing.SystemColors.Control;
            this.button5.Location = new System.Drawing.Point(211, 54);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(89, 27);
            this.button5.TabIndex = 6;
            this.button5.Text = "How To Use";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(24, 105);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(276, 15);
            this.label9.TabIndex = 20;
            this.label9.Text = "Status: Inactive";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox3.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox3.Location = new System.Drawing.Point(211, 22);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(89, 19);
            this.checkBox3.TabIndex = 16;
            this.checkBox3.Text = "Use Build";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.numericUpDown2.ForeColor = System.Drawing.SystemColors.Control;
            this.numericUpDown2.Location = new System.Drawing.Point(82, 58);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(60, 20);
            this.numericUpDown2.TabIndex = 19;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.numericUpDown1.ForeColor = System.Drawing.SystemColors.Control;
            this.numericUpDown1.Location = new System.Drawing.Point(82, 21);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(60, 20);
            this.numericUpDown1.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(20, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 15);
            this.label8.TabIndex = 18;
            this.label8.Text = "Height:";
            // 
            // tab1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.autoBuildStructurePanel);
            this.Name = "tab1";
            this.Text = "tab1";
            this.autoBuildStructurePanel.ResumeLayout(false);
            this.autoBuildStructurePanel.PerformLayout();
            this.progressBarPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel autoBuildStructurePanel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel progressBarPanel;
        private System.Windows.Forms.Panel progressBarVal;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label8;
    }
}