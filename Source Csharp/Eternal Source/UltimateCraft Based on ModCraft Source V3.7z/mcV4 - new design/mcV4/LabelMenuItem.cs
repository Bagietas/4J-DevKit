﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;
namespace mcV4
{
    public class LabelMenuItem : ToolStripControlHost
    {
        private Label label;

        public LabelMenuItem()
            : base(new Label())
        {
            this.label = this.Control as Label;
        }
    }
}
