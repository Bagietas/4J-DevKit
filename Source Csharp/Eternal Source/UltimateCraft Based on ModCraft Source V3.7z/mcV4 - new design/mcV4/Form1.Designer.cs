﻿namespace mcV4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.sub1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.connectionBtn = new System.Windows.Forms.Button();
            this.connectionPanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.xxxxxxxxxxxxx = new System.Windows.Forms.RichTextBox();
            this.xxxxxxxxxxxx = new System.Windows.Forms.RichTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.xxxxx = new System.Windows.Forms.RichTextBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.button7 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.ultL = new System.Windows.Forms.RichTextBox();
            this.mcL = new System.Windows.Forms.RichTextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.modMenuBtn = new System.Windows.Forms.Button();
            this.settingsBtn = new System.Windows.Forms.Button();
            this.gameManagerBtn = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.gameManagerPanel = new System.Windows.Forms.Panel();
            this.itemPanel = new System.Windows.Forms.Panel();
            this.buttonh2u = new System.Windows.Forms.Button();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.iSlot27 = new System.Windows.Forms.Label();
            this.iSlot26 = new System.Windows.Forms.Label();
            this.iSlot25 = new System.Windows.Forms.Label();
            this.iSlot24 = new System.Windows.Forms.Label();
            this.iSlot23 = new System.Windows.Forms.Label();
            this.iSlot22 = new System.Windows.Forms.Label();
            this.iSlot21 = new System.Windows.Forms.Label();
            this.iSlot20 = new System.Windows.Forms.Label();
            this.iSlot19 = new System.Windows.Forms.Label();
            this.iSlot18 = new System.Windows.Forms.Label();
            this.iSlot17 = new System.Windows.Forms.Label();
            this.iSlot16 = new System.Windows.Forms.Label();
            this.iSlot15 = new System.Windows.Forms.Label();
            this.iSlot14 = new System.Windows.Forms.Label();
            this.iSlot13 = new System.Windows.Forms.Label();
            this.iSlot12 = new System.Windows.Forms.Label();
            this.iSlot11 = new System.Windows.Forms.Label();
            this.iSlot10 = new System.Windows.Forms.Label();
            this.iSlot9 = new System.Windows.Forms.Label();
            this.iSlot8 = new System.Windows.Forms.Label();
            this.iSlot7 = new System.Windows.Forms.Label();
            this.iSlot6 = new System.Windows.Forms.Label();
            this.iSlot5 = new System.Windows.Forms.Label();
            this.iSlot4 = new System.Windows.Forms.Label();
            this.iSlot3 = new System.Windows.Forms.Label();
            this.iSlot2 = new System.Windows.Forms.Label();
            this.iSlot1 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.hSlot9 = new System.Windows.Forms.Label();
            this.hSlot8 = new System.Windows.Forms.Label();
            this.hSlot7 = new System.Windows.Forms.Label();
            this.hSlot6 = new System.Windows.Forms.Label();
            this.hSlot5 = new System.Windows.Forms.Label();
            this.hSlot4 = new System.Windows.Forms.Label();
            this.hSlot3 = new System.Windows.Forms.Label();
            this.hSlot2 = new System.Windows.Forms.Label();
            this.hSlot1 = new System.Windows.Forms.Label();
            this.oSlot1 = new System.Windows.Forms.Label();
            this.aSlot4 = new System.Windows.Forms.Label();
            this.aSlot3 = new System.Windows.Forms.Label();
            this.aSlot1 = new System.Windows.Forms.Label();
            this.aSlot2 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.posPanel = new System.Windows.Forms.Panel();
            this.button15 = new System.Windows.Forms.Button();
            this.buttonclear = new System.Windows.Forms.Button();
            this.buttonsave = new System.Windows.Forms.Button();
            this.buttonlist = new System.Windows.Forms.Button();
            this.buttoncur = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.contextMenuStrip4 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripMenuItem();
            this.removePositionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.buttonP = new System.Windows.Forms.Button();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnM1 = new System.Windows.Forms.Button();
            this.btnM4 = new System.Windows.Forms.Button();
            this.btnM3 = new System.Windows.Forms.Button();
            this.btnM5 = new System.Windows.Forms.Button();
            this.btnM2 = new System.Windows.Forms.Button();
            this.btnBindsPanel = new System.Windows.Forms.Panel();
            this.button24 = new System.Windows.Forms.Button();
            this.buttonR = new System.Windows.Forms.Button();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.hostOptsPanel = new System.Windows.Forms.Panel();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.xxxxxxxxxx = new System.Windows.Forms.TextBox();
            this.xxxxxxxxxxx = new System.Windows.Forms.TextBox();
            this.xxxxxxxxxxxxxx = new System.Windows.Forms.TextBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.buttonuse = new System.Windows.Forms.Button();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button18 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.autoBuildStructurePanel = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.progressBarPanel = new System.Windows.Forms.Panel();
            this.progressBarVal = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox5 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.modMenuPanel = new System.Windows.Forms.Panel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.xxxxxxxxxxxxxxxxxx = new System.Windows.Forms.TextBox();
            this.xxxxxxxxxxxxxxxxx = new System.Windows.Forms.TextBox();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.settingsPanel = new System.Windows.Forms.Panel();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button25 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.xxxx = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.modsTimer = new System.Windows.Forms.Timer(this.components);
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox2 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox4 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox3 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox7 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker3 = new System.ComponentModel.BackgroundWorker();
            this.timer7 = new System.Windows.Forms.Timer(this.components);
            this.saveIMC = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox8 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem21 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox9 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem22 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem23 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox10 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem24 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox11 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem26 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem27 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox12 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundWorker4 = new System.ComponentModel.BackgroundWorker();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.connectionPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.gameManagerPanel.SuspendLayout();
            this.itemPanel.SuspendLayout();
            this.posPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.btnBindsPanel.SuspendLayout();
            this.hostOptsPanel.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.autoBuildStructurePanel.SuspendLayout();
            this.progressBarPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.modMenuPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.settingsPanel.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.contextMenuStrip3.SuspendLayout();
            this.saveIMC.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(90, 29);
            this.panel1.TabIndex = 0;
            this.panel1.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(5, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Game Mods";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sub1
            // 
            this.sub1.AllowDrop = true;
            this.sub1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.sub1.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sub1.Name = "sub1";
            this.sub1.ShowImageMargin = false;
            this.sub1.ShowItemToolTips = false;
            this.sub1.Size = new System.Drawing.Size(36, 4);
            this.sub1.Closed += new System.Windows.Forms.ToolStripDropDownClosedEventHandler(this.sub1_Closed);
            this.sub1.Opened += new System.EventHandler(this.sub1_Opened);
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 200;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(564, 36);
            this.panel2.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Consolas", 14F);
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(519, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(43, 34);
            this.button1.TabIndex = 10;
            this.button1.Text = "✖️";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.Control;
            this.button2.Location = new System.Drawing.Point(477, 1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(43, 34);
            this.button2.TabIndex = 4;
            this.button2.Text = "_";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Consolas", 14F);
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(564, 36);
            this.label2.TabIndex = 3;
            this.label2.Text = "UltimateCraft Tool";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label2_MouseDown);
            this.label2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label2_MouseMove);
            // 
            // connectionBtn
            // 
            this.connectionBtn.AutoSize = true;
            this.connectionBtn.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.connectionBtn.FlatAppearance.BorderSize = 0;
            this.connectionBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.connectionBtn.Font = new System.Drawing.Font("Consolas", 10F);
            this.connectionBtn.ForeColor = System.Drawing.SystemColors.Control;
            this.connectionBtn.Location = new System.Drawing.Point(91, 0);
            this.connectionBtn.Name = "connectionBtn";
            this.connectionBtn.Size = new System.Drawing.Size(100, 30);
            this.connectionBtn.TabIndex = 4;
            this.connectionBtn.Text = "Connection";
            this.connectionBtn.UseVisualStyleBackColor = true;
            this.connectionBtn.Click += new System.EventHandler(this.button3_Click);
            // 
            // connectionPanel
            // 
            this.connectionPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.connectionPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.connectionPanel.Controls.Add(this.pictureBox1);
            this.connectionPanel.Controls.Add(this.groupBox3);
            this.connectionPanel.Controls.Add(this.groupBox2);
            this.connectionPanel.Enabled = false;
            this.connectionPanel.Location = new System.Drawing.Point(477, 407);
            this.connectionPanel.Name = "connectionPanel";
            this.connectionPanel.Size = new System.Drawing.Size(47, 38);
            this.connectionPanel.TabIndex = 4;
            this.connectionPanel.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(268, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(258, 170);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.xxxxxxxxxxxxx);
            this.groupBox3.Controls.Add(this.xxxxxxxxxxxx);
            this.groupBox3.Font = new System.Drawing.Font("Consolas", 10F);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox3.Location = new System.Drawing.Point(249, 181);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(292, 84);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Connection Information";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label6.Location = new System.Drawing.Point(12, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(140, 45);
            this.label6.TabIndex = 14;
            this.label6.Text = " PS3 Connect: False\r\n Game Attach: False\r\nSelected API: None";
            // 
            // xxxxxxxxxxxxx
            // 
            this.xxxxxxxxxxxxx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.xxxxxxxxxxxxx.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.xxxxxxxxxxxxx.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.xxxxxxxxxxxxx.Location = new System.Drawing.Point(392, 218);
            this.xxxxxxxxxxxxx.Name = "xxxxxxxxxxxxx";
            this.xxxxxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxxxxx.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.xxxxxxxxxxxxx.Size = new System.Drawing.Size(40, 32);
            this.xxxxxxxxxxxxx.TabIndex = 11;
            this.xxxxxxxxxxxxx.Text = resources.GetString("xxxxxxxxxxxxx.Text");
            this.xxxxxxxxxxxxx.WordWrap = false;
            // 
            // xxxxxxxxxxxx
            // 
            this.xxxxxxxxxxxx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.xxxxxxxxxxxx.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.xxxxxxxxxxxx.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.xxxxxxxxxxxx.Location = new System.Drawing.Point(402, 362);
            this.xxxxxxxxxxxx.Name = "xxxxxxxxxxxx";
            this.xxxxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxxxx.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.xxxxxxxxxxxx.Size = new System.Drawing.Size(39, 32);
            this.xxxxxxxxxxxx.TabIndex = 10;
            this.xxxxxxxxxxxx.Text = resources.GetString("xxxxxxxxxxxx.Text");
            this.xxxxxxxxxxxx.WordWrap = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.xxxxx);
            this.groupBox2.Controls.Add(this.radioButton3);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.checkBox2);
            this.groupBox2.Controls.Add(this.button7);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Font = new System.Drawing.Font("Consolas", 10F);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Location = new System.Drawing.Point(20, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(223, 253);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Game Connection";
            // 
            // xxxxx
            // 
            this.xxxxx.Location = new System.Drawing.Point(462, 552);
            this.xxxxx.Name = "xxxxx";
            this.xxxxx.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.xxxxx.Size = new System.Drawing.Size(37, 18);
            this.xxxxx.TabIndex = 17;
            this.xxxxx.Text = resources.GetString("xxxxx.Text");
            this.xxxxx.WordWrap = false;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.radioButton3.Location = new System.Drawing.Point(159, 27);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(46, 19);
            this.radioButton3.TabIndex = 16;
            this.radioButton3.Text = "HEN";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.ForeColor = System.Drawing.SystemColors.Control;
            this.textBox3.Location = new System.Drawing.Point(13, 195);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(145, 23);
            this.textBox3.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label5.Location = new System.Drawing.Point(10, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "Enter PS3 IP:";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox2.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox2.Location = new System.Drawing.Point(13, 224);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(145, 19);
            this.checkBox2.TabIndex = 13;
            this.checkBox2.Text = "Use webMan Notify";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // button7
            // 
            this.button7.AutoSize = true;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button7.ForeColor = System.Drawing.SystemColors.Control;
            this.button7.Location = new System.Drawing.Point(20, 137);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(185, 27);
            this.button7.TabIndex = 7;
            this.button7.Text = "Change API Info";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label3.Location = new System.Drawing.Point(17, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 30);
            this.label3.TabIndex = 11;
            this.label3.Text = "Target Number: N/A\r\nPS3 IP: N/A";
            // 
            // button6
            // 
            this.button6.AutoSize = true;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button6.ForeColor = System.Drawing.SystemColors.Control;
            this.button6.Location = new System.Drawing.Point(20, 58);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(185, 27);
            this.button6.TabIndex = 3;
            this.button6.Text = "Connect";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.radioButton2.Location = new System.Drawing.Point(90, 27);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(60, 19);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "CCAPI";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.radioButton1.Location = new System.Drawing.Point(20, 27);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(60, 19);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "TMAPI";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // ultL
            // 
            this.ultL.Location = new System.Drawing.Point(422, 582);
            this.ultL.Name = "ultL";
            this.ultL.ReadOnly = true;
            this.ultL.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.ultL.Size = new System.Drawing.Size(36, 40);
            this.ultL.TabIndex = 19;
            this.ultL.Text = resources.GetString("ultL.Text");
            this.ultL.WordWrap = false;
            // 
            // mcL
            // 
            this.mcL.Location = new System.Drawing.Point(352, 525);
            this.mcL.Name = "mcL";
            this.mcL.ReadOnly = true;
            this.mcL.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.mcL.Size = new System.Drawing.Size(44, 40);
            this.mcL.TabIndex = 18;
            this.mcL.Text = resources.GetString("mcL.Text");
            this.mcL.WordWrap = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.modMenuBtn);
            this.panel3.Controls.Add(this.settingsBtn);
            this.panel3.Controls.Add(this.gameManagerBtn);
            this.panel3.Controls.Add(this.connectionBtn);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 36);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(564, 32);
            this.panel3.TabIndex = 5;
            // 
            // modMenuBtn
            // 
            this.modMenuBtn.AutoSize = true;
            this.modMenuBtn.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.modMenuBtn.FlatAppearance.BorderSize = 0;
            this.modMenuBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.modMenuBtn.Font = new System.Drawing.Font("Consolas", 10F);
            this.modMenuBtn.ForeColor = System.Drawing.SystemColors.Control;
            this.modMenuBtn.Location = new System.Drawing.Point(321, 0);
            this.modMenuBtn.Name = "modMenuBtn";
            this.modMenuBtn.Size = new System.Drawing.Size(82, 30);
            this.modMenuBtn.TabIndex = 9;
            this.modMenuBtn.Text = "Mod Menu";
            this.modMenuBtn.UseVisualStyleBackColor = true;
            this.modMenuBtn.Click += new System.EventHandler(this.button4_Click);
            // 
            // settingsBtn
            // 
            this.settingsBtn.AutoSize = true;
            this.settingsBtn.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.settingsBtn.FlatAppearance.BorderSize = 0;
            this.settingsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.settingsBtn.Font = new System.Drawing.Font("Consolas", 10F);
            this.settingsBtn.ForeColor = System.Drawing.SystemColors.Control;
            this.settingsBtn.Location = new System.Drawing.Point(405, 0);
            this.settingsBtn.Name = "settingsBtn";
            this.settingsBtn.Size = new System.Drawing.Size(82, 30);
            this.settingsBtn.TabIndex = 8;
            this.settingsBtn.Text = "Settings";
            this.settingsBtn.UseVisualStyleBackColor = true;
            this.settingsBtn.Click += new System.EventHandler(this.settingsBtn_Click);
            // 
            // gameManagerBtn
            // 
            this.gameManagerBtn.AutoSize = true;
            this.gameManagerBtn.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.gameManagerBtn.FlatAppearance.BorderSize = 0;
            this.gameManagerBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gameManagerBtn.Font = new System.Drawing.Font("Consolas", 10F);
            this.gameManagerBtn.ForeColor = System.Drawing.SystemColors.Control;
            this.gameManagerBtn.Location = new System.Drawing.Point(191, 0);
            this.gameManagerBtn.Name = "gameManagerBtn";
            this.gameManagerBtn.Size = new System.Drawing.Size(129, 30);
            this.gameManagerBtn.TabIndex = 5;
            this.gameManagerBtn.Text = "Game Managers";
            this.gameManagerBtn.UseVisualStyleBackColor = true;
            this.gameManagerBtn.Click += new System.EventHandler(this.button8_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.panel5.Location = new System.Drawing.Point(690, 74);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(85, 24);
            this.panel5.TabIndex = 6;
            this.panel5.Visible = false;
            // 
            // gameManagerPanel
            // 
            this.gameManagerPanel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gameManagerPanel.Controls.Add(this.itemPanel);
            this.gameManagerPanel.Controls.Add(this.posPanel);
            this.gameManagerPanel.Controls.Add(this.panel4);
            this.gameManagerPanel.Controls.Add(this.btnBindsPanel);
            this.gameManagerPanel.Controls.Add(this.hostOptsPanel);
            this.gameManagerPanel.Controls.Add(this.autoBuildStructurePanel);
            this.gameManagerPanel.Location = new System.Drawing.Point(92, 407);
            this.gameManagerPanel.Name = "gameManagerPanel";
            this.gameManagerPanel.Size = new System.Drawing.Size(43, 36);
            this.gameManagerPanel.TabIndex = 7;
            this.gameManagerPanel.Visible = false;
            // 
            // itemPanel
            // 
            this.itemPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.itemPanel.Controls.Add(this.buttonh2u);
            this.itemPanel.Controls.Add(this.checkBox8);
            this.itemPanel.Controls.Add(this.label17);
            this.itemPanel.Controls.Add(this.label52);
            this.itemPanel.Controls.Add(this.iSlot27);
            this.itemPanel.Controls.Add(this.iSlot26);
            this.itemPanel.Controls.Add(this.iSlot25);
            this.itemPanel.Controls.Add(this.iSlot24);
            this.itemPanel.Controls.Add(this.iSlot23);
            this.itemPanel.Controls.Add(this.iSlot22);
            this.itemPanel.Controls.Add(this.iSlot21);
            this.itemPanel.Controls.Add(this.iSlot20);
            this.itemPanel.Controls.Add(this.iSlot19);
            this.itemPanel.Controls.Add(this.iSlot18);
            this.itemPanel.Controls.Add(this.iSlot17);
            this.itemPanel.Controls.Add(this.iSlot16);
            this.itemPanel.Controls.Add(this.iSlot15);
            this.itemPanel.Controls.Add(this.iSlot14);
            this.itemPanel.Controls.Add(this.iSlot13);
            this.itemPanel.Controls.Add(this.iSlot12);
            this.itemPanel.Controls.Add(this.iSlot11);
            this.itemPanel.Controls.Add(this.iSlot10);
            this.itemPanel.Controls.Add(this.iSlot9);
            this.itemPanel.Controls.Add(this.iSlot8);
            this.itemPanel.Controls.Add(this.iSlot7);
            this.itemPanel.Controls.Add(this.iSlot6);
            this.itemPanel.Controls.Add(this.iSlot5);
            this.itemPanel.Controls.Add(this.iSlot4);
            this.itemPanel.Controls.Add(this.iSlot3);
            this.itemPanel.Controls.Add(this.iSlot2);
            this.itemPanel.Controls.Add(this.iSlot1);
            this.itemPanel.Controls.Add(this.label25);
            this.itemPanel.Controls.Add(this.label26);
            this.itemPanel.Controls.Add(this.hSlot9);
            this.itemPanel.Controls.Add(this.hSlot8);
            this.itemPanel.Controls.Add(this.hSlot7);
            this.itemPanel.Controls.Add(this.hSlot6);
            this.itemPanel.Controls.Add(this.hSlot5);
            this.itemPanel.Controls.Add(this.hSlot4);
            this.itemPanel.Controls.Add(this.hSlot3);
            this.itemPanel.Controls.Add(this.hSlot2);
            this.itemPanel.Controls.Add(this.hSlot1);
            this.itemPanel.Controls.Add(this.oSlot1);
            this.itemPanel.Controls.Add(this.aSlot4);
            this.itemPanel.Controls.Add(this.aSlot3);
            this.itemPanel.Controls.Add(this.aSlot1);
            this.itemPanel.Controls.Add(this.aSlot2);
            this.itemPanel.Controls.Add(this.label27);
            this.itemPanel.Enabled = false;
            this.itemPanel.Location = new System.Drawing.Point(243, 322);
            this.itemPanel.Name = "itemPanel";
            this.itemPanel.Size = new System.Drawing.Size(38, 41);
            this.itemPanel.TabIndex = 34;
            this.itemPanel.Visible = false;
            // 
            // buttonh2u
            // 
            this.buttonh2u.AutoSize = true;
            this.buttonh2u.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonh2u.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonh2u.Font = new System.Drawing.Font("Consolas", 10F);
            this.buttonh2u.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonh2u.Location = new System.Drawing.Point(241, 16);
            this.buttonh2u.Name = "buttonh2u";
            this.buttonh2u.Size = new System.Drawing.Size(100, 29);
            this.buttonh2u.TabIndex = 161;
            this.buttonh2u.Text = "How To Use";
            this.buttonh2u.UseVisualStyleBackColor = true;
            this.buttonh2u.Click += new System.EventHandler(this.buttonh2u_Click);
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox8.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox8.Location = new System.Drawing.Point(159, 23);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(68, 19);
            this.checkBox8.TabIndex = 160;
            this.checkBox8.Text = "Enable";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.Control;
            this.label17.Location = new System.Drawing.Point(156, 56);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(84, 15);
            this.label17.TabIndex = 159;
            this.label17.Text = "Status: Off";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.ForeColor = System.Drawing.SystemColors.Control;
            this.label52.Location = new System.Drawing.Point(251, 79);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(70, 15);
            this.label52.TabIndex = 158;
            this.label52.Text = "Inventory";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // iSlot27
            // 
            this.iSlot27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot27.Location = new System.Drawing.Point(432, 178);
            this.iSlot27.Name = "iSlot27";
            this.iSlot27.Size = new System.Drawing.Size(42, 39);
            this.iSlot27.TabIndex = 157;
            this.iSlot27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot27.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot27_MouseClick);
            // 
            // iSlot26
            // 
            this.iSlot26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot26.Location = new System.Drawing.Point(391, 178);
            this.iSlot26.Name = "iSlot26";
            this.iSlot26.Size = new System.Drawing.Size(42, 39);
            this.iSlot26.TabIndex = 156;
            this.iSlot26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot26.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot26_MouseClick);
            // 
            // iSlot25
            // 
            this.iSlot25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot25.Location = new System.Drawing.Point(350, 178);
            this.iSlot25.Name = "iSlot25";
            this.iSlot25.Size = new System.Drawing.Size(42, 39);
            this.iSlot25.TabIndex = 155;
            this.iSlot25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot25.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot25_MouseClick);
            // 
            // iSlot24
            // 
            this.iSlot24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot24.Location = new System.Drawing.Point(309, 178);
            this.iSlot24.Name = "iSlot24";
            this.iSlot24.Size = new System.Drawing.Size(42, 39);
            this.iSlot24.TabIndex = 154;
            this.iSlot24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot24.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot24_MouseClick);
            // 
            // iSlot23
            // 
            this.iSlot23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot23.Location = new System.Drawing.Point(268, 178);
            this.iSlot23.Name = "iSlot23";
            this.iSlot23.Size = new System.Drawing.Size(42, 39);
            this.iSlot23.TabIndex = 153;
            this.iSlot23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot23.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot23_MouseClick);
            // 
            // iSlot22
            // 
            this.iSlot22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot22.Location = new System.Drawing.Point(227, 178);
            this.iSlot22.Name = "iSlot22";
            this.iSlot22.Size = new System.Drawing.Size(42, 39);
            this.iSlot22.TabIndex = 152;
            this.iSlot22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot22.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot22_MouseClick);
            // 
            // iSlot21
            // 
            this.iSlot21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot21.Location = new System.Drawing.Point(186, 178);
            this.iSlot21.Name = "iSlot21";
            this.iSlot21.Size = new System.Drawing.Size(42, 39);
            this.iSlot21.TabIndex = 151;
            this.iSlot21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot21.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot21_MouseClick);
            // 
            // iSlot20
            // 
            this.iSlot20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot20.Location = new System.Drawing.Point(145, 178);
            this.iSlot20.Name = "iSlot20";
            this.iSlot20.Size = new System.Drawing.Size(42, 39);
            this.iSlot20.TabIndex = 150;
            this.iSlot20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot20.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot20_MouseClick);
            // 
            // iSlot19
            // 
            this.iSlot19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot19.Location = new System.Drawing.Point(104, 178);
            this.iSlot19.Name = "iSlot19";
            this.iSlot19.Size = new System.Drawing.Size(42, 39);
            this.iSlot19.TabIndex = 149;
            this.iSlot19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot19.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot19_MouseClick);
            // 
            // iSlot18
            // 
            this.iSlot18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot18.Location = new System.Drawing.Point(432, 140);
            this.iSlot18.Name = "iSlot18";
            this.iSlot18.Size = new System.Drawing.Size(42, 39);
            this.iSlot18.TabIndex = 148;
            this.iSlot18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot18.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot18_MouseClick);
            // 
            // iSlot17
            // 
            this.iSlot17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot17.Location = new System.Drawing.Point(391, 140);
            this.iSlot17.Name = "iSlot17";
            this.iSlot17.Size = new System.Drawing.Size(42, 39);
            this.iSlot17.TabIndex = 147;
            this.iSlot17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot17.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot17_MouseClick);
            // 
            // iSlot16
            // 
            this.iSlot16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot16.Location = new System.Drawing.Point(350, 140);
            this.iSlot16.Name = "iSlot16";
            this.iSlot16.Size = new System.Drawing.Size(42, 39);
            this.iSlot16.TabIndex = 146;
            this.iSlot16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot16.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot16_MouseClick);
            // 
            // iSlot15
            // 
            this.iSlot15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot15.Location = new System.Drawing.Point(309, 140);
            this.iSlot15.Name = "iSlot15";
            this.iSlot15.Size = new System.Drawing.Size(42, 39);
            this.iSlot15.TabIndex = 145;
            this.iSlot15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot15.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot15_MouseClick);
            // 
            // iSlot14
            // 
            this.iSlot14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot14.Location = new System.Drawing.Point(268, 140);
            this.iSlot14.Name = "iSlot14";
            this.iSlot14.Size = new System.Drawing.Size(42, 39);
            this.iSlot14.TabIndex = 144;
            this.iSlot14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot14.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot14_MouseClick);
            // 
            // iSlot13
            // 
            this.iSlot13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot13.Location = new System.Drawing.Point(227, 140);
            this.iSlot13.Name = "iSlot13";
            this.iSlot13.Size = new System.Drawing.Size(42, 39);
            this.iSlot13.TabIndex = 143;
            this.iSlot13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot13.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot13_MouseClick);
            // 
            // iSlot12
            // 
            this.iSlot12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot12.Location = new System.Drawing.Point(186, 140);
            this.iSlot12.Name = "iSlot12";
            this.iSlot12.Size = new System.Drawing.Size(42, 39);
            this.iSlot12.TabIndex = 142;
            this.iSlot12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot12.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot12_MouseClick);
            // 
            // iSlot11
            // 
            this.iSlot11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot11.Location = new System.Drawing.Point(145, 140);
            this.iSlot11.Name = "iSlot11";
            this.iSlot11.Size = new System.Drawing.Size(42, 39);
            this.iSlot11.TabIndex = 141;
            this.iSlot11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot11.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot11_MouseClick);
            // 
            // iSlot10
            // 
            this.iSlot10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot10.Location = new System.Drawing.Point(104, 140);
            this.iSlot10.Name = "iSlot10";
            this.iSlot10.Size = new System.Drawing.Size(42, 39);
            this.iSlot10.TabIndex = 140;
            this.iSlot10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot10_MouseClick);
            // 
            // iSlot9
            // 
            this.iSlot9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot9.Location = new System.Drawing.Point(432, 102);
            this.iSlot9.Name = "iSlot9";
            this.iSlot9.Size = new System.Drawing.Size(42, 39);
            this.iSlot9.TabIndex = 139;
            this.iSlot9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot9_MouseClick);
            // 
            // iSlot8
            // 
            this.iSlot8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot8.Location = new System.Drawing.Point(391, 102);
            this.iSlot8.Name = "iSlot8";
            this.iSlot8.Size = new System.Drawing.Size(42, 39);
            this.iSlot8.TabIndex = 138;
            this.iSlot8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot8_MouseClick);
            // 
            // iSlot7
            // 
            this.iSlot7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot7.Location = new System.Drawing.Point(350, 102);
            this.iSlot7.Name = "iSlot7";
            this.iSlot7.Size = new System.Drawing.Size(42, 39);
            this.iSlot7.TabIndex = 137;
            this.iSlot7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot7_MouseClick);
            // 
            // iSlot6
            // 
            this.iSlot6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot6.Location = new System.Drawing.Point(309, 102);
            this.iSlot6.Name = "iSlot6";
            this.iSlot6.Size = new System.Drawing.Size(42, 39);
            this.iSlot6.TabIndex = 136;
            this.iSlot6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot6_MouseClick);
            // 
            // iSlot5
            // 
            this.iSlot5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot5.Location = new System.Drawing.Point(268, 102);
            this.iSlot5.Name = "iSlot5";
            this.iSlot5.Size = new System.Drawing.Size(42, 39);
            this.iSlot5.TabIndex = 135;
            this.iSlot5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot5_MouseClick);
            // 
            // iSlot4
            // 
            this.iSlot4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot4.Location = new System.Drawing.Point(227, 102);
            this.iSlot4.Name = "iSlot4";
            this.iSlot4.Size = new System.Drawing.Size(42, 39);
            this.iSlot4.TabIndex = 134;
            this.iSlot4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot4_MouseClick);
            // 
            // iSlot3
            // 
            this.iSlot3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot3.Location = new System.Drawing.Point(186, 102);
            this.iSlot3.Name = "iSlot3";
            this.iSlot3.Size = new System.Drawing.Size(42, 39);
            this.iSlot3.TabIndex = 133;
            this.iSlot3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot3_MouseClick);
            // 
            // iSlot2
            // 
            this.iSlot2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot2.Location = new System.Drawing.Point(145, 102);
            this.iSlot2.Name = "iSlot2";
            this.iSlot2.Size = new System.Drawing.Size(42, 39);
            this.iSlot2.TabIndex = 132;
            this.iSlot2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot2_MouseClick);
            // 
            // iSlot1
            // 
            this.iSlot1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.iSlot1.Location = new System.Drawing.Point(104, 102);
            this.iSlot1.Name = "iSlot1";
            this.iSlot1.Size = new System.Drawing.Size(42, 39);
            this.iSlot1.TabIndex = 131;
            this.iSlot1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.iSlot1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.iSlot1_MouseClick);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.SystemColors.Control;
            this.label25.Location = new System.Drawing.Point(68, 64);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(14, 90);
            this.label25.TabIndex = 129;
            this.label25.Text = "A\r\nr\r\nm\r\no\r\nu\r\nr";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.SystemColors.Control;
            this.label26.Location = new System.Drawing.Point(262, 230);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(56, 15);
            this.label26.TabIndex = 128;
            this.label26.Text = "Hot Bar";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hSlot9
            // 
            this.hSlot9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot9.Location = new System.Drawing.Point(432, 254);
            this.hSlot9.Name = "hSlot9";
            this.hSlot9.Size = new System.Drawing.Size(42, 39);
            this.hSlot9.TabIndex = 127;
            this.hSlot9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.hSlot9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hSlot9_MouseClick);
            // 
            // hSlot8
            // 
            this.hSlot8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot8.Location = new System.Drawing.Point(391, 254);
            this.hSlot8.Name = "hSlot8";
            this.hSlot8.Size = new System.Drawing.Size(42, 39);
            this.hSlot8.TabIndex = 126;
            this.hSlot8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.hSlot8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hSlot8_MouseClick);
            // 
            // hSlot7
            // 
            this.hSlot7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot7.Location = new System.Drawing.Point(350, 254);
            this.hSlot7.Name = "hSlot7";
            this.hSlot7.Size = new System.Drawing.Size(42, 39);
            this.hSlot7.TabIndex = 125;
            this.hSlot7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.hSlot7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hSlot7_MouseClick);
            // 
            // hSlot6
            // 
            this.hSlot6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot6.Location = new System.Drawing.Point(309, 254);
            this.hSlot6.Name = "hSlot6";
            this.hSlot6.Size = new System.Drawing.Size(42, 39);
            this.hSlot6.TabIndex = 124;
            this.hSlot6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.hSlot6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hSlot6_MouseClick);
            // 
            // hSlot5
            // 
            this.hSlot5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot5.Location = new System.Drawing.Point(268, 254);
            this.hSlot5.Name = "hSlot5";
            this.hSlot5.Size = new System.Drawing.Size(42, 39);
            this.hSlot5.TabIndex = 123;
            this.hSlot5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.hSlot5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hSlot5_MouseClick);
            // 
            // hSlot4
            // 
            this.hSlot4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot4.Location = new System.Drawing.Point(227, 254);
            this.hSlot4.Name = "hSlot4";
            this.hSlot4.Size = new System.Drawing.Size(42, 39);
            this.hSlot4.TabIndex = 122;
            this.hSlot4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.hSlot4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hSlot4_MouseClick);
            // 
            // hSlot3
            // 
            this.hSlot3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot3.Location = new System.Drawing.Point(186, 254);
            this.hSlot3.Name = "hSlot3";
            this.hSlot3.Size = new System.Drawing.Size(42, 39);
            this.hSlot3.TabIndex = 121;
            this.hSlot3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.hSlot3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hSlot3_MouseClick);
            // 
            // hSlot2
            // 
            this.hSlot2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot2.Location = new System.Drawing.Point(145, 254);
            this.hSlot2.Name = "hSlot2";
            this.hSlot2.Size = new System.Drawing.Size(42, 39);
            this.hSlot2.TabIndex = 120;
            this.hSlot2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.hSlot2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hSlot2_MouseClick);
            // 
            // hSlot1
            // 
            this.hSlot1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hSlot1.Location = new System.Drawing.Point(104, 254);
            this.hSlot1.Name = "hSlot1";
            this.hSlot1.Size = new System.Drawing.Size(42, 39);
            this.hSlot1.TabIndex = 119;
            this.hSlot1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.hSlot1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hSlot1_MouseClick);
            // 
            // oSlot1
            // 
            this.oSlot1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.oSlot1.Location = new System.Drawing.Point(22, 254);
            this.oSlot1.Name = "oSlot1";
            this.oSlot1.Size = new System.Drawing.Size(42, 39);
            this.oSlot1.TabIndex = 118;
            this.oSlot1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.oSlot1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.oSlot1_MouseClick);
            // 
            // aSlot4
            // 
            this.aSlot4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aSlot4.Location = new System.Drawing.Point(22, 64);
            this.aSlot4.Name = "aSlot4";
            this.aSlot4.Size = new System.Drawing.Size(42, 39);
            this.aSlot4.TabIndex = 117;
            this.aSlot4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.aSlot4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.aSlot4_MouseClick);
            // 
            // aSlot3
            // 
            this.aSlot3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aSlot3.Location = new System.Drawing.Point(22, 102);
            this.aSlot3.Name = "aSlot3";
            this.aSlot3.Size = new System.Drawing.Size(42, 39);
            this.aSlot3.TabIndex = 116;
            this.aSlot3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.aSlot3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.aSlot3_MouseClick);
            // 
            // aSlot1
            // 
            this.aSlot1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aSlot1.Location = new System.Drawing.Point(22, 178);
            this.aSlot1.Name = "aSlot1";
            this.aSlot1.Size = new System.Drawing.Size(42, 39);
            this.aSlot1.TabIndex = 115;
            this.aSlot1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.aSlot1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.aSlot1_MouseClick);
            // 
            // aSlot2
            // 
            this.aSlot2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aSlot2.Location = new System.Drawing.Point(22, 140);
            this.aSlot2.Name = "aSlot2";
            this.aSlot2.Size = new System.Drawing.Size(42, 39);
            this.aSlot2.TabIndex = 114;
            this.aSlot2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.aSlot2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.aSlot2_MouseClick);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.SystemColors.Control;
            this.label27.Location = new System.Drawing.Point(23, 219);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(42, 30);
            this.label27.TabIndex = 130;
            this.label27.Text = "Off\r\n Hand";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // posPanel
            // 
            this.posPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.posPanel.Controls.Add(this.button15);
            this.posPanel.Controls.Add(this.buttonclear);
            this.posPanel.Controls.Add(this.buttonsave);
            this.posPanel.Controls.Add(this.buttonlist);
            this.posPanel.Controls.Add(this.buttoncur);
            this.posPanel.Controls.Add(this.label16);
            this.posPanel.Controls.Add(this.label15);
            this.posPanel.Controls.Add(this.dataGridView1);
            this.posPanel.Controls.Add(this.textBox4);
            this.posPanel.Controls.Add(this.buttonP);
            this.posPanel.Controls.Add(this.checkBox7);
            this.posPanel.Enabled = false;
            this.posPanel.Location = new System.Drawing.Point(191, 329);
            this.posPanel.Name = "posPanel";
            this.posPanel.Size = new System.Drawing.Size(37, 38);
            this.posPanel.TabIndex = 33;
            this.posPanel.Visible = false;
            // 
            // button15
            // 
            this.button15.AutoSize = true;
            this.button15.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button15.ForeColor = System.Drawing.SystemColors.Control;
            this.button15.Location = new System.Drawing.Point(26, 222);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(139, 27);
            this.button15.TabIndex = 39;
            this.button15.Text = "Copy Position";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click_1);
            // 
            // buttonclear
            // 
            this.buttonclear.AutoSize = true;
            this.buttonclear.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonclear.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttonclear.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonclear.Location = new System.Drawing.Point(445, 255);
            this.buttonclear.Name = "buttonclear";
            this.buttonclear.Size = new System.Drawing.Size(89, 27);
            this.buttonclear.TabIndex = 38;
            this.buttonclear.Text = "Clear List";
            this.buttonclear.UseVisualStyleBackColor = true;
            this.buttonclear.Click += new System.EventHandler(this.buttonclear_Click);
            // 
            // buttonsave
            // 
            this.buttonsave.AutoSize = true;
            this.buttonsave.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonsave.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttonsave.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonsave.Location = new System.Drawing.Point(203, 255);
            this.buttonsave.Name = "buttonsave";
            this.buttonsave.Size = new System.Drawing.Size(89, 27);
            this.buttonsave.TabIndex = 37;
            this.buttonsave.Text = "Save List";
            this.buttonsave.UseVisualStyleBackColor = true;
            this.buttonsave.Click += new System.EventHandler(this.buttonsave_Click);
            // 
            // buttonlist
            // 
            this.buttonlist.AutoSize = true;
            this.buttonlist.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonlist.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttonlist.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonlist.Location = new System.Drawing.Point(324, 255);
            this.buttonlist.Name = "buttonlist";
            this.buttonlist.Size = new System.Drawing.Size(89, 27);
            this.buttonlist.TabIndex = 36;
            this.buttonlist.Text = "Load List";
            this.buttonlist.UseVisualStyleBackColor = true;
            this.buttonlist.Click += new System.EventHandler(this.buttonlist_Click);
            // 
            // buttoncur
            // 
            this.buttoncur.AutoSize = true;
            this.buttoncur.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttoncur.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttoncur.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttoncur.ForeColor = System.Drawing.SystemColors.Control;
            this.buttoncur.Location = new System.Drawing.Point(203, 222);
            this.buttoncur.Name = "buttoncur";
            this.buttoncur.Size = new System.Drawing.Size(331, 27);
            this.buttoncur.TabIndex = 34;
            this.buttoncur.Text = "Add Current Position To List";
            this.buttoncur.UseVisualStyleBackColor = true;
            this.buttoncur.Click += new System.EventHandler(this.buttoncur_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label16.ForeColor = System.Drawing.SystemColors.Control;
            this.label16.Location = new System.Drawing.Point(23, 13);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(126, 15);
            this.label16.TabIndex = 33;
            this.label16.Text = "Enter Coordinates";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label15.ForeColor = System.Drawing.SystemColors.Control;
            this.label15.Location = new System.Drawing.Point(23, 136);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 45);
            this.label15.TabIndex = 32;
            this.label15.Text = "X: N/A\r\nY: N.A\r\nZ: N/A";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Consolas", 8.75F);
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip4;
            this.dataGridView1.GridColor = System.Drawing.Color.Black;
            this.dataGridView1.Location = new System.Drawing.Point(203, 13);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Consolas", 8.75F);
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(331, 203);
            this.dataGridView1.TabIndex = 31;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Name";
            this.Column1.Name = "Column1";
            this.Column1.Width = 120;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Coordinates XYZ";
            this.Column2.Name = "Column2";
            this.Column2.Width = 140;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Set";
            this.Column3.Name = "Column3";
            this.Column3.Width = 50;
            // 
            // contextMenuStrip4
            // 
            this.contextMenuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem29,
            this.removePositionToolStripMenuItem});
            this.contextMenuStrip4.Name = "contextMenuStrip1";
            this.contextMenuStrip4.ShowImageMargin = false;
            this.contextMenuStrip4.ShowItemToolTips = false;
            this.contextMenuStrip4.Size = new System.Drawing.Size(129, 48);
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(128, 22);
            this.toolStripMenuItem29.Text = "Copy Position";
            this.toolStripMenuItem29.Click += new System.EventHandler(this.toolStripMenuItem29_Click);
            // 
            // removePositionToolStripMenuItem
            // 
            this.removePositionToolStripMenuItem.Name = "removePositionToolStripMenuItem";
            this.removePositionToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.removePositionToolStripMenuItem.Text = "Delete Position";
            this.removePositionToolStripMenuItem.Click += new System.EventHandler(this.removePositionToolStripMenuItem_Click);
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.ForeColor = System.Drawing.SystemColors.Control;
            this.textBox4.Location = new System.Drawing.Point(26, 31);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(139, 23);
            this.textBox4.TabIndex = 27;
            // 
            // buttonP
            // 
            this.buttonP.AutoSize = true;
            this.buttonP.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonP.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttonP.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonP.Location = new System.Drawing.Point(26, 59);
            this.buttonP.Name = "buttonP";
            this.buttonP.Size = new System.Drawing.Size(139, 27);
            this.buttonP.TabIndex = 26;
            this.buttonP.Text = "Set Position";
            this.buttonP.UseVisualStyleBackColor = true;
            this.buttonP.Click += new System.EventHandler(this.buttonP_Click);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox7.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox7.Location = new System.Drawing.Point(26, 197);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(138, 19);
            this.checkBox7.TabIndex = 25;
            this.checkBox7.Text = "Show Coordinates";
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.btnM1);
            this.panel4.Controls.Add(this.btnM4);
            this.panel4.Controls.Add(this.btnM3);
            this.panel4.Controls.Add(this.btnM5);
            this.panel4.Controls.Add(this.btnM2);
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(685, 35);
            this.panel4.TabIndex = 32;
            // 
            // btnM1
            // 
            this.btnM1.AutoSize = true;
            this.btnM1.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnM1.FlatAppearance.BorderSize = 0;
            this.btnM1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnM1.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.btnM1.ForeColor = System.Drawing.SystemColors.Control;
            this.btnM1.Location = new System.Drawing.Point(3, 1);
            this.btnM1.Name = "btnM1";
            this.btnM1.Size = new System.Drawing.Size(124, 30);
            this.btnM1.TabIndex = 23;
            this.btnM1.Text = "Build Structure";
            this.btnM1.UseVisualStyleBackColor = true;
            this.btnM1.Click += new System.EventHandler(this.button12_Click);
            // 
            // btnM4
            // 
            this.btnM4.AutoSize = true;
            this.btnM4.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnM4.FlatAppearance.BorderSize = 0;
            this.btnM4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnM4.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.btnM4.ForeColor = System.Drawing.SystemColors.Control;
            this.btnM4.Location = new System.Drawing.Point(333, 1);
            this.btnM4.Name = "btnM4";
            this.btnM4.Size = new System.Drawing.Size(122, 30);
            this.btnM4.TabIndex = 26;
            this.btnM4.Text = "Player Position";
            this.btnM4.UseVisualStyleBackColor = true;
            this.btnM4.Click += new System.EventHandler(this.button15_Click);
            // 
            // btnM3
            // 
            this.btnM3.AutoSize = true;
            this.btnM3.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnM3.FlatAppearance.BorderSize = 0;
            this.btnM3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnM3.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.btnM3.ForeColor = System.Drawing.SystemColors.Control;
            this.btnM3.Location = new System.Drawing.Point(230, 1);
            this.btnM3.Name = "btnM3";
            this.btnM3.Size = new System.Drawing.Size(101, 30);
            this.btnM3.TabIndex = 25;
            this.btnM3.Text = "Button Binds";
            this.btnM3.UseVisualStyleBackColor = true;
            this.btnM3.Click += new System.EventHandler(this.button14_Click);
            // 
            // btnM5
            // 
            this.btnM5.AutoSize = true;
            this.btnM5.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnM5.FlatAppearance.BorderSize = 0;
            this.btnM5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnM5.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.btnM5.ForeColor = System.Drawing.SystemColors.Control;
            this.btnM5.Location = new System.Drawing.Point(457, 1);
            this.btnM5.Name = "btnM5";
            this.btnM5.Size = new System.Drawing.Size(101, 30);
            this.btnM5.TabIndex = 27;
            this.btnM5.Text = "Item Control";
            this.btnM5.UseVisualStyleBackColor = true;
            this.btnM5.Click += new System.EventHandler(this.button16_Click);
            // 
            // btnM2
            // 
            this.btnM2.AutoSize = true;
            this.btnM2.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnM2.FlatAppearance.BorderSize = 0;
            this.btnM2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnM2.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.btnM2.ForeColor = System.Drawing.SystemColors.Control;
            this.btnM2.Location = new System.Drawing.Point(127, 1);
            this.btnM2.Name = "btnM2";
            this.btnM2.Size = new System.Drawing.Size(101, 30);
            this.btnM2.TabIndex = 24;
            this.btnM2.Text = "Self Options";
            this.btnM2.UseVisualStyleBackColor = true;
            this.btnM2.Click += new System.EventHandler(this.button13_Click);
            // 
            // btnBindsPanel
            // 
            this.btnBindsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnBindsPanel.Controls.Add(this.button24);
            this.btnBindsPanel.Controls.Add(this.buttonR);
            this.btnBindsPanel.Controls.Add(this.listBox3);
            this.btnBindsPanel.Controls.Add(this.label13);
            this.btnBindsPanel.Enabled = false;
            this.btnBindsPanel.Location = new System.Drawing.Point(132, 331);
            this.btnBindsPanel.Name = "btnBindsPanel";
            this.btnBindsPanel.Size = new System.Drawing.Size(39, 36);
            this.btnBindsPanel.TabIndex = 31;
            this.btnBindsPanel.Visible = false;
            // 
            // button24
            // 
            this.button24.AutoSize = true;
            this.button24.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button24.ForeColor = System.Drawing.SystemColors.Control;
            this.button24.Location = new System.Drawing.Point(23, 246);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(254, 27);
            this.button24.TabIndex = 20;
            this.button24.Text = "How To Use";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // buttonR
            // 
            this.buttonR.AutoSize = true;
            this.buttonR.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonR.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttonR.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonR.Location = new System.Drawing.Point(24, 213);
            this.buttonR.Name = "buttonR";
            this.buttonR.Size = new System.Drawing.Size(254, 27);
            this.buttonR.TabIndex = 19;
            this.buttonR.Text = "Remove Selected Bind";
            this.buttonR.UseVisualStyleBackColor = true;
            this.buttonR.Click += new System.EventHandler(this.buttonR_Click);
            // 
            // listBox3
            // 
            this.listBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.listBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.listBox3.ForeColor = System.Drawing.SystemColors.Control;
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 15;
            this.listBox3.Location = new System.Drawing.Point(24, 26);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(254, 182);
            this.listBox3.TabIndex = 18;
            this.listBox3.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listBox3_DrawItem);
            this.listBox3.SelectedIndexChanged += new System.EventHandler(this.listBox3_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label13.ForeColor = System.Drawing.SystemColors.Control;
            this.label13.Location = new System.Drawing.Point(114, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 15);
            this.label13.TabIndex = 17;
            this.label13.Text = "Bind List";
            // 
            // hostOptsPanel
            // 
            this.hostOptsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.hostOptsPanel.Controls.Add(this.groupBox8);
            this.hostOptsPanel.Controls.Add(this.groupBox7);
            this.hostOptsPanel.Enabled = false;
            this.hostOptsPanel.Location = new System.Drawing.Point(13, 333);
            this.hostOptsPanel.Name = "hostOptsPanel";
            this.hostOptsPanel.Size = new System.Drawing.Size(48, 30);
            this.hostOptsPanel.TabIndex = 30;
            this.hostOptsPanel.Visible = false;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.mcL);
            this.groupBox8.Controls.Add(this.ultL);
            this.groupBox8.Controls.Add(this.xxxxxxxxxx);
            this.groupBox8.Controls.Add(this.xxxxxxxxxxx);
            this.groupBox8.Controls.Add(this.xxxxxxxxxxxxxx);
            this.groupBox8.Controls.Add(this.checkBox6);
            this.groupBox8.Controls.Add(this.numericUpDown3);
            this.groupBox8.Controls.Add(this.label10);
            this.groupBox8.Controls.Add(this.checkBox4);
            this.groupBox8.Controls.Add(this.buttonuse);
            this.groupBox8.Controls.Add(this.checkBox5);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox8.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox8.Location = new System.Drawing.Point(13, 18);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(306, 141);
            this.groupBox8.TabIndex = 26;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Server Player - Host Only";
            // 
            // xxxxxxxxxx
            // 
            this.xxxxxxxxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxx.Location = new System.Drawing.Point(426, 84);
            this.xxxxxxxxxx.Name = "xxxxxxxxxx";
            this.xxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxxxxxxxx.TabIndex = 27;
            this.xxxxxxxxxx.Text = "11798247788415868458496190753235";
            // 
            // xxxxxxxxxxx
            // 
            this.xxxxxxxxxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxx.Location = new System.Drawing.Point(426, 84);
            this.xxxxxxxxxxx.Name = "xxxxxxxxxxx";
            this.xxxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxxxxxxxxx.TabIndex = 26;
            this.xxxxxxxxxxx.Text = "448590002658602";
            // 
            // xxxxxxxxxxxxxx
            // 
            this.xxxxxxxxxxxxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxx.Location = new System.Drawing.Point(426, 84);
            this.xxxxxxxxxxxxxx.Name = "xxxxxxxxxxxxxx";
            this.xxxxxxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxxxxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxxxxxxxxxxxx.TabIndex = 25;
            this.xxxxxxxxxxxxxx.Text = "865328593944257997423333425";
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox6.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox6.Location = new System.Drawing.Point(19, 22);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(68, 19);
            this.checkBox6.TabIndex = 24;
            this.checkBox6.Text = "Enable";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.numericUpDown3.ForeColor = System.Drawing.SystemColors.Control;
            this.numericUpDown3.Location = new System.Drawing.Point(187, 72);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(94, 23);
            this.numericUpDown3.TabIndex = 19;
            this.numericUpDown3.Value = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.numericUpDown3.ValueChanged += new System.EventHandler(this.numericUpDown3_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label10.ForeColor = System.Drawing.SystemColors.Control;
            this.label10.Location = new System.Drawing.Point(125, 74);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 15);
            this.label10.TabIndex = 18;
            this.label10.Text = "RTM XP:";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox4.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox4.Location = new System.Drawing.Point(187, 47);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(96, 19);
            this.checkBox4.TabIndex = 20;
            this.checkBox4.Text = "Pick Block";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // buttonuse
            // 
            this.buttonuse.AutoSize = true;
            this.buttonuse.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.buttonuse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonuse.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.buttonuse.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonuse.Location = new System.Drawing.Point(19, 62);
            this.buttonuse.Name = "buttonuse";
            this.buttonuse.Size = new System.Drawing.Size(89, 27);
            this.buttonuse.TabIndex = 23;
            this.buttonuse.Text = "How To Use";
            this.buttonuse.UseVisualStyleBackColor = true;
            this.buttonuse.Click += new System.EventHandler(this.buttonuse_Click);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox5.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox5.Location = new System.Drawing.Point(187, 22);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(110, 19);
            this.checkBox5.TabIndex = 21;
            this.checkBox5.Text = "Invulnerable";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label11.ForeColor = System.Drawing.SystemColors.Control;
            this.label11.Location = new System.Drawing.Point(16, 111);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 15);
            this.label11.TabIndex = 22;
            this.label11.Text = "Status: Off";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button18);
            this.groupBox7.Controls.Add(this.button23);
            this.groupBox7.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox7.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox7.Location = new System.Drawing.Point(12, 165);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(307, 73);
            this.groupBox7.TabIndex = 25;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "God Mode / Invisibility - Non-host Only";
            // 
            // button18
            // 
            this.button18.AutoSize = true;
            this.button18.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button18.ForeColor = System.Drawing.SystemColors.Control;
            this.button18.Location = new System.Drawing.Point(15, 26);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(96, 27);
            this.button18.TabIndex = 7;
            this.button18.Text = "Take Damage";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button23
            // 
            this.button23.AutoSize = true;
            this.button23.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button23.ForeColor = System.Drawing.SystemColors.Control;
            this.button23.Location = new System.Drawing.Point(195, 26);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(96, 27);
            this.button23.TabIndex = 6;
            this.button23.Text = "How To Use";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // autoBuildStructurePanel
            // 
            this.autoBuildStructurePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.autoBuildStructurePanel.Controls.Add(this.label7);
            this.autoBuildStructurePanel.Controls.Add(this.progressBarPanel);
            this.autoBuildStructurePanel.Controls.Add(this.button5);
            this.autoBuildStructurePanel.Controls.Add(this.label9);
            this.autoBuildStructurePanel.Controls.Add(this.checkBox3);
            this.autoBuildStructurePanel.Controls.Add(this.numericUpDown2);
            this.autoBuildStructurePanel.Controls.Add(this.numericUpDown1);
            this.autoBuildStructurePanel.Controls.Add(this.label8);
            this.autoBuildStructurePanel.Enabled = false;
            this.autoBuildStructurePanel.Location = new System.Drawing.Point(79, 333);
            this.autoBuildStructurePanel.Name = "autoBuildStructurePanel";
            this.autoBuildStructurePanel.Size = new System.Drawing.Size(47, 33);
            this.autoBuildStructurePanel.TabIndex = 22;
            this.autoBuildStructurePanel.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(34, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 15);
            this.label7.TabIndex = 15;
            this.label7.Text = "Size:";
            // 
            // progressBarPanel
            // 
            this.progressBarPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.progressBarPanel.Controls.Add(this.progressBarVal);
            this.progressBarPanel.Location = new System.Drawing.Point(23, 123);
            this.progressBarPanel.Name = "progressBarPanel";
            this.progressBarPanel.Size = new System.Drawing.Size(277, 19);
            this.progressBarPanel.TabIndex = 21;
            // 
            // progressBarVal
            // 
            this.progressBarVal.BackColor = System.Drawing.Color.Green;
            this.progressBarVal.Dock = System.Windows.Forms.DockStyle.Left;
            this.progressBarVal.Location = new System.Drawing.Point(0, 0);
            this.progressBarVal.Name = "progressBarVal";
            this.progressBarVal.Size = new System.Drawing.Size(0, 17);
            this.progressBarVal.TabIndex = 22;
            // 
            // button5
            // 
            this.button5.AutoSize = true;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button5.ForeColor = System.Drawing.SystemColors.Control;
            this.button5.Location = new System.Drawing.Point(211, 54);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(89, 27);
            this.button5.TabIndex = 6;
            this.button5.Text = "How To Use";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(24, 105);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(276, 15);
            this.label9.TabIndex = 20;
            this.label9.Text = "Status: Inactive";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox3.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox3.Location = new System.Drawing.Point(211, 22);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(89, 19);
            this.checkBox3.TabIndex = 16;
            this.checkBox3.Text = "Use Build";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.numericUpDown2.ForeColor = System.Drawing.SystemColors.Control;
            this.numericUpDown2.Location = new System.Drawing.Point(82, 58);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown2.TabIndex = 19;
            this.numericUpDown2.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.numericUpDown1.ForeColor = System.Drawing.SystemColors.Control;
            this.numericUpDown1.Location = new System.Drawing.Point(82, 21);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown1.TabIndex = 17;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(20, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 15);
            this.label8.TabIndex = 18;
            this.label8.Text = "Height:";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem8,
            this.toolStripComboBox5,
            this.toolStripMenuItem11});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.ShowImageMargin = false;
            this.contextMenuStrip1.ShowItemToolTips = false;
            this.contextMenuStrip1.Size = new System.Drawing.Size(157, 75);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(156, 22);
            this.toolStripMenuItem8.Text = "toolStripMenuItem8";
            // 
            // toolStripComboBox5
            // 
            this.toolStripComboBox5.Items.AddRange(new object[] {
            "Dpad Up",
            "Dpad Down",
            "Dpad Left",
            "Dpad Right",
            "Start",
            "Select",
            "Triangle",
            "Square",
            "Circle",
            "Cross",
            "R1",
            "R2",
            "R3",
            "L1",
            "L2",
            "L3"});
            this.toolStripComboBox5.Name = "toolStripComboBox5";
            this.toolStripComboBox5.Size = new System.Drawing.Size(121, 23);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(156, 22);
            this.toolStripMenuItem11.Text = "Set";
            this.toolStripMenuItem11.Click += new System.EventHandler(this.setToolStripMenuItem1_Click);
            // 
            // modMenuPanel
            // 
            this.modMenuPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.modMenuPanel.Controls.Add(this.checkBox1);
            this.modMenuPanel.Controls.Add(this.button4);
            this.modMenuPanel.Controls.Add(this.groupBox1);
            this.modMenuPanel.Controls.Add(this.label4);
            this.modMenuPanel.Enabled = false;
            this.modMenuPanel.Location = new System.Drawing.Point(371, 394);
            this.modMenuPanel.Name = "modMenuPanel";
            this.modMenuPanel.Size = new System.Drawing.Size(56, 49);
            this.modMenuPanel.TabIndex = 10;
            this.modMenuPanel.Visible = false;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox1.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox1.Location = new System.Drawing.Point(13, 37);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(68, 19);
            this.checkBox1.TabIndex = 27;
            this.checkBox1.Text = "Enable";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // button4
            // 
            this.button4.AutoSize = true;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button4.ForeColor = System.Drawing.SystemColors.Control;
            this.button4.Location = new System.Drawing.Point(12, 62);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(141, 27);
            this.button4.TabIndex = 28;
            this.button4.Text = "How To Use";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.xxxxxxxxxxxxxxxxxx);
            this.groupBox1.Controls.Add(this.xxxxxxxxxxxxxxxxx);
            this.groupBox1.Controls.Add(this.button12);
            this.groupBox1.Controls.Add(this.button13);
            this.groupBox1.Controls.Add(this.button14);
            this.groupBox1.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Location = new System.Drawing.Point(13, 95);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(140, 133);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Color Settings";
            // 
            // xxxxxxxxxxxxxxxxxx
            // 
            this.xxxxxxxxxxxxxxxxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxxxxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxxxxxx.Location = new System.Drawing.Point(46, 612);
            this.xxxxxxxxxxxxxxxxxx.Name = "xxxxxxxxxxxxxxxxxx";
            this.xxxxxxxxxxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxxxxxxxxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxxxxxxxxxxxxxxxx.TabIndex = 14;
            this.xxxxxxxxxxxxxxxxxx.Text = "022677030247";
            // 
            // xxxxxxxxxxxxxxxxx
            // 
            this.xxxxxxxxxxxxxxxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxxxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxxxxx.Location = new System.Drawing.Point(15, 662);
            this.xxxxxxxxxxxxxxxxx.Name = "xxxxxxxxxxxxxxxxx";
            this.xxxxxxxxxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxxxxxxxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxxxxxxxxxxxxxxx.TabIndex = 16;
            this.xxxxxxxxxxxxxxxxx.Text = "43683878012";
            // 
            // button12
            // 
            this.button12.AutoSize = true;
            this.button12.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button12.ForeColor = System.Drawing.SystemColors.Control;
            this.button12.Location = new System.Drawing.Point(13, 24);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(112, 27);
            this.button12.TabIndex = 5;
            this.button12.Text = "Theme";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click_1);
            // 
            // button13
            // 
            this.button13.AutoSize = true;
            this.button13.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button13.ForeColor = System.Drawing.SystemColors.Control;
            this.button13.Location = new System.Drawing.Point(13, 57);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(112, 27);
            this.button13.TabIndex = 10;
            this.button13.Text = "Text";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click_1);
            // 
            // button14
            // 
            this.button14.AutoSize = true;
            this.button14.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button14.ForeColor = System.Drawing.SystemColors.Control;
            this.button14.Location = new System.Drawing.Point(13, 90);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(112, 27);
            this.button14.TabIndex = 6;
            this.button14.Text = "Background";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(10, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 15);
            this.label4.TabIndex = 29;
            this.label4.Text = "Status: Inactive";
            // 
            // settingsPanel
            // 
            this.settingsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.settingsPanel.Controls.Add(this.groupBox9);
            this.settingsPanel.Controls.Add(this.groupBox6);
            this.settingsPanel.Controls.Add(this.groupBox5);
            this.settingsPanel.Controls.Add(this.groupBox4);
            this.settingsPanel.Enabled = false;
            this.settingsPanel.Font = new System.Drawing.Font("Consolas", 10F);
            this.settingsPanel.Location = new System.Drawing.Point(273, 394);
            this.settingsPanel.Name = "settingsPanel";
            this.settingsPanel.Size = new System.Drawing.Size(82, 45);
            this.settingsPanel.TabIndex = 9;
            this.settingsPanel.Visible = false;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.checkBox12);
            this.groupBox9.Controls.Add(this.checkBox11);
            this.groupBox9.Controls.Add(this.checkBox10);
            this.groupBox9.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox9.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox9.Location = new System.Drawing.Point(145, 3);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(144, 132);
            this.groupBox9.TabIndex = 27;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Tool Settings";
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox12.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox12.Location = new System.Drawing.Point(9, 95);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(131, 19);
            this.checkBox12.TabIndex = 28;
            this.checkBox12.Text = "Selecting Sound";
            this.checkBox12.UseVisualStyleBackColor = true;
            this.checkBox12.CheckedChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox11.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox11.Location = new System.Drawing.Point(9, 60);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(82, 19);
            this.checkBox11.TabIndex = 27;
            this.checkBox11.Text = "x2 Scale";
            this.checkBox11.UseVisualStyleBackColor = true;
            this.checkBox11.CheckedChanged += new System.EventHandler(this.checkBox11_CheckedChanged);
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox10.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox10.Location = new System.Drawing.Point(9, 26);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(75, 19);
            this.checkBox10.TabIndex = 26;
            this.checkBox10.Text = "Topmost";
            this.checkBox10.UseVisualStyleBackColor = true;
            this.checkBox10.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button25);
            this.groupBox6.Controls.Add(this.button22);
            this.groupBox6.Controls.Add(this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx);
            this.groupBox6.Controls.Add(this.button8);
            this.groupBox6.Controls.Add(this.checkBox9);
            this.groupBox6.Controls.Add(this.xxxx);
            this.groupBox6.Controls.Add(this.button3);
            this.groupBox6.Controls.Add(this.button20);
            this.groupBox6.Controls.Add(this.button21);
            this.groupBox6.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox6.Location = new System.Drawing.Point(19, 145);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(394, 135);
            this.groupBox6.TabIndex = 13;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Game Mods Settings";
            // 
            // button25
            // 
            this.button25.AutoSize = true;
            this.button25.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button25.ForeColor = System.Drawing.SystemColors.Control;
            this.button25.Location = new System.Drawing.Point(15, 93);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(241, 27);
            this.button25.TabIndex = 28;
            this.button25.Text = "View Activated Options";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button22
            // 
            this.button22.AutoSize = true;
            this.button22.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button22.ForeColor = System.Drawing.SystemColors.Control;
            this.button22.Location = new System.Drawing.Point(426, 236);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(96, 27);
            this.button22.TabIndex = 10;
            this.button22.Text = "Test";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
            // 
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.Location = new System.Drawing.Point(68, 622);
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.Name = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.ReadOnly = true;
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.TabIndex = 15;
            this.xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.Text = "02158542626241";
            // 
            // button8
            // 
            this.button8.AutoSize = true;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button8.ForeColor = System.Drawing.SystemColors.Control;
            this.button8.Location = new System.Drawing.Point(262, 22);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(117, 27);
            this.button8.TabIndex = 27;
            this.button8.Text = "View Load Path";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.checkBox9.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox9.Location = new System.Drawing.Point(100, 62);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(208, 19);
            this.checkBox9.TabIndex = 25;
            this.checkBox9.Text = "Load Config on Game Attach";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // xxxx
            // 
            this.xxxx.BackColor = System.Drawing.SystemColors.Control;
            this.xxxx.ForeColor = System.Drawing.SystemColors.Control;
            this.xxxx.Location = new System.Drawing.Point(68, 347);
            this.xxxx.Name = "xxxx";
            this.xxxx.ReadOnly = true;
            this.xxxx.Size = new System.Drawing.Size(10, 23);
            this.xxxx.TabIndex = 13;
            this.xxxx.Text = "1916280619523";
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button3.ForeColor = System.Drawing.SystemColors.Control;
            this.button3.Location = new System.Drawing.Point(262, 93);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(117, 27);
            this.button3.TabIndex = 26;
            this.button3.Text = "Reset Options";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button20
            // 
            this.button20.AutoSize = true;
            this.button20.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button20.ForeColor = System.Drawing.SystemColors.Control;
            this.button20.Location = new System.Drawing.Point(15, 22);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(117, 27);
            this.button20.TabIndex = 11;
            this.button20.Text = "Load Config";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.AutoSize = true;
            this.button21.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button21.ForeColor = System.Drawing.SystemColors.Control;
            this.button21.Location = new System.Drawing.Point(138, 22);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(118, 27);
            this.button21.TabIndex = 12;
            this.button21.Text = "Save Config";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button16);
            this.groupBox5.Controls.Add(this.button17);
            this.groupBox5.Controls.Add(this.button11);
            this.groupBox5.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox5.Location = new System.Drawing.Point(295, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(119, 132);
            this.groupBox5.TabIndex = 12;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Information";
            // 
            // button16
            // 
            this.button16.AutoSize = true;
            this.button16.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button16.ForeColor = System.Drawing.SystemColors.Control;
            this.button16.Location = new System.Drawing.Point(11, 23);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(96, 27);
            this.button16.TabIndex = 8;
            this.button16.Text = "About";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click_1);
            // 
            // button17
            // 
            this.button17.AutoSize = true;
            this.button17.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button17.ForeColor = System.Drawing.SystemColors.Control;
            this.button17.Location = new System.Drawing.Point(11, 56);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(96, 27);
            this.button17.TabIndex = 9;
            this.button17.Text = "Mod Tips";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button11
            // 
            this.button11.AutoSize = true;
            this.button11.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button11.ForeColor = System.Drawing.SystemColors.Control;
            this.button11.Location = new System.Drawing.Point(11, 89);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(96, 27);
            this.button11.TabIndex = 7;
            this.button11.Text = "Credits";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button9);
            this.groupBox4.Controls.Add(this.button19);
            this.groupBox4.Controls.Add(this.button10);
            this.groupBox4.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox4.Location = new System.Drawing.Point(20, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(119, 132);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Color Settings";
            // 
            // button9
            // 
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button9.ForeColor = System.Drawing.SystemColors.Control;
            this.button9.Location = new System.Drawing.Point(11, 23);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(96, 27);
            this.button9.TabIndex = 5;
            this.button9.Text = "Theme";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button19
            // 
            this.button19.AutoSize = true;
            this.button19.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button19.ForeColor = System.Drawing.SystemColors.Control;
            this.button19.Location = new System.Drawing.Point(11, 56);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(96, 27);
            this.button19.TabIndex = 10;
            this.button19.Text = "Text";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button10
            // 
            this.button10.AutoSize = true;
            this.button10.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.button10.ForeColor = System.Drawing.SystemColors.Control;
            this.button10.Location = new System.Drawing.Point(11, 89);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(96, 27);
            this.button10.TabIndex = 6;
            this.button10.Text = "Background";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // timer3
            // 
            this.timer3.Interval = 5000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // modsTimer
            // 
            this.modsTimer.Interval = 1;
            this.modsTimer.Tick += new System.EventHandler(this.modsTimer_Tick);
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem15,
            this.toolStripMenuItem17});
            this.contextMenuStrip3.Name = "contextMenuStrip1";
            this.contextMenuStrip3.ShowImageMargin = false;
            this.contextMenuStrip3.ShowItemToolTips = false;
            this.contextMenuStrip3.Size = new System.Drawing.Size(143, 48);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTextBox1,
            this.toolStripMenuItem1});
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(142, 22);
            this.toolStripMenuItem15.Text = "Change Quaunity";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 23);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem1.Text = "Set";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click_1);
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem6,
            this.toolStripMenuItem4,
            this.toolStripMenuItem13,
            this.toolStripMenuItem14});
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(142, 22);
            this.toolStripMenuItem17.Text = "Change Item";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBox2,
            this.toolStripMenuItem3});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(129, 22);
            this.toolStripMenuItem2.Text = "Blocks";
            // 
            // toolStripComboBox2
            // 
            this.toolStripComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripComboBox2.Items.AddRange(new object[] {
            "Stone",
            "Grass Block",
            "Cobblestone",
            "Sand",
            "Block of Gold",
            "Block of Iron",
            "Lapis Lazuli Block",
            "Block of Diamond",
            "Block of Emerald",
            "Oak Wood",
            "Acacia Wood",
            "Obsidian",
            "Nether Brick",
            "Red Nether Brick",
            "Soul Sand",
            "Magma Block",
            "Stone Bricks"});
            this.toolStripComboBox2.Name = "toolStripComboBox2";
            this.toolStripComboBox2.Size = new System.Drawing.Size(121, 23);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem3.Text = "Set";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click_1);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBox4,
            this.toolStripMenuItem7});
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(129, 22);
            this.toolStripMenuItem6.Text = "Glazed";
            // 
            // toolStripComboBox4
            // 
            this.toolStripComboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripComboBox4.Items.AddRange(new object[] {
            "Black",
            "Blue",
            "Light Blue",
            "Cyan",
            "Green",
            "Lime",
            "Pink",
            "Magenta",
            "Purple",
            "Red",
            "Brown",
            "Orange",
            "Yellow",
            "White",
            "Light Gray",
            "Gray"});
            this.toolStripComboBox4.Name = "toolStripComboBox4";
            this.toolStripComboBox4.Size = new System.Drawing.Size(121, 23);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem7.Text = "Set";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click_1);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBox3,
            this.toolStripMenuItem5});
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(129, 22);
            this.toolStripMenuItem4.Text = "Misc.";
            // 
            // toolStripComboBox3
            // 
            this.toolStripComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripComboBox3.Items.AddRange(new object[] {
            "TNT",
            "Block of RedStone",
            "Golden Apple",
            "Steak",
            "Map",
            "Beacon",
            "Monster Spawner",
            "Nether Star"});
            this.toolStripComboBox3.Name = "toolStripComboBox3";
            this.toolStripComboBox3.Size = new System.Drawing.Size(121, 23);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem5.Text = "Set";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click_1);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBox1,
            this.toolStripMenuItem10});
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(129, 22);
            this.toolStripMenuItem13.Text = "Combat";
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripComboBox1.Items.AddRange(new object[] {
            "Helmet",
            "Chestplate",
            "Legs",
            "Boots",
            "Sword",
            "Shovel",
            "Pickaxe",
            "Axe",
            "Hoe",
            "Bow",
            "Arrow",
            "Trident",
            "Turtle Shell",
            "Totem of Undying",
            "Diamond Horse Armour"});
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 23);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem10.Text = "Set";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.setToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBox7,
            this.toolStripMenuItem12});
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(129, 22);
            this.toolStripMenuItem14.Text = "Rare Items";
            // 
            // toolStripComboBox7
            // 
            this.toolStripComboBox7.Items.AddRange(new object[] {
            "Conduit",
            "End Crystal",
            "Ender Pearl",
            "Eye Of Ender",
            "End Portal Frame",
            "Name Tag",
            "Bottle O Enchanting",
            "Dragons Breath",
            "Elytra",
            "Heart of the sea",
            "Firework Rocket"});
            this.toolStripComboBox7.Name = "toolStripComboBox7";
            this.toolStripComboBox7.Size = new System.Drawing.Size(121, 23);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem12.Text = "Set";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.setToolStripMenuItem_Click);
            // 
            // backgroundWorker2
            // 
            this.backgroundWorker2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker2_DoWork);
            // 
            // backgroundWorker3
            // 
            this.backgroundWorker3.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker3_DoWork);
            // 
            // timer7
            // 
            this.timer7.Interval = 500;
            this.timer7.Tick += new System.EventHandler(this.timer7_Tick);
            // 
            // saveIMC
            // 
            this.saveIMC.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem9,
            this.toolStripMenuItem18});
            this.saveIMC.Name = "contextMenuStrip1";
            this.saveIMC.ShowImageMargin = false;
            this.saveIMC.ShowItemToolTips = false;
            this.saveIMC.Size = new System.Drawing.Size(143, 48);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTextBox2,
            this.toolStripMenuItem16});
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(142, 22);
            this.toolStripMenuItem9.Text = "Change Quaunity";
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(100, 23);
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem16.Text = "Set";
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem19,
            this.toolStripMenuItem21,
            this.toolStripMenuItem23,
            this.toolStripMenuItem25,
            this.toolStripMenuItem27});
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(142, 22);
            this.toolStripMenuItem18.Text = "Change Item";
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBox8,
            this.toolStripMenuItem20});
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(129, 22);
            this.toolStripMenuItem19.Text = "Blocks";
            // 
            // toolStripComboBox8
            // 
            this.toolStripComboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripComboBox8.Items.AddRange(new object[] {
            "Stone",
            "Grass Block",
            "Cobblestone",
            "Sand",
            "Block of Gold",
            "Block of Iron",
            "Lapis Lazuli Block",
            "Block of Diamond",
            "Block of Emerald",
            "Oak Wood",
            "Acacia Wood",
            "Obsidian",
            "Nether Brick",
            "Red Nether Brick",
            "Soul Sand",
            "Magma Block",
            "Stone Bricks"});
            this.toolStripComboBox8.Name = "toolStripComboBox8";
            this.toolStripComboBox8.Size = new System.Drawing.Size(121, 23);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem20.Text = "Set";
            // 
            // toolStripMenuItem21
            // 
            this.toolStripMenuItem21.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBox9,
            this.toolStripMenuItem22});
            this.toolStripMenuItem21.Name = "toolStripMenuItem21";
            this.toolStripMenuItem21.Size = new System.Drawing.Size(129, 22);
            this.toolStripMenuItem21.Text = "Glazed";
            // 
            // toolStripComboBox9
            // 
            this.toolStripComboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripComboBox9.Items.AddRange(new object[] {
            "Black",
            "Blue",
            "Light Blue",
            "Cyan",
            "Green",
            "Lime",
            "Pink",
            "Magenta",
            "Purple",
            "Red",
            "Brown",
            "Orange",
            "Yellow",
            "White",
            "Light Gray",
            "Gray"});
            this.toolStripComboBox9.Name = "toolStripComboBox9";
            this.toolStripComboBox9.Size = new System.Drawing.Size(121, 23);
            // 
            // toolStripMenuItem22
            // 
            this.toolStripMenuItem22.Name = "toolStripMenuItem22";
            this.toolStripMenuItem22.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem22.Text = "Set";
            // 
            // toolStripMenuItem23
            // 
            this.toolStripMenuItem23.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBox10,
            this.toolStripMenuItem24});
            this.toolStripMenuItem23.Name = "toolStripMenuItem23";
            this.toolStripMenuItem23.Size = new System.Drawing.Size(129, 22);
            this.toolStripMenuItem23.Text = "Misc.";
            // 
            // toolStripComboBox10
            // 
            this.toolStripComboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripComboBox10.Items.AddRange(new object[] {
            "TNT",
            "Block of RedStone",
            "Golden Apple",
            "Steak",
            "Map",
            "Beacon",
            "Monster Spawner",
            "Nether Star"});
            this.toolStripComboBox10.Name = "toolStripComboBox10";
            this.toolStripComboBox10.Size = new System.Drawing.Size(121, 23);
            // 
            // toolStripMenuItem24
            // 
            this.toolStripMenuItem24.Name = "toolStripMenuItem24";
            this.toolStripMenuItem24.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem24.Text = "Set";
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBox11,
            this.toolStripMenuItem26});
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(129, 22);
            this.toolStripMenuItem25.Text = "Combat";
            // 
            // toolStripComboBox11
            // 
            this.toolStripComboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripComboBox11.Items.AddRange(new object[] {
            "Helmet",
            "Chestplate",
            "Legs",
            "Boots",
            "Sword",
            "Shovel",
            "Pickaxe",
            "Axe",
            "Hoe",
            "Bow",
            "Arrow",
            "Trident",
            "Totem of Undying"});
            this.toolStripComboBox11.Name = "toolStripComboBox11";
            this.toolStripComboBox11.Size = new System.Drawing.Size(121, 23);
            // 
            // toolStripMenuItem26
            // 
            this.toolStripMenuItem26.Name = "toolStripMenuItem26";
            this.toolStripMenuItem26.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem26.Text = "Set";
            // 
            // toolStripMenuItem27
            // 
            this.toolStripMenuItem27.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBox12,
            this.toolStripMenuItem28});
            this.toolStripMenuItem27.Name = "toolStripMenuItem27";
            this.toolStripMenuItem27.Size = new System.Drawing.Size(129, 22);
            this.toolStripMenuItem27.Text = "Rare Items";
            // 
            // toolStripComboBox12
            // 
            this.toolStripComboBox12.Items.AddRange(new object[] {
            "Conduit",
            "End Crystal",
            "Ender Pearl",
            "Eye Of Ender",
            "Name Tag",
            "Bottle O Enchanting",
            "Dragons Breath",
            "Elytra",
            "Heart of the sea"});
            this.toolStripComboBox12.Name = "toolStripComboBox12";
            this.toolStripComboBox12.Size = new System.Drawing.Size(121, 23);
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem28.Text = "Set";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 455);
            this.Controls.Add(this.gameManagerPanel);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.modMenuPanel);
            this.Controls.Add(this.settingsPanel);
            this.Controls.Add(this.connectionPanel);
            this.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "mcV4";
            this.TransparencyKey = System.Drawing.Color.Thistle;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.connectionPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.gameManagerPanel.ResumeLayout(false);
            this.itemPanel.ResumeLayout(false);
            this.itemPanel.PerformLayout();
            this.posPanel.ResumeLayout(false);
            this.posPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip4.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.btnBindsPanel.ResumeLayout(false);
            this.btnBindsPanel.PerformLayout();
            this.hostOptsPanel.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.autoBuildStructurePanel.ResumeLayout(false);
            this.autoBuildStructurePanel.PerformLayout();
            this.progressBarPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.modMenuPanel.ResumeLayout(false);
            this.modMenuPanel.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.settingsPanel.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.contextMenuStrip3.ResumeLayout(false);
            this.saveIMC.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip sub1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button connectionBtn;
        private System.Windows.Forms.Panel connectionPanel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel gameManagerPanel;
        private System.Windows.Forms.Panel progressBarPanel;
        private System.Windows.Forms.Panel progressBarVal;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button gameManagerBtn;
        private System.Windows.Forms.Button settingsBtn;
        private System.Windows.Forms.Button btnM1;
        private System.Windows.Forms.Button btnM2;
        private System.Windows.Forms.Button btnM5;
        private System.Windows.Forms.Button btnM3;
        private System.Windows.Forms.Button btnM4;
        private System.Windows.Forms.Panel autoBuildStructurePanel;
        private System.Windows.Forms.Panel hostOptsPanel;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.Button buttonuse;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Panel btnBindsPanel;
        private System.Windows.Forms.Button buttonR;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel posPanel;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button buttonP;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.Button buttonsave;
        private System.Windows.Forms.Button buttonlist;
        private System.Windows.Forms.Button buttoncur;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel itemPanel;
        private System.Windows.Forms.Button buttonh2u;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label iSlot27;
        private System.Windows.Forms.Label iSlot26;
        private System.Windows.Forms.Label iSlot25;
        private System.Windows.Forms.Label iSlot24;
        private System.Windows.Forms.Label iSlot23;
        private System.Windows.Forms.Label iSlot22;
        private System.Windows.Forms.Label iSlot21;
        private System.Windows.Forms.Label iSlot20;
        private System.Windows.Forms.Label iSlot19;
        private System.Windows.Forms.Label iSlot18;
        private System.Windows.Forms.Label iSlot17;
        private System.Windows.Forms.Label iSlot16;
        private System.Windows.Forms.Label iSlot15;
        private System.Windows.Forms.Label iSlot14;
        private System.Windows.Forms.Label iSlot13;
        private System.Windows.Forms.Label iSlot12;
        private System.Windows.Forms.Label iSlot11;
        private System.Windows.Forms.Label iSlot10;
        private System.Windows.Forms.Label iSlot9;
        private System.Windows.Forms.Label iSlot8;
        private System.Windows.Forms.Label iSlot7;
        private System.Windows.Forms.Label iSlot6;
        private System.Windows.Forms.Label iSlot5;
        private System.Windows.Forms.Label iSlot4;
        private System.Windows.Forms.Label iSlot3;
        private System.Windows.Forms.Label iSlot2;
        private System.Windows.Forms.Label iSlot1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label hSlot9;
        private System.Windows.Forms.Label hSlot8;
        private System.Windows.Forms.Label hSlot7;
        private System.Windows.Forms.Label hSlot6;
        private System.Windows.Forms.Label hSlot5;
        private System.Windows.Forms.Label hSlot4;
        private System.Windows.Forms.Label hSlot3;
        private System.Windows.Forms.Label hSlot2;
        private System.Windows.Forms.Label hSlot1;
        private System.Windows.Forms.Label oSlot1;
        private System.Windows.Forms.Label aSlot4;
        private System.Windows.Forms.Label aSlot3;
        private System.Windows.Forms.Label aSlot1;
        private System.Windows.Forms.Label aSlot2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel settingsPanel;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer modsTimer;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.Button buttonclear;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewButtonColumn Column3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.RichTextBox xxxxxxxxxxxxx;
        private System.Windows.Forms.RichTextBox xxxxxxxxxxxx;
        private System.Windows.Forms.Button modMenuBtn;
        private System.Windows.Forms.Panel modMenuPanel;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label4;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private System.ComponentModel.BackgroundWorker backgroundWorker3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer7;
        private System.Windows.Forms.ContextMenuStrip saveIMC;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem21;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem22;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem23;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem24;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem25;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem26;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem27;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem29;
        private System.Windows.Forms.ToolStripMenuItem removePositionToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.TextBox xxxxxxxxxx;
        private System.Windows.Forms.TextBox xxxxxxxxxxx;
        private System.Windows.Forms.TextBox xxxxxxxxxxxxxx;
        private System.Windows.Forms.TextBox xxxxxxxxxxxxxxxxx;
        private System.Windows.Forms.TextBox xxxxxxxxxxxxxxxxxxxxxxxxxxxxx;
        private System.Windows.Forms.TextBox xxxxxxxxxxxxxxxxxx;
        private System.Windows.Forms.TextBox xxxx;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.ComponentModel.BackgroundWorker backgroundWorker4;
        private System.Windows.Forms.RichTextBox xxxxx;
        private System.Windows.Forms.RichTextBox ultL;
        private System.Windows.Forms.RichTextBox mcL;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;


    }
}

