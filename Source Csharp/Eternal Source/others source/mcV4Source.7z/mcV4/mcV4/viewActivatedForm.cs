﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mcV4
{
    public partial class viewActivatedForm : Form
    {
        public viewActivatedForm()
        {
            InitializeComponent();
        }

        private void viewActivatedForm_Load(object sender, EventArgs e)
        {
            Font = Form1.getFont;
            BackColor = Form1.bgColor;
            ForeColor = Form1.txtColor;
            listBox1.BackColor = Form1.bgColor;
            listBox1.ForeColor = Form1.txtColor;
            listBox1.Items.Clear();
            listBox1.Items.AddRange(Form1.getOptions);
        }
    }
}
