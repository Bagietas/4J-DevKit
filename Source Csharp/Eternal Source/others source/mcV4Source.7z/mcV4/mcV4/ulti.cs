﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PS3Lib;

namespace mcV4
{
    public class ulti
    {
        /*
         Credit: Creator of Downcraft (most of the options)
                 Class edited by MayhemModding        
        */
        #region bool
        public int kkmg57b7a5jhdhlsy1rbv(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B2021U, new byte[] { 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4B2021U, new byte[] { 0x20 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int d16rfn7lvi3z6m7vkzrdu(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A3FF0U, new byte[] { 0x40, 0x80 });
            }
            else 
            { 
                PS3API ps = Form1.PS3; uint offset = 0x3A3FF0U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            } 
            if (toggle == 1) return 0; else return 1;
        }
        public int Nvnca12ceuy2jn9pm105l(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4018U, new byte[] { 0x40, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4018U, new byte[] { 0x3E, 0xCC });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int uc0frojmrgrio7ypn4qnu(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4018U, new byte[2]);
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4018U, new byte[] { 0x3E, 0xCC });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int b4haubpsmsjt9w1r4iuvs(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1AC411U, new byte[] { 0xE0, 0x28, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1AC411U, new byte[] { 0xE0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int aqv7dqomzucskmkr5zuq8(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD68U, new byte[] { 0x3F, 0xF9, 0x99, 0x99 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD68U, new byte[] { 0x3F, 0xE9, 0x99, 0x99 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int P5s6ysmgofoud2ygfnxo5(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x224B13U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x224B13U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int cd31q1iwlkvfydw0qvaeh(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xFB4C5U, new byte[] { 0xE0, 0x18, 0x18 });
            }
            else
            {
                Form1.PS3.SetMemory(0xFB4C5U, new byte[] { 0xE0, 8, 0x18 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Awgra7iprghv1p357htgz(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x10E0C4U, new byte[] { byte.MaxValue, 0xE0, 0x28, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x10E0C4U, new byte[] { byte.MaxValue, 0xE0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Jvp5voqfiexxj37a7l1ss(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x18CE4U, new byte[] { byte.MaxValue, 0xE0, 0, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x18CE4U, new byte[] { byte.MaxValue, 0xE0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int U2ffc9oij13ic3pvhk6vq(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEEE54U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEEE54U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int uchnttm8s38wqax6qk2va(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD49U, new byte[] { byte.MaxValue, byte.MaxValue, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD49U, new byte[] { 0x26, 0xAD, 0x89 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Hh5qlovqol3wpgcpv1wsx(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4619E4U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4619E4U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int tq0q3h2bfsf6skuig0ce8(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC894U, new byte[] { 0x39, 0x40, 0, 0x10 });
            }
            else 
            {
                PS3API ps = Form1.PS3; uint offset = 0x1CC894U; byte[] array = new byte[4]; array[0] = 0x39; array[1] = 0x40; ps.SetMemory(offset, array);
            } 
            if (toggle == 1) return 0; else return 1;
        }
        public int C6ugalgj7ilyxj7urpxdv(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA999U, new byte[] { 0xA0 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA999U, new byte[] { 0x68 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ktk5f6eev4i4zsu16tpra(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x22790BU, new byte[] { 0x14 });
            }
            else
            {
                Form1.PS3.SetMemory(0x22790BU, new byte[] { 0x18 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Asd7gqjima00d8sovyaeh(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA77CU, new byte[] { 0x3F, 0x47, 0x7F, 0x42 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA77CU, new byte[] { 0x3E, 0xD7, 0xA, 0x3D });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ngd2o6x0ytc2hti46kj0w(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB01BACU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB01BACU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int h51vdr109gfhskk85a80q(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA95FB9U, new byte[] { 0x80 }); Form1.PS3.SetMemory(0xA95FC1U, new byte[] { 0x80 }); PS3API ps = Form1.PS3; uint offset = 0xB351D8U; byte[] array = new byte[4]; array[0] = 0x43; array[1] = 0xA0; ps.SetMemory(offset, array); PS3API ps2 = Form1.PS3; uint offset2 = 0xB351DCU; byte[] array2 = new byte[4]; array2[0] = 0x43; array2[1] = 0xA0; ps2.SetMemory(offset2, array2);
            }
            else
            { 
                Form1.PS3.SetMemory(0xA95FB9U, new byte[] { 0x18 }); Form1.PS3.SetMemory(0xA95FC1U, new byte[] { 8 }); PS3API ps3 = Form1.PS3; uint offset3 = 0xB351D8U; byte[] array3 = new byte[4]; array3[0] = 0x40; array3[1] = 0xA0; ps3.SetMemory(offset3, array3); PS3API ps4 = Form1.PS3; uint offset4 = 0xB351DCU; byte[] array4 = new byte[4]; array4[0] = 0x40; array4[1] = 0x90; ps4.SetMemory(offset4, array4); 
            } 
            if (toggle == 1) return 0; else return 1;
        }
        public int Xdtgl2074p8j9lrlkcarz(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEB090U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEB090U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Gjgsaqp05fhpo8itmvjk1(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x98871FU, new byte[] { 1 });
            }
            else
            { 
                Form1.PS3.SetMemory(0x98871FU, new byte[1]); 
            } 
            if (toggle == 1) return 0; else return 1;
        }
        public int v35th6ig28y29rbh7bg5m(int toggle)
        {
            if (toggle == 1)
            {
               // Form1.PS3.SetMemory(0x3AFB60U, new byte[] { byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue });
            }
            else
            {
               // Form1.PS3.SetMemory(0x3AFB60U, new byte[] { 0x3F, 0x7A, 0xE1, 0x48 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int J32axm662236lv0jxcy72(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, 0, 0x7A, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, 0xEF, 0x5C, 0x29 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int bj77roq77awkoo712fmzc(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA999U, new byte[] { 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA999U, new byte[] { 0x68 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Shd489aj1f3l0cwdcei2c(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B1CE0U, new byte[] { 0xFC, 2, 0x10 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4B1CE0U, new byte[] { 0xFC, 1, 0x10 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int p7dcmykn27dhjvbafc8ro(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B1D60U, new byte[] { 0xFC, 0, 0xF8, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4B1D60U, new byte[] { 0xFC, 0x20, 0xF8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int bgf1hkul14zx7txeebsjz(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB01DECU, new byte[] { 0x40, 0x82 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB01DECU, new byte[] { 0x41, 0x82 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int lxr4cvbfbw8ag0o51l4be(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD8158U, new byte[] { 0x4C });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD8158U, new byte[] { 0x2C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Rxq2ixva686g4qr0b39cv(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA99154U, new byte[] { 0xFC, 0x80, 0x30, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA99154U, new byte[] { 0xFC, 0x60, 0x30, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int zpkf5zrge2m3grf1ctvwl(int toggle)
        {
            if (toggle == 1)
            {
                //Form1.PS3.SetMemory(0xAD8480U, new byte[] { 0x41, 0x82 });
            }
            else
            {
                //Form1.PS3.SetMemory(0xAD8480U, new byte[] { 0x40, 0x82 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Zkhe14qr7yfqwj1zxpct8(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x90B5F0U, new byte[] { 0x38, 0x80, 0, 1 });
            }
            else
            { 
                PS3API ps = Form1.PS3; uint offset = 0x90B5F0U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x80; ps.SetMemory(offset, array);
            } 
            if (toggle == 1) return 0; else return 1;
        }
        public int Jdwftc7csbyfzcj8hfobi(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEF56CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEF56CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int yajqw6g6zqdwrcyiybuy7(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDC9U, new byte[] { 0xF4 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDC9U, new byte[] { 0xB4 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int In85990ua3rsbak74gsx5(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEF514U, new byte[] { 0x40, 0x82, 0, 0x1C });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEF514U, new byte[] { 0x41, 0x82, 0, 0x1C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Vanc8cyxnbjfuze5bnqwg(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x34B8F4U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x34B8F4U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int zv1qw4q97hzablmsmmj3f(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEC42CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEC42CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Actlf91b8i6hmhvbf5j8n(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEC34CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEC34CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Xh5wx1ww6h4fqtldp8mxw(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x390410U, new byte[] { 0x3B, 0x40, 0, 0x10 }); Form1.PS3.SetMemory(0x3ABD44U, new byte[] { 0x3D });
            }
            else
            {
                PS3API ps = Form1.PS3; uint offset = 0x390410U; byte[] array = new byte[4]; array[0] = 0x3B; array[1] = 0x40; ps.SetMemory(offset, array); Form1.PS3.SetMemory(0x3ABD44U, new byte[] { 0x3C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int bitn472xqu2t2tpehuk2y(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Tlpzt0agvn3fep0jxs108(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7865ECU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7865ECU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int s9gmolm6eg65xu9l343d6(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA99420U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA99420U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int xwcc1xon2fqy3t3yeckio(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD40U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD40U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Pdcor8ruqpq3yx3m7ev16(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD44U, new byte[] { 0xBC });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD44U, new byte[] { 0x3C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int g8d80hbd0kg1tvz2txv2f(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA97F34U, new byte[] { 0xDF });
            }
            else
            {
                Form1.PS3.SetMemory(0xA97F34U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int W47nzx9fzr1aqtlpaexj6(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA97F2CU, new byte[] { 0x23 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA97F2CU, new byte[] { 0x43 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int uo3fiyjd7b2js2wbb0idh(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEBED4U, new byte[] { byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEBED4U, new byte[] { 0x3E });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int c6nitgkajk2pal61b1ean(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x11230U, new byte[] { byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue });
            }
            else
            { 
                Form1.PS3.SetMemory(0x11230U, new byte[8]);
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int n5iyzrrx6joj5ubaauwco(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5EC8U, new byte[] { 0xBF, byte.MaxValue }); PS3API ps = Form1.PS3; uint offset = 0x410734U; byte[] array = new byte[4]; array[0] = 0xCD; array[1] = 0xC0; ps.SetMemory(offset, array);
            }
            else
            { 
                Form1.PS3.SetMemory(0xAD5EC8U, new byte[] { 0xBF, 0x80 }); PS3API ps2 = Form1.PS3; uint offset2 = 0x410734U; byte[] array2 = new byte[4]; array2[0] = 0x40; array2[1] = 0xC0; ps2.SetMemory(offset2, array2); 
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Yj4ximjh55ajwhzlyytby(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5EC8U, new byte[] { 0x50, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5EC8U, new byte[] { 0xBF, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Zwd96tupk60rfcwebupmh(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5EC8U, new byte[] { 0x3F, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5EC8U, new byte[] { 0xBF, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Yk1bjfxx4zmlaun1f50z2(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xA9A6C8U; byte[] array = new byte[4]; array[0] = 0x4F; array[1] = 0x80; ps.SetMemory(offset, array);
            }
            else 
            { 
                PS3API ps2 = Form1.PS3; uint offset2 = 0xA9A6C8U; byte[] array2 = new byte[4]; array2[0] = 0x3F; array2[1] = 0x80; ps2.SetMemory(offset2, array2);
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int t469etdtvvkdig4n4cz15(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ACEF4U, new byte[] { 0xBF, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ACEF4U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int E6uuupquy58g30unn260b(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEF9F0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEF9F0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int idcipic40a6df945jmozc(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEB090U, new byte[] { byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEB090U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ct50xdjswqacf8014mflm(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x90FAC8U, new byte[] { 0x41, 0x82 });
            }
            else
            {
                Form1.PS3.SetMemory(0x90FAC8U, new byte[] { 0x40, 0x82 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int sv3y85b46ydbngxrilvl9(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x225EA8U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x225EA8U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Tthk948gjca7hdnqzh11c(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x310AD4U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x310AD4U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int lpw7n9y8lits03m2otye7(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7865D0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7865D0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int b4u3yg3k3g1au3it7k6af(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x785DBCU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x785DBCU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int m95bsrhn0ucgsw4i52igf(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98F4CU, new byte[] { 0xAF });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F4CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int zoeeqs86v25dwx978slg9(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98F40U, new byte[] { byte.MaxValue });
            }
            else { Form1.PS3.SetMemory(0xA98F40U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int icki88qr78yc8o0o4awyr(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9A6C8U, new byte[] { 0x7F });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9A6C8U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ek28z8t5w7jmqbhz45a5a(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x233290U, new byte[] { byte.MaxValue });
            }
            else 
            { 
                Form1.PS3.SetMemory(0x233290U, new byte[1]); 
            } if (toggle == 1) return 0; else return 1;
        }
        public int A97ud0c62ich8mxyxvufb(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB023ECU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB023ECU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int jxlb0mx9sf690z8tmh486(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x30012913U, new byte[] { 5 });
            }
            else
            {
                Form1.PS3.SetMemory(0x30012913U, new byte[] { 7 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Kxco4boeoscjl53nx531c(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x30012913U, new byte[] { 2 });
            }
            else
            {
                Form1.PS3.SetMemory(0x30012913U, new byte[] { 7 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int wcnwmcqindlp0vinu7gz8(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x30012913U, new byte[] { 1 });
            }
            else
            {
                Form1.PS3.SetMemory(0x30012913U, new byte[] { 7 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ytvadwy55v5qnd53jqb2u(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, 0xEF });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Yf1kgxtzwp30ze2trnszo(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Uum2h5bwzpde5oe22k3qd(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x14C6880U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int J9jq2f1jlml67mo938clv(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int d69hlz4ka91htcwol6acd(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAECE70U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAECE70U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ru8f2rqjqkbwtcwsujsch(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB02378U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB02378U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Nqjlven4z9y68ai3uvdes(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEFE64U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEFE64U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int fkk5979ahopj271wsa294(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int HUD_LOADING(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14CE214U, new byte[] { 1 });
            }
            else
            { 
                Form1.PS3.SetMemory(0x14CE214U, new byte[1]); 
            } 
            if (toggle == 1) return 0; else return 1;
        }
        public int Il3aqc4hkbwn89uagnlxf(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x4F, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int fmxktpebjvku3ekgqjp7d(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1310954U, new byte[] { 0x7E });
            }
            else
            {
                Form1.PS3.SetMemory(0x1310954U, new byte[] { 0x3E });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int d10g2bk2m0qfyf3rytqa8(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1310954U, new byte[] { 0x7E }); Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x4F });
            }
            else
            {
                Form1.PS3.SetMemory(0x1310954U, new byte[] { 0x3E }); Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int E38y0cu4yot67ouovqsse(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x38C658U, new byte[] { 0x7F });
            }
            else
            {
                Form1.PS3.SetMemory(0x38C658U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ylysef5xk2r72o9j2bpzq(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x38C658U, new byte[] { byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x38C658U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Nqd8huhkvp6ia86wfqtvg(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3097C8U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3097B8U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3097C8U, new byte[] { 0x41 }); Form1.PS3.SetMemory(0x3097B8U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int n6t66vdtpkwtb2cxi0lu8(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x310AFCU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x310AFCU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Mvc56j74smels4st7hbvq(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEF428U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEF428U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Xy5k3mhh6ioof9xv4x9xy(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEE7E8U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEE7E8U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int aibcgkbgjs0ayzdk02cuc(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAF0354U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAF0354U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int gz8j8zgth6zjio6ix2dsk(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB02368U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB02368U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ea7nsnzp5m5cvou9k1dre(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAECF10U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAECF10U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ps8n2r1k35x7ytjb1u0u9(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A3FF0U, new byte[] { byte.MaxValue, byte.MaxValue });
            }
            else 
            { 
                PS3API ps = Form1.PS3; uint offset = 0x3A3FF0U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int G0x4bxx33675ywo2buvbv(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB52100U, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0xB52100U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int cpwaz8ncfsizatrn4elf3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x389B3CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x389B3CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int O8r771jberag9z9uexedj(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3E });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Pvykyh4fea77jphx7yc8y(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { byte.MaxValue, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int vm7ysb0lu7jh9i6ikgiz7(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA999U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA999U, new byte[] { 0x68 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int pd6etc7trlwpvgo7x92wr(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5ECCU, new byte[] { 0x1F });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5ECCU, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Usvh107at9n1qmaup2epe(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5ECCU, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5ECCU, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int zg4ik3w348ukowioszn3f(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x10673FU, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x10673FU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int S7ar859if3s55mrkym77d(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x410738U, new byte[] { 0x3F, 0x10 }); Form1.PS3.SetMemory(0x38C658U, new byte[] { 0x7F });
            }
            else
            {
                Form1.PS3.SetMemory(0x410738U, new byte[] { 0x3F, 0x80 }); Form1.PS3.SetMemory(0x38C658U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Oefupdm3ewc0plkhgmko4(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB022F8U, new byte[] { 0x4C });
            }
            else
            {
                Form1.PS3.SetMemory(0xB022F8U, new byte[] { 0x2C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int xoyaqzobe7zg1pza1pc4t(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA857D8U, new byte[] { 0x50 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA857D8U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Mfds12ptckelctczqee0y(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA857D8U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0xA857D8U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ylyh6589vjq0kp5ykfjyj(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA857C8U, new byte[] { 0x44 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA857C8U, new byte[] { 0xC0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int d5942odinauwllghr5w53(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA857D0U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0xA857D0U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Op824nbwxnol5qq3l4os2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2F0348U, new byte[] { 0x38, 0x80, 0, 1 }); PS3API ps = Form1.PS3; uint offset = 0x2F0398U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x80; ps.SetMemory(offset, array);
            }
            else
            {
                PS3API ps2 = Form1.PS3; uint offset2 = 0x2F0348U; byte[] array2 = new byte[4]; array2[0] = 0x38; array2[1] = 0x80; ps2.SetMemory(offset2, array2); Form1.PS3.SetMemory(0x2F0398U, new byte[] { 0x38, 0x80, 0, 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Dzwvy3p8ixhoso446g9om(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x2F0368U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x80; ps.SetMemory(offset, array); Form1.PS3.SetMemory(0x2F0378U, new byte[] { 0x38, 0x80, 0, 1 });
            }
            else { Form1.PS3.SetMemory(0x2F0368U, new byte[] { 0x38, 0x80, 0, 1 }); PS3API ps2 = Form1.PS3; uint offset2 = 0x2F0378U; byte[] array2 = new byte[4]; array2[0] = 0x38; array2[1] = 0x80; ps2.SetMemory(offset2, array2); }
            if (toggle == 1) return 0; else return 1;
        }
        public int Qqu9vj045n6wrddd3nda8(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3F, 0x10, 0x23, 0x50 }); Form1.PS3.SetMemory(0x3AA999U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3E, 0x26, 0xAD, 0x89 }); Form1.PS3.SetMemory(0x3AA999U, new byte[] { 0x68 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int vcoaf92rvw6f49flfw9pc(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, 0xAF });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, 0xEF });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int oud51v7ok0atc8qkcu3wr(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2278E4U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2278E4U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int qjiiq01r828goy7n8siub(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x227BDCU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x227BDCU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Dng5vnd5s5iu3m83l5oa3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2F03D0U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2F03D0U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int tqqs14fnbdltmjudcnwdx(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDC8U, new byte[] { 0x3F });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDC8U, new byte[] { 0xBF });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int M58ctonb0ebdeh0v7yd1h(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEEB83U, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEEB83U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int pz4puyht2508ikn7ro8nq(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98F4CU, new byte[] { 0x50 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F4CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int gex7cipes9gok558bts5g(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98EF4U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98EF4U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int D3j5nc4342dsz0kdb7mli(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3F, byte.MaxValue, 0, 1 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3E, 0x26, 0xAD, 0x89 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ydb2ymxmpo685dgw42u9n(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA99050U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA99050U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Lwkz5xzuu26dhgwd1qgap(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA991ACU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA991ACU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int grop6fwwtxiinm8w2m7bx(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x245DEBU, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x245DEBU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Hd2ws20zqc5owtu5h52za(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98EBCU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98EBCU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ada6tx04ialpsenmz17do(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABF3CU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABF3CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int C7fr24w32co7thbuc5d4c(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x90FCC0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x90FCC0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int F6rq1q5sgigq7zkc7teyb(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x90FDFFU, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x90FDFFU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int g6cgvn5lc2j4xdasqy0m9(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x910298U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x910298U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int sext589378ws1p2f3k5nu(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC85CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC85CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int vupn8m24y1wj31z7jskwo(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC827U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC827U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Gboef0cik4zf3m2oyjvtf(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC81CU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC81CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ufffmnz9046kai9tglihj(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AFB60U, new byte[] { 0x4F });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AFB60U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int hut3cqpq9ki961rj6i22b(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x90FB6CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x90FB6CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Pcsq8ofvnjinbojuvlc58(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEB11CU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEB11CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int tjapv6nj1zw7sqggcd5yl(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x310B0CU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x310B0CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int f4c0c58sr6xvg632cc4ba(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEFE18U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEFE18U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int q53xwk4vicsrpotdgkm08(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393E84U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E84U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int R525cb1wwne9j4xpapd1a(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xA857D0U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0xA857D0U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int gmkongf2mzw10dcfd8vvt(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD8480U, new byte[] { 0x41, 0x82 }); Form1.PS3.SetMemory(0x98871FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x2F0348U, new byte[] { 0x38, 0x80, 0, 1 }); PS3API ps = Form1.PS3; uint offset = 0x2F0398U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x80; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0xAD8480U, new byte[] { 0x40, 0x82 }); Form1.PS3.SetMemory(0x98871FU, new byte[1]); PS3API ps2 = Form1.PS3; uint offset2 = 0x2F0348U; byte[] array2 = new byte[4]; array2[0] = 0x38; array2[1] = 0x80; ps2.SetMemory(offset2, array2); Form1.PS3.SetMemory(0x2F0398U, new byte[] { 0x38, 0x80, 0, 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int si848siv0ed1hu0vunr66(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA996C8U, new byte[] { 0x4D });
            }
            else
            {
                Form1.PS3.SetMemory(0xA996C8U, new byte[] { 0x3D });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Z9j61njg1slb3sh2nqq57(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9A6DCU, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9A6DCU, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int jtbiw5ufmru0rzzu8ccui(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xFB4C5U, new byte[] { 0xE0, 0x58 });
            }
            else
            {
                Form1.PS3.SetMemory(0xFB4C5U, new byte[] { 0xE0, 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Zc4h2b7yn8hd7v8m7bk62(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2271B0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2271B0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Je3k7vte3w3lo5w5z3pu7(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x11ACCU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x11ACCU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int H52ojq261mx62f2ejujhs(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C6728U, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C6728U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int f350e6zb8cxdw096loaq2(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C67D8U, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C67D8U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int sxnq96tidswfuhceacjn1(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x2F });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C6880U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int O17yztkcg524t2p4po0im(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x1CC7E0U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Mq8qqrtox46jexzb0y0pv(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Mrchz1v12hywlbak2qiha(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x40, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Q5ol9tz5dod1xkw5o10y6(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x42, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CC7E0U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Z2wpfk8dxojjqtp0d0igc(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2258F8U, new byte[] { 0x4F, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2258F8U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int j0xoe78aof6azulij8gzu(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x225FA0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x225FA0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int swiye4ke561xtuvgeilil(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x11ADCU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x11ADCU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Q7yssit5hgreusvpr9jkw(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD66C0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD66C0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int I3esnirf8fdaw7nx7zf6k(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2271F4U, new byte[] { 0xFC, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2271F4U, new byte[] { 0xFC, 0x20 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int So7ypwca8gyf9bvs2gej0(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CCC2CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CCC2CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Lo7cdqswf7s13m9h6pc0f(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x6C0610U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x6C0610U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int org2q8bvm550v6g6r4v9e(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x6C0630U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x6C0630U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int uq5ax6lwcnvmdodjhfweo(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x245DF0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x245DF0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int G7kjc2g7gd0c4dvzwfetw(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x245E58U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x245E58U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Rps8jswg26ymiruhgv75z(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4A3FB8U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4A3FB8U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int kop8xtsa3oxbacr9ol9uf(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x51E558U, new byte[] { 0x2F, 0xA4 });
            }
            else
            {
                Form1.PS3.SetMemory(0x51E558U, new byte[] { 0x3F, 0xA4 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Saejoo3mtotahj4i9uk09(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x51E6A0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x51E6A0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int xwnnjxlg9v34vnzzjgujz(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEE434U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x393E34U, new byte[] { 0xCF, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x4F, 0x80 }); Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x2F, 0x80 }); Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F, 0x80 }); Form1.PS3.SetMemory(0xAEE434U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Wfqo5w30ij94ajusx090c(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEE434U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEE434U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Nxn8vyo4te839ba4g8sx3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2267B0U, new byte[] { 0x3F, 0x80 });
            }
            else { Form1.PS3.SetMemory(0x2267B0U, new byte[2]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int Yv80v94m2hcsg3gc2s3gi(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2267F0U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x2267F0U, new byte[] { 0x3F, 0x19 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int x8gdkg48i0myim7rzxnv4(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x2267F0U; byte[] array = new byte[2]; array[0] = 0x2F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x2267F0U, new byte[] { 0x3F, 0x19 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Xbcmcqxg58cxemo5o4ppe(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xABA948U, new byte[] { 0x42, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xABA948U, new byte[] { 0x42, 0x48 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int C5dc4nk36zmefhmg63b4s(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xABA948U, new byte[] { 0x44, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xABA948U, new byte[] { 0x42, 0x48 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int vxdkyyu67cd4i7r989syf(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB0229CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB0229CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int J3kfv7s6ai8u3u6q12nf3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA972B0U, new byte[2]);
            }
            else
            {
                Form1.PS3.SetMemory(0xA972B0U, new byte[] { 0x40, 0x49 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int no54vr6h0mi6lmzzn7z0f(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A409CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A409CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int dx5zdsbxbaifwm517puda(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B0094U, new byte[] { 0x7C, 0xA5, 0x10, 0x14 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4B0094U, new byte[] { 0x7C, 0xA5, 0x20, 0x14 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int olfxabir5hd3dwafsg0dq(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x41, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3E, 0x26 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int mjf0eck9q717nvz4rizcj(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x10E0C4U, new byte[] { byte.MaxValue, 0xE0, 0x18, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x10E0C4U, new byte[] { byte.MaxValue, 0xE0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Xu146ob9mzi1zrx1fps70(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98F50U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F50U, new byte[] { 0x3D });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int zja7pfpr6fykqx36rl3za(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA998U, new byte[] { 0x3E });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA998U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ulw0z9i688ycz1mat3o19(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AAA98U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AAA98U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ktcgb8kbx1j3v36pwjiq6(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x11ADCU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x11ADCU, new byte[] { 0x41 }); Form1.PS3.SetMemory(0x3ABDD0U, new byte[] { 0x3F, 0xEF });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int rst8rwuzl2my7c0qiqz0y(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA77CU, new byte[] { 0x3E, 0x27 }); Form1.PS3.SetMemory(0x233290U, new byte[] { byte.MaxValue }); Form1.PS3.SetMemory(0xAEBED4U, new byte[] { byte.MaxValue, byte.MaxValue }); Form1.PS3.SetMemory(0xB01BACU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA77CU, new byte[] { 0x3E, 0xD7 }); Form1.PS3.SetMemory(0x233290U, new byte[1]); Form1.PS3.SetMemory(0xAEBED4U, new byte[] { 0x3E, 0x80 }); Form1.PS3.SetMemory(0xB01BACU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Tgihy4q646nju75qaezoo(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4018U, new byte[] { 0xBF, 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4018U, new byte[] { 0x3E, 0xCC });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int gv05ov6tcqhfus1zkljwf(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x245C4CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x245C4CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int fy4opdd9hkqe1kmcqn3d8(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x30012AB3U, new byte[] { 3 });
            }
            else
            {
                Form1.PS3.SetMemory(0x30012AB3U, new byte[] { 4 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int h73ozhzbffgy4cjz0lplr(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x300136D3U, new byte[] { 2 });
            }
            else
            {
                Form1.PS3.SetMemory(0x300136D3U, new byte[] { 6 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int K6m29cojgzj6sfxh5qzhn(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9A6C8U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9A6C8U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int pc3cd1jybwmf8rwbvaow3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x51E558U, new byte[] { 0x4F });
            }
            else
            {
                Form1.PS3.SetMemory(0x51E558U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int yq5q5kfzpc4kvh7pdjzi3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9C2B4U, new byte[] { 0x3E, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9C2B4U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int lzitme8atvv4bco7gmg3v(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A7654U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A7654U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Nuj82bt0uh8llg3dile1m(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AD910U, new byte[] { 0xFC, 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AD910U, new byte[] { 0xFC, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int fef3q9it3ai0d5wjpj1kv(int toggle)
        {
            if (toggle == 1)
            {
               // Form1.PS3.SetMemory(0x3ABE18U, new byte[] { byte.MaxValue, 0x40 });
            }
            else
            {
               // Form1.PS3.SetMemory(0x3ABE18U, new byte[] { byte.MaxValue, 0x20 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int chqlwjt5jkz4iprroqr23(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AD388U, new byte[] { 0x2F });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AD388U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int l96t9iipuux8u3fey4ghq(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABDC8U, new byte[] { 0x3F });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABDC8U, new byte[] { 0xBF });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int lnjslnrxof4919rvl7mob(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x18CE4U, new byte[] { byte.MaxValue, 0xE0, 0x28, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x18CE4U, new byte[] { byte.MaxValue, 0xE0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Idkzw0kpjn3ujklq0oiv1(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD8320U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD8320U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int zubpzyhulu30r2fncu5vd(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9A6D8U, new byte[] { 0x4F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9A6D8U, new byte[] { 0x3F, 0xC0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Gbnalk0qya56z1wqc5a8t(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x245BE4U, new byte[] { byte.MaxValue, 0x60, 0x18, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x245BE4U, new byte[] { byte.MaxValue, 0x60, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Lzdzuccqe8ogsws0gado7(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD8110U, new byte[] { byte.MaxValue, 0xC0, 0xE0, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD8110U, new byte[] { byte.MaxValue, 0xC0, 0x10, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int l06lz6b0gzkhu7bn7yqji(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98FA4U, new byte[] { byte.MaxValue, 0xA0, 0x18, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98FA4U, new byte[] { byte.MaxValue, 0xA0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Sjmzwzocj6jb1va332axa(int toggle)
        {
            if (toggle == 1)
            {
                //Form1.PS3.SetMemory(0x3ABE28U, new byte[] { byte.MaxValue, 0x60, 0x88, 0x90 });
            }
            else
            {
                //Form1.PS3.SetMemory(0x3ABE28U, new byte[] { byte.MaxValue, 0x60, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Tlkpxgwuue2st3gyngyar(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98FA4U, new byte[] { byte.MaxValue, 0xA, 0x28, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98FA4U, new byte[] { byte.MaxValue, 0xA0, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int R8rjqjp86iuex2i786cpc(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4064U, new byte[] { byte.MaxValue, 0x40, 0x88, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4064U, new byte[] { byte.MaxValue, 0x40, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int p3ree0s7ompweagb3b9o1(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4064U, new byte[] { byte.MaxValue, 0x40, 0x28, 0x90 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4064U, new byte[] { byte.MaxValue, 0x40, 8, 0x90 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Jxymux40uj0rei7yrnfz0(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Vruu38axwgd77yypffuq5(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xEA89E2U, new byte[] { 0x18 });
            }
            else
            {
                Form1.PS3.SetMemory(0xEA89E2U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int P1mfw8r6druq5jxkddsvw(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x225E80U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x225E80U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int vheof2tqursl2y39eo85q(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x11B00U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x11B00U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Oeuewxbxanmbw83yw893o(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x226168U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x226168U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int bblv8jxhqyfyexfsw92s1(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA77CU, new byte[] { 0x3F });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA77CU, new byte[] { 0x3E });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int W5pgfry44emfpfqp29fma(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B00ACU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4B00ACU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int u4hmiy693lcxgrbtvfqru(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x2ADCE8U; byte[] array = new byte[4]; array[0] = 0x68; array[1] = 0x63; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x2ADCE8U, new byte[] { 0x68, 0x63, 0, 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int L2mllai9h0zw4pr7xd8ru(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3105F4U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3105F4U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int uzatbz88d63xty2hr5ahp(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABF88U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABF88U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int j71dvp219d5sh97422kwb(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x924FFU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x924FFU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int Pk5l6cdgwkp2c0bx878w6(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x92507U, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x92507U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int yh99alqt18pzvogfbqgsl(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3F, byte.MaxValue, 0, 1 }); Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x41, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3E, 0x26, 0xAD, 0x89 }); Form1.PS3.SetMemory(0x3ABD48U, new byte[] { 0x3E, 0x26 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ewezydpq7j644xz3k5kvw(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x65FB60U, new byte[] { 0x2D });
            }
            else
            {
                Form1.PS3.SetMemory(0x65FB60U, new byte[] { 0x3D });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ntpy40gxu6ws0pkjcjl65(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x65FB60U, new byte[] { 0x4D });
            }
            else
            {
                Form1.PS3.SetMemory(0x65FB60U, new byte[] { 0x3D });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Q9wrbu57zm4ffv61hp487(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB01EEFU, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0xB01EEFU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int L16axneonp1bunzw77wk5(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xFB55CU, new byte[] { 0x80 });
            }
            else
            {
                Form1.PS3.SetMemory(0xFB55CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Xi8hcqmftscwpn9ddw4yq(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xFB644U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xFB644U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Zqujv3v26j4j3ucz3y7hb(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xFB55CU, new byte[] { 0x45 });
            }
            else
            {
                Form1.PS3.SetMemory(0xFB55CU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int L855nevgovskd83oyzwj4(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4A3D99U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4A3D99U, new byte[] { 0x20 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Jujjx235kkkpywwruz5rh(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB52100U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0xB52100U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Xook0ug40ybebymqzwhvk(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x22C85AU, new byte[] { 0x28 });
            }
            else
            {
                Form1.PS3.SetMemory(0x22C85AU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int S06dldvqlm383fcpg8sdv(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB21C96U, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB21C96U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int X9ewjgnakg28rkgrsk8x8(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB259DEU, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB259DEU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Bzso4ck6w6k0dd9lvj4fz(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1D3BF2U, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1D3BF2U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Vvgfu5rt8u7694f6q01g5(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4A36U, new byte[] { 0x48 }); Form1.PS3.SetMemory(0x3A7BB6U, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4A36U, new byte[] { 8 }); Form1.PS3.SetMemory(0x3A7BB6U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int pron5b4ok55ip38mtn49u(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4668B6U, new byte[] { 0x58 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4668B6U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int f17b9o0j8d44sxkhh2ksa(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7151AAU, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7151AAU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Mcidzyqg62nd61wdumoqk(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x79E326U, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0x79E326U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ovqhaa01t0f0cl9rt4ll7(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x79E8DEU, new byte[] { 0x58 });
            }
            else
            {
                Form1.PS3.SetMemory(0x79E8DEU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int cumfz180bhx4o3hpwbcy7(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD6172U, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD6172U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int qzwgxwau2etzbdt0jkrjc(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x5BF34EU, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0x5BF34EU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int a9zmclmjet5s2wni7fsd1(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9B23EU, new byte[] { 0x48 }); Form1.PS3.SetMemory(0xA9B986U, new byte[] { 0x58 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9B23EU, new byte[] { 8 }); Form1.PS3.SetMemory(0xA9B986U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int en87x83kkrflt3w79kdlk(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9B23EU, new byte[] { 0x48 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9B23EU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int W1qiib7ozk3d2oryb1yes(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAA1B76U, new byte[] { 0x28 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAA1B76U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Kb9xnt88apiwbg2a6zyvb(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x98871FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x98871FU, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int Rov9xcsfl76hv93i134zc(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x98871FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x393E34U, new byte[] { byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x98871FU, new byte[1]); Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int P8nkcgbwvr1mddddq99la(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ABD49U, new byte[] { 0x86 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ABD49U, new byte[] { 0x26 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int b3xctaacmtic49tcal7ra(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x22C7FCU, new byte[] { 0x50 });
            }
            else
            {
                Form1.PS3.SetMemory(0x22C7FCU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int X6t3gtes6z224tzjkl0bf(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4668B6U, new byte[] { 0x78 });
            }
            else
            {
                Form1.PS3.SetMemory(0x4668B6U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int O9kbjyreuacfcrkej3696(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0x393E34U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ssfw1piljj2zu6mbwsurc(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x246A2CU, new byte[] { byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0x246A2CU, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ta85xxzniv9rp1ew3xk3q(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4668B6U, new byte[] { 0x78 }); Form1.PS3.SetMemory(0x4668B6U, new byte[] { 0x78 }); Form1.PS3.SetMemory(0x4668B6U, new byte[] { 8 }); Form1.PS3.SetMemory(0x4668B6U, new byte[] { 8 });
            }
            else { } if (toggle == 1) return 0; else return 1;
        }
        public int ig4kinugfjs1ip75tj9e0(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2267B0U, new byte[] { 0x3F, 0xF0 });
            }
            else { Form1.PS3.SetMemory(0x2267B0U, new byte[4]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int C4cyklk31zh8h1a5gyxkc(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB22050U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB22050U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Wti8dhia3iduxgdvdfa7d(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB24177U, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0xB24177U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int J1ppcttrobz5wzbgwevcc(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98A91U, new byte[] { 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98A91U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ujaswxlbxo2ax0gle26tx(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA98A95U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98A95U, new byte[] { 0x30 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int S0v1sh88f699t843063pi(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x98871FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x98871FU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int vs3ajzi5szc3hbomyi9pz(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA68148U, new byte[] { 0x4F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xA68148U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Zm61p3qz6nuh9qlf6us39(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAF10A8U, new byte[] { 0x38, 0x60, 0, 1 });
            }
            else { PS3API ps = Form1.PS3; uint offset = 0xAF10A8U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x60; ps.SetMemory(offset, array); } if (toggle == 1) return 0; else return 1;
        }
        public int ucpp4f1sures7o05wcvqi(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD14ECU, new byte[] { 0xBF, 0xF }); Form1.PS3.SetMemory(0xAD0274U, new byte[] { 0xBF, 0x23 }); Form1.PS3.SetMemory(0xAD8158U, new byte[] { 0x4C }); Form1.PS3.SetMemory(0xB01DECU, new byte[] { 0x40, 0x82 }); Form1.PS3.SetMemory(0x3097C8U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3097B8U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x90B5F0U, new byte[] { 0x38, 0x80, 0, 1 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x3F, byte.MaxValue }); Form1.PS3.SetMemory(0x227BDCU, new byte[] { 0x40 }); Form1.PS3.CCAPI.Notify(CCAPI.NotifyIcon.CAUTION, "Ultimatecraft Notification\nLabymod ON");
            }
            else { Form1.PS3.SetMemory(0xAD14ECU, new byte[] { 0x3F, 0xF }); Form1.PS3.SetMemory(0xAD0274U, new byte[] { 0x3F, 0x23 }); Form1.PS3.SetMemory(0xAD8158U, new byte[] { 0x2C }); Form1.PS3.SetMemory(0xB01DECU, new byte[] { 0x41, 0x82 }); Form1.PS3.SetMemory(0x3097C8U, new byte[] { 0x41 }); Form1.PS3.SetMemory(0x3097B8U, new byte[] { 0x41 }); PS3API ps = Form1.PS3; uint offset = 0x90B5F0U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x80; ps.SetMemory(offset, array); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x3F, 0x80 }); Form1.PS3.SetMemory(0x227BDCU, new byte[] { 0x41 }); Form1.PS3.CCAPI.Notify(CCAPI.NotifyIcon.CAUTION, "Ultimatecraft Notification\nLabymod OFF"); } if (toggle == 1) return 0; else return 1;
        }
        public int us8fe441ziqe0fpw7q6jb(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB50B32U, new byte[] { 0x58 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB50B32U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int F8fpicku0qt39bvqdkkak(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB5A62EU, new byte[] { 0x98 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB5A62EU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int f92lba218d7fglojnt6ct(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB5A62EU, new byte[] { 0xC8 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB5A62EU, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int mjajzwfyu9swf68bg3nij(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5B7AU, new byte[] { 0xD0 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5B7AU, new byte[] { 0xC0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ctwwsnxxxlctniqb8swo4(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A3FF0U, new byte[] { 0x20 });
            }
            else { Form1.PS3.SetMemory(0x3A3FF0U, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int reh9vk9knmcugx2axo0l9(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x3A3FF0U; byte[] array = new byte[2]; array[0] = byte.MaxValue; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x3A3FF0U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int tsai69j7p7cxh9nfmxbhn(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x41 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x6F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int snjljsn0pqnu2komd8cvb(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x41 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { byte.MaxValue, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int lc4pjomgjxyans7wiz9nv(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x987502U, new byte[] { 0x68 });
            }
            else
            {
                Form1.PS3.SetMemory(0x987502U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int qtr9us57ubbnupfls4c4g(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x987502U, new byte[] { 0xF8 });
            }
            else
            {
                Form1.PS3.SetMemory(0x987502U, new byte[] { 8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int igq22ngjm1eo9yasu550t(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x39E2D4U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x39E2D4U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int P66yhadkru3utheugyqnq(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x43E9F7U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x43E9F7U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Rwu26wn5ox1x9ll0vhgr6(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEBED4U, new byte[] { 0xBE });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEBED4U, new byte[] { 0x3E });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ti6zx014rvp4yxo642m97(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAECF10U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAECF10U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int outz5qol4q35tzkdz5ef5(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xA98F50U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array); Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x41 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x6F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F50U, new byte[] { 0x3D, 0x8C }); Form1.PS3.SetMemory(0xAD5B60U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0xAD5A5CU, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Utn2h68l6o524gumyg4hm(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AE03U, new byte[] { 1 }); Form1.PS3.SetMemory(0x233290U, new byte[] { byte.MaxValue }); Form1.PS3.SetMemory(0xB25998U, new byte[] { 0x41 }); Form1.PS3.SetMemory(0xB25A59U, new byte[] { 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AE03U, new byte[1]); Form1.PS3.SetMemory(0x233290U, new byte[1]); Form1.PS3.SetMemory(0xB25998U, new byte[] { 0x40 }); Form1.PS3.SetMemory(0xB25A59U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int hqaa2tk9nlg9xgeog0s8s(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x393F8FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x393F8FU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int ddopuabme7ota73osnaxw(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xA98F50U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F50U, new byte[] { 0x3D, 0x8C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int y87vh6eycgf7y6yibup1s(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xA98F50U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F50U, new byte[] { 0x3D, 0x8C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int w74p6x90mz5304mtf3iy5(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xA98F50U; byte[] array = new byte[2]; array[0] = 0x3F; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0xA98F50U, new byte[] { 0x3D, 0x8C });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int wmk82r4eivn87ifyerzt7(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x8FC4B4U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x8FC4B4U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Colnlmh4tfcil06fx5xp3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2F0273U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x2F0273U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int x4r1l65szypxdz1rb6xpj(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x979BCFU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x979BCFU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int qaudsfwgm9ai4k0c7ucor(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xE0F90U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0xE0F90U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Dyf50pew9oe1ihf3jnifj(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x884148U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x884148U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int kygzyg338ztr4i8u4zndb(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2FE98BU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x2FE98BU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int V9h75j9wf62tl6e2sphtv(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2FE983U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x2FE983U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int flxk5w69ju8uafekrj3og(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA73854U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA73854U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Lgxc69g8efcos3rzl7cim(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA9C2B4U, new byte[] { 0x3F, byte.MaxValue });
            }
            else
            {
                Form1.PS3.SetMemory(0xA9C2B4U, new byte[] { 0x3F, 0x80 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int vanu7itf14ljv2mpxvn5q(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA73878U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA73878U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int M85dstbgxo8thvcg3deyq(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x217DCFU, new byte[] { 8 });
            }
            else { Form1.PS3.SetMemory(0x217DCFU, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int Qagj4220rcc0tg1nfjcog(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x428704U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x428704U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int pmrn51cazgvuryoq2vjz0(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x108ACU, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x108ACU, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ilzvmi9a3zbtb0ses2ncz(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x218A4FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x218A4FU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int w2bkqsj52lutamx5w6bx1(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x218A4FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x218A4FU, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int Vch9fcs0gj79hh98kpe39(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x234F9FU, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x234F9FU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int yehrerszcwsw1zkxubfn9(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB0142BU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0xB0142BU, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int kszsoul3myvh1hyx4z5xt(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A74F3U, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x3A74F3U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int H3yt1lir6mnij03roydtf(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA89AC8U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA89AC8U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int aznobl4ubw35gr4g3g1dm(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xA8919DU, new byte[] { 0xF0 }); Form1.PS3.SetMemory(0xA891A1U, new byte[] { 0xF0 });
            }
            else
            {
                Form1.PS3.SetMemory(0xA8919DU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0xA891A1U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int V469km7anhifwls3qjrpq(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB018D0U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB018D0U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ixqktsc16xxi6agl3ndzn(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A3F6CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A3F6CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int l3g4oxi49a0uymwznwq1j(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x218A4FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x218A4FU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int Xfe0uaiwegacf2bwrw55j(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C90D4U, new byte[] { 0x32, 0x20, 0x8D, 0xA0 });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C90D4U, new byte[] { 0x32, 0x1E, 0xAD, 0xA0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int kh157ctunr7h6lpizqjno(int toggle)
        {
            if (toggle == 1)
            {
                //Form1.PS3.SetMemory(0x1D7FCCU, new byte[] { 0x40 });
            }
            else
            {
               // Form1.PS3.SetMemory(0x1D7FCCU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Xw03axo6kah10urboi2rq(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3B000AU, new byte[] { 2 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3B000AU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Qyjwi2f4m37amrrxr85jy(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x151F2F0U, new byte[] { 0x30, 1, 0x87, 0xF0 });
            }
            else
            {
                Form1.PS3.SetMemory(0x151F2F0U, new byte[] { 0x30, 1, 0x87, 0xF8 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Jwjmjgrm4o3qx270neuhs(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB520F7U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0xB520F7U, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int huurchoid4upmt23o6mcl(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2341D0U, new byte[] { 0xC3 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2341D0U, new byte[] { 0xC0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int p3979qmuu0jnny1ec2kc1(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x39DE28U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x39DE28U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Nii94nde9emr1s5yuwrw4(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x39F52FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x39F52FU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int p4ymvgcy2y1wvkkduadvm(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C9048U, new byte[] { 0x32, 0x3A, 0x84, 0xC0 });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C9048U, new byte[] { 0x32, 0x39, 0x4B, 0xD0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int xiuqo1v42cupkxh7u6oxl(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAE3C3FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0xAE3C3FU, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int dpllmz5ri2ets6jwkh73v(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x39F587U, new byte[] { 1 });
            }
            else
            {
                Form1.PS3.SetMemory(0x39F587U, new byte[] { 0x14 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int xh60dll8cnsywqk76idy6(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x39F587U, new byte[1]);
            }
            else
            {
                Form1.PS3.SetMemory(0x39F587U, new byte[] { 0x14 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int rew98a6oovwm8ubdsvhbo(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B5DF3U, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x4B5DF3U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int H7o4kp7bwmzcej6qv61do(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4B5DF3U, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BB9DFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BBACFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BBBBFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BBCAFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BBD9FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BBEEFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC07FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC16FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC25FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC34FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC43FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC52FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC61FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC70FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC75FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC84FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BC93FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BCA2FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BCB1FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BCC0FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BCCFFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BCE8FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BCF7FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD06FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD15FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD24FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD33FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD42FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD51FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD6BFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD7AFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD89FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BD98FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BDA7FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BDB6FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BDC5FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BDD4FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BDE3FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BDF2FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE01FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE10FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE1FFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE2EFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE3DFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE4DFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE5CFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE6BFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE7AFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE89FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BE98FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BEA7FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BEB6FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BEC5FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BED4FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BEE3FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BEF2FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF01FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF10FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF1FFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF2EFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF3DFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF4CFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF5BFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF6AFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF79FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF88FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BF8DFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BFA0FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BFAFFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BFBEFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BFCDFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323BFDCFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323F1EEFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323F1F3FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FBEEFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FBFDFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC0CFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC1BFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC2AFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC39FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC48FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC57FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC66FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC75FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC84FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FC93FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCA2FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCB1FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCC0FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCCFFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCDEFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCEDFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FCFCFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD0BFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD1AFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD29FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD47FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD66FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD75FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x323FD84FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32412D8FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32414C5FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32414D4FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32414E3FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32414F2FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241501FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241525FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241534FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241543FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241552FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241561FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241570FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x324157FFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x324158EFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x324159DFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32415ACFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32415FDFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x324160CFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x324161BFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x324162AFU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241639FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241648FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241657FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241666FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241684FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32416B1FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x32416C0FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241710FU, new byte[] { 0x40 }); Form1.PS3.SetMemory(0x3241D95FU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x323BB9DFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BBACFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BBBBFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BBCAFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BBD9FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BBEEFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC07FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC16FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC25FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC34FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC43FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC52FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC61FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC70FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC75FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC84FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BC93FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BCA2FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BCB1FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BCC0FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BCCFFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BCE8FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BCF7FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD06FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD15FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD24FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD33FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD42FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD51FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD6BFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD7AFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD89FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BD98FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BDA7FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BDB6FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BDC5FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BDD4FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BDE3FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BDF2FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE01FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE10FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE1FFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE2EFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE3DFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE4DFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE5CFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE6BFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE7AFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE89FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BE98FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BEA7FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BEB6FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BEC5FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BED4FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BEE3FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BEF2FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF01FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF10FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF1FFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF2EFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF3DFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF4CFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF5BFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF6AFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF79FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF88FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BF8DFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BFA0FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BFAFFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BFBEFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BFCDFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323BFDCFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323F1EEFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323F1F3FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FBEEFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FBFDFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC0CFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC1BFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC2AFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC39FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC48FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC57FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC66FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC75FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC84FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FC93FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCA2FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCB1FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCC0FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCCFFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCDEFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCEDFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FCFCFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD0BFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD1AFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD29FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD47FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD66FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD75FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x323FD84FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32412D8FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32414C5FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32414D4FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32414E3FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32414F2FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241501FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241525FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241534FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241543FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241552FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241561FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241570FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x324157FFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x324158EFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x324159DFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32415ACFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32415FDFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x324160CFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x324161BFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x324162AFU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241639FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241648FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241657FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241666FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241684FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32416B1FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x32416C0FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241710FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x3241D95FU, new byte[] { 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int o7tr0f0bpgolack801zsd(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x324193B9U, new byte[] { 8 });
            }
            else { Form1.PS3.SetMemory(0x324193B9U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int i52c5uizyvsv3ewrn6dey(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x324193B9U, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x324193B9U, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int R5wp7nbc8704hi9tervg7(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2C0D98U, new byte[] { 0x3B, 0xA0, 0, 1 });
            }
            else { PS3API ps = Form1.PS3; uint offset = 0x2C0D98U; byte[] array = new byte[4]; array[0] = 0x3B; array[1] = 0xA0; ps.SetMemory(offset, array); } if (toggle == 1) return 0; else return 1;
        }
        public int Vbn3y2r5p2v3xv3iimess(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2C2948U, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0x2C2948U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Og004yovfcm6k7gxs21e6(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x4B2468U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x60; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x4B2468U, new byte[] { 0x38, 0x60, 0, 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int hgwgm6gvo1l2mdx1lx8ao(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1CDB98U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1CDB98U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x71 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int q60nqytzpg0pvavmtun8r(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x23B240U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x23B240U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x21 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int d2go1ttgkom430zapjzyn(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x237BC8U, new byte[] { 0x38, 0x60, 0, 1 });
            }
            else { PS3API ps = Form1.PS3; uint offset = 0x237BC8U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x60; ps.SetMemory(offset, array); } if (toggle == 1) return 0; else return 1;
        }
        public int Rqgia6hmskh1jasvzlw6f(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x39F548U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x39F548U, new byte[] { 0xF8, 0x21, 0xFE, 0xE1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Hmpa45v4kv6k4zvbw7n5m(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A9350U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A9350U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x91 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int jgy9gvu3iekew2saafofk(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A52B8U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A52B8U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int wnc6n76upr9180t8xq3jk(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x90FA30U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x90FA30U, new byte[] { 0xF8, 0x21, 0xF5, 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int T2wgl2xbguaqthu9e2vjy(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A52B0U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else { PS3API ps = Form1.PS3; uint offset = 0x3A52B0U; byte[] array = new byte[4]; array[0] = 0x3F; array[1] = 0x80; ps.SetMemory(offset, array); } if (toggle == 1) return 0; else return 1;
        }
        public int Vao0esf5iunumf5s16vvj(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3B30A8U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3B30A8U, new byte[] { 0xF8, 0x21, 0xFE, 0xB1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int x4o4rti0gu354tukn5b3w(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3B3008U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3B3008U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x91 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int V12whqdombiigaa3vtjvj(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA964U, new byte[] { 0x3F, 0x7C, 0xCC, 0xCD });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA964U, new byte[] { 0x3F, 0x4C, 0xCC, 0xCD });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Xpzy0rz2uuf5428rc1xbp(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AA940U, new byte[] { 0x3F, 0xF4, 0x7A, 0xE1 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AA940U, new byte[] { 0x3F, 0xBA, 0xCC, 0xCD });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int a3nelvy4s0y3wqthce6z0(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A9FE8U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A9FE8U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Nl326moobt146hfqbumf3(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A8678U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A8678U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x91 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int R4j36ljoi1p857keavh9h(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x2379E4U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x60; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x2379E4U, new byte[] { 0x38, 0x60, 0, 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Zj29946okdfr1165b96vd(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x22FDC8U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x22FDC8U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x11 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int G9gke3997bppnn7tbk4bo(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x22CE40U; byte[] array = new byte[4]; array[0] = 0x48; array[1] = byte.MaxValue; ps.SetMemory(offset, array);
            }
            else { PS3API ps2 = Form1.PS3; uint offset2 = 0x22CE40U; byte[] array2 = new byte[4]; array2[0] = 0x40; array2[1] = 0x48; ps2.SetMemory(offset2, array2); } if (toggle == 1) return 0; else return 1;
        }
        public int g4dfv7gdbodazw5hds5g5(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C89FCU, new byte[] { 0x32, 0x18, 0x11, 0xC0 });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C89FCU, new byte[] { 0x32, 0x18, 0x5E, 0x70 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int T7rjx0dn3m41f4hi6azgw(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A4A3CU, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A4A3CU, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int M57s7p01s0qtoygqn3s53(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1550AA0U, new byte[] { 0x30, 0xAF, 0x25, 0xB8 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1550AA0U, new byte[] { 0x30, 0xAF, 0x23, 0x10 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int x2kzul45owkc3zt9a8lha(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x1550AA0U, new byte[] { 0x30, 0xAF, 0x21, 0xA8 });
            }
            else
            {
                Form1.PS3.SetMemory(0x1550AA0U, new byte[] { 0x30, 0xAF, 0x23, 0x10 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Wm5c5kmqx04cs3m3ui8wu(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB0143FU, new byte[] { 0xF });
            }
            else
            {
                Form1.PS3.SetMemory(0xB0143FU, new byte[] { 0xE });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int h4m5qo0yegqpsk5r7i3k8(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x224FD4U, new byte[] { 0xC3 }); Form1.PS3.SetMemory(0x224FD8U, new byte[] { 0x43 });
            }
            else
            {
                Form1.PS3.SetMemory(0x224FD4U, new byte[] { 0xC2 }); Form1.PS3.SetMemory(0x224FD8U, new byte[] { 0x42 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Xnhy1hu9nzp1azxfaavrt(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D75A3U, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x7D75A3U, new byte[1]); } 
            if (toggle == 1) return 0; else return 1;
        }
        public int Txmqkpui856moxxgwydi4(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAED18FU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0xAED18FU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int L1lp1yo2xzr6wl0kb1nmw(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D75FFU, new byte[] { 1 });
            }
            else { Form1.PS3.SetMemory(0x7D75FFU, new byte[1]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int klar2dmmcqsl6nx2m7ywa(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3241B6B4U, new byte[] { 0x32, 0x1B, 0xB4, 0x20 }); Form1.PS3.SetMemory(0x3241B7A4U, new byte[] { 0x32, 0x1B, 0xB7, 0xF0 }); Form1.PS3.SetMemory(0x3241B894U, new byte[] { 0x32, 0x1D, 0x45, 0x90 }); Form1.PS3.SetMemory(0x3241B984U, new byte[] { 0x32, 0x1D, 0x9B, 0x10 }); Form1.PS3.SetMemory(0x3241BA74U, new byte[] { 0x32, 0x1D, 0x9D, 0xE0 }); Form1.PS3.SetMemory(0x3241BB64U, new byte[] { 0x32, 0x1D, 0x70, 0 }); Form1.PS3.SetMemory(0x3241BC54U, new byte[] { 0x32, 0x20, 0x8D, 0xA0 }); Form1.PS3.SetMemory(0x3241BD44U, new byte[] { 0x32, 0x1B, 0xE3, 0xA0 }); Form1.PS3.SetMemory(0x3241BE34U, new byte[] { 0x32, 0x1B, 0xE9, 0xF0 }); Form1.PS3.SetMemory(0x3241BF24U, new byte[] { 0x32, 0x1B, 0xEC, 0xE0 }); Form1.PS3.SetMemory(0x3241C014U, new byte[] { 0x32, 0x1B, 0xEF, 0xD0 }); Form1.PS3.SetMemory(0x3241C104U, new byte[] { 0x32, 0x1B, 0xF2, 0xC0 }); Form1.PS3.SetMemory(0x3241B3D4U, new byte[] { 0x32, 0x1B, 0xF5, 0x10 }); Form1.PS3.SetMemory(0x3241B284U, new byte[] { 0x32, 0x1B, 0xF7, 0x60 }); Form1.PS3.SetMemory(0x3241B134U, new byte[] { 0x32, 0x1B, 0xF9, 0xB0 }); Form1.PS3.SetMemory(0x3241AFE4U, new byte[] { 0x32, 0x1B, 0xFC, 0 }); Form1.PS3.SetMemory(0x3241AE94U, new byte[] { 0x32, 0x1B, 0xFE, 0x50 }); Form1.PS3.SetMemory(0x3241AD44U, new byte[] { 0x32, 0x1C, 0, 0xA0 }); Form1.PS3.SetMemory(0x3241ABF4U, new byte[] { 0x32, 0x1C, 0x84, 0xF0 }); Form1.PS3.SetMemory(0x3241AAA4U, new byte[] { 0x32, 0x1C, 0x89, 0x90 }); Form1.PS3.SetMemory(0x3241A954U, new byte[] { 0x32, 0x1D, 0x2B, 0x90 }); Form1.PS3.SetMemory(0x3241A804U, new byte[] { 0x32, 0x1D, 0xA7, 0xA0 }); Form1.PS3.SetMemory(0x3241A6B4U, new byte[] { 0x32, 0x1D, 0xC0, 0x70 }); Form1.PS3.SetMemory(0x3241A564U, new byte[] { 0x32, 0x1E, 0x8D, 0x20 }); Form1.PS3.SetMemory(0x3241A414U, new byte[] { 0x32, 0x1E, 0x8F, 0x70 }); Form1.PS3.SetMemory(0x3241A2C4U, new byte[] { 0x32, 0x1E, 0x91, 0xC0 }); Form1.PS3.SetMemory(0x3241A174U, new byte[] { 0x32, 0x1E, 0x94, 0x10 }); Form1.PS3.SetMemory(0x3241A024U, new byte[] { 0x32, 0x1E, 0x96, 0x60 }); Form1.PS3.SetMemory(0x32419ED4U, new byte[] { 0x32, 0x1E, 0x98, 0xB0 }); Form1.PS3.SetMemory(0x32419D84U, new byte[] { 0x32, 0x20, 0x8F, 0xF0 }); Form1.PS3.SetMemory(0x324199F4U, new byte[] { 0x32, 0x1B, 0xC1, 0x60 }); Form1.PS3.SetMemory(0x324198A4U, new byte[] { 0x32, 0x1B, 0xDA, 0x60 }); Form1.PS3.SetMemory(0x32419754U, new byte[] { 0x32, 0x1B, 0xDC, 0xB0 }); Form1.PS3.SetMemory(0x32419604U, new byte[] { 0x32, 0x1B, 0xDF, 0 }); Form1.PS3.SetMemory(0x324194B4U, new byte[] { 0x32, 0x1F, 0xB4, 0xC0 }); Form1.PS3.SetMemory(0x32419364U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419214U, new byte[] { 0x32, 0x20, 0xB, 0xE0 }); Form1.PS3.SetMemory(0x324190C4U, new byte[] { 0x32, 0x20, 0x32, 0x80 }); Form1.PS3.SetMemory(0x32418F74U, new byte[] { 0x32, 0x20, 0x64, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3241B6B4U, new byte[] { 0x32, 0x1E, 0x58, 0x70 }); Form1.PS3.SetMemory(0x3241B7A4U, new byte[] { 0x32, 0x1E, 0x5B, 0x30 }); Form1.PS3.SetMemory(0x3241B894U, new byte[] { 0x32, 0x1E, 0x5D, 0xA0 }); Form1.PS3.SetMemory(0x3241B984U, new byte[] { 0x32, 0x1E, 0x60, 0x10 }); Form1.PS3.SetMemory(0x3241BA74U, new byte[] { 0x32, 0x1E, 0x62, 0x80 }); Form1.PS3.SetMemory(0x3241BB64U, new byte[] { 0x32, 0x1E, 0x64, 0xF0 }); Form1.PS3.SetMemory(0x3241BC54U, new byte[] { 0x32, 0x1E, 0x67, 0x60 }); Form1.PS3.SetMemory(0x3241BD44U, new byte[] { 0x32, 0x1E, 0x69, 0xD0 }); Form1.PS3.SetMemory(0x3241BE34U, new byte[] { 0x32, 0x1E, 0x6C, 0x40 }); Form1.PS3.SetMemory(0x3241BF24U, new byte[] { 0x32, 0x1E, 0x6E, 0xB0 }); Form1.PS3.SetMemory(0x3241C014U, new byte[] { 0x32, 0x21, 3, 0x60 }); Form1.PS3.SetMemory(0x3241C104U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241B3D4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241B284U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241B134U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241AFE4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241AE94U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241AD44U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241ABF4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241AAA4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A954U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A804U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A6B4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A564U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A414U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A2C4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A174U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x3241A024U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419ED4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419D84U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x324199F4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x324198A4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419754U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419604U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x324194B4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419364U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32419214U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x324190C4U, new byte[] { 0x32, 0x20, 1, 0xC0 }); Form1.PS3.SetMemory(0x32418F74U, new byte[] { 0x32, 0x20, 1, 0xC0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int E2uioazd7me5k1vs04wyl(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAED18FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x98871FU, new byte[] { 1 }); Form1.PS3.SetMemory(0x7D75A3U, new byte[] { 1 }); Form1.PS3.SetMemory(0x7D767CU, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAED18FU, new byte[1]); Form1.PS3.SetMemory(0x98871FU, new byte[1]); Form1.PS3.SetMemory(0x7D75A3U, new byte[] { 1 }); Form1.PS3.SetMemory(0x7D767CU, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Nczhhfajy78ec1l411d2n(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D79D0U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7D79D0U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Jjo0lxbe1fbrkak8cnbj9(int toggle)
        {
            if (toggle == 1)
            {
                MessageBox.Show("You will take damage for are in god mode, don't move and wait !", "How to use ?", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x14C93F0U, new byte[] { 0x32, 0x1C, 0xA, 0x60 });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C93F0U, new byte[] { 0x32, 0x20, 0xA4, 0xF0 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Bqpana2tq10803kbx95ud(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D86A0U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7D86A0U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int p5ss5r3cqn1n04374onl4(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAF1EE0U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAF1EE0U, new byte[] { 0xF8, 0x21, 0xFD, 0x21 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Esy9oc1r0jkdrrfe76e6g(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x4A0A60U, new byte[] { 0x38, 0x60, 0, 1 });
            }
            else { PS3API ps = Form1.PS3; uint offset = 0x4A0A60U; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x60; ps.SetMemory(offset, array); }
            if (toggle == 1) return 0; else return 1;
        }
        public int H0cdami5anhjvuzvhtd2z(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C93D8U, new byte[] { 0x32, 0x1C, 0xA, 0x60 });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C93D8U, new byte[] { 0x32, 0x20, 0x94, 0x50 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Bllhcx5jzy98jreepu8b4(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3AF338U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3AF338U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x71 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int u5rmcbs71t7o2lg4o4anr(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3ACF00U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3ACF00U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x71 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int t9glni9epvgwub8348fbf(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x7D8B0CU; byte[] array = new byte[4]; array[0] = 0x4F; array[1] = 0x80; ps.SetMemory(offset, array);
            }
            else { Form1.PS3.SetMemory(0x7D8B0CU, new byte[4]); }
            if (toggle == 1) return 0; else return 1;
        }
        public int S8rf1uf7kkzuuvu4zg93b(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x7DC3BCU; byte[] array = new byte[4]; array[0] = 0x38; array[1] = 0x60; ps.SetMemory(offset, array);
            }
            else
            {
                Form1.PS3.SetMemory(0x7DC3BCU, new byte[] { 0x38, 0x60, 0, 1 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Pnsgnk40nmapz9issat2d(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAACEDCU, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAACEDCU, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x71 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int hb3f5vc8qdey9m91qk2r0(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D7AA0U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7D7AA0U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x71 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Mou7kk5uncmzxhzauml2i(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0xB21C60U; byte[] array = new byte[4]; array[0] = 0x40; array[1] = 0xD7; ps.SetMemory(offset, array);
            }
            else { PS3API ps2 = Form1.PS3; uint offset2 = 0xB21C60U; byte[] array2 = new byte[4]; array2[0] = 0x40; array2[1] = 0x30; ps2.SetMemory(offset2, array2); } if (toggle == 1) return 0; else return 1;
        }
        public int O6kkimqnaqciiccyr55u0(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xB2437CU, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0xB2437CU, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x71 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Truo1ob2w9gd8ai3ekz84(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAFB458U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAFB458U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x11 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Qru69eruebtyr0b1m5t3k(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C89FCU, new byte[] { 0x32, 0x18, 0x14, 0x70 });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C89FCU, new byte[] { 0x32, 0x18, 0x5E, 0x70 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Tx1bk8jh3iuhg70i7xpx7(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D8FB8U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7D8FB8U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Zqxvpswh8rrj05xg0twa4(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D88C0U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7D88C0U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Dj15qmrta33yq554afv1m(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2335C8U, new byte[] { 0xD3, 0x23, 1, 0x30 }); Form1.PS3.SetMemory(0x2335CCU, new byte[] { 0xD8, 0x43, 1, 0x38 }); Form1.PS3.SetMemory(0x2335D0U, new byte[] { 0xD3, 0x63, 1, 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2335C8U, new byte[] { 0xD8, 0x23, 1, 0x30 }); Form1.PS3.SetMemory(0x2335CCU, new byte[] { 0xD8, 0x43, 1, 0x38 }); Form1.PS3.SetMemory(0x2335D0U, new byte[] { 0xD8, 0x63, 1, 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int jcjm1lqlkusnao2yz1edb(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x2335C8U, new byte[] { 0xD9, 0x23, 1, 0x30 }); Form1.PS3.SetMemory(0x2335CCU, new byte[] { 0xD8, 0x43, 1, 0x38 }); Form1.PS3.SetMemory(0x2335D0U, new byte[] { 0xD9, 0x63, 1, 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0x2335C8U, new byte[] { 0xD8, 0x23, 1, 0x30 }); Form1.PS3.SetMemory(0x2335CCU, new byte[] { 0xD8, 0x43, 1, 0x38 }); Form1.PS3.SetMemory(0x2335D0U, new byte[] { 0xD8, 0x63, 1, 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int achfx23592gu75y19oef6(int toggle)
        {
            if (toggle == 1)
            {
                PS3API ps = Form1.PS3; uint offset = 0x51E0D0U; byte[] array = new byte[4]; array[0] = 0x42; array[1] = 0x80; ps.SetMemory(offset, array);
            }
            else { PS3API ps2 = Form1.PS3; uint offset2 = 0x51E0D0U; byte[] array2 = new byte[4]; array2[0] = 0x40; array2[1] = 0x80; ps2.SetMemory(offset2, array2); }
            if (toggle == 1) return 0; else return 1;
        }
        public int ifjpkpybchfibr0j4dy9s(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x912D08U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x912D08U, new byte[] { 0xF8, 0x21, 0xFE, 0x51 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ivmro7qf0bykx9h5314hd(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0xAEFA74U, new byte[] { 0x40 });
            }
            else
            {
                Form1.PS3.SetMemory(0xAEFA74U, new byte[] { 0x41 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int C122w7tpfo65zexk31bn9(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x14C6728U, new byte[] { 0xBF });
            }
            else
            {
                Form1.PS3.SetMemory(0x14C6728U, new byte[] { 0x3F });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int ytlbs5ubk5qdjr502u4qn(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x3A7654U, new byte[] { 0x41 });
            }
            else
            {
                Form1.PS3.SetMemory(0x3A7654U, new byte[] { 0x40 });
            }
            if (toggle == 1) return 0; else return 1;
        }
        public int Ja9le2usm6bb0rhuq0j1m(int toggle)
        {
            if (toggle == 1)
            {
                Form1.PS3.SetMemory(0x7D7984U, new byte[] { 0x4E, 0x80, 0, 0x20 });
            }
            else
            {
                Form1.PS3.SetMemory(0x7D7984U, new byte[] { 0xF8, 0x21, byte.MaxValue, 0x81 });
            }
            if (toggle == 1) return 0; else return 1;
        }

        #endregion
        #region bool2
        public int Qrfk83wij7rj6v99t970k(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int Kczn3on2jljckdd64zmkg(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x1F, 0x5F, 0x80 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int Jmjoo1ffribr2trk11quq(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x1E, 0xB2, 0x40 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int G488xp93rdf3wxu82k9ci(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x20, 0x64, 0x20 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int yikbk2j1w3edj23lnl192(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x20, 1, 0xC0 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int wmxoch4f9trr2olit6y4f(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x1E, 0xD5, 0x20 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int yhhy9bu33iurtak6u68c7(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x1E, 0xDB, 0x50 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int se2dlxl5rv1qx63ue9pbw(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C91F0U, new byte[] { 0x32, 0x20, 0x8D, 0xA0 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int Gal08a71doyx8v6apemm0(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0x93, 0xC0 });
            else
                Form1.PS3.SetMemory(0x14C91F0, new byte[] { 0x32, 0x1F, 0x68, 0xD0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int Mzmiqd4wgz2ur7q72bekz(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0x2E, 0x10 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int vt1d6dsb92eawck6ydk5g(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0xED, 0xB0 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int flvowdgae9in9cwh8jlmu(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0xEF, 0x30 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int T2xnu17oxtjz1ieo8nq27(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0x4F, 0x20 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int Ss6au0auqd8o17koxh34f(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int M2nv0sw18ijv2tpb5x230(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0xF4, 0xC0 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int Wn7uv4747z00tvwefljbe(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x19, 0xEC, 0 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int fjvh3nwirisao9e243a6u(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x18, 0xB4, 0x60 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int n23issbg6k6tn1zq100hi(int toggle)
        {
            if (toggle == 1)
                Form1.PS3.SetMemory(0x14C8C84U, new byte[] { 0x32, 0x18, 0xBE, 0 });
            else
                Form1.PS3.SetMemory(0x14C8C84, new byte[] { 0x32, 0x19, 0xF1, 0xE0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int lplhm9xxjxaec2x5peb2h(int toggle)
        {
            MessageBox.Show("Eggs of Elder Guardian has been changed to the Ender Dragon eggs, you can spawn it with a Monster Spawner", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xE7, 0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xC }); return 0;
            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xE });
            else
                Form1.PS3.SetMemory(0x32418D18, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xE });
            if (toggle == 1) return 0; else return 1;
        }
        public int Aqzbauiakn9oap53nfmib(int toggle)
        {
            MessageBox.Show("Eggs of Shulker has been changed to the Wither eggs, you can spawn it with a Monster Spawner", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418A79U, new byte[] { 0x77, 0, 0x69, 0, 0x74, 0, 0x68, 0, 0x65, 0, 0x72, 0, 0, 0, 0, 0, 0, 0, 6 }); 
            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418A79U, new byte[] { 0x73, 0, 0x68, 0, 0x75, 0, 0x6C, 0, 0x6B, 0, 0x65, 0, 0x72, 0, 0, 0, 0, 0, 7 });
            else
                Form1.PS3.SetMemory(0x32418A79, new byte[] { 0x73, 0x0, 0x68, 0x0, 0x75, 0x0, 0x6C, 0x0, 0x6B, 0x0, 0x65, 0x0, 0x72, 0x0, 0x0, 0x0, 0x0, 0x0, 0x7, 0x0 });
            if (toggle == 1) return 0; else return 1;

        }
        public int jxk34fjszv6mm6d5zjg10(int toggle)
        {
            MessageBox.Show("Eggs of Shulker has been changed to the Bunny Killer eggs, you can spawn it with a Monster Spawner", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418A79U, new byte[] { 0x77, 0, 0x69, 0, 0x74, 0, 0x68, 0, 0x65, 0, 0x72, 0, 0, 0, 0, 0, 0, 0, 6 }); 
            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418A79U, new byte[] { 0x73, 0, 0x68, 0, 0x75, 0, 0x6C, 0, 0x6B, 0, 0x65, 0, 0x72, 0, 0, 0, 0, 0, 7 });
            else
                Form1.PS3.SetMemory(0x32418A79, new byte[] { 0x73, 0x0, 0x68, 0x0, 0x75, 0x0, 0x6C, 0x0, 0x6B, 0x0, 0x65, 0x0, 0x72, 0x0, 0x0, 0x0, 0x0, 0x0, 0x7, 0x0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int Cxn6xwdx64rk130tf5h4l(int toggle)
        {
            MessageBox.Show("Eggs of Shulker has been changed to the Giant Zombie eggs, you can spawn it with a Monster Spawner", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418A79U, new byte[] { 0x67, 0, 0x69, 0, 0x61, 0, 0x6E, 0, 0x74, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5 }); 
            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418A79U, new byte[] { 0x73, 0, 0x68, 0, 0x75, 0, 0x6C, 0, 0x6B, 0, 0x65, 0, 0x72, 0, 0, 0, 0, 0, 7 });
            else
                Form1.PS3.SetMemory(0x32418A79, new byte[] { 0x73, 0x0, 0x68, 0x0, 0x75, 0x0, 0x6C, 0x0, 0x6B, 0x0, 0x65, 0x0, 0x72, 0x0, 0x0, 0x0, 0x0, 0x0, 0x7, 0x0 });
            if (toggle == 1) return 0; else return 1;
        }
        public int Rzkyrxceladd8vrokoghc(int toggle)
        {
            MessageBox.Show("Eggs of Elder Guardian has been changed to the Iron Golem eggs, you can spawn it with a Monster Spawner", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xF6, 0xA0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xE }); 

            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xE });
            else
                Form1.PS3.SetMemory(0x32418D18, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xE });
            if (toggle == 1) return 0; else return 1;
        }
        public int Dww4evvsfuz4cmqbmypau(int toggle)
        {
            MessageBox.Show("Eggs of Elder Guardian has been changed to Snowball, you can spawn it with a Monster Spawner (YOU CAN FREEZE)", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x9D, 0xA4, 0xC0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8 }); 
            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xE });
            else
                Form1.PS3.SetMemory(0x32418D18, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xE });
            if (toggle == 1) return 0; else return 1;
        }
        public int t9l61nmfmmj1za2ycpu5b(int toggle)
        {
            MessageBox.Show("Eggs of Elder Guardian has been changed to Armor Stand, you can spawn it with a Monster Spawner (YOU CAN FREEZE)", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xE3, 0x60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xB }); 
            if (toggle == 1)
            Form1.PS3.SetMemory(0x32418D18U, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xE });
            else
                Form1.PS3.SetMemory(0x32418D18, new byte[] { 0x30, 0x99, 0xD3, 0xE0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xE });
            if (toggle == 1) return 0; else return 1;
        }
        public int Te7njioayg6ii64kr7nl1(int toggle)
        {
            bool flag = toggle == 0; if (flag)
            {
                MessageBox.Show("Use a diamond hoe on the grass and you will see the block you have select. With that you can draw :p", "How to use ?", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x14C8A28U, new byte[] { 0x32, 0x18, 0xB9, 0xE0 }); return 0;
            }
            else
            {
                bool flag2 = toggle == 1; if (flag2)
                {
                    MessageBox.Show("Use a diamond hoe on the grass and you will see the block you have select. With that you can draw :p", "How to use ?", MessageBoxButtons.OK, MessageBoxIcon.Question); Form1.PS3.SetMemory(0x14C8A28U, new byte[] { 0x32, 0x19, 0xAE, 0x10 }); return 0;
                }
            }
            if (toggle == 1) return 0; else return 1;
        }
#endregion
        #region track
        public int Apg3l7ecu186eu8bbtvrl(int toggle)
        {
            uint offset = 0x14CB898U; uint offset2 = 0x14CB898U; uint offset3 = 0x14CB89CU; uint offset4 = 0x14CB8A0U; uint offset5 = 0x14CB8A4U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[2]; byte[] buffer2 = new byte[2]; byte[] buffer3 = new byte[2]; byte[] buffer4 = new byte[2]; byte[] buffer5 = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer); Form1.PS3.SetMemory(offset2, buffer2); Form1.PS3.SetMemory(offset3, buffer3); Form1.PS3.SetMemory(offset4, buffer4); Form1.PS3.SetMemory(offset5, buffer5); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer6 = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer7 = new byte[] { 0x42 }; Form1.PS3.SetMemory(offset2, buffer7); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer8 = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset3, buffer8); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer9 = new byte[] { 0xF0 }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer10 = new byte[] { 0xF0 }; Form1.PS3.SetMemory(offset3, buffer10); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer11 = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset4, buffer11); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer12 = new byte[] { 0xF0 }; Form1.PS3.SetMemory(offset4, buffer12); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer13 = new byte[] { 0x3F, 0x60 }; Form1.PS3.SetMemory(offset5, buffer13); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer14 = new byte[] { 0x3F, 0x90 }; Form1.PS3.SetMemory(offset5, buffer14); } } } } } } } } } }
            return (++toggle >= 10) ? 0 : toggle;
        }
        public int dza6jx3tmznnm3wvmeqme(int toggle)
        {
            uint offset = 0xC202C8U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x50 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x3F, 0x60 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x3F, 0x70 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x3F, 0x90 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x3F, 0xF0 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x3F, 0x40 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0x3F, 0x30 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer9 = new byte[] { 0x3F, 0x20 }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer10 = new byte[] { 0x3F, 0x10 }; Form1.PS3.SetMemory(offset, buffer10); } else { bool flag11 = toggle == 10; if (flag11) { byte[] array = new byte[2]; array[0] = 0x3F; byte[] buffer11 = array; Form1.PS3.SetMemory(offset, buffer11); } } } } } } } } } } }
            return (++toggle >= 11) ? 0 : toggle;
        }
        public int e9corfqogwb1dvptpkuxe(int toggle)
        {
            uint offset = 0xAD5A5CU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x6F, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { byte.MaxValue, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer3); } } }
            return (++toggle >= 3) ? 0 : toggle;
        }
        public int buz4nvul7my6cjnlxwpdh(int toggle)
        {
            uint offset = 0x1DA1D4U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x43 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x44 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x45 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x46 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x47 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x48 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer8); } } } } } } } }
            return (++toggle >= 8) ? 0 : toggle;
        }
        public int zom0xvj0ncgbu3itkha5v(int toggle)
        {
            uint offset = 0x1DA1D4U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x41 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x42 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x43 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x44 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x45 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x46 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0x47 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer9 = new byte[] { 0x48 }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer10 = new byte[] { 0x49 }; Form1.PS3.SetMemory(offset, buffer10); } else { bool flag11 = toggle == 10; if (flag11) { byte[] buffer11 = new byte[] { byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer11); } } } } } } } } } } }
            return (++toggle >= 11) ? 0 : toggle;
        }
        public int rfq47ez4id535qqzi9h1m(int toggle)
        {
            uint offset = 0xAF6B9CU; uint offset2 = 0xAF6B98U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x41, 0x80 }; byte[] buffer2 = new byte[] { 0xBF, 0x80 }; Form1.PS3.SetMemory(offset, buffer); Form1.PS3.SetMemory(offset2, buffer2); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer3 = new byte[] { 0xAF }; Form1.PS3.SetMemory(offset2, buffer3); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer4 = new byte[] { 0xBF, byte.MaxValue }; Form1.PS3.SetMemory(offset2, buffer4); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer5 = new byte[] { 0xEF }; Form1.PS3.SetMemory(offset2, buffer5); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer6 = new byte[] { 0x40, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer7 = new byte[] { 0x41, 0xF0 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer8 = new byte[] { 0x42, 0x80 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer9 = new byte[] { 0x43, 0x80 }; Form1.PS3.SetMemory(offset, buffer9); } } } } } } } }
            return (++toggle >= 8) ? 0 : toggle;
        }
        public int v374gxmja3bqvtsb8s2s6(int toggle)
        {
            uint offset = 0x14C670CU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x3F, 0x70 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x3F, 0x60 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x3F, 0x50 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x3F, 0x40 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x3F, 0x30 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x3F, 0x25 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0x3F, 0x20 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer9 = new byte[] { 0x3F, 0x15 }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer10 = new byte[] { 0x3F, 0x10 }; Form1.PS3.SetMemory(offset, buffer10); } else { bool flag11 = toggle == 10; if (flag11) { byte[] buffer11 = new byte[] { 0x1F, 0x80 }; Form1.PS3.SetMemory(offset, buffer11); } else { bool flag12 = toggle == 11; if (flag12) { byte[] buffer12 = new byte[] { 0x3F, byte.MaxValue, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer12); } } } } } } } } } } } }
            return (++toggle >= 12) ? 0 : toggle;
        }
        public int qoskhngdnslkajt1ivxk2(int toggle)
        {
            uint offset = 0x410734U; uint offset2 = 0x410738U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x40, 0xC0 }; byte[] buffer2 = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer); Form1.PS3.SetMemory(offset2, buffer2); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer3 = new byte[] { 0x40, 0x50 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer4 = new byte[] { 0xBF, 0x80 }; Form1.PS3.SetMemory(offset2, buffer4); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer5 = new byte[] { 0x49, 0xC0 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer6 = new byte[] { 0x42, 0xC0 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer7 = new byte[] { 0x43, 0xC0 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer8 = new byte[] { 0xF0, 0xC0 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer9 = new byte[] { 0x3F, 0xF0 }; Form1.PS3.SetMemory(offset2, buffer9); } } } } } } } }
            return (++toggle >= 8) ? 0 : toggle;
        }
        public int qq3ocohm8o1zgy47lxx2q(int toggle)
        {
            uint offset = 0x30DBAD64U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x3F, 0x80, 0, 0, 0x4F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x3F, 0x80, 0, 0, 0x1F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x3F, byte.MaxValue, 0, 0, 0x1F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x5F, 0x80, 0, 0, 0x5F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x8F, 0x80, 0, 0, 0x8F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[0x10]; Form1.PS3.SetMemory(offset, buffer7); } } } } } } }
            return (++toggle >= 7) ? 0 : toggle;
        }
        public int li5ss0qm903m4r0qudi2f(int toggle)
        {
            uint offset = 0xAD5EC8U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0xBF, 0x80 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] array = new byte[2]; array[0] = 0xBF; byte[] buffer2 = array; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0xBF, 0xAA }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0xBF, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0xC0, 0x50 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0xC0, 0x99 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0xC0, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0xC1, 0x80 }; Form1.PS3.SetMemory(offset, buffer8); } } } } } } } }
            return (++toggle >= 8) ? 0 : toggle;
        }
        public int n3f81vdlowqu843tul5l8(int toggle)
        {
            uint offset = 0xAD5ECCU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x2F, 0x80 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x40, 0x80 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x40, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x41, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x43, 0x80 }; Form1.PS3.SetMemory(offset, buffer7); } } } } } } }
            return (++toggle >= 7) ? 0 : toggle;
        }
        public int T5mivp4z7onhp4xwd616x(int toggle)
        {
            uint offset = 0xAF0443U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[1]; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x10 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x20 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x30 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x50 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x60 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0x70 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer9 = new byte[] { 0x80 }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer10 = new byte[] { 0x90 }; Form1.PS3.SetMemory(offset, buffer10); } else { bool flag11 = toggle == 10; if (flag11) { byte[] buffer11 = new byte[] { 0xA0 }; Form1.PS3.SetMemory(offset, buffer11); } else { bool flag12 = toggle == 11; if (flag12) { byte[] buffer12 = new byte[] { 0xB0 }; Form1.PS3.SetMemory(offset, buffer12); } else { bool flag13 = toggle == 12; if (flag13) { byte[] buffer13 = new byte[] { 0xC0 }; Form1.PS3.SetMemory(offset, buffer13); } else { bool flag14 = toggle == 13; if (flag14) { byte[] buffer14 = new byte[] { 0xD0 }; Form1.PS3.SetMemory(offset, buffer14); } else { bool flag15 = toggle == 14; if (flag15) { byte[] buffer15 = new byte[] { 0xE0 }; Form1.PS3.SetMemory(offset, buffer15); } else { bool flag16 = toggle == 15; if (flag16) { byte[] buffer16 = new byte[] { 0xF0 }; Form1.PS3.SetMemory(offset, buffer16); } } } } } } } } } } } } } } } }
            return (++toggle >= 16) ? 0 : toggle;
        }
        public int ioo9jjfdhgqxu9x3798ma(int toggle)
        {
            uint offset = 0x3000AAF8U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0x3F, byte.MaxValue, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0x3F, 0, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 0x4F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, 0, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, byte.MaxValue, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x3F, 0x80, 0, 0, 0x4F, 0x80, 0, 0, 0x3F, 0x80 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, 0 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer9 = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer10 = new byte[] { 0x3F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x4F, 0x80 }; Form1.PS3.SetMemory(offset, buffer10); } else { bool flag11 = toggle == 10; if (flag11) { byte[] buffer11 = new byte[] { 0x3F, 0x80, 0, 0, 0x4F, 0x80, 0, 0, 0x4F, 0x80 }; Form1.PS3.SetMemory(offset, buffer11); } else { bool flag12 = toggle == 11; if (flag12) { byte[] buffer12 = new byte[] { 0x4F, 0x80, 0, 0, 0x4F, 0x80, 0, 0, 0x4F, 0x80 }; Form1.PS3.SetMemory(offset, buffer12); } else { bool flag13 = toggle == 12; if (flag13) { byte[] buffer13 = new byte[] { 0x4F, 0x80, 0, 0, 0x3F, 0x80, 0, 0, 0x4F, 0x80 }; Form1.PS3.SetMemory(offset, buffer13); } } } } } } } } } } } } }
            return (++toggle >= 13) ? 0 : toggle;
        }
        public int T4a0se9samfgtpei07ead(int toggle)
        {
            uint offset = 0x38B964U; uint offset2 = 0x38B968U; uint offset3 = 0xB230ACU; uint offset4 = 0xB230D0U; uint offset5 = 0xB230FCU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3E, 0xCC }; byte[] buffer2 = new byte[] { 0x3F, 0x59 }; byte[] buffer3 = new byte[] { 0xBF, 0x80 }; byte[] buffer4 = new byte[] { 0x3F, 0x60 }; byte[] buffer5 = new byte[] { 0x41, 0x80 }; Form1.PS3.SetMemory(offset, buffer); Form1.PS3.SetMemory(offset2, buffer2); Form1.PS3.SetMemory(offset3, buffer3); Form1.PS3.SetMemory(offset4, buffer4); Form1.PS3.SetMemory(offset5, buffer5); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer6 = new byte[] { byte.MaxValue, 0xCC }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer7 = new byte[] { 0x3F, 0xCC }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer8 = new byte[] { 0x8E, 0xCC }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer9 = new byte[] { byte.MaxValue }; Form1.PS3.SetMemory(offset2, buffer9); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer10 = new byte[] { 0xBF, 0x70 }; Form1.PS3.SetMemory(offset3, buffer10); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer11 = new byte[] { 0x3F, 0x80 }; Form1.PS3.SetMemory(offset4, buffer11); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer12 = new byte[] { 0x43 }; Form1.PS3.SetMemory(offset5, buffer12); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer13 = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset, buffer13); } } } } } } } } }
            return (++toggle >= 9) ? 0 : toggle;
        }
        public int Hk2r0iyiiamr8bl7oxrfj(int toggle)
        {
            uint offset = 0x300040FFU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 5 }; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[1]; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 2 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 1 }; Form1.PS3.SetMemory(offset, buffer4); } } } }
            return (++toggle >= 4) ? 0 : toggle;
        }
        public int Hxd4bkef4pd957i0btajp(int toggle)
        {
            uint offset = 0xB25990U; uint offset2 = 0xB25994U; uint offset3 = 0xB25998U; uint offset4 = 0xB259A0U; uint offset5 = 0xB25A58U; uint offset6 = 0xB25A59U; uint offset7 = 0xB259A0U; uint blue = 0xB25A5EU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[2]; byte[] buffer2 = new byte[] { 0x3E, 0xCC }; byte[] array = new byte[2]; array[0] = 0x40; byte[] buffer3 = array; byte[] buffer4 = new byte[] { 0x3F, 0x60 }; byte[] buffer5 = new byte[] { 0xFC, 0x40 }; byte[] buffer6 = new byte[] { 8 }; Form1.PS3.SetMemory(offset, buffer); Form1.PS3.SetMemory(offset2, buffer2); Form1.PS3.SetMemory(offset3, buffer3); Form1.PS3.SetMemory(offset4, buffer4); Form1.PS3.SetMemory(offset5, buffer5); Form1.PS3.SetMemory(blue, buffer6); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer7 = new byte[] { 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer8 = new byte[] { 0x4E }; Form1.PS3.SetMemory(offset2, buffer8); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer9 = new byte[] { 0x7E }; Form1.PS3.SetMemory(offset6, buffer9); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer10 = new byte[] { 0x48 }; Form1.PS3.SetMemory(blue, buffer10); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer11 = new byte[] { 0x41 }; Form1.PS3.SetMemory(offset3, buffer11); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer12 = new byte[] { 0x42 }; Form1.PS3.SetMemory(offset3, buffer12); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer13 = new byte[] { 0x60 }; Form1.PS3.SetMemory(offset3, buffer13); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer14 = new byte[] { 0xA0 }; Form1.PS3.SetMemory(offset7, buffer14); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer15 = new byte[] { 0xB0 }; Form1.PS3.SetMemory(offset7, buffer15); } else { bool flag11 = toggle == 10; if (flag11) { byte[] buffer16 = new byte[] { 0xD0 }; Form1.PS3.SetMemory(offset7, buffer16); } else { bool flag12 = toggle == 11; if (flag12) { byte[] buffer17 = new byte[] { byte.MaxValue }; Form1.PS3.SetMemory(offset7, buffer17); } } } } } } } } } } } }
            return (++toggle >= 12) ? 0 : toggle;
        }
        public int U0j99yhreh4cq80qh7qqe(int toggle)
        {
            uint remove = 0xB21F1CU; uint size = 0xB21F28U; uint change = 0xB21F5CU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80 }; byte[] buffer2 = new byte[] { 0x42, 0xC8 }; byte[] buffer3 = new byte[] { 0x43, 0xB4 }; Form1.PS3.SetMemory(remove, buffer); Form1.PS3.SetMemory(size, buffer2); Form1.PS3.SetMemory(change, buffer3); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer4 = new byte[] { 0x2F, 0x80 }; Form1.PS3.SetMemory(remove, buffer4); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer5 = new byte[] { 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(remove, buffer5); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer6 = new byte[] { 0x4F, byte.MaxValue }; Form1.PS3.SetMemory(remove, buffer6); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer7 = new byte[] { 0x43, 0xC8 }; Form1.PS3.SetMemory(size, buffer7); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer8 = new byte[] { 0x41, 0xC8 }; Form1.PS3.SetMemory(size, buffer8); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer9 = new byte[] { 0x40, 0xC8 }; Form1.PS3.SetMemory(size, buffer9); } else { bool flag8 = toggle == 7; if (flag8) { byte[] array = new byte[2]; array[0] = 0x40; byte[] buffer10 = array; Form1.PS3.SetMemory(size, buffer10); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer11 = new byte[] { 0x43, 0x84 }; Form1.PS3.SetMemory(change, buffer11); } } } } } } } } }
            return (++toggle >= 9) ? 0 : toggle;
        }
        public int nso37nva2u54xiztne4mc(int toggle)
        {
            uint normal = 0xAD14ECU; uint normal2 = 0xAD14F0U; uint normal3 = 0xAD14F4U; uint normal4 = 0xAD14F8U; uint normal5 = 0xAD0274U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0xF }; byte[] buffer2 = new byte[] { 0xBF, 0x19 }; byte[] buffer3 = new byte[] { 0xBF, 5 }; byte[] buffer4 = new byte[] { 0xBF, 0x38 }; byte[] buffer5 = new byte[] { 0x3F, 0x23 }; Form1.PS3.SetMemory(normal, buffer); Form1.PS3.SetMemory(normal2, buffer2); Form1.PS3.SetMemory(normal3, buffer3); Form1.PS3.SetMemory(normal4, buffer4); Form1.PS3.SetMemory(normal5, buffer5); } bool flag2 = toggle == 1; if (flag2) { byte[] buffer6 = new byte[] { 0x3F, 0xF }; Form1.PS3.SetMemory(normal, buffer6); } bool flag3 = toggle == 2; if (flag3) { byte[] buffer7 = new byte[] { 0xBF, 0xF }; byte[] buffer8 = new byte[] { 0xBF, 0x23 }; Form1.PS3.SetMemory(normal, buffer7); Form1.PS3.SetMemory(normal5, buffer8); } bool flag4 = toggle == 3; if (flag4) { byte[] buffer9 = new byte[] { 0x8F, 0xF }; byte[] buffer10 = new byte[] { 0x8F, 0x23 }; Form1.PS3.SetMemory(normal, buffer9); Form1.PS3.SetMemory(normal5, buffer10); } bool flag5 = toggle == 4; if (flag5) { byte[] buffer11 = new byte[] { 0x8F, 5 }; Form1.PS3.SetMemory(normal3, buffer11); } bool flag6 = toggle == 5; if (flag6) { byte[] buffer12 = new byte[] { 0xBF, 0x25 }; Form1.PS3.SetMemory(normal3, buffer12); } bool flag7 = toggle == 6; if (flag7) { byte[] buffer13 = new byte[] { 0xBF, 0x68 }; Form1.PS3.SetMemory(normal4, buffer13); } bool flag8 = toggle == 7; if (flag8) { byte[] buffer14 = new byte[] { 0xBF, 0x98 }; Form1.PS3.SetMemory(normal4, buffer14); } bool flag9 = toggle == 8; if (flag9) { byte[] buffer15 = new byte[] { 0xBF, 0xB8 }; Form1.PS3.SetMemory(normal4, buffer15); } bool flag10 = toggle == 9; if (flag10) { byte[] buffer16 = new byte[] { 0xBF, byte.MaxValue }; Form1.PS3.SetMemory(normal4, buffer16); }
            return (++toggle >= 10) ? 0 : toggle;
        }
        public int Gwbwvbt6g2sddte6lpbwc(int toggle)
        {
            uint offset = 0xACA524U; bool flag = toggle == 0; if (flag) { byte[] array = new byte[2]; array[0] = 0xBF; byte[] buffer = array; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 0xAF, 0x80 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 0xBF, 0x80 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] array2 = new byte[2]; array2[0] = 0x3F; byte[] buffer4 = array2; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 0xBF, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x4F, byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer7); } } } } } } }
            return (++toggle >= 7) ? 0 : toggle;
        }
        public int kgytl9ohjhcdddorr1h64(int toggle)
        {
            uint normal = 0xA9B140U; uint normal2 = 0xA9B144U; uint normal3 = 0xA9B150U; uint normal4 = 0xA9B158U; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x3F, 0x80 }; byte[] array = new byte[2]; array[0] = 0x3F; byte[] buffer2 = array; byte[] buffer3 = new byte[] { 0xBF, 5 }; byte[] buffer4 = new byte[] { 0x3F, 0xA0 }; byte[] array2 = new byte[] { 0x3F, 0x23 }; Form1.PS3.SetMemory(normal, buffer); Form1.PS3.SetMemory(normal2, buffer2); Form1.PS3.SetMemory(normal3, buffer3); Form1.PS3.SetMemory(normal4, buffer4); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer5 = new byte[] { 0x1F, 0x80 }; Form1.PS3.SetMemory(normal, buffer5); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer6 = new byte[] { 0x4F, 0x80 }; Form1.PS3.SetMemory(normal, buffer6); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer7 = new byte[] { 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(normal, buffer7); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer8 = new byte[] { 0x3F, byte.MaxValue }; Form1.PS3.SetMemory(normal2, buffer8); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer9 = new byte[] { byte.MaxValue, 0x80 }; Form1.PS3.SetMemory(normal3, buffer9); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer10 = new byte[] { 0x4E, 0x80 }; Form1.PS3.SetMemory(normal3, buffer10); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer11 = new byte[] { 0x8E, 0x80 }; Form1.PS3.SetMemory(normal3, buffer11); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer12 = new byte[] { 0x1F, 0xA0 }; Form1.PS3.SetMemory(normal4, buffer12); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer13 = new byte[] { 0xBF, 0x90 }; Form1.PS3.SetMemory(normal4, buffer13); } } } } } } } } } }
            return (++toggle >= 10) ? 0 : toggle;
        }
        public int Xz3ab21ed2h7cik58rkvw(int toggle)
        {
            uint offset = 0xA95FB9U; uint offset2 = 0xA95FC1U; uint offset3 = 0xB351D8U; uint offset4 = 0xB351DCU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[] { 0x18 }; byte[] buffer2 = new byte[] { 8 }; byte[] array = new byte[4]; array[0] = 0x40; array[1] = 0xA0; byte[] buffer3 = array; byte[] array2 = new byte[4]; array2[0] = 0x40; array2[1] = 0x90; byte[] buffer4 = array2; Form1.PS3.SetMemory(offset, buffer); Form1.PS3.SetMemory(offset2, buffer2); Form1.PS3.SetMemory(offset3, buffer3); Form1.PS3.SetMemory(offset4, buffer4); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer5 = new byte[] { 0x80 }; byte[] buffer6 = new byte[] { 0x80 }; byte[] array3 = new byte[4]; array3[0] = 0x41; array3[1] = 0xA0; byte[] buffer7 = array3; byte[] array4 = new byte[4]; array4[0] = 0x41; array4[1] = 0xA0; byte[] buffer8 = array4; Form1.PS3.SetMemory(offset, buffer5); Form1.PS3.SetMemory(offset2, buffer6); Form1.PS3.SetMemory(offset3, buffer7); Form1.PS3.SetMemory(offset4, buffer8); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer9 = new byte[] { 0x80 }; byte[] buffer10 = new byte[] { 0x80 }; byte[] array5 = new byte[4]; array5[0] = 0x42; array5[1] = 0xA0; byte[] buffer11 = array5; byte[] array6 = new byte[4]; array6[0] = 0x42; array6[1] = 0xA0; byte[] buffer12 = array6; Form1.PS3.SetMemory(offset, buffer9); Form1.PS3.SetMemory(offset2, buffer10); Form1.PS3.SetMemory(offset3, buffer11); Form1.PS3.SetMemory(offset4, buffer12); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer13 = new byte[] { 0x80 }; byte[] buffer14 = new byte[] { 0x80 }; byte[] array7 = new byte[4]; array7[0] = 0x45; array7[1] = 0xA0; byte[] buffer15 = array7; byte[] array8 = new byte[4]; array8[0] = 0x45; array8[1] = 0xA0; byte[] buffer16 = array8; Form1.PS3.SetMemory(offset, buffer13); Form1.PS3.SetMemory(offset2, buffer14); Form1.PS3.SetMemory(offset3, buffer15); Form1.PS3.SetMemory(offset4, buffer16); } } } }
            return (++toggle >= 4) ? 0 : toggle;
        }
        public int Elw90pa9fxptif1mmyrti(int toggle)
        {
            uint offset = 0x218A4FU; bool flag = toggle == 0; if (flag) { byte[] buffer = new byte[1]; Form1.PS3.SetMemory(offset, buffer); } else { bool flag2 = toggle == 1; if (flag2) { byte[] buffer2 = new byte[] { 1 }; Form1.PS3.SetMemory(offset, buffer2); } else { bool flag3 = toggle == 2; if (flag3) { byte[] buffer3 = new byte[] { 2 }; Form1.PS3.SetMemory(offset, buffer3); } else { bool flag4 = toggle == 3; if (flag4) { byte[] buffer4 = new byte[] { 3 }; Form1.PS3.SetMemory(offset, buffer4); } else { bool flag5 = toggle == 4; if (flag5) { byte[] buffer5 = new byte[] { 4 }; Form1.PS3.SetMemory(offset, buffer5); } else { bool flag6 = toggle == 5; if (flag6) { byte[] buffer6 = new byte[] { 5 }; Form1.PS3.SetMemory(offset, buffer6); } else { bool flag7 = toggle == 6; if (flag7) { byte[] buffer7 = new byte[] { 0x10 }; Form1.PS3.SetMemory(offset, buffer7); } else { bool flag8 = toggle == 7; if (flag8) { byte[] buffer8 = new byte[] { 0x20 }; Form1.PS3.SetMemory(offset, buffer8); } else { bool flag9 = toggle == 8; if (flag9) { byte[] buffer9 = new byte[] { 0x30 }; Form1.PS3.SetMemory(offset, buffer9); } else { bool flag10 = toggle == 9; if (flag10) { byte[] buffer10 = new byte[] { 0x40 }; Form1.PS3.SetMemory(offset, buffer10); } else { bool flag11 = toggle == 10; if (flag11) { byte[] buffer11 = new byte[] { byte.MaxValue }; Form1.PS3.SetMemory(offset, buffer11); } } } } } } } } } } }
            return (++toggle >= 11) ? 0 : toggle;
        }
        public int Dker9ea42st9qwktc4jw1(int toggle)
        {
            bool flag = toggle == 0; if (flag)
            {
                Form1.PS3.SetMemory(0x15118BCU, new byte[] { 0x30, 0x8B, 0xC4, 0xEC }); 
                Form1.PS3.SetMemory(0x15118C4U, new byte[] { 0x30, 0x8B, 0xC5, 0x24 }); 
            }

            bool flag2 = toggle == 1; if (flag2)
            {
                Form1.PS3.SetMemory(0x15118BCU, new byte[] { 0x30, 0x8B, 0xC5, 0x24 }); 
            }

            bool flag3 = toggle == 2; if (flag3)
            {
                Form1.PS3.SetMemory(0x15118C4U, new byte[] { 0x30, 0x8B, 0xC4, 0xEC }); 
            }

            bool flag4 = toggle == 3; if (flag4)
            {
                Form1.PS3.SetMemory(0x15118BCU, new byte[] { 0x30, 0x8B, 0xC5, 8 }); 
            }
            return (++toggle >= 4) ? 0 : toggle;
        }
        public int ombloo0j9am0x9mlf4bev(int toggle)
        {
            bool flag = toggle == 0; if (flag)
            {
                Form1.PS3.SetMemory(0x151DBECU, new byte[] { 0x30, 0xDC, 0x40, 0x50 });
            }

            bool flag2 = toggle == 1; if (flag2)
            {
                Form1.PS3.SetMemory(0x151DBECU, new byte[] { 0x30, 0xDC, 0x41, 0xD0 });
            }

            bool flag3 = toggle == 2; if (flag3)
            {
                Form1.PS3.SetMemory(0x151DBECU, new byte[] { 0x30, 0xDC, 0x41, 0x90 });
            }

            return (++toggle >= 3) ? 0 : toggle;
        }
        public int yhx7b1vua0wrqbhmc9dir(int toggle)
        {
            bool flag = toggle == 0; if (flag)
            {
                Form1.PS3.SetMemory(0x151DBF0U, new byte[] { 0x30, 0xDC, 0x41, 0x90 });
            }

            bool flag2 = toggle == 1; if (flag2)
            {
                Form1.PS3.SetMemory(0x151DBF0U, new byte[] { 0x30, 0xDC, 0x40, 0x50 });
            }

            bool flag3 = toggle == 2; if (flag3)
            {
                Form1.PS3.SetMemory(0x151DBF0U, new byte[] { 0x30, 0xDC, 0x41, 0xD0 });
            }
            return (++toggle >= 3) ? 0 : toggle;
        }
        public int O3cfr2dj7t051l0tyekw3(int toggle)
        {
            bool flag = toggle == 0; if (flag)
            {
                Form1.PS3.SetMemory(0x151DBECU, new byte[] { 0x30, 0xDC, 0x40, 0x50 });
            }

            bool flag2 = toggle == 1; if (flag2)
            {
               Form1.PS3.SetMemory(0x151DBECU, new byte[] { 0x30, 0xDC, 0x41, 0xD0 });
            }

            bool flag3 = toggle == 2; if (flag3)
            {
                Form1.PS3.SetMemory(0x151DBECU, new byte[] { 0x30, 0xDC, 0x41, 0x90 });
            }

            return (++toggle >= 3) ? 0 : toggle;
        }
        public int Cqmzmyj30ut446xnk6m8z(int toggle)
        {
            bool flag = toggle == 0; if (flag)
            {
                Form1.PS3.SetMemory(0x14C93F0U, new byte[] { 0x32, 0x20, 0xA4, 0xF0 });
            }

            bool flag2 = toggle == 1; if (flag2)
            {
                Form1.PS3.SetMemory(0x14C93F0U, new byte[] { 0x32, 0x1F, 0x97, 0xC0 });
            }

            bool flag3 = toggle == 2; if (flag3)
            {
                Form1.PS3.SetMemory(0x14C93F0U, new byte[] { 0x32, 0x1E, 0xA1, 0x40 });
            }

            bool flag4 = toggle == 3; if (flag4)
            {
                Form1.PS3.SetMemory(0x14C93F0U, new byte[] { 0x32, 0x1E, 0xD5, 0x20 });
            }
            return (++toggle >= 4) ? 0 : toggle;
        }
        #endregion
        #region get
        public int It81kjbwfpcv8fxclzd1j(int toogle)
        {
            byte[] data = Form1.PS3.Extension.ReadBytes(0x14CF38FU, 1);
            string VALUES = BitConverter.ToString(data);
            GetPingz = VALUES;
            return 0;
        }
        public int Qzmzhzlur4kmlnqmqnzkm(int toggle)
        {
            LastPlayersJoinedPSN = Form1.PS3.Extension.ReadString(0x30F46AC4U);
            LastPlayersRegion = Form1.PS3.Extension.ReadString(0x30F46AD8U);
            LastPlayersAvatar = Form1.PS3.Extension.ReadString(0x30F46B80U);
            return 0;
        }
        #endregion
        #region set string
        public int u18qmxz7q7sja1nlgf9wo(string text)
        {
            Form1.PS3.SetMemory(0x320E8410U, Encoding.ASCII.GetBytes(fixText(text))); return 0;
        }
        public int lfhwdpdv4iksp41qlyemo(string text)
        {
            Form1.PS3.SetMemory(0x320E89E0U, Encoding.ASCII.GetBytes(fixText(text))); return 0;
        }
        public int Mdo49k9zj8m74xivumm7u(string text)
        {
            Form1.PS3.SetMemory(0x30FAA197U, Encoding.ASCII.GetBytes(fixText(text))); return 0;
        }
        public int Iechxa4f969raxhk1mw3q(string text)
        {
            Form1.PS3.SetMemory(0x30FAA1D7U, Encoding.ASCII.GetBytes(fixText(text))); return 0;
        }
        public int hnm66mx1wg69mh1kbgh9p(string text)
        {
            string PSN = Form1.PS3.Extension.ReadString(0x3000AD34U); Form1.PS3.SetMemory(0x3000ABE4U, new byte[0x18]); byte[] bytes = Encoding.ASCII.GetBytes(text ?? ""); Form1.PS3.SetMemory(0x3000ABE4U, bytes); Form1.PS3.CCAPI.Notify(CCAPI.NotifyIcon.CAUTION, "Ultimatecraft Notification\nName Changed, rejoin the world for see your new name!"); return 0;
        }
        public int I30m847hp73iztqg1glkm(string text)
        {
            string PSN = Form1.PS3.Extension.ReadString(0x3000AD34U); Form1.PS3.SetMemory(0x3000ABE4U, new byte[0x18]); byte[] bytes = Encoding.ASCII.GetBytes(text); byte[] buffer = new byte[] { 0x20, 0xC2, 0xA7, 0x33 }; Form1.PS3.SetMemory(0x3000ABE4U, bytes); Form1.PS3.SetMemory(0x3000ABF7U, buffer); Form1.PS3.CCAPI.Notify(CCAPI.NotifyIcon.CAUTION, "Ultimatecraft Notification\nName Changed To Glitched, rejoin the world for see your new name!"); return 0;
        }
        public int rcs39af267jvfwnxxa7bp(string text)
        {
            string PSN = Form1.PS3.Extension.ReadString(0x3000AD34U); PS3API ps = Form1.PS3; uint offset = 0x3000ABE4U; byte[] array = new byte[0x18]; array[0] = 0xC2; array[1] = 0xA7; ps.SetMemory(offset, array); byte[] bytes = Encoding.ASCII.GetBytes(text ?? ""); Form1.PS3.SetMemory(0x3000ABE6U, bytes); Form1.PS3.CCAPI.Notify(CCAPI.NotifyIcon.CAUTION, "Ultimatecraft Notification\nName Changed To Colored, rejoin the world for see your new name!"); return 0;
        }
        public int Eekrxidcf3t1jk5603ql0(string text)
        {
            string PSN = Form1.PS3.Extension.ReadString(0x3000AD34U); Form1.PS3.SetMemory(0x3000ABE4U, new byte[0x18]); byte[] bytes = Encoding.ASCII.GetBytes(text ?? ""); Form1.PS3.SetMemory(0x3000ABE4U, bytes); Form1.PS3.CCAPI.Notify(CCAPI.NotifyIcon.CAUTION, "Ultimatecraft Notification\nName Changed To Lines, rejoin the world for see your new name!"); return 0;
        }
        #endregion
        public string getLocation()
        { string xyz = " "; for (int i = 0; i < 3; i++) { xyz = xyz + Math.Round(Form1.PS3.Extension.ReadDouble(Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(0x14CF2E4U) + 0x44U) + 0x84U) + (uint)(8 * i))).ToString() + ","; } return xyz; }
        public void setLocation(int x, int y, int z)
        { double[] xyz = new double[] { (double)x, (double)y, (double)z }; double[] xyz2 = new double[] { (double)x + 0.6, (double)y + 1.8, (double)z + 0.6 }; List<byte> xyzBytes = new List<byte>(); for (int i = 0; i < 3; i++) { byte[] rev = BitConverter.GetBytes(xyz[i]); Array.Reverse(rev); xyzBytes.AddRange(rev); } for (int j = 0; j < 3; j++) { byte[] rev2 = BitConverter.GetBytes(xyz2[j]); Array.Reverse(rev2); xyzBytes.AddRange(rev2); } Form1.PS3.SetMemory(Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(0x14CF2E4U) + 0x44U) + 0x158U), xyzBytes.ToArray()); }
        public double[] playerPos()
        { uint memRegion = 0U; uint clientOrg = 0x100U; uint num = memRegion + Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(0x14CF2E4U) + 0x44U) + clientOrg; int num2 = (int)Form1.PS3.Extension.ReadDouble(num); int num3 = (int)Form1.PS3.Extension.ReadDouble(num + 0x10U); return new double[] { (double)((num2 > 0) ? num2 : (num2 - 1)), Math.Round(Form1.PS3.Extension.ReadDouble(num + 8U)) + 1.0, (double)((num3 > 0) ? num3 : (num3 - 1)) }; }
        public string fixText(string fixStr)
        {
            int length = fixStr.Length;
            int startIndex = 1;
            int num3 = 0;
            for (; ; )
            {
                bool flag = num3 >= length;
                if (flag)
                {
                    break;
                }
                fixStr = fixStr.Insert(startIndex, ".");
                startIndex += 2;
                num3++;
            }
            fixStr = fixStr.Replace(".", "\0");
            return fixStr + "\0\0\0";
        }
        public void setLocation(int x, int y, int z, bool fallDamage)
        {
            double[] array = new double[] { (double)x, (double)y, (double)z }; double[] array2 = new double[] { (double)x + 0.6, (double)y + 1.8, (double)z + 0.6 }; List<byte> list = new List<byte>(); for (int i = 0; i < 3; i++) { byte[] bytes = BitConverter.GetBytes(array[i]); Array.Reverse(bytes); list.AddRange(bytes); } for (int j = 0; j < 3; j++) { byte[] bytes2 = BitConverter.GetBytes(array2[j]); Array.Reverse(bytes2); list.AddRange(bytes2); } bool flag = false; bool flag2 = !fallDamage; if (flag2)
            {
                Form1.PS3.SetMemory(0x227908U, new byte[] { 0x41, 0x82, 0, 0x18 }); flag = true; Form1.PS3.SetMemory(0x227908U, new byte[] { 0x41, 0x82, 0, 0x28 });
            } Form1.PS3.SetMemory(Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(Form1.PS3.Extension.ReadUInt32(0x14CF2E4U) + 0x44U) + 0x158U), list.ToArray()); bool flag3 = flag && !fallDamage; if (flag3)
            {
                Task.Delay(0x1F4).Wait(); Form1.PS3.SetMemory(0x227908U, new byte[] { 0x41, 0x82, 0, 0x18 });
            }
        }
        public void CHANGING_EFFECT_REGENERATION(int toggle)
        { bool flag = toggle == 0; if (flag) { Form1.PS3.SetMemory(0x14C9B48U, ulti.ModEffectsSPEED); } else { bool flag2 = toggle == 1; if (flag2) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsSLOWNESS); } else { bool flag3 = toggle == 2; if (flag3) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsHASTE); } else { bool flag4 = toggle == 3; if (flag4) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsMINING_FATIGUE); } else { bool flag5 = toggle == 4; if (flag5) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsSTRENGTH); } else { bool flag6 = toggle == 5; if (flag6) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsINSTANT_HEALTH); } else { bool flag7 = toggle == 6; if (flag7) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsINSTANT_DAMAGE); } else { bool flag8 = toggle == 7; if (flag8) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsJUMP_BOOST); } else { bool flag9 = toggle == 8; if (flag9) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsNAUSEA); } else { bool flag10 = toggle == 9; if (flag10) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsREGENERATION); } else { bool flag11 = toggle == 10; if (flag11) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsRESISTANCE); } else { bool flag12 = toggle == 11; if (flag12) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsFIRE_RESISTANCE); } else { bool flag13 = toggle == 12; if (flag13) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsWATER_BREATHING); } else { bool flag14 = toggle == 13; if (flag14) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsINVISIBILITY); } else { bool flag15 = toggle == 14; if (flag15) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsBLINDNESS); } else { bool flag16 = toggle == 15; if (flag16) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsNIGHT_VISION); } else { bool flag17 = toggle == 16; if (flag17) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsHUNGER); } else { bool flag18 = toggle == 17; if (flag18) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsWEAKNESS); } else { bool flag19 = toggle == 18; if (flag19) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsPOISON); } else { bool flag20 = toggle == 19; if (flag20) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsWITHER); } else { bool flag21 = toggle == 20; if (flag21) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsHEALTH_BOOST); } else { bool flag22 = toggle == 21; if (flag22) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsABSORPTION); } else { bool flag23 = toggle == 22; if (flag23) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsSATURATION); } else { bool flag24 = toggle == 23; if (flag24) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsGLOWING); } else { bool flag25 = toggle == 24; if (flag25) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsLEVITATION); } else { bool flag26 = toggle == 25; if (flag26) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsLUCK); } else { bool flag27 = toggle == 26; if (flag27) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsUNLUCK); } else { bool flag28 = toggle == 27; if (flag28) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsCONDUIT_POWER); } else { bool flag29 = toggle == 28; if (flag29) { Form1.PS3.SetMemory(0x14C9B48U, ulti.MobEffectsSLOW_FALLING); } else { bool flag30 = toggle == 29; if (flag30) { MessageBox.Show("Change the regeneration effect to a another effect\n\nIf you eat a apple or use the totem of undying you will get the regeneration effect, so if you change this effec to a another you will get the new effect.", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } }
        public void CHANGING_EFFECT_REGENERATION_TIME(int toggle)
        { bool flag = toggle == 0; if (flag) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer1); } else { bool flag2 = toggle == 1; if (flag2) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer2); } else { bool flag3 = toggle == 2; if (flag3) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer3); } else { bool flag4 = toggle == 3; if (flag4) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer4); } else { bool flag5 = toggle == 4; if (flag5) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer5); } else { bool flag6 = toggle == 5; if (flag6) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer6); } else { bool flag7 = toggle == 6; if (flag7) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer7); } else { bool flag8 = toggle == 7; if (flag8) { Form1.PS3.SetMemory(0x3A55ECU, ulti.MobEffectTimer8); } else { bool flag9 = toggle == 8; if (flag9) { MessageBox.Show("Change duration of the regeneration effect\nWorking only if you using the totem of undying select the duration you want, use the totem and you will get the duration on the regeneration effect. If you change the effect of regeneration to a another it's working too.", "Infos", MessageBoxButtons.OK, MessageBoxIcon.Question); } } } } } } } } } }
        public void CHANGING_ITEMS_SWAPPER_OFFSET(int toggle)
        { bool flag = toggle == 0; if (flag) { Offset_Default_Items = 0x14C90CCU; } else { bool flag2 = toggle == 1; if (flag2) { Offset_Default_Items = 0x14C9124U; } else { bool flag3 = toggle == 2; if (flag3) { Offset_Default_Items = 0x14C9140U; } else { bool flag4 = toggle == 3; if (flag4) { Offset_Default_Items = 0x14C91D0U; } else { bool flag5 = toggle == 4; if (flag5) { Offset_Default_Items = 0x14C91F0U; } else { bool flag6 = toggle == 5; if (flag6) { Offset_Default_Items = 0x14C9340U; } else { bool flag7 = toggle == 6; if (flag7) { Offset_Default_Items = 0x14C93F0U; } else { bool flag8 = toggle == 7; if (flag8) { Offset_Default_Items = 0x14C9298U; } } } } } } } } }
        public void CHANGING_ITEMS_SWAPPER_VALUES(int toggle)
        { bool flag = toggle == 0; if (flag) { Items_Default_Items = Items_air; } else { bool flag2 = toggle == 1; if (flag2) { Items_Default_Items = Items_flint_and_steel; } else { bool flag3 = toggle == 2; if (flag3) { Items_Default_Items = Items_string; } else { bool flag4 = toggle == 3; if (flag4) { Items_Default_Items = Items_bow; } else { bool flag5 = toggle == 4; if (flag5) { Items_Default_Items = Items_arrow; } else { bool flag6 = toggle == 5; if (flag6) { Items_Default_Items = Items_spectral_arrow; } else { bool flag7 = toggle == 6; if (flag7) { Items_Default_Items = Items_tipped_arrow; } else { bool flag8 = toggle == 7; if (flag8) { Items_Default_Items = Items_diamond_shovel; } else { bool flag9 = toggle == 8; if (flag9) { Items_Default_Items = Items_diamond_pickaxe; } else { bool flag10 = toggle == 9; if (flag10) { Items_Default_Items = Items_diamond_axe; } else { bool flag11 = toggle == 10; if (flag11) { Items_Default_Items = Items_diamond_sword; } else { bool flag12 = toggle == 11; if (flag12) { Items_Default_Items = Items_diamond_hoe; } else { bool flag13 = toggle == 12; if (flag13) { Items_Default_Items = Items_diamond; } else { bool flag14 = toggle == 13; if (flag14) { Items_Default_Items = Items_coocked_porkchop; } else { bool flag15 = toggle == 14; if (flag15) { Items_Default_Items = Items_golden_apple; } else { bool flag16 = toggle == 15; if (flag16) { Items_Default_Items = Items_air; } else { bool flag17 = toggle == 16; if (flag17) { Items_Default_Items = Items_armor_stand; } else { bool flag18 = toggle == 17; if (flag18) { Items_Default_Items = Items_banner; } else { bool flag19 = toggle == 18; if (flag19) { Items_Default_Items = Items_blazer_rood; } else { bool flag20 = toggle == 19; if (flag20) { Items_Default_Items = Items_bucket_lava; } else { bool flag21 = toggle == 20; if (flag21) { Items_Default_Items = Items_commande_block_minecraft; } else { bool flag22 = toggle == 21; if (flag22) { Items_Default_Items = Items_cooked_beef; } else { bool flag23 = toggle == 22; if (flag23) { Items_Default_Items = Items_debug_four_items; } else { bool flag24 = toggle == 23; if (flag24) { Items_Default_Items = Items_egg; } else { bool flag25 = toggle == 24; if (flag25) { Items_Default_Items = Items_emerald; } else { bool flag26 = toggle == 25; if (flag26) { Items_Default_Items = Items_enchanted_book; } else { bool flag27 = toggle == 26; if (flag27) { Items_Default_Items = Items_ender_perl; } else { bool flag28 = toggle == 27; if (flag28) { Items_Default_Items = Items_end_crystal; } else { bool flag29 = toggle == 28; if (flag29) { Items_Default_Items = Items_experience_bottle; } else { bool flag30 = toggle == 29; if (flag30) { Items_Default_Items = Items_snowball; } else { bool flag31 = toggle == 30; if (flag31) { Items_Default_Items = Items_spawn_egg; } else { bool flag32 = toggle == 31; if (flag32) { Items_Default_Items = Items_tnt_minecraft; } else { bool flag33 = toggle == 32; if (flag33) { Items_Default_Items = Items_totem_of_undying; } else { bool flag34 = toggle == 33; if (flag34) { Items_Default_Items = Items_trident; } else { bool flag35 = toggle == 34; if (flag35) { Items_Default_Items = Items_writen_booke; } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } }
        public void CHANGING_BLOCKS_SWAPPER_OFFSET(int toggle)
        { bool flag = toggle == 0; if (flag) { Offset_Default_Blocks = 0x14C893CU; } else { bool flag2 = toggle == 1; if (flag2) { Offset_Default_Blocks = 0x14C8940U; } else { bool flag3 = toggle == 2; if (flag3) { Offset_Default_Blocks = 0x14C8950U; } else { bool flag4 = toggle == 3; if (flag4) { Offset_Default_Blocks = 0x14C8C84U; } else { bool flag5 = toggle == 4; if (flag5) { Offset_Default_Blocks = 0x14C894CU; } else { bool flag6 = toggle == 5; if (flag6) { Offset_Default_Blocks = 0x14C8930U; } else { bool flag7 = toggle == 6; if (flag7) { Offset_Default_Blocks = 0x14C8A04U; } else { bool flag8 = toggle == 7; if (flag8) { Offset_Default_Blocks = 0x14C8A08U; } } } } } } } } }
        public void CHANGING_BLOCKS_SWAPPER_VALUES(int toggle)
        {
            bool flag = toggle == 0; if (flag) { Blocks_Default_Blocks = Blocks_air; }
        }
        public void ENABLE_SPRX()
        {
            Form1.PS3.SetMemory(0x3000D2FBU, new byte[] { 0x44, 0x6F, 0x77, 0x6E, 0x43, 0x72, 0x61, 0x66, 0x74 }); Form1.PS3.SetMemory(0x3000D343U, new byte[] { 0x53, 0x50, 0x52, 0x58 }); Form1.PS3.SetMemory(0x3000D3BBU, new byte[] { 0x50, 0x72, 0x65, 0x6D, 0x69, 0x75, 0x6D }); Form1.PS3.SetMemory(0x3000D44BU, new byte[] { 0x45, 0x6E, 0x61, 0x62, 0x6C, 0x65, 0x64 });
        }
        public string LastPlayersJoinedPSN = "";
        public string LastPlayersRegion = "";
        public string LastPlayersAvatar = "";
        public string GetPingz = "-1";
        public uint Offset_Default_Items = 0U;
        public byte[] Items_Default_Items = new byte[1];
        public uint Offset_Default_Blocks = 0U;
        public byte[] Blocks_Default_Blocks = new byte[1];
        public static byte[] ModEffectsSPEED = new byte[] { 0x32, 0x1B, 0x8C, 0xD0 };
        public static byte[] MobEffectsSLOWNESS = new byte[] { 0x32, 0x1B, 0x8D, 0x10 };
        public static byte[] MobEffectsHASTE = new byte[] { 0x32, 0x1B, 0x95, 0x40 };
        public static byte[] MobEffectsMINING_FATIGUE = new byte[] { 0x32, 0x1B, 0x96, 0x90 };
        public static byte[] MobEffectsSTRENGTH = new byte[] { 0x32, 0x1B, 0x97, 0xE0 };
        public static byte[] MobEffectsINSTANT_HEALTH = new byte[] { 0x32, 0x1B, 0x99, 0x40 };
        public static byte[] MobEffectsINSTANT_DAMAGE = new byte[] { 0x32, 0x1B, 0x9A, 0x40 };
        public static byte[] MobEffectsJUMP_BOOST = new byte[] { 0x32, 0x1B, 0x9B, 0x40 };
        public static byte[] MobEffectsNAUSEA = new byte[] { 0x32, 0x1B, 0x9C, 0x40 };
        public static byte[] MobEffectsREGENERATION = new byte[] { 0x32, 0x1B, 0x9D, 0x80 };
        public static byte[] MobEffectsRESISTANCE = new byte[] { 0x32, 0x1B, 0x9E, 0x80 };
        public static byte[] MobEffectsFIRE_RESISTANCE = new byte[] { 0x32, 0x1B, 0x9F, 0x80 };
        public static byte[] MobEffectsWATER_BREATHING = new byte[] { 0x32, 0x1B, 0xA0, 0x80 };
        public static byte[] MobEffectsINVISIBILITY = new byte[] { 0x32, 0x1B, 0x9C, 0x80 };
        public static byte[] MobEffectsBLINDNESS = new byte[] { 0x32, 0x1B, 0xA2, 0x90 };
        public static byte[] MobEffectsNIGHT_VISION = new byte[] { 0x32, 0x1B, 0xA3, 0x90 };
        public static byte[] MobEffectsHUNGER = new byte[] { 0x32, 0x1B, 0xA4, 0x90 };
        public static byte[] MobEffectsWEAKNESS = new byte[] { 0x32, 0x1B, 0xA5, 0x90 };
        public static byte[] MobEffectsPOISON = new byte[] { 0x32, 0x1B, 0x93, 0xE0 };
        public static byte[] MobEffectsWITHER = new byte[] { 0x32, 0x1B, 0xA0, 0xC0 };
        public static byte[] MobEffectsHEALTH_BOOST = new byte[] { 0x32, 0x1B, 0x93, 0x30 };
        public static byte[] MobEffectsABSORPTION = new byte[] { 0x32, 0x1B, 0xAB, 0x30 };
        public static byte[] MobEffectsSATURATION = new byte[] { 0x32, 0x1B, 0xAC, 0x30 };
        public static byte[] MobEffectsGLOWING = new byte[] { 0x32, 0x1B, 0xAD, 0x30 };
        public static byte[] MobEffectsLEVITATION = new byte[] { 0x32, 0x1B, 0xAE, 0x30 };
        public static byte[] MobEffectsLUCK = new byte[] { 0x32, 0x1B, 0xAF, 0x30 };
        public static byte[] MobEffectsUNLUCK = new byte[] { 0x32, 0x1B, 0xB0, 0x80 };
        public static byte[] MobEffectsCONDUIT_POWER = new byte[] { 0x32, 0x1B, 0xB1, 0xD0 };
        public static byte[] MobEffectsSLOW_FALLING = new byte[] { 0x32, 0x1B, 0xB3, 0x20 };
        public static byte[] MobEffectTimer1 = new byte[] { 0x38, 0xA0, 3, 0x20 };
        public static byte[] MobEffectTimer2 = new byte[] { 0x38, 0xA0, 8, 0x20 };
        public static byte[] MobEffectTimer3 = new byte[] { 0x38, 0xA0, 0x10, 0x20 };
        public static byte[] MobEffectTimer4 = new byte[] { 0x38, 0xA0, 0x20, 0x20 };
        public static byte[] MobEffectTimer5 = new byte[] { 0x38, 0xA0, 0x30, 0x20 };
        public static byte[] MobEffectTimer6 = new byte[] { 0x38, 0xA0, 0x40, 0x20 };
        public static byte[] MobEffectTimer7 = new byte[] { 0x38, 0xA0, 0x60, 0x20 };
        public static byte[] MobEffectTimer8 = new byte[] { 0x38, 0xA0, 0x70, 0x80 };
        public byte[] Items_air = new byte[] { 0x32, 0x1C, 0xA, 0x60 };
        public byte[] Items_flint_and_steel = new byte[] { 0x32, 0x1E, 0xA4, 0x60 };
        public byte[] Items_string = new byte[] { 0x32, 0x1E, 0xF5, 0 };
        public byte[] Items_bow = new byte[] { 0x32, 0x1E, 0xA9, 0xD0 };
        public byte[] Items_arrow = new byte[] { 0x32, 0x1E, 0xAD, 0xA0 };
        public byte[] Items_spectral_arrow = new byte[] { 0x32, 0x20, 0x8D, 0xA0 };
        public byte[] Items_tipped_arrow = new byte[] { 0x32, 0x20, 0x8F, 0xF0 };
        public byte[] Items_bucket_lava = new byte[] { 0x32, 0x1F, 0x6B, 0x20 };
        public byte[] Items_diamond = new byte[] { 0x32, 0x1E, 0xB2, 0x40 };
        public byte[] Items_diamond_shovel = new byte[] { 0x32, 0x1E, 0xD8, 0x30 };
        public byte[] Items_diamond_pickaxe = new byte[] { 0x32, 0x1E, 0xDB, 0x50 };
        public byte[] Items_diamond_axe = new byte[] { 0x32, 0x1E, 0xDE, 0x70 };
        public byte[] Items_diamond_sword = new byte[] { 0x32, 0x1E, 0xD5, 0x20 };
        public byte[] Items_diamond_hoe = new byte[] { 0x32, 0x1F, 5, 0x20 };
        public byte[] Items_apple = new byte[] { 0x32, 0x1E, 0xA7, 0x70 };
        public byte[] Items_coocked_porkchop = new byte[] { 0x32, 0x1F, 0x5A, 0xD0 };
        public byte[] Items_golden_apple = new byte[] { 0x32, 0x1F, 0x5F, 0x80 };
        public byte[] Items_snowball = new byte[] { 0x32, 0x1F, 0x76, 0xB0 };
        public byte[] Items_furnace = new byte[] { 0x32, 0x1F, 0x8F, 0xC0 };
        public byte[] Items_egg = new byte[] { 0x32, 0x1F, 0x91, 0x50 };
        public byte[] Items_cooked_beef = new byte[] { 0x32, 0x1F, 0xC3, 0x80 };
        public byte[] Items_blazer_rood = new byte[] { 0x32, 0x1D, 0xAC, 0x40 };
        public byte[] Items_ender_perl = new byte[] { 0x32, 0x1D, 0xA9, 0xF0 };
        public byte[] Items_spawn_egg = new byte[] { 0x32, 0x20, 1, 0xC0 };
        public byte[] Items_experience_bottle = new byte[] { 0x32, 0x20, 4, 0x10 };
        public byte[] Items_writen_booke = new byte[] { 0x32, 0x20, 0xB, 0xE0 };
        public byte[] Items_emerald = new byte[] { 0x32, 0x20, 0xE, 0x30 };
        public byte[] Items_enchanted_book = new byte[] { 0x32, 0x20, 0x32, 0x80 };
        public byte[] Items_tnt_minecraft = new byte[] { 0x32, 0x20, 0x3B, 0xC0 };
        public byte[] Items_armor_stand = new byte[] { 0x32, 0x20, 0x52, 0x70 };
        public byte[] Items_commande_block_minecraft = new byte[] { 0x32, 0x20, 0x64, 0x20 };
        public byte[] Items_banner = new byte[] { 0x32, 0x20, 0x6C, 0 };
        public byte[] Items_end_crystal = new byte[] { 0x32, 0x20, 0x6E, 0x50 };
        public byte[] Items_totem_of_undying = new byte[] { 0x32, 0x20, 0xA4, 0xF0 };
        public byte[] Items_trident = new byte[] { 0x32, 0x20, 0xB0, 0x30 };
        public byte[] Items_debug_four_items = new byte[] { 0x32, 0x20, 0xCF, 0xB0 };
        public byte[] Blocks_air = new byte[] { 0x32, 0x18, 0x10, 0x20 };
        public byte[] Blocks_stone = new byte[] { 0x32, 0x18, 0x11, 0xC0 };
        public byte[] Blocks_grass = new byte[] { 0x32, 0x18, 0x13, 0x10 };
        public byte[] Blocks_water = new byte[] { 0x32, 0x18, 0x1D, 0x70 };
        public byte[] Blocks_lava = new byte[] { 0x32, 0x18, 0x20, 0xF0 };
        public byte[] Blocks_sand = new byte[] { 0x32, 0x18, 0x22, 0xA0 };
        public byte[] Blocks_bed = new byte[] { 0x32, 0x18, 0x37, 0x80 };
    }
}