﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Threading;
using System.Net.Sockets;
using System.IO;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace SPRX_Injector
{
    public partial class Form1 : Form
    {
        #region vars
        private static TMAPI PS3 = new TMAPI();
        private static PS3RPC PS3RPC = new PS3RPC(PS3);
        string currentPath = "";
        string currentName = "";
        string[] saveText = { "False", "", "" }; //change text to whatever
        string app_file = @"C:\Users\" + Environment.UserName + @"\AppData\Roaming\sprxLoader\settings.txt";
        string app_folder = @"C:\Users\" + Environment.UserName + @"\AppData\Roaming\sprxLoader";
        string sprxName = "";
        bool canUnload = false;
        string pName = "na";
        int[] saveIndex = new int[1000];
        #endregion
        #region form load
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists(app_file))
                {
                    saveText = File.ReadAllLines(app_file);
                }
                else
                {
                    if (!Directory.Exists(app_folder))
                    {
                        Directory.CreateDirectory(app_folder);
                    }
                    File.WriteAllLines(app_file, saveText);
                    saveText = File.ReadAllLines(app_file);
                }
                //change text box to whatever
                checkBox2.Checked = (saveText[0] == "True") ? true : false;
                currentPath = saveText[1];
                if (currentPath != "")
                    addSprx(currentPath);
                string paths = saveText[2];
                if (paths != "")
                {
                    string[] check = Regex.Split(paths, "<pn>");
                    for (int i = 0; i < check.Length; i++)
                    {
                        if (check[i] != "" && check[i].EndsWith(".sprx"))
                        {
                            FileInfo file = new FileInfo(check[i]);
                            dataGridView1.Rows.Add(file.Name.Remove(file.Name.Length - 5, 5), check[i]);
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("Error has ocurred when retrieving settings.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                string combinePaths = "";
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    combinePaths += dataGridView1[1, i].Value.ToString() + "<pn>";
                }
                saveText = new string[] { checkBox2.Checked.ToString(), currentPath, combinePaths }; //change text box to whatever
                if (!Directory.Exists(app_folder))
                {
                    Directory.CreateDirectory(app_folder);
                }
                File.WriteAllLines(app_file, saveText);
            }
            catch
            {
                MessageBox.Show("Error has ocurred when saving settings.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion
        #region sprx control
        private void loadingSprx(string doWhat)
        {
            ulong error = 0x0;
            if (doWhat == "load" && currentName != "" && currentPath.EndsWith(".sprx"))
            {
                string modulePath = currentPath;
                if (!modulePath.Contains("hdd0"))
                    modulePath = "/host_root/" + currentPath;

                modulePath.Replace("\\", "/");
                error = PS3RPC.LoadModule(modulePath);
            }
            else if (doWhat == "unload" && canUnload)
            {
                uint moduleId = getSprxID();

                if (moduleId != 0x0)
                    error = PS3RPC.UnloadModule(moduleId);
                else if (moduleId == 0x0)
                    MessageBox.Show("No SPRX Loaded");
            }

            if (error != 0x0)
                MessageBox.Show("Unload Module Error: 0x" + error.ToString("X"));
        }

        uint getSprxID()
        {
            uint[] modules = PS3RPC.GetModules();

            for (int i = 0; i < modules.Length; i++)
            {
                if (modules[i] != 0x0)
                {
                    string Name = PS3.GetModuleName(modules[i]);
                    if (Name == currentName)
                    {
                        pName = "cur " + i + " len " + modules.Length + " " + Name + " | " + modules[i];
                        sprxName = PS3.GetModuleName(modules[i]);
                        return modules[i];
                    }
                }
            }
            return 0;
        }
        uint[] modIds;
        private void updateModules()
        {
            listBox1.Items.Clear();
            uint[] modules = PS3RPC.GetModules();
            modIds = new uint[modules.Length];
            for (int i = 0; i < modules.Length; i++)
            {
                if (modules[i] != 0x0)
                {
                    string Name = PS3.GetModuleName(modules[i]);
                    string modName = "#" + i + " len " + modules.Length + " " + Name + " | ID " + modules[i];
                    modIds[i] = modules[i];
                    listBox1.Items.Add(modName);
                }
            }
        }

        private void addSprx(string path)
        {
            FileInfo file = new FileInfo(path);
            if (path.EndsWith(".sprx"))
            {
                currentPath = path;
                currentName = file.Name.Remove(file.Name.Length - 5, 5);
                label4.Text = "Current SPRX: " + currentName;
            }
            else
                MessageBox.Show("Invalid File!");
        }

        private void addSprxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addSprx(dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString());
        }
        #endregion
        #region form controls
        private void button1_Click(object sender, EventArgs e)
        {
            loadingSprx("unload");
            Task.Delay(200).Wait();
            loadingSprx("load");
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            TopMost = checkBox2.Checked;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            loadingSprx("unload");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "SPRX Files|*.sprx";
            openFileDialog1.Title = "Select a File";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                FileInfo file = new FileInfo(openFileDialog1.FileName);

                if (file.Name.EndsWith(".sprx"))
                {
                    dataGridView1.Rows.Add(file.Name.Remove(file.Name.Length - 5, 5), openFileDialog1.FileName);
                }
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count != 0)
            {
                if (dataGridView1.CurrentRow.Index != -1)
                {
                    dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            new prxCode().ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show((currentPath != "") ? currentPath : "No Path Entered");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(pName);
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex != -1)
                {
                    string name = dataGridView1[1, e.RowIndex].Value.ToString();
                    if (name.EndsWith(".sprx"))
                    {
                        FileInfo file = new FileInfo(name);
                        dataGridView1[0, e.RowIndex].Value = file.Name.Remove(file.Name.Length - 5, 5);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Invalid File!");
            }
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                PS3RPC.UnloadModule(modIds[listBox1.SelectedIndex]);
                updateModules();
            }
        }
        #endregion
        #region connection
        private void button2_Click(object sender, EventArgs e)
        {
            string connect = "";
            string attach = "";
            try
            {
                if (PS3.ConnectTarget())
                {
                    connect = "Connected";
                    try
                    {
                        if (PS3.AttachProcess())
                        {
                            attach = "Attached";
                            label5.Text = "Current Game: " + PS3.GetCurrentGame();
                            updateModules();
                            timer1.Stop();
                            timer1.Start();
                        }
                        else
                        {
                            attach = "Cannot Attach";
                        }
                    }
                    catch
                    {
                        attach = "Impossible to Attach";
                    }
                }
                else
                {
                    connect = "Cannot Connect";
                }
            }
            catch
            {
                connect = "Impossible To Connect";
            }
            Text = "SPRX Injector: " + connect + " - " + attach;
        }
        #endregion
        #region timer
        public static bool checkByte(ulong addr)
        {
            byte[] val = new byte[1];
            bool ret = (PS3TMAPI.ProcessGetMemory(0, PS3TMAPI.UnitType.PPU, TMAPI.Parameters.ProcessID, 0, addr, ref val) ==
                PS3TMAPI.SNRESULT.SN_S_OK);
            return ret;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!checkByte(0x00020000))
            {
                button1.Enabled = false;
                button3.Enabled = false;
                label5.Text = "Current Game: N/A";
                label2.Text = "False";
                label2.ForeColor = Color.Red;
                Text = "SPRX Injector: Not Connected - Not Attached";
            }
            else
            {
                if (getSprxID() != 0)
                {
                    label2.Text = "True";
                    label2.ForeColor = Color.Green;
                    button3.Enabled = true;
                    canUnload = true;
                }
                else
                {
                    label2.Text = "False";
                    label2.ForeColor = Color.Red;
                    button3.Enabled = false;
                    canUnload = false;
                }

            }
            if (currentName != "")
                button1.Enabled = true;
            else
                button1.Enabled = false;

        }
        #endregion
    }
}