﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Debugger_NEW
{
    public partial class Form2 : Form
    {
        public static bool isOpen = false;
        public static bool updateForm = false;
        public static bool canUpdateForm = false;
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Form1.addResult.Count != 0)
            {
                SaveFileDialog file = new SaveFileDialog();
                file.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                file.FileName = "Results";
                if (file.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllLines(file.FileName, Form1.addResult.ToArray());
                    MessageBox.Show("Saved at: " + file.FileName, "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
        
        private void Form2_Load(object sender, EventArgs e)
        {
            isOpen = true;
            
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            updateForm = false;
            isOpen = false;
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                uint copy = Form1.foundOfs[listBox1.SelectedIndex];
                if (copy != 0)
                    Clipboard.SetText( "0x" +  Form1.padZeros(String.Format("{0:X}", copy)));
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                Form1.foundOfs.RemoveAt(listBox1.SelectedIndex);
                Form1.foundVal.RemoveAt(listBox1.SelectedIndex);
                Form1.editVal.RemoveAt(listBox1.SelectedIndex);
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            }
        }

        private void yesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1.foundOfs.Clear();
            Form1.foundVal.Clear();
            Form1.editVal.Clear();
            listBox1.Items.Clear();
        }

        private void copySelectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string copy = listBox1.Text;
            if (copy != "")
                Clipboard.SetText(copy);
        }

        private void onToolStripMenuItem_Click(object sender, EventArgs e)
        {
            canUpdateForm = true;
            updateForm = true;
            updateList();
        }

        private void offToolStripMenuItem_Click(object sender, EventArgs e)
        {
            canUpdateForm = false;
            updateForm = false;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            updateList();
        }
        private void updateList()
        {
            if (listBox1.SelectedIndex != -1 && updateForm)
            {
                Form1.CURoffset = Form1.foundOfs[listBox1.SelectedIndex];
            }
        }
        private void toggleVal()
        {
            int index = listBox1.SelectedIndex;
            if (Form1.isAttached && Form1.foundVal.Count != 0 && index != -1)
            {
                if (Form1.PS3.Extension.ReadBytes(Form1.foundOfs[index], Form1.editVal[index].Length / 2).SequenceEqual(Form1.hex2Bytes_(Form1.editVal[index])))
                    Form1.PS3.Extension.WriteBytes(Form1.foundOfs[index], Form1.hex2Bytes_(Form1.foundVal[index]));
                else
                    Form1.PS3.Extension.WriteBytes(Form1.foundOfs[index], Form1.hex2Bytes_(Form1.editVal[index]));
            }
        }

        private void toggleValueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toggleVal();
        }

        private void listBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == ' ')
                toggleVal();
        }
    }
}
