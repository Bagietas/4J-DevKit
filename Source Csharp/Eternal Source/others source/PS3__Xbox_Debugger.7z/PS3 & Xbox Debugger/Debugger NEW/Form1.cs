﻿using System.Collections.Generic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Data;
using Be.Windows.Forms;
using XDevkit;
using PS3Lib;

namespace Debugger_NEW
{
    public partial class Form1 : Form
    {
        #region defaults
        string console = "ps3";
        public static PS3API PS3 = new PS3API();
        public static IXboxConsole Jtag;
        public static ulong CURoffset = 0x00010000;
        DynamicFileByteProvider dynamicFileByteProvider;
        Memory pc64 = new Memory();
        string processName64 = "";
        string directionMethod = "";
        bool pause = true;
        string currentOfs = "0x00010000";
        bool writeByte = false;
        string[] saveText = { "255-255-255", "0-0-0", "default", "0", "0x00010000", "", "", "170-170-170", "150-150-150", "", "False", "192.168.1.1", "0-0-0" }; //change text to whatever
        int pcBit = 32;
        string app_file = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + @"\Debugger Settings\Settings.txt";
        string app_folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + @"\Debugger Settings";
        bool useCB = true;
        bool groupDiv = false;
        #endregion
        #region Form
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < 20; i++)
                {
                    Panel panel = new Panel();
                    panel.Size = new Size(1, 1000);
                    panel.Location = new Point(81 + 96 * i, 0);
                    panel.BackColor = Color.Black;
                    panel.Name = "panelLine" + i;
                    panel.Visible = false;
                    hexBox1.Controls.Add(panel);
                }
                if (File.Exists(app_file))
                {
                    saveText = File.ReadAllLines(app_file);
                }
                else
                {
                    if (!Directory.Exists(app_folder))
                    {
                        Directory.CreateDirectory(app_folder);
                    }
                    File.WriteAllLines(app_file, saveText);
                    saveText = File.ReadAllLines(app_file);
                }
                //change text box to whatever
                string[] getBg = Regex.Split(saveText[0], "-");
                string[] getTxt = Regex.Split(saveText[1], "-");
                string[] getCB = Regex.Split(saveText[7], "-");
                string[] getSel = Regex.Split(saveText[8], "-");
                string[] getDiv = Regex.Split(saveText[12], "-");
                //toolStripTextBox1.Text = Convert.ToString(saveText[2]);
                toolStripTextBox3.Text = Convert.ToString(saveText[9]);
                groupDiv = Convert.ToBoolean(saveText[10]);

                toolStripComboBox1.SelectedIndex = Convert.ToInt32(saveText[3]);
                string[] split = Regex.Split(saveText[4], "-");
                textBox1.Text = saveText[5];
                textBox2.Text = saveText[6];
                toolStripTextBox2.Text = saveText[11];
                toolStripComboBox2.Items.AddRange(split);
                toolStripComboBox2.SelectedIndex = 0;
                saveAddy.AddRange(split);
                if (getBg[0] == "0" && getBg[1] == "0" && getBg[2] == "0" && getTxt[0] == "0" && getTxt[1] == "0" && getTxt[2] == "0")
                {
                    getBg[0] = "255";
                    getBg[1] = "255";
                    getBg[2] = "255";
                }
                if (getCB[0] == "0" && getCB[1] == "0" && getCB[2] == "0")
                {
                    getCB[0] = "100";
                    getCB[1] = "100";
                    getCB[2] = "100";
                }
                if (getSel[0] == "0" && getSel[1] == "0" && getSel[2] == "0")
                {
                    getSel[0] = "150";
                    getSel[1] = "150";
                    getSel[2] = "150";
                }

                bg.Color = Color.FromArgb(Convert.ToInt16(getBg[0]), Convert.ToInt16(getBg[1]), Convert.ToInt16(getBg[2]));
                txt.Color = Color.FromArgb(Convert.ToInt16(getTxt[0]), Convert.ToInt16(getTxt[1]), Convert.ToInt16(getTxt[2]));
                cb.Color = Color.FromArgb(Convert.ToInt16(getCB[0]), Convert.ToInt16(getCB[1]), Convert.ToInt16(getCB[2]));
                sel.Color = Color.FromArgb(Convert.ToInt16(getSel[0]), Convert.ToInt16(getSel[1]), Convert.ToInt16(getSel[2]));
                div.Color = Color.FromArgb(Convert.ToInt16(getDiv[0]), Convert.ToInt16(getDiv[1]), Convert.ToInt16(getDiv[2]));
                setBgColor(bg.Color);
                setTxtColor(txt.Color);
                setSelColor(sel.Color);
                setDivColor(div.Color);
                this.hexBox1.MouseWheel += new MouseEventHandler(hexBox_MouseWheel);
            }
            catch
            {
                MessageBox.Show("Error has ocurred when retrieving settings.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            timer1.Start();
            timer2.Start();
            timer3.Start();
            timer4.Start();


        }
        Panel panel = new Panel();

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                List<string> addOfs = new List<string>();
                for (int i = 0; i < toolStripComboBox2.Items.Count; i++)
                    addOfs.Add(toolStripComboBox2.Items[i].ToString());
                string bgRGB = Convert.ToString(bg.Color.R) + "-" + Convert.ToString(bg.Color.G) + "-" + Convert.ToString(bg.Color.B);
                string txtRGB = Convert.ToString(txt.Color.R) + "-" + Convert.ToString(txt.Color.G) + "-" + Convert.ToString(txt.Color.B);
                string cbRGB = Convert.ToString(cb.Color.R) + "-" + Convert.ToString(cb.Color.G) + "-" + Convert.ToString(cb.Color.B);
                string selRGB = Convert.ToString(sel.Color.R) + "-" + Convert.ToString(sel.Color.G) + "-" + Convert.ToString(sel.Color.B);
                string divRGB = Convert.ToString(div.Color.R) + "-" + Convert.ToString(div.Color.G) + "-" + Convert.ToString(div.Color.B);

                saveText = new string[] { bgRGB, txtRGB, "", toolStripComboBox1.SelectedIndex.ToString(), String.Join("-", addOfs.ToArray()), textBox1.Text, textBox2.Text, cbRGB, selRGB, toolStripTextBox3.Text, groupDiv.ToString(), toolStripTextBox2.Text, divRGB }; //change text box to whatever
                if (!Directory.Exists(app_folder))
                {
                    Directory.CreateDirectory(app_folder);
                }
                File.WriteAllLines(app_file, saveText);
            }
            catch
            {
                MessageBox.Show("Error has ocurred when saving settings.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion
        #region Theme
        public static ColorDialog bg = new ColorDialog();
        public static ColorDialog txt = new ColorDialog();
        public static ColorDialog cb = new ColorDialog();
        public static ColorDialog sel = new ColorDialog();
        public static ColorDialog div = new ColorDialog();
        private void backgroundToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            bg.FullOpen = true;
            if (bg.ShowDialog() == DialogResult.OK)
                setBgColor(bg.Color);
        }

        private void textToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            txt.FullOpen = true;
            if (txt.ShowDialog() == DialogResult.OK)
                setTxtColor(txt.Color);
        }

        private void changedByteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cb.FullOpen = true;
            cb.ShowDialog();
        }

        private void selectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sel.FullOpen = true;
            if (sel.ShowDialog() == DialogResult.OK)
                setSelColor(sel.Color);
        }
        Color tintColor(Color rgb)
        {
            int[] cR = new int[3];
            int[] num = new int[3];
            for (int i = 0; i < 3; i++)
            {
                if (i == 0) { cR[i] = rgb.R; }
                if (i == 1) { cR[i] = rgb.G; }
                if (i == 2) { cR[i] = rgb.B; }
                if (cR[i] > 51) { num[i] = 50; }
                else { num[i] = cR[i]; }
            }

            return Color.FromArgb(100, cR[0] - num[0], cR[1] - num[1], cR[2] - num[2]);
        }
        public void setBgColor(Color rgb)
        {
            hexBox1.BackColor = rgb;
        }

        public void setTxtColor(Color rgb)
        {
            hexBox1.ForeColor = rgb;
            hexBox1.SelectionForeColor = rgb;
            hexBox1.InfoForeColor = rgb;
        }
        public void setDivColor(Color rgb)
        {
            foreach (Panel ctrl in hexBox1.Controls.OfType<Panel>())
            {
                ctrl.BackColor = rgb;
            }
        }
        public void setSelColor(Color rgb)
        {
            hexBox1.SelectionBackColor = rgb;
            hexBox1.ShadowSelectionColor = Color.FromArgb(100, rgb);
        }
        #endregion
        #region Connection
        private void connectPs3()
        {
            string connect = "Not Connected";
            string attach = "Not Attached";
            try
            {
                bool conPS3 = false;
                ps3Ip = toolStripTextBox2.Text;
                if (toolStripComboBox1.SelectedIndex == 0) { PS3.ChangeAPI(SelectAPI.TargetManager); conPS3 = PS3.ConnectTarget(); }
                else if (toolStripComboBox1.SelectedIndex == 1) { PS3.ChangeAPI(SelectAPI.ControlConsole); conPS3 = PS3.ConnectTarget(ps3Ip); }

                if (conPS3)
                {
                    connect = "Connected";
                    try
                    {
                        if (PS3.AttachProcess())
                        {
                            attach = "Attached";
                            console = "ps3";
                            afterAttach();
                        }
                        else
                        {
                            attach = "Cannot Attach";
                        }
                    }
                    catch
                    {
                        attach = "Impossible to Attach";
                    }
                }
                else
                {
                    connect = "Cannot Connect";
                }
            }
            catch
            {
                connect = "Impossible To Connect";
            }
            Text = "Universal Debugger - " + connect + " - " + attach + " | API - " + PS3.GetCurrentAPIName();
        }

        //private void connectXbox()
        //{
        //    string connect = "Not Connected";
        //    string attach = "Not Attached";
        //    try
        //    {
        //        string shit = toolStripTextBox1.Text;
        //        if (Jtag.Connect(out Jtag, shit))
        //        {
        //            connect = "Connected";
        //            attach = "Attached";
        //            console = "xbox";
        //            afterAttach();
        //        }
        //        else
        //        {
        //            connect = "Cannot Connect";
        //        }
        //    }
        //    catch
        //    {
        //        connect = "Impossible To Connect";
        //    }
        //    Text = "Universal Debugger - " + connect + " | " + attach;
        //}

        #region "DEVKIT/XBOX - Conection"

        ///
        // This is the Correct Connection for the DEVKIT/XBOX
        // This will also work flawless with a normal RGH/XBOX 
        // You should not need the JRPC only the xdrpc.dll (has JRPC, RPC, and XRPC in it already) 
        // I have provided everything uou need in this text document and the .zip/.rar file :) 
        // One last thing fix that button scroll bar to a normal scroll bar LOL ;)
        // ~ MrMods (TheOne.and.OnlyMrMods)
        ///

        public IXboxManager xbManager = null;
        public IXboxConsole xbCon = null;
        public bool activeConnection = false;
        public uint xboxConnection = 0;
        private string debuggerName = null;
        private string userName = null;
        public uint outBytes = 0;
        public uint num;
        private static byte[] MemoryData = null;
        private uint currentTitle = 0;
        private string xbConTitle = "DEVKIT";

        public bool ConnectToConsole()
        {
            string connect = "Not Connected";
            string attach = "Not Attached";
            try
            {
                if (!this.activeConnection)
                {
                    this.xbManager = new XboxManager();
                    this.xbCon = this.xbManager.OpenConsole(this.xbManager.DefaultConsole);

                    try
                    {
                        this.xboxConnection = this.xbCon.OpenConnection(null);
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Could not connect to console: " + this.xbManager.DefaultConsole, xbConTitle);
                        connect = "Cannot Connect";
                        attach = "Cannot Attach";
                        Text = "Universal Debugger - " + connect + " | " + attach;
                        return false;
                    }
                    if (this.xbCon.DebugTarget.IsDebuggerConnected(out this.debuggerName, out this.userName))
                    {
                        this.activeConnection = true;
                        MessageBox.Show("Connection to " + xbCon.Name + " established!", xbConTitle);//\n\n" + "Current Title ID: 0x" + xbCon.GetCurrentTitleId().ToString("X"), xbConTitle);
                        connect = "Connected";
                        attach = "Attached";
                        console = "xbox";
                        Text = "Universal Debugger - " + connect + " | " + attach;
                        afterAttach();
                        return true;
                    }
                    else
                    {
                        this.xbCon.DebugTarget.ConnectAsDebugger("MrMods", XboxDebugConnectFlags.Force);
                        if (!this.xbCon.DebugTarget.IsDebuggerConnected(out this.debuggerName, out this.userName))
                        {
                            MessageBox.Show("Attempted to connect to console: " + xbCon.Name + " but failed", xbConTitle);
                            connect = "Cannot Connect";
                            connect = "Cannot Attach";
                            Text = "Universal Debugger - " + connect + " | " + attach;
                            return false;
                        }
                        else
                        {
                            this.activeConnection = true;
                            MessageBox.Show("Connection to " + xbCon.Name + " established!", xbConTitle);//\n\n" + "Current Title ID: 0x" + xbCon.GetCurrentTitleId().ToString("X"), xbConTitle);
                            connect = "Connected";
                            attach = "Attached";
                            console = "xbox";
                            Text = "Universal Debugger - " + connect + " | " + attach;
                            afterAttach();
                            return true;
                        }
                    }
                }
                else if (this.xbCon.DebugTarget.IsDebuggerConnected(out this.debuggerName, out this.userName))
                {
                    MessageBox.Show("Connection to " + xbCon.Name + " already established!", xbConTitle);
                    connect = "Connected";
                    attach = "Attached";
                    console = "xbox";
                    Text = "Universal Debugger - " + connect + " | " + attach;
                    afterAttach();
                    return true;
                }
                else
                {
                    this.activeConnection = false;
                    connect = "Cannot Connect";
                    attach = "Cannot Attach";
                    Text = "Universal Debugger - " + connect + " | " + attach;
                    return ConnectToConsole();
                }
            }
            catch
            {
                connect = "Impossible To Connect";
                attach = "Impossible To Attach";
                Text = "Universal Debugger - " + connect + " | " + attach;
                return ConnectToConsole();
            }
        }
        #endregion

        private void connectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConnectToConsole();
        }
        #endregion
        #region Hex Box
        private void afterAttach()
        {
            isAttached = true;
            // tableLayoutPanel1.Visible = true;
            vScrollBar1.Visible = true;
            dynamicFileByteProvider = new DynamicFileByteProvider(Stream.Null);
            hexBox1.CurrentPositionInLineChanged += new System.EventHandler(this.Position_Changed);
            hexBox1.CurrentLineChanged += new System.EventHandler(this.Position_Changed);
            dynamicFileByteProvider.Changed += new System.EventHandler(this.byte_Changed);
            setOfs();
            if (console == "xbox")
            {
                saveOfs();
                updateHexView = true;
            }
            else if (console == "ps3")
            {
                updateHexView = true;
            }
            
            else if (console == "pc")
            {
                if (toolStripComboBox3.SelectedIndex == 0)
                    pcBit = 32;
                else if (toolStripComboBox3.SelectedIndex == 1)
                    pcBit = 64;
                saveOfs();
                updateHexView = true;
                if (pcBit == 64)
                {
                    processName64 = toolStripTextBox3.Text;

                    if (pc64.Open_pHandel(processName64))
                        MessageBox.Show("" + pc64.ReadByte(0x23DFEFB8B38));
                }
            }
            if (groupDiv)
            {
                hexBox1.GroupSeparatorVisible = true;
                unfollowPointerToolStripMenuItem.Visible = true;
                followPointerToolStripMenuItem.Visible = true;
            }
            canConAPI = true;
            if (!backgroundWorker1.IsBusy)
                backgroundWorker1.RunWorkerAsync();

        }
        void byte_Changed(object sender, EventArgs e)
        {
            try
            {
                if (writeByte && hexBox1.SelectionStart > -1)
                {
                    if (console == "xbox")
                        XDRPCPlusPlus.WriteByte(xbCon, Convert.ToUInt32(currentOfs, 16), dynamicFileByteProvider.ReadByte(hexBox1.SelectionStart));
                    else if (console == "ps3")
                        PS3.Extension.WriteByte(Convert.ToUInt32(currentOfs, 16), dynamicFileByteProvider.ReadByte(hexBox1.SelectionStart));
                    else if (console == "pc")
                    {
                        if (pcBit == 32)
                        {
                            CC.ProcessName = toolStripTextBox3.Text; CC.Write._Byte(Convert.ToUInt32(currentOfs, 16), dynamicFileByteProvider.ReadByte(hexBox1.SelectionStart));
                        }
                        else if (pcBit == 64)
                        {
                            if (pc64.Open_pHandel(processName64))
                            {
                                pc64.WriteByte(Convert.ToInt64(currentOfs, 16), dynamicFileByteProvider.ReadByte(hexBox1.SelectionStart));
                            }
                        }
                    }

                }
            }
            catch
            {

            }
        }
        public static string padZeros(string inInt)
        {
            StringBuilder stringBuilder = new StringBuilder();
            if (inInt.Length < 8)
            {
                int length = 8 - inInt.Length;
                for (int i = 0; i < length; i++)
                {
                    stringBuilder.Append("0");
                }
            }
            stringBuilder.Append(inInt);
            return stringBuilder.ToString().ToUpper();
        }
        void Position_Changed(object sender, EventArgs e)
        {
            posChange();
        }
        private void posChange()
        {
            try
            {
                uint math = (uint)hexBox1.VerticalByteCount * (uint)hexBox1.HorizontalByteCount;
                if (math <= hexBox1.SelectionStart)
                {
                    hexBox1.SelectionStart = math - 1;
                }
                uint val = (uint)CURoffset + (uint)hexBox1.SelectionStart;
                currentOfs = "0x" + padZeros(String.Format("{0:X}", val));
            }
            catch
            {

            }
        }
        byte[] prevDump = { };
        int[] changedBytes = { };
        byte[] byteDump = { };
        private void loadBytes()
        {
            if (FormWindowState.Minimized != WindowState)
            {
                try
                {
                    if (console != "pc")
                    {
                        if (CURoffset < 0x00010000)
                            CURoffset = 0x00010000;
                    }
                    writeByte = false;
                    dynamicFileByteProvider.DeleteBytes(0, dynamicFileByteProvider.Length);
                    if (console == "xbox")
                    {
                        byteDump = XDRPCPlusPlus.ReadBytes(xbCon, (uint)CURoffset, (uint)hexBox1.VerticalByteCount * (uint)hexBox1.HorizontalByteCount);
                        dynamicFileByteProvider.InsertBytes(0, byteDump);
                    }
                    else if (console == "ps3")
                    {
                        byteDump = PS3.Extension.ReadBytes((uint)CURoffset, hexBox1.VerticalByteCount * hexBox1.HorizontalByteCount);
                        dynamicFileByteProvider.InsertBytes(0, byteDump);
                    }
                    else if (console == "pc")
                    {
                        if (pcBit == 32)
                        {
                            if (CC.ProcessName != "")
                            {
                                CC.ProcessName = toolStripTextBox3.Text;
                                byteDump = CC.Read._Bytes((uint)CURoffset, hexBox1.VerticalByteCount * hexBox1.HorizontalByteCount);
                                dynamicFileByteProvider.InsertBytes(0, byteDump);
                            }
                            else
                                isAttached = false;
                        }
                        else if (pcBit == 64)
                        {
                            if (pc64.Open_pHandel(processName64))
                            {
                                byteDump = pc64.ReadBytes((long)CURoffset, hexBox1.VerticalByteCount * hexBox1.HorizontalByteCount);
                                dynamicFileByteProvider.InsertBytes(0, byteDump);
                            }
                        }
                    }

                    hexBox1.ByteProvider = dynamicFileByteProvider;
                    hexBox1.LineInfoOffset = (uint)CURoffset;
                    hexBox1.Refresh();
                    posChange();

                    if (pause)
                        timer1.Interval = 500;
                    else
                        timer1.Interval = scrollSpeed;

                    pause = false;

                    writeByte = true;

                }
                catch
                {

                }
            }
        }
        Rectangle updateByte(int pos)
        {
            int h = hexBox1.HorizontalByteCount;
            int y = pos / h;
            int x = pos - y * h;
            return new Rectangle(85 + 24 * x, 1 + 16 * y, 16, 16);
        }

        private void hexBox1_Paint(object sender, PaintEventArgs e)
        {
            if (useCB)
            {
                Graphics g = e.Graphics;
                System.Drawing.SolidBrush myBrush = new System.Drawing.SolidBrush(cb.Color);

                for (int i = 0; i < changedBytes.Length; i++)
                    g.FillRectangle(myBrush, updateByte(changedBytes[i]));
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {

        }

        bool canChange = false;
        int scrollValue = 20;
        private void vScrollBar1_ValueChanged(object sender, EventArgs e)
        {
            if (canChange)
                vScrollBar1.Value = scrollValue;

        }
        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            if (e.Type == ScrollEventType.ThumbTrack)
            {
                canChange = false;

                if (e.OldValue > e.NewValue)
                {
                    multiLine = true;
                    loadLine = true;
                    pageUp();
                }
                else if (e.OldValue < e.NewValue)
                {
                    multiLine = true;
                    loadLine = true;
                    pageDown();
                }

            }
            else
                canChange = true;
            if (e.Type == ScrollEventType.EndScroll)
                vScrollBar1.Value = scrollValue;

            if (e.Type == ScrollEventType.SmallIncrement)
            {
                loadLine = true;
                pageDown();
            }
            if (e.Type == ScrollEventType.SmallDecrement)
            {
                loadLine = true;
                pageUp();
            }
            if (e.Type == ScrollEventType.LargeIncrement)
            {
                pageDown();
            }
            if (e.Type == ScrollEventType.LargeDecrement)
            {
                pageUp();
            }
        }
        #endregion
        #region Debugger
        bool loadLine = false;
        bool loadPrevFirst = true;
        //direction, loadLine, multiLine
        public void debugger()
        {
            if (autoUpdate)
                updateHexView = true;
            if (updateHexView)
            {
                updateHexView = false;

                uint len = (uint)hexBox1.VerticalByteCount * (uint)hexBox1.HorizontalByteCount;
                if (loadLine)
                {
                    if (multiLine)
                        len = (uint)hexBox1.HorizontalByteCount * 2;
                    else
                        len = (uint)hexBox1.HorizontalByteCount;
                }
                if (directionMethod == "down")
                    CURoffset += (uint)len;
                else if (directionMethod == "up")
                    CURoffset -= (uint)len;
                bool tickCB = false;
                if (directionMethod != "")
                {
                    if (useCB)
                    {
                        tickCB = true;
                        useCB = false;
                    }
                    directionMethod = "";
                }

                loadBytes();

                if (loadPrevFirst)
                {
                    loadPrevFirst = false;
                    prevDump = byteDump;
                }

                if (!byteDump.SequenceEqual(prevDump))
                {
                    try
                    {
                        changedBytes = byteDump.Select((b, i) => b != prevDump[i] ? i : -1).Where(i => i != -1).ToArray();

                        if (useCB)
                           hexBox1.Refresh();

                        prevDump = byteDump;
                    }
                    catch
                    {

                    }
                }
                if (tickCB)
                    useCB = true;
            }
        }
        #endregion
        #region Controls
        private void hexBox_MouseWheel(object sender, MouseEventArgs e)
        {
            if (isAttached)
            {
                if (e.Delta > 0)
                {
                    multiLine = true;
                    loadLine = true;
                    pageUp();
                }
                else
                {
                    multiLine = true;
                    loadLine = true;
                    pageDown();
                }
            }
        }
        bool IsDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                    return false;
            }

            return true;
        }
        int scrollSpeed = 100;
        private void setToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    if (IsDigitsOnly(toolStripTextBox4.Text))
            //    {
            //        scrollSpeed = Convert.ToInt32(toolStripTextBox4.Text);
            //    }
            //    else
            //        MessageBox.Show("Invaild Number", "Unreconized characters", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            //catch
            //{
            //    MessageBox.Show("Invaild Number", "Unreconized characters", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
        }
        private void hexBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void onToolStripMenuItem_Click(object sender, EventArgs e)
        {
            useCB = true;
        }

        private void offToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            useCB = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(textBox1, "Length: " + textBox1.TextLength.ToString());
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(textBox2, "Length: " + textBox2.TextLength.ToString());
        }

        private void helpAboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Universal Debugger Developed by MayhemModding - v2.1\n\nThis memory debugger can be used on PC, PS3 and Xbox 360.\n\nTips:\n- Press G on hex view to go to address box.\n- In address box, math can be used. '0x' not needed.\n- In View results, right click on an offset and\n  click 'Toggle Value' to change between values.", "Help / About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void onToolStripMenuItem1_Click(object sender, EventArgs e)
        {
           // tableLayoutPanel3.Visible = true;
        }

        private void offToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            //tableLayoutPanel3.Visible = false;
        }

        private void yesToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            TopMost = true;
        }

        private void noToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            TopMost = false;
        }

        private void connectToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            connectPs3();
        }

        private void toolStripComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            setOfs();
        }
        private void copyOffsetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (isAttached)
                Clipboard.SetText(currentOfs);
        }

        private void pasteWriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (isAttached)
            {
                string getStr = Clipboard.GetText();
                if (getStr != "")
                {
                    if (console == "xbox")
                        XDRPCPlusPlus.WriteBytes(xbCon, Convert.ToUInt32(currentOfs, 16), ConvertHexToBytes(getStr.Replace(" ", "")));
                    else if (console == "ps3")
                        PS3.SetMemory(Convert.ToUInt32(currentOfs, 16), ConvertHexToBytes(getStr.Replace(" ", "")));
                    else if (console == "pc")
                    {
                        if (pcBit == 32)
                        {
                            CC.ProcessName = toolStripTextBox3.Text; CC.Write._Bytes(Convert.ToUInt32(currentOfs, 16), ConvertHexToBytes(getStr.Replace(" ", "")));
                        }
                        else if (pcBit == 64)
                        {
                            if (pc64.Open_pHandel(processName64))
                            {
                                pc64.WriteBytes(Convert.ToInt64(currentOfs, 16), ConvertHexToBytes(getStr.Replace(" ", "")));
                            }
                        }
                    }
                    updateHexView = true;

                }
            }
        }

        private void pasteCharToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (isAttached)
            {
                string getStr = Clipboard.GetText();
                if (getStr != "")
                {
                    if (console == "xbox")
                        XDRPCPlusPlus.WriteBytes(xbCon, Convert.ToUInt32(currentOfs, 16), Encoding.ASCII.GetBytes(getStr));
                    else if (console == "ps3")
                        PS3.SetMemory(Convert.ToUInt32(currentOfs, 16), Encoding.ASCII.GetBytes(getStr));
                    else if (console == "pc")
                    {
                        if (pcBit == 32)
                        {
                            CC.ProcessName = toolStripTextBox3.Text; CC.Write._Bytes(Convert.ToUInt32(currentOfs, 16), Encoding.ASCII.GetBytes(getStr));
                        }
                        else if (pcBit == 64)
                        {
                            if (pc64.Open_pHandel(processName64))
                            {
                                pc64.WriteBytes(Convert.ToInt64(currentOfs, 16), Encoding.ASCII.GetBytes(getStr));
                            }
                        }
                    }
                    updateHexView = true;
                }
            }
        }
        private static bool isHex(String str)
        {
            return Regex.IsMatch(str, @"^[a-fA-F0-9]+$");
        }
        private static byte[] ConvertHexToBytes(string input)
        {
            try
            {
                var result = new byte[(input.Length + 1) / 2];
                var offset = 0;
                if (input.Length % 2 == 1)
                {
                    // If length of input is odd, the first character has an implicit 0 prepended.
                    result[0] = (byte)Convert.ToUInt32(input[0] + "", 16);
                    offset = 1;
                }
                for (int i = 0; i < input.Length / 2; i++)
                {
                    result[i + offset] = (byte)Convert.ToUInt32(input.Substring(i * 2 + offset, 2), 16);
                }
                return result;
            }
            catch
            {
                return new byte[] { };
            }

        }

        private void copyHexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (isAttached)
            {
                writeByte = true;
                hexBox1.CopyHex();
            }
        }
        private void copyCharToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (isAttached)
                {
                    hexBox1.CopyHex();
                    string copy = Clipboard.GetText();

                    if (copy != "")
                        Clipboard.SetText(Hex2Str(ConvertHexToBytes(copy.Replace(" ", ""))));
                }
            }
            catch
            {

            }
        }
        private string Hex2Str(byte[] numArray)
        {
            StringBuilder stringBuilder = new StringBuilder();
            StringBuilder stringBuilder1 = new StringBuilder();
            for (int i = 0; i < (int)numArray.Length; i++)
            {
                int num2 = numArray[i];
                if (num2 > Convert.ToInt32(0x19) && num2 < Convert.ToInt32(0x7F))
                {
                    stringBuilder1.Append((char)numArray[i]);
                }
                else
                {
                    stringBuilder1.Append(".");
                }

                stringBuilder.Append(string.Concat(stringBuilder1.ToString()));
                stringBuilder1 = new StringBuilder();
            }
            return stringBuilder.ToString();
        }
        List<string> saveAddy = new List<string>();
        void saveOfs()
        {
            List<string> addItems = new List<string>();
            string line = toolStripComboBox2.Text;
            toolStripComboBox2.Items.Insert(0, line);

            for (int i = 0; i < toolStripComboBox2.Items.Count; i++)
                addItems.Add(toolStripComboBox2.Items[i].ToString());
            toolStripComboBox2.Items.Clear();

            toolStripComboBox2.Items.AddRange(addItems.Distinct().ToArray());
            if (toolStripComboBox2.Items.Count > 8)
                toolStripComboBox2.Items.RemoveAt(8);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            setOfs();
        }
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            updateHexView = true;
        }
        bool multiLine = false;
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (toolStripButton2.Checked)
            {
                autoUpdate = true;
            }
            else
            {
                autoUpdate = false;
            }
        }
        private void setOfs()
        {
            try
            {
                if (isAttached)
                {
                    string ofs = toolStripComboBox2.Text;
                    CURoffset = Convert.ToUInt64(ofs, 16);
                    saveOfs();
                    updateHexView = true;
                    resetTxt = true;

                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Invalid Address\n\n" + ex.ToString(), "Unreconized characters", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Clipboard.SetText(ex.ToString());
            }
        }

        private void toolStripComboBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                setOfs();
            }
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (groupDiv)
            {
                hexBox1.UseFixedBytesPerLine = false;
                hexBox1.BytesPerLine = (int)roundMulti4((uint)hexBox1.HorizontalByteCount);
                hexBox1.UseFixedBytesPerLine = true;
            }
        }

        private void pageUp()
        {
            updateHexView = true;
            directionMethod = "up";
        }
      
        private void pageDown()
        {
            updateHexView = true;
            directionMethod = "down";
        }
     

        bool canResetCB = true;
        bool resetTxt = false;
        private void hexBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (hexBox1.SelectionLength > 1)
                hexBox1.SelectionLength = 1;
            if (e.KeyCode == Keys.Delete || e.KeyCode == Keys.Back || e.Control && e.KeyCode == Keys.X || e.Control && e.KeyCode == Keys.V)
            {
                e.Handled = true;
            }
        }
        [DllImport("user32", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        private static extern short GetAsyncKeyState(Int32 vkey);

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (groupDiv && isAttached)
            {
                int lineCount = hexBox1.HorizontalByteCount / 4;
                int count = 0;
                foreach (Panel ctrl in hexBox1.Controls.OfType<Panel>())
                {
                    if (count < lineCount)
                    {
                        ctrl.Visible = true;
                    }
                    else
                        ctrl.Visible = false;
                    count++;
                }
            }
            if (resetTxt)
            {
                toolStripComboBox2.SelectedIndex = 0;
                resetTxt = false;
            }
            if (canUpdate)
            {
                canUpdate = false;
                updateList();
            }

            debugger();

        }
        int[] cbBytes = { };
        List<ulong> followOfs = new List<ulong>();
        public void updateList()
        {
            addResult.Clear();
            for (int i = 0; i < Form1.foundOfs.Count; i++)
                addResult.Add("0x" + padZeros(String.Format("{0:X}", Form1.foundOfs[i])) + " - " + foundVal[i]);

            if (Form2.isOpen)
            {
                frm2.listBox1.Items.Clear();
                frm2.listBox1.Items.AddRange(addResult.ToArray());
            }
        }
        private void followPointerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            followOfs.Add(CURoffset);
            hexBox1.SelectionStart = roundMulti4((uint)hexBox1.SelectionStart);
            uint ofs = PS3.Extension.ReadUInt32((uint)(CURoffset + (uint)hexBox1.SelectionStart));
            CURoffset = ofs;
            updateHexView = true;
        }

        uint roundMulti4(uint val)
        {
            uint lastNumber = val % 16;
            uint final = 0;
            if (lastNumber < 4)
                final = val - lastNumber;
            else if (lastNumber < 8)
                final = val - lastNumber + 4;
            else if (lastNumber < 12)
                final = val - lastNumber + 8;
            else if (lastNumber < 16)
                final = val - lastNumber + 12;
            return final;
        }

        private void unfollowPointerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (followOfs.Count != 0)
            {
                CURoffset = followOfs[followOfs.Count - 1];
                updateHexView = true;
                followOfs.RemoveAt(followOfs.Count - 1);
            }
        }

        private void onToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            groupDiv = true;
            hexBox1.GroupSeparatorVisible = true;
            unfollowPointerToolStripMenuItem.Visible = true;
            followPointerToolStripMenuItem.Visible = true;
        }

        private void offToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupDiv = false;
            hexBox1.GroupSeparatorVisible = false;
            unfollowPointerToolStripMenuItem.Visible = false;
            followPointerToolStripMenuItem.Visible = false;
            foreach (Panel ctrl in hexBox1.Controls.OfType<Panel>())
            {
                ctrl.Visible = false;
            }
        }
        private void copyPointerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (isAttached)
            {
                try
                {
                    hexBox1.SelectionStart = roundMulti4((uint)hexBox1.SelectionStart);
                    uint ofs = PS3.Extension.ReadUInt32((uint)(CURoffset + (uint)hexBox1.SelectionStart));
                    Clipboard.SetText("0x" + padZeros(String.Format("{0:X}", ofs)));
                }
                catch
                {

                }
            }
        }
        private void dividerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            div.FullOpen = true;
            if (div.ShowDialog() == DialogResult.OK)
                setDivColor(div.Color);
        }

        #endregion
        #region searcher
        #region outputs
        public int findBytes(byte[] haystack, byte[] needle, int start_index, bool searchStr)
        {
            int len = needle.Length;
            int limit = haystack.Length - len;
            for (int i = start_index; i <= limit; i++)
            {
                int k = 0;
                for (; k < len; k++)
                {
                    if (searchStr)
                    {
                        if (console != "pc")
                        {
                            bool check = string.Equals(byte2Char(needle[k]), byte2Char(haystack[i + k]), StringComparison.CurrentCultureIgnoreCase);
                            if (!check)
                                break;
                        }
                        else
                            if (needle[k] != haystack[i + k]) break;
                    }
                    else
                        if (needle[k] != haystack[i + k]) break;
                }
                if (k == len) return i;
            }
            return -1;
        }
        public static string ByteArrayToString(byte[] ba)
        {
            string hex = BitConverter.ToString(ba);
            return hex.Replace("-", "");
        }
        private byte[] str2Bytes(string str)
        {
            try
            {
                isValidStr = true;
                return Encoding.ASCII.GetBytes(str);
            }
            catch
            {
                isValidStr = false;
                return new byte[] { };
            }
        }

        public static List<int> IndexOfSequence(byte[] buffer, byte[] pattern, int startIndex)
        {
            List<int> positions = new List<int>();
            int i = Array.IndexOf<byte>(buffer, pattern[0], startIndex);
            while (i >= 0 && i <= buffer.Length - pattern.Length)
            {
                byte[] segment = new byte[pattern.Length];
                Buffer.BlockCopy(buffer, i, segment, 0, pattern.Length);
                if (segment.SequenceEqual<byte>(pattern))
                    positions.Add(i);
                i = Array.IndexOf<byte>(buffer, pattern[0], i + pattern.Length);
            }
            return positions;
        }
        bool isValidBytes;
        private byte[] hex2Bytes(string input)
        {
            try
            {
                isValidBytes = true;
                var result = new byte[(input.Length + 1) / 2];
                var offset = 0;
                if (input.Length % 2 == 1)
                {
                    result[0] = (byte)Convert.ToUInt32(input[0] + "", 16);
                    offset = 1;
                }
                for (int i = 0; i < input.Length / 2; i++)
                {
                    result[i + offset] = (byte)Convert.ToUInt32(input.Substring(i * 2 + offset, 2), 16);
                }
                return result;

            }
            catch
            {
                isValidBytes = false;
                return new byte[] { };
            }
        }
        public static byte[] hex2Bytes_(string input)
        {
            var result = new byte[(input.Length + 1) / 2];
            var offset = 0;
            if (input.Length % 2 == 1)
            {
                result[0] = (byte)Convert.ToUInt32(input[0] + "", 16);
                offset = 1;
            }
            for (int i = 0; i < input.Length / 2; i++)
            {
                result[i + offset] = (byte)Convert.ToUInt32(input.Substring(i * 2 + offset, 2), 16);
            }
            return result;
        }

        string byte2Char(byte charB)
        {
            string str = "";
            str += (char)charB;
            return str;
        }
        #endregion

        #region defaults
        public static bool isAttached = false;
        string replaceStr = "";
        string findStr = "";
        private Form2 frm2;
        public static List<string> addResult = new List<string>();
        bool isValidStr = false;
        public static List<uint> foundOfs = new List<uint>();
        public static List<string> foundVal = new List<string>();
        public static List<string> editVal = new List<string>();
        byte[] findVal = { };
        byte[] replaceVal = { };
        bool canConAPI = true;
        bool searchStr = false;
        string ps3Ip = "";
        bool canSearch = false;
        int findPos = 0;
        bool canUpdate = false;
        bool canReplace = false;
        uint searchOfs = 0;
        bool collectR = true;
        int autoMS = 100;
        bool autoUp = false;
        bool useSearcher = false;
        byte[] buffer = { };
        int[] indexes = { };
        int prevLen = 0;
        bool canPlus = false;
        bool autoUpdate = false;
        bool updateHexView = false;
        int updateTog = 0;
        #endregion

        #region controls
        private void button3_Click(object sender, EventArgs e)
        {

            byte[] sbyteDump = CC.Read._Bytes(0x7FF752410048, 100);

            MessageBox.Show("" + sbyteDump[0]);

            if (isAttached)
            {
                isValidStr = false;
                isValidBytes = false;
                if (radioButton3.Checked)
                {
                    searchStr = false;
                    findVal = hex2Bytes(textBox1.Text);
                }
                else if (radioButton4.Checked)
                {
                    searchStr = true;
                    findVal = str2Bytes(textBox1.Text);
                }
                if (isValidBytes || isValidStr)
                {
                    if (Form2.canUpdateForm)
                        Form2.updateForm = false;
                    findStr = textBox1.Text;
                    canPlus = true;
                    canReplace = false;
                    canSearch = true;
                }
                else
                    MessageBox.Show("Illegal characters detected!\nCheck that the Value Type is correct for the value you entered.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (isAttached)
            {
                isValidStr = false;
                isValidBytes = false;
                if (radioButton3.Checked)
                {
                    searchStr = false;
                    findVal = hex2Bytes(textBox1.Text);
                }
                else if (radioButton4.Checked)
                {
                    searchStr = true;
                    findVal = str2Bytes(textBox1.Text);
                }
                if (isValidBytes || isValidStr)
                {
                    if (Form2.canUpdateForm)
                        Form2.updateForm = false;
                    replaceStr = textBox2.Text;
                    replaceVal = hex2Bytes(textBox2.Text);
                    canPlus = true;
                    canReplace = true;
                    canSearch = true;
                }
                else
                    MessageBox.Show("Illegal characters detected!\nCheck that the Value Type is correct for the value you entered.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void conAPI(string use)
        {
            if (use == "ps3")
            {
                if (PS3.GetCurrentAPIName() == "Target Manager")
                    PS3.ConnectTarget();
                else if (PS3.GetCurrentAPIName() == "Control Console")
                    PS3.ConnectTarget(ps3Ip);
            }

            canConAPI = false;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            for (; ; )
            {
                if (canConAPI)
                    conAPI(console);

                uint searchLen = 10000000;
                if (console == "ps3")
                    searchLen = 10000;
                if (canSearch)
                {
                    updateTog = 1;
                    int len = 0;
                    if (canPlus)
                        len = prevLen;

                    CURoffset += (uint)len;
                    if (console == "ps3")
                        buffer = PS3.Extension.ReadBytes((uint)CURoffset, (int)searchLen);
                    else if (console == "xbox")
                        buffer = XDRPCPlusPlus.ReadBytes(xbCon, (uint)CURoffset, (uint)searchLen);
                    else if (console == "pc")
                    {
                        if (pcBit == 32)
                        {
                            if (CURoffset > 0x7FFFFFFE)
                                CURoffset = 0;
                            CC.ProcessName = processName;
                            buffer = CC.Read._Bytes((uint)CURoffset, (int)searchLen);
                        }
                        else if (pcBit == 64)
                        {
                            if (CURoffset > 0x7FFFFFFFFFFE)
                                CURoffset = 0;
                            if (pc64.Open_pHandel(processName64))
                            {
                                buffer = pc64.ReadBytes((long)CURoffset, (int)searchLen);
                            }
                        }
                    }
                    findPos = findBytes(buffer, findVal, 0, searchStr);
                    // findPos = -1;
                    if (findPos == -1)
                    {
                        CURoffset += searchLen;
                        searchOfs = (uint)CURoffset;
                    }
                    else
                    {
                        canPlus = false;
                        CURoffset += (uint)findPos;
                        prevLen = findVal.Length;
                        if (collectR)
                        {
                            foundOfs.Add((uint)CURoffset);
                            if (!searchStr)
                            {
                                foundVal.Add(ByteArrayToString(findVal));
                                editVal.Add(ByteArrayToString(replaceVal));
                            }
                            else
                            {
                                foundVal.Add(findStr);
                                editVal.Add(replaceStr);
                            }
                        }
                        if (console == "ps3")
                        {
                            if (canReplace && !searchStr)
                                PS3.SetMemory((uint)CURoffset, replaceVal);
                            else if (canReplace && searchStr)
                                PS3.SetMemory((uint)CURoffset, Encoding.ASCII.GetBytes(replaceStr));
                        }
                        else if (console == "xbox")
                        {
                            if (canReplace && !searchStr)
                                XDRPCPlusPlus.WriteBytes(xbCon, (uint)CURoffset, replaceVal);
                            else if (canReplace && searchStr)
                                XDRPCPlusPlus.WriteBytes(xbCon, (uint)CURoffset, Encoding.ASCII.GetBytes(replaceStr));
                        }
                        else if (console == "pc")
                        {
                            if (pcBit == 32)
                            {
                                if (canReplace && !searchStr)
                                {
                                    CC.ProcessName = processName;
                                    CC.Write._Bytes((uint)CURoffset, replaceVal);
                                }
                                else if (canReplace && searchStr)
                                {
                                    CC.ProcessName = processName;
                                    CC.Write._Bytes((uint)CURoffset, Encoding.ASCII.GetBytes(replaceStr));
                                }
                            }
                            else if (pcBit == 64)
                            {
                                if (canReplace && !searchStr)
                                {
                                    if (pc64.Open_pHandel(processName64))
                                        pc64.WriteBytes((long)CURoffset, replaceVal);
                                }
                                else if (canReplace && searchStr)
                                {
                                    if (pc64.Open_pHandel(processName64))
                                        pc64.WriteBytes((long)CURoffset, Encoding.ASCII.GetBytes(replaceStr));
                                }
                            }
                        }
                        searchOfs = 0;
                        if (!autoUp)
                        {
                            canUpdate = true;
                            canSearch = false;
                        }
                        else
                        {
                            canPlus = true;
                            if (autoMS != 0)
                                Task.Delay(autoMS).Wait();
                        }
                    }
                }
                else
                {
                    if (updateTog == 0 || updateTog == 1)
                    {
                        updateTog = 2;
                        if (Form2.canUpdateForm)
                            Form2.updateForm = true;
                    }
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (!Form2.isOpen)
            {
                frm2 = new Form2();
                frm2.Show();
                updateList();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            collectR = checkBox1.Checked;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            toolStripLabel4.Text = " Selected: " + currentOfs;

            if (useSearcher)
                if (canSearch)
                {
                    if (searchOfs != 0)
                        toolStripLabel6.Text = "Searcher: 0x" + padZeros(String.Format("{0:X}", searchOfs));
                    else
                        toolStripLabel6.Text = "Searcher: Active";
                }
                else
                    toolStripLabel6.Text = "Searcher: Idle";
            else
                toolStripLabel6.Text = "Searcher: Off";

            if (Form2.isOpen)
                frm2.Text = "Result Count: " + foundOfs.Count;
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            canSearch = false;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            autoUp = checkBox2.Checked;
            if (!autoUp)
                canUpdate = true;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            autoMS = (int)numericUpDown1.Value;
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (toolStripButton4.Checked)
            {
                panel1.Visible = true;
                useSearcher = true;
            }
            else
            {
                panel1.Visible = false;
                useSearcher = false;
                canSearch = false;
            }
        }
        #endregion

        #endregion
        #region pc
        #region 32bit

        private static string ProcName = "";
        private static IntPtr pHandle = IntPtr.Zero;
        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
        static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, int nSize, out IntPtr lpNumberOfBytesWritten);
        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
        static extern bool ReadProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, [System.Runtime.InteropServices.Out] byte[] lpBuffer, int dwSize, out IntPtr lpNumberOfBytesRead);

        public static string ProcessName
        { get { return ProcName; } set { if (System.Diagnostics.Process.GetProcessesByName(value).Length != 0) { pHandle = System.Diagnostics.Process.GetProcessesByName(value)[0].Handle; ProcName = value; } else { System.Windows.Forms.MessageBox.Show(value + "\n\n      Not Found!", "Error:" + value, System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error); ProcName = ""; } } }


        private const uint MEM_COMMIT = 0x1000;
        private const uint MEM_RESERVE = 0x2000;
        private const uint PAGE_EXECUTE_READWRITE = 0x40;
        private static int ProcessID = -1;
        private static IntPtr ProcessHandle = IntPtr.Zero;

        [DllImport("kernel32.dll", EntryPoint = "WriteProcessMemory")]
        private static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, [Out] int lpNumberOfBytesWritten);

        [DllImport("kernel32.dll", EntryPoint = "OpenProcess")]
        private static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
        static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

        [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
        static extern bool VirtualFreeEx(IntPtr hProcess, IntPtr lpAddress, UIntPtr dwSize, uint dwFreeType);

        [DllImport("kernel32")]
        public static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, out IntPtr lpThreadId);

        private static class Win32
        {
            public static class NativeMethods
            {
                #region IsWow64Process
                public static bool IsWow64Process(IntPtr handel)
                {
                    bool isTarget64Bit = false;
                    IsWow64Process(handel, out isTarget64Bit);
                    return isTarget64Bit;
                }

                [DllImport("kernel32.dll", SetLastError = true, CallingConvention = CallingConvention.Winapi)]
                [return: MarshalAs(UnmanagedType.Bool)]
                private static extern bool IsWow64Process([In] IntPtr process, [Out] out bool wow64Process);
                #endregion
            }

            public static class x64
            {
                [DllImport("kernel32.dll", SetLastError = true)]
                public static extern bool VirtualProtectEx(IntPtr hProcess, long lpAddress, UInt32 dwSize, uint flNewProtect, out uint lpflOldProtect);

                [DllImport("kernel32.dll")]
                public static extern bool ReadProcessMemory(IntPtr hProcess, long lpBaseAddress, [In, Out] byte[] buffer, UInt32 size, out int lpNumberOfBytesWritten);

                [DllImport("kernel32.dll")]
                public static extern bool WriteProcessMemory(IntPtr hProcess, long lpBaseAddress, [In, Out] byte[] buffer, UInt32 size, out int lpNumberOfBytesWritten);
            }

            public static class x86
            {
                [DllImport("kernel32.dll", SetLastError = true)]
                public static extern bool VirtualProtectEx(IntPtr hProcess, int lpAddress, UInt32 dwSize, uint flNewProtect, out uint lpflOldProtect);

                [DllImport("kernel32.dll")]
                public static extern bool ReadProcessMemory(IntPtr hProcess, int lpBaseAddress, [In, Out] byte[] buffer, UInt32 size, out int lpNumberOfBytesWritten);

                [DllImport("kernel32.dll")]
                public static extern bool WriteProcessMemory(IntPtr hProcess, int lpBaseAddress, [In, Out] byte[] buffer, UInt32 size, out int lpNumberOfBytesWritten);
            }
        }

        private IntPtr pHandel = IntPtr.Zero;
        private Process attachedProcess = null;
        public bool Open_pHandel(string processName)
        {
            Process[] proc = Process.GetProcessesByName(processName);

            if (proc.Length == 0)
                return false;
            else if (proc.Length > 1)
                throw new Exception("More then one process found.");
            else
            {
                attachedProcess = proc[0];
                pHandel = proc[0].Handle;
                return true;
            }
        }

        public byte[] ReadBytes(uint address, int length)
        {
            byte[] readBytes = new byte[length];
            int numBytesChanged = 0;

            Win32.x86.ReadProcessMemory(pHandel, (int)address, readBytes, (uint)length, out numBytesChanged);

            return readBytes;
        }
        public bool WriteBytes(uint address, byte[] value, bool virtualProtect = false)
        {
            int countOfUsed = 0;
            bool result = false;
            uint oldProtection = 0;


            if (virtualProtect)
                Win32.x86.VirtualProtectEx(pHandel, (int)address, (uint)value.Length, 0x40, out oldProtection);

            result = Win32.x86.WriteProcessMemory(pHandel, (int)address, value, (uint)value.Length, out countOfUsed);

            if (virtualProtect)
                Win32.x86.VirtualProtectEx(pHandel, (int)address, (uint)value.Length, oldProtection, out oldProtection);

            return result;
        }

        public bool WriteByte(uint address, byte value, bool virtualProtect = false)
        {
            buffer = new byte[] { value };
            return WriteBytes(address, buffer, virtualProtect);
        }
        public static bool disOnce = true;

        class CC
        {
            private static string ProcName = "";
            private static IntPtr pHandle = IntPtr.Zero;
            [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
            static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, int nSize, out IntPtr lpNumberOfBytesWritten);
            [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
            static extern bool ReadProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, [System.Runtime.InteropServices.Out] byte[] lpBuffer, Int64 dwSize, out IntPtr lpNumberOfBytesRead);

            public static string ProcessName
            { get { return ProcName; } set { if (System.Diagnostics.Process.GetProcessesByName(value).Length != 0) { pHandle = System.Diagnostics.Process.GetProcessesByName(value)[0].Handle; ProcName = value; } else { if (disOnce) { disOnce = false; System.Windows.Forms.MessageBox.Show(value + "\n\n      Not Found!", "Error:" + value, System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error); ProcName = ""; } } } }

            public class Write
            {
                public static void _Int16(Int64 Address, Int16 Value)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt;
                        WriteProcessMemory(pHandle, new IntPtr(Address), BitConverter.GetBytes(Value), sizeof(Int16), out retByt);
                    }
                }
                public static void _Int32(Int64 Address, Int32 Value)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt;
                        WriteProcessMemory(pHandle, new IntPtr(Address), BitConverter.GetBytes(Value), sizeof(Int32), out retByt);
                    }
                }
                public static void _Int64(Int64 Address, Int64 Value)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt;
                        WriteProcessMemory(pHandle, new IntPtr(Address), BitConverter.GetBytes(Value), sizeof(Int64), out retByt);
                    }
                }
                public static void _Float(Int64 Address, Single Float)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt;
                        WriteProcessMemory(pHandle, new IntPtr(Address), BitConverter.GetBytes(Float), sizeof(Single), out retByt);
                    }
                }
                public static void _String(Int64 Address, String Value)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt;
                        WriteProcessMemory(pHandle, new IntPtr(Address), ASCIIEncoding.ASCII.GetBytes(Value), sizeof(Int64), out retByt);
                    }
                }
                public static void _Bytes(Int64 Address, Byte[] Value)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt;
                        WriteProcessMemory(pHandle, new IntPtr(Address), Value, Value.Length, out retByt);
                    }
                }

                public static void _Byte(Int64 Address, byte Value)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt;
                        WriteProcessMemory(pHandle, new IntPtr(Address), new byte[] { Value }, 1, out retByt);
                    }
                }

            }
            public class Read
            {
                public static Int16 _Int16(Int64 Address)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt; Byte[] buffer = new Byte[sizeof(Int16)];
                        ReadProcessMemory(pHandle, new IntPtr(Address), buffer, sizeof(Int16), out retByt);
                        return BitConverter.ToInt16(buffer, 0);
                    }
                    else return 0;
                }
                public static Int32 _Int32(Int64 Address)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt; Byte[] buffer = new Byte[sizeof(Int32)];
                        ReadProcessMemory(pHandle, new IntPtr(Address), buffer, sizeof(Int32), out retByt);
                        return BitConverter.ToInt32(buffer, 0);
                    }
                    else return 0;
                }
                public static Int64 _Int64(Int64 Address)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt; Byte[] buffer = new Byte[sizeof(Int64)];
                        ReadProcessMemory(pHandle, new IntPtr(Address), buffer, sizeof(Int64), out retByt);
                        return BitConverter.ToInt64(buffer, 0);
                    }
                    else return 0;
                }
                public static Single _Float(Int64 Address)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt; Byte[] buffer = new Byte[sizeof(Single)];
                        ReadProcessMemory(pHandle, new IntPtr(Address), buffer, sizeof(Single), out retByt);
                        return BitConverter.ToSingle(buffer, 0);
                    }
                    else return 0;
                }
                public static String _String(Int64 Address, Int32 _Length)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt; Byte[] buffer = new Byte[_Length];
                        ReadProcessMemory(pHandle, new IntPtr(Address), buffer, _Length, out retByt);
                        return ASCIIEncoding.ASCII.GetString(buffer);
                    }
                    else return "";
                }
                public static Byte[] _Bytes(Int64 Address, Int32 _Size)
                {
                    if (System.Diagnostics.Process.GetProcessesByName(ProcName).Length != 0)
                    {
                        IntPtr retByt; Byte[] buffer = new Byte[_Size];
                        ReadProcessMemory(pHandle, new IntPtr(Address), buffer, _Size, out retByt);
                        return buffer;
                    }
                    else return new byte[0];
                }
            }
        }

        private void pCToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        string processName = "";

        private void loadProcessToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                processName = toolStripTextBox3.Text;
                disOnce = true;
                CC.ProcessName = toolStripTextBox3.Text;
                if (disOnce)
                {
                    Text = "Universal Debugger - Process Connected" + " | " + toolStripTextBox3.Text;
                    console = "pc";
                    afterAttach();
                }
                else
                    Text = "Universal Debugger - Process Not Found" + " | " + toolStripTextBox3.Text;
            }
            catch
            {
                MessageBox.Show("An error has occured.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion
        #region 64bit
        class Memory
        {
            private IntPtr pHandel = IntPtr.Zero;
            private Process attachedProcess = null;
            private byte[] buffer;

            public bool Open_pHandel(string processName)
            {
                Process[] proc = Process.GetProcessesByName(processName);

                if (proc.Length == 0)
                    return false;
                else if (proc.Length > 1)
                    throw new Exception("More then one process found.");
                else
                {
                    attachedProcess = proc[0];
                    pHandel = proc[0].Handle;
                    return true;
                }
            }
            /*
            #region x86
            #region Write
            public bool WriteBytes(int address, byte[] value, bool virtualProtect = false)
            {
                int countOfUsed = 0;
                bool result = false;
                uint oldProtection = 0;


                if (virtualProtect)
                    Win32.x86.VirtualProtectEx(pHandel, address, (uint)value.Length, 0x40, out oldProtection);

                result = Win32.x86.WriteProcessMemory(pHandel, address, value, (uint)value.Length, out countOfUsed);

                if (virtualProtect)
                    Win32.x86.VirtualProtectEx(pHandel, address, (uint)value.Length, oldProtection, out oldProtection);

                return result;
            }

            public bool WriteInt(int address, int value, bool virtualProtect = false)
            {
                buffer = BitConverter.GetBytes(value);
                return WriteBytes(address, buffer, virtualProtect);
            }

            public bool WriteByte(int address, byte value, bool virtualProtect = false)
            {
                buffer = new byte[] { value };
                return WriteBytes(address, buffer, virtualProtect);
            }

            public bool WriteString(int address, string value, bool virtualProtect = false)
            {
                buffer = Encoding.ASCII.GetBytes(value);//No unicode support atm
                return WriteBytes(address, buffer, virtualProtect);
            }

            public bool WriteFloat(int address, float value, bool virtualProtect = false)
            {
                buffer = BitConverter.GetBytes(value);
                return WriteBytes(address, buffer, virtualProtect);
            }
            #endregion
            #region Read

            public string ReadString(int offset)
            {
                int blocksize = 40;
                int scalesize = 0;
                string str = string.Empty;

                while (!str.Contains('\0'))
                {
                    byte[] buffer = ReadBytes(offset + scalesize, blocksize);
                    str += Encoding.UTF8.GetString(buffer);
                    scalesize += blocksize;
                }

                return str.Substring(0, str.IndexOf('\0'));
            }

            public byte[] ReadBytes(int address, int length)
            {
                byte[] readBytes = new byte[length];
                int numBytesChanged = 0;

                Win32.x86.ReadProcessMemory(pHandel, address, readBytes, (uint)length, out numBytesChanged);

                return readBytes;
            }

            public int ReadInt(int address)
            {
                return BitConverter.ToInt32(ReadBytes(address, 4), 0);
            }

            public byte ReadByte(int address)
            {
                return ReadBytes(address, 1)[0];
            }

            public string ReadString(int address, int length)
            {//No unicode support
                return Encoding.ASCII.GetString(ReadBytes(address, length));
            }

            public string ReadStringAdvanced(int address, int maxStringLength = 1000)
            {//No unicode support
                string result = null;
                byte currentByte = 0;

                for (int i = 0; i < maxStringLength; i++)
                {
                    currentByte = ReadByte(address + i);

                    if (currentByte == 0x00)
                        break;
                    else
                        result += (char)currentByte;
                }

                return result;
            }

            public float ReadFloat(int address)
            {
                return BitConverter.ToSingle(ReadBytes(address, 4), 0);
            }
            #endregion
            #region Scans
            public int PatternScan(string pattern)
            {
                string[] splitPattern = pattern.Split(' ');
                bool[] indexValid = new bool[splitPattern.Length];
                byte[] indexValue = new byte[splitPattern.Length];

                byte tempByte = (byte)0x00;

                for (int i = 0; i < splitPattern.Length; i++)
                {
                    indexValid[i] = !(splitPattern[i] == "??" || splitPattern[i] == "?");
                    if (Byte.TryParse(splitPattern[i], out tempByte))
                        indexValue[i] = tempByte;
                    else
                        indexValid[i] = false;
                }

                int startOfMemory = attachedProcess.MainModule.BaseAddress.ToInt32();
                int endOfMemory = attachedProcess.MainModule.ModuleMemorySize;

                for (int currentMemAddy = startOfMemory; currentMemAddy < endOfMemory; currentMemAddy++)
                {
                    bool complete = false;
                    for (int i = 0; i < splitPattern.Length; i++)
                    {
                        if (!indexValid[i])
                            continue;

                        tempByte = ReadByte(currentMemAddy + i);

                        if (tempByte != indexValue[i])
                            break;

                        if (i == splitPattern.Length - 1)
                            complete = true;

                        if (complete)
                            break;
                    }

                    if (complete)
                        return currentMemAddy;
                }

                throw new Exception("Pattern not found!");
                return 0;
            }
            #endregion
            #endregion
            */


            public bool WriteBytes(long address, byte[] value, bool virtualProtect = false)
            {
                int countOfUsed = 0;
                bool result = false;
                uint oldProtection = 0;


                if (virtualProtect)
                    Win32.x64.VirtualProtectEx(pHandel, address, (uint)value.Length, 0x40, out oldProtection);

                result = Win32.x64.WriteProcessMemory(pHandel, address, value, (uint)value.Length, out countOfUsed);

                if (virtualProtect)
                    Win32.x64.VirtualProtectEx(pHandel, address, (uint)value.Length, oldProtection, out oldProtection);

                return result;
            }
            public bool WriteInt(long address, int value, bool virtualProtect = false)
            {
                buffer = BitConverter.GetBytes(value);
                return WriteBytes(address, buffer, virtualProtect);
            }
            public bool WriteByte(long address, byte value, bool virtualProtect = false)
            {
                buffer = new byte[] { value };
                return WriteBytes(address, buffer, virtualProtect);
            }
            public bool WriteString(long address, string value, bool virtualProtect = false)
            {
                buffer = Encoding.ASCII.GetBytes(value);//No unicode support atm
                return WriteBytes(address, buffer, virtualProtect);
            }
            public bool WriteFloat(long address, float value, bool virtualProtect = false)
            {
                buffer = BitConverter.GetBytes(value);
                return WriteBytes(address, buffer, virtualProtect);
            }

            public string ReadString_(long offset)
            {
                int blocksize = 40;
                int scalesize = 0;
                string str = string.Empty;

                byte[] buffer = ReadBytes(offset + scalesize, blocksize);
                str += Encoding.UTF8.GetString(buffer);
                scalesize += blocksize;

                return str.Substring(0, str.IndexOf('\0'));
            }

            public string ReadString(long offset)
            {
                int blocksize = 40;
                int scalesize = 0;
                string str = string.Empty;

                while (!str.Contains('\0'))
                {
                    byte[] buffer = ReadBytes(offset + scalesize, blocksize);
                    str += Encoding.UTF8.GetString(buffer);
                    scalesize += blocksize;
                }

                return str.Substring(0, str.IndexOf('\0'));
            }

            public byte[] ReadBytes(long address, long length)
            {
                int numBytesChanged = 0;
                byte[] readBytes = new byte[length];

                Win32.x64.ReadProcessMemory(pHandel, address, readBytes, (ulong)length, out numBytesChanged);
                return readBytes;
            }

            public int ReadInt(long address)
            {
                return BitConverter.ToInt32(ReadBytes(address, 4), 0);
            }

            public byte ReadByte(long address)
            {
                return ReadBytes(address, 1)[0];
            }

            public string ReadString(long address, int length)
            {//No unicode support
                return Encoding.ASCII.GetString(ReadBytes(address, length));
            }

            public string ReadStringAdvanced(long address, int maxStringLength = 1000)
            {//No unicode support
                string result = null;
                byte currentByte = 0;

                for (int i = 0; i < maxStringLength; i++)
                {
                    currentByte = ReadByte(address + i);

                    if (currentByte == 0x00)
                        break;
                    else
                        result += (char)currentByte;
                }

                return result;
            }

            public float ReadFloat(long address)
            {
                return BitConverter.ToSingle(ReadBytes(address, 4), 0);
            }
            public long PatternScan(string pattern)
            {
                string[] splitPattern = pattern.Split(' ');
                bool[] indexValid = new bool[splitPattern.Length];
                byte[] indexValue = new byte[splitPattern.Length];

                byte tempByte = (byte)0x00;

                for (int i = 0; i < splitPattern.Length; i++)
                {
                    indexValid[i] = !(splitPattern[i] == "??" || splitPattern[i] == "?");
                    if (Byte.TryParse(splitPattern[i], out tempByte))
                        indexValue[i] = tempByte;
                    else
                        indexValid[i] = false;
                }

                long startOfMemory = attachedProcess.MainModule.BaseAddress.ToInt64();
                long endOfMemory = attachedProcess.MainModule.ModuleMemorySize;

                for (long currentMemAddy = startOfMemory; currentMemAddy < endOfMemory; currentMemAddy++)
                {
                    bool complete = false;
                    for (int i = 0; i < splitPattern.Length; i++)
                    {
                        if (!indexValid[i])
                            continue;

                        tempByte = ReadByte(currentMemAddy + i);

                        if (tempByte != indexValue[i])
                            break;

                        if (i == splitPattern.Length - 1)
                            complete = true;

                        if (complete)
                            break;
                    }

                    if (complete)
                        return currentMemAddy;
                }

                throw new Exception("Pattern not found!");
                return 0;
            }


            private static class Win32
            {
                public static class NativeMethods
                {
                    #region IsWow64Process
                    public static bool IsWow64Process(IntPtr handel)
                    {
                        bool isTarget64Bit = false;
                        IsWow64Process(handel, out isTarget64Bit);
                        return isTarget64Bit;
                    }

                    [DllImport("kernel32.dll", SetLastError = true, CallingConvention = CallingConvention.Winapi)]
                    [return: MarshalAs(UnmanagedType.Bool)]
                    private static extern bool IsWow64Process([In] IntPtr process, [Out] out bool wow64Process);
                    #endregion
                }

                public static class x64
                {
                    [DllImport("kernel32.dll", SetLastError = true)]
                    public static extern bool VirtualProtectEx(IntPtr hProcess, long lpAddress, UInt32 dwSize, uint flNewProtect, out uint lpflOldProtect);

                    [DllImport("kernel32.dll")]
                    public static extern bool ReadProcessMemory(IntPtr hProcess, long lpBaseAddress, [In, Out] byte[] buffer, UInt64 size, out int lpNumberOfBytesWritten);

                    [DllImport("kernel32.dll")]
                    public static extern bool WriteProcessMemory(IntPtr hProcess, long lpBaseAddress, [In, Out] byte[] buffer, UInt32 size, out int lpNumberOfBytesWritten);
                }

                public static class x86
                {
                    [DllImport("kernel32.dll", SetLastError = true)]
                    public static extern bool VirtualProtectEx(IntPtr hProcess, int lpAddress, UInt32 dwSize, uint flNewProtect, out uint lpflOldProtect);

                    [DllImport("kernel32.dll")]
                    public static extern bool ReadProcessMemory(IntPtr hProcess, int lpBaseAddress, [In, Out] byte[] buffer, UInt32 size, out int lpNumberOfBytesWritten);

                    [DllImport("kernel32.dll")]
                    public static extern bool WriteProcessMemory(IntPtr hProcess, int lpBaseAddress, [In, Out] byte[] buffer, UInt32 size, out int lpNumberOfBytesWritten);
                }
            }
        }
        #endregion

        private void hexBox1_DoubleClick(object sender, EventArgs e)
        {
            if (groupDiv)
            {
                hexBox1.SelectionStart = roundMulti4((uint)hexBox1.SelectionStart);
                hexBox1.SelectionLength = 4;
            }
        }

        #endregion

        private void timer4_Tick(object sender, EventArgs e)
        {
            int result = 0;
            char key = '¶';
            int i = 0;
            for (i = 1; i <= 110; i++)
            {
                result = 0;
                result = GetAsyncKeyState(i);
                if (result == -32767)
                {
                    key = Convert.ToChar(i);
                    if (i == 13)
                        //    key = Convert.to Environment.NewLine;
                        break; // TODO: might not be correct. Was : Exit For
                }
            }
            if (Control.ModifierKeys == Keys.Control && key == 71)
            {
                toolStripComboBox2.Focus();

            }
        }
    }
}