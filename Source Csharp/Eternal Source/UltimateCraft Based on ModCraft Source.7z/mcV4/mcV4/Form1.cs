﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;
using PS3Lib;
using System.Net;
using System.IO;
using System.Security.Cryptography;
using System.Diagnostics;
using System.Xml;
using System.Security.Principal;
using System.Management;
using System.Text.RegularExpressions;
using System.Drawing.Drawing2D;
using System.Management.Instrumentation;
using System.Drawing.Imaging;
using ucConnect;
using System.Reflection;
using System.Linq.Expressions;
using System.Media;

namespace mcV4
{
    public partial class Form1 : Form
    {
        #region form load close
        public Form1()
        {
            const string appName = "mcV4";
            bool createdNew;
            mutex = new Mutex(true, appName, out createdNew);
            if (!createdNew)
                Environment.Exit(0);

            InitializeComponent();
            oooooooooooooo();
            llllllllllllllll();
            new Thread(() => Protections.iiiiiii()) { IsBackground = true }.Start();
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            }
            catch (Exception)
            {
                MessageBox.Show("Error Code: 3", Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }
        private Button btnAdd = new Button();
        ToolStripMenuItem[] tsMenuItems = new ToolStripMenuItem[100];
        private void Form1_Load(object sender, EventArgs e)
        {
            saveInfoLoad();
            runTheme(saveThemeColor, saveTextColor, saveBackColor);
            #region set
            Size = new Size(563, 436);
            mainPanels = new Panel[] { connectionPanel, gameManagerPanel, settingsPanel, modMenuPanel };
            mainBtns = new Button[] { connectionBtn, gameManagerBtn, settingsBtn, modMenuBtn };
            GMpanels = new Panel[] { autoBuildStructurePanel, hostOptsPanel, btnBindsPanel, posPanel, itemPanel };
            GMbtns = new Button[] { btnM1, btnM2, btnM3, btnM4, btnM5 };
            connectionPanel.Size = new Size(563, 287);
            connectionPanel.Location = new Point(0, 67);
            gameManagerPanel.Location = new Point(0, 67);
            gameManagerPanel.Size = new Size(563, 355);
            settingsPanel.Location = new Point(0, 67);
            settingsPanel.Size = new Size(430, 290);
            modMenuPanel.Location = new Point(0, 67);
            modMenuPanel.Size = new Size(170, 242);

            hostOptsPanel.Location = new Point(0, 34);
            hostOptsPanel.Size = new Size(332, 251);

            autoBuildStructurePanel.Location = new Point(0, 34);
            autoBuildStructurePanel.Size = new Size(321, 154);

            btnBindsPanel.Location = new Point(0, 34);
            btnBindsPanel.Size = new Size(303, 287);

            posPanel.Location = new Point(0, 34);
            posPanel.Size = new Size(563, 307);

            itemPanel.Location = new Point(0, 34);
            itemPanel.Size = new Size(496, 312);
            curSlot.Text = "";
            toolStripComboBox5.SelectedIndex = 0;

            setupTS();
            #endregion
            timer3.Start();
            checkBox11.Checked = useX2Scale;
            if (useX2Scale)
                scaleTool();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            saveInfoClose();
        }
        #endregion

        #region form controls

        #region TS controls
        private void TS_MenuItem0_Closing(object sender, ToolStripDropDownClosingEventArgs e)
        {
            if (e.CloseReason == ToolStripDropDownCloseReason.ItemClicked)
            {
                e.Cancel = true;
            }
        }
        private void TS_MenuItem_Closing(object sender, ToolStripDropDownClosingEventArgs e)
        {
            if (e.CloseReason == ToolStripDropDownCloseReason.ItemClicked)
            {
                e.Cancel = true;
            }
        }
        private void TS_Item_Click(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                for (int i = 0; i < TS_Item.Length; i++)
                {
                    if (!Object.ReferenceEquals(TS_Item[i], null))
                    {
                        if (TS_Item[i].Selected && TS_Item[i].Name == "checkBox")
                        {
                            try
                            {
                                LabelMenuItem label = new LabelMenuItem();
                                label.ForeColor = textColorCM;
                                label.BackColor = backgroundColorCM;
                                label.Text = TS_Item[i].Text;
                                selectedOptionTxt = label.Text;
                                selectedOptionState = func_state[i];
                                contextMenuStrip1.Items.RemoveAt(0);
                                contextMenuStrip1.Items.Insert(0, label);
                                contextMenuStrip1.Show(Cursor.Position);
                            }
                            catch
                            {

                            }
                            break;
                        }
                    }
                }
            }
        }
        private void TS_TrackBar_Click(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                for (int i = 0; i < TS_TrackBar.Length; i++)
                {
                    if (!Object.ReferenceEquals(TS_TrackBar[i], null))
                    {
                        if (selectedTrack == TS_TrackBar[i])
                        {
                            try
                            {
                                string[] split = Regex.Split(TS_Label[i].Text, " : ");

                                LabelMenuItem label = new LabelMenuItem();
                                label.ForeColor = textColorCM;
                                label.BackColor = backgroundColorCM;
                                label.Text = split[0];
                                selectedOptionTxt = label.Text;
                                selectedOptionState = func_state[i];
                                contextMenuStrip1.Items.RemoveAt(0);
                                contextMenuStrip1.Items.Insert(0, label);
                                contextMenuStrip1.Show(Cursor.Position);
                            }
                            catch
                            {

                            }
                            break;
                        }
                    }
                }
            }
        }
        private void TS_ComboBox_Click(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                for (int i = 0; i < TS_ComboBox.Length; i++)
                {
                    if (selectedBox == TS_ComboBox[i])
                    {
                        try
                        {
                            selectedOptionTxt = TS_Label[i].Text;
                            selectedOptionState = func_state[i];
                            contextMenuStrip1.Items.RemoveAt(0);
                            contextMenuStrip1.Items.Insert(0, TS_Label[i]);
                            contextMenuStrip1.Show(Cursor.Position);
                        }
                        catch
                        {

                        }
                        break;
                    }
                }
            }
        }

        string selectedOptionTxt = "";
        string selectedOptionState = "";
        colorCBTS selectedBox;
        TrackBarMenuItem selectedTrack;
        private void TS_ComboBox_MouseHover(object sender, EventArgs e)
        {
            if (sender is colorCBTS)
            {
                colorCBTS item = sender as colorCBTS;
                selectedBox = item;
            }
        }
        private void TS_TrackBar_MouseHover(object sender, EventArgs e)
        {
            if (sender is TrackBarMenuItem)
            {
                TrackBarMenuItem item = sender as TrackBarMenuItem;
                selectedTrack = item;
            }
        }
        #endregion

        #region main form control
        private void listBox3_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                e = new DrawItemEventArgs(e.Graphics,
                                          e.Font,
                                          e.Bounds,
                                          e.Index,
                                          e.State ^ DrawItemState.Selected,
                                          saveTextColor,
                                          saveThemeColor);

            SolidBrush brush = new SolidBrush(saveTextColor);
            e.DrawBackground();
            e.Graphics.DrawString(listBox3.Items[e.Index].ToString(), e.Font, brush, e.Bounds, StringFormat.GenericDefault);
            e.DrawFocusRectangle();
        }
        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            TopMost = checkBox10.Checked;
        }


        private void panel1_MouseEnter(object sender, EventArgs e)
        {
            Point pos = Location;
            pos.Y += panel3.Location.Y + panel3.Size.Height;

            sub1.Show(pos, ToolStripDropDownDirection.Default);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void label2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                newpoint = Control.MousePosition;
                newpoint.X -= x;
                newpoint.Y -= y;
                Location = newpoint;
            }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.Style |= WS_MINIMIZEBOX;
                cp.ClassStyle |= CS_DBLCLKS;
                return cp;
            }
        }

        private void label2_MouseDown(object sender, MouseEventArgs e)
        {
            x = Control.MousePosition.X - Location.X;
            y = Control.MousePosition.Y - Location.Y;

        }

        #endregion

        private class MyRenderer : ToolStripProfessionalRenderer
        {
            protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
            {
                Rectangle rc = new Rectangle(Point.Empty, e.Item.Size);
                Color c = e.Item.Selected ? selectColorCM : backgroundColorCM;
                using (SolidBrush brush = new SolidBrush(c))
                    e.Graphics.FillRectangle(brush, rc);
            }
            protected override void OnRenderItemCheck(ToolStripItemImageRenderEventArgs e)
            {

                Rectangle rc = new Rectangle(new Point(4, 2), new Size(e.Item.Height - 4, e.Item.Height - 4));
                Color c = Color.Black;

                Rectangle rc2 = new Rectangle(new Point(5, 3), new Size(e.Item.Height - 6, e.Item.Height - 6));
                Color c2 = selectColorCM;

                int x = 2, y = 1;
                using (SolidBrush brush = new SolidBrush(c))
                    e.Graphics.FillRectangle(brush, rc);
                using (SolidBrush brush = new SolidBrush(c2))
                    e.Graphics.FillRectangle(brush, rc2);
                e.Graphics.DrawLine(new Pen(Color.White, 2), new Point(6 + x, 10 + y), new Point(10 + x, 14 + y));
                e.Graphics.DrawLine(new Pen(Color.White, 2), new Point(10 + x, 14 + y), new Point(16 + x, 5 + y));
            }
            protected override void OnRenderArrow(ToolStripArrowRenderEventArgs e)
            {
                Rectangle rc1 = new Rectangle(Point.Empty, new Size(2, e.Item.Size.Height));
                Color c1 = textColorCM;

                using (SolidBrush brush = new SolidBrush(c1))
                    e.Graphics.FillRectangle(brush, rc1);

                int middle = e.Item.Height / 2;
                int size = 5;
                e.Graphics.DrawLine(new Pen(saveTextColor, 1), new Point(e.Item.Width - size - 5, middle - 3), new Point(e.Item.Width - size - 2, middle));
                e.Graphics.DrawLine(new Pen(saveTextColor, 1), new Point(e.Item.Width - size - 5, middle + 3), new Point(e.Item.Width - size - 2, middle));
            }
        }
        Panel[] mainPanels;
        Button[] mainBtns;
        #region buttont tabs
        private void sub1_Opened(object sender, EventArgs e)
        {
            panel1.BackColor = ChangeColorBrightness(backgroundColorCM, (float)0.05);
            label1.BackColor = ChangeColorBrightness(backgroundColorCM, (float)0.05);
        }

        private void sub1_Closed(object sender, ToolStripDropDownClosedEventArgs e)
        {
            panel1.BackColor = ChangeColorBrightness(backgroundColorCM, 0);
            label1.BackColor = ChangeColorBrightness(backgroundColorCM, 0);
        }
        private void panelControl(Panel E9ZwEb1b7Zjo5ged5OAEa, Panel[] panels)
        {
            for (int i = 0; i < panels.Length; i++)
            {
                if (E9ZwEb1b7Zjo5ged5OAEa.Name == panels[i].Name)
                {
                    if (!E9ZwEb1b7Zjo5ged5OAEa.Visible)
                    {
                        E9ZwEb1b7Zjo5ged5OAEa.Visible = true;
                    }
                    else
                    {
                        E9ZwEb1b7Zjo5ged5OAEa.Visible = false;
                    }
                }
                else
                    panels[i].Visible = false;
            }
        }

        private void buttonControl(Button button, Button[] buttons)
        {
            for (int i = 0; i < buttons.Length; i++)
            {
                if (button.Name == buttons[i].Name)
                {
                    if (button.FlatAppearance.BorderSize == 0)
                    {
                        button.FlatAppearance.BorderSize = 1;
                    }
                    else
                    {
                        button.FlatAppearance.BorderSize = 0;
                    }
                }
                else
                    buttons[i].FlatAppearance.BorderSize = 0;
            }
        }

        private void settingsBtn_Click(object sender, EventArgs e)
        {
            panelControl(settingsPanel, mainPanels);
            buttonControl(settingsBtn, mainBtns);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panelControl(modMenuPanel, mainPanels);
            buttonControl(modMenuBtn, mainBtns);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panelControl(connectionPanel, mainPanels);
            buttonControl(connectionBtn, mainBtns);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panelControl(gameManagerPanel, mainPanels);
            buttonControl(gameManagerBtn, mainBtns);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            panelControl(autoBuildStructurePanel, GMpanels);
            buttonControl(btnM1, GMbtns);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            panelControl(hostOptsPanel, GMpanels);
            buttonControl(btnM2, GMbtns);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            panelControl(btnBindsPanel, GMpanels);
            buttonControl(btnM3, GMbtns);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            panelControl(posPanel, GMpanels);
            buttonControl(btnM4, GMbtns);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            panelControl(itemPanel, GMpanels);
            buttonControl(btnM5, GMbtns);
        }
        #endregion
        #endregion

        #region vars
        #region tool vars
        private static Mutex mutex = null;
        public static connect conn = new connect();
        public static PS3API PS3 = new PS3API();
        public static PS3MAPI PS3H = new PS3MAPI();
        ToolStripMenuItem[] TS_Item = new ToolStripMenuItem[10000];
        ToolStripSeparator[] TS_Seperator = new ToolStripSeparator[10000];
        ToolStripTextBox[] TS_TextBox = new ToolStripTextBox[10000];
        ToolStripMenuItem[] TS_MenuItem = new ToolStripMenuItem[10000];
        colorCBTS[] TS_ComboBox = new colorCBTS[10000];
        TrackBarMenuItem[] TS_TrackBar = new TrackBarMenuItem[10000];
        LabelMenuItem[] TS_Label = new LabelMenuItem[10000];
        string[] func_state = new string[10000];
        public static string MF_SubMenu = "subMenu;", MF_textOnly = "textOnly;", MF_textBox = "textBox;", MF_Seperator = "seperator;", MF_CheckBox = "checkBox;", MF_Trackbar = "trackBar;", MF_ComboBox = "comboBox;", MF_button = "button;", MF_button2 = "btn;", MF_none = "none;";
        string[][] itemTxt = new string[1000][];
        public static Color selectColorCM = Color.ForestGreen;
        public static Color backgroundColorCM = Color.FromArgb(50, 50, 50);
        public static Color textColorCM = Color.White;
        string[] funcVal = new string[10000];
        bool setOnce = false;
        bool[] getSubMenus = new bool[100];
        bool[] saveLabel = new bool[10000];
        string[] saveL = new string[10000];
        ToolStripItemCollection mainOpts;
        public static int y;
        public static int x;
        public static Point newpoint = new Point();
        const int WS_MINIMIZEBOX = 0x20000;
        const int CS_DBLCLKS = 0x8;
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        Panel[] GMpanels;
        Button[] GMbtns;
        string[] TSbtns = new string[10000];
        public static Color saveThemeColor = Color.FromArgb(70, 70, 245);
        public static Color saveTextColor = Color.FromArgb(200, 200, 200);
        public static Color saveBackColor = Color.FromArgb(40, 40, 40);
        Random rgbR = new Random();
        Color transKey = SystemColors.ControlDarkDark;
        SoundPlayer snd = new SoundPlayer(Properties.Resources.click);
        bool scaleOnce = false;
        #endregion
        #region game vars
        bool useOP = false;
        bool useUfo = false;
        uint clientPick = 0x6F3;
        uint clientInvul = 0x7F6;
        uint clientXp = 0x700;
        uint clientView = 0xE0;
        uint clientView2 = 0x148;
        uint clientPlus = 0x6F2;
        uint clientOrg = 0x100;
        string name_backup = "";
        bool checkCon = false;
        bool canUseTool = false;
        Random rhudRGB = new Random();
        int[] hudRGB = new int[] { 255, 0, 0 };
        Random rhudRGB_ = new Random();
        int[] hudRGB_ = new int[] { 255, 0, 0 };
        int colorInt = 0;
        ColorDialog rgb = new ColorDialog();
        bool useProgressBar = false;
        int progressVal = 0, progressMax = 0;
        public static int targetIndex = -1;
        public static string ps3IP = "-1";
        public static string ps3Status = "False";
        public static string gameStatus = "False";
        public static string apiStatus = "None";
        public static string accStatus = "Not Logged In";
        public static string targetStatus = "Target Number: N/A";
        public static string ccapiipStatus = "PS3 IP: N/A";
        public static List<CCAPI.ConsoleInfo> cList = Form1.PS3.CCAPI.GetConsoleList();
        public static apiForm apiForm_ = new apiForm();
        public static string labelTxtCT = "";
        public static string textBoxCT = "1";
        public static List<string> listCT = new List<string>();
        public static string curAPI = "";

        #endregion
        #region tool vars
        bool loaded = false;
        bool playClickSound = false;
        bool useX2Scale = false;
        public string[] check;
        public string[] saveText = { "-1", "-1", "0", "False", "192.168.1.1", "255-23-23", "255-255-255", "0-0-0", "False", "False", "N/A", "255-23-23", "255-255-255", "30-30-30", "False", "False" };
        public string app_file = @"C:\Users\" + Environment.UserName + @"\AppData\Roaming\ultCraft\settings.mcs";
        public string app_folder = @"C:\Users\" + Environment.UserName + @"\AppData\Roaming\ultCraft";
        public string headC = "b3981ae01cf6d3739af28037daf38416b29ca314";
        public WebClient client = new WebClient();
        string errorCode = "";
        string[] mmx = { };
        string[] mma = { };
        string[] mmb = { };
        string[] mmc = { };
        string[] mmd = { };
        ColorDialog colorDialog1 = new ColorDialog();
        ColorDialog colorDialog2 = new ColorDialog();
        ColorDialog colorDialog3 = new ColorDialog();
        ulti ult = new ulti();
        #endregion

        #endregion

        #region login
        private void loadInfo()
        {
            errorCode = "";
            try
            {
                loaded = true;
                string hg38565hfdw36 = mHk69B3quzv48 + Xf01b63c3mvuq + E7664vlykqx35 + bve3myzeo0jhe + Qwrldldl0myp2 + wnbp8mm0hiygc + Lav9nmcs6zb8w + Smn4ffjmefl4q + Zavb87m48ilcg;
                string kfhd957gfhskfsdja5 = mHk69B3quzv48 + Xf01b63c3mvuq + Zavb87m48ilcg + bve3myzeo0jhe + E7664vlykqx35 + Lav9nmcs6zb8w + Qwrldldl0myp2 + wnbp8mm0hiygc + Smn4ffjmefl4q;
                string[] Decrypt_ = connect.con;
                string[] Decrypt = new string[Decrypt_.Length];
                List<string> Str = new List<string>();
                using (var service = new Cryptography(kfhd957gfhskfsdja5))
                {
                    for (int i = 0; i < Decrypt.Length; i++)
                        Str.Add(service.Decrypt2(Decrypt_[i]));
                }
                string[] decrypt_ = Str.ToArray();
                string[] decrypt = new string[decrypt_.Length];
                string str = "";
                using (var service = new Cryptography(hg38565hfdw36))
                {
                    for (int i = 0; i < decrypt.Length; i++)
                        str += service.Decrypt2(decrypt_[i]);
                }
                //not working...
                initialTxt = str;
            }
            catch
            {

            }

            if (initialTxt.StartsWith("idjl6a3fjafa4"))
            {
                try
                {
                    initialTxt = initialTxt.Remove(0, 13);
                }
                catch
                {
                    errorCode += "1.2" + "\n";
                }
                try
                {
                    mmx = Regex.Split(initialTxt, "<x>");
                    mma = Regex.Split(mmx[0], "<m1>");
                    mmb = Regex.Split(mmx[1], "<m2>");
                    mmc = Regex.Split(mmx[2], "<m3>");

                    ins1.Clear();
                    ins2.Clear();
                    ins3.Clear();
                }
                catch
                {
                    errorCode += "1.3" + "\n";
                }
                try
                {
                    for (int i = 0; i < mma.Length; i++)
                        ins1.Add(Convert.ToUInt32(mma[i], 16));

                    for (int i = 0; i < mmb.Length; i++)
                        ins2.Add(Convert.ToDouble(mmb[i]));

                    for (int i = 0; i < mmc.Length; i++)
                        ins3.Add(Convert.ToUInt32(mmc[i], 16));
                }
                catch
                {
                    errorCode += "1.4" + "\n";
                }
                if (errorCode != "")
                    MessageBox.Show("Error Code(s):\n" + errorCode, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("Error Code: 2", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        #endregion

        #region save info
        private void saveInfoLoad()
        {
            try
            {
                if (File.Exists(app_file))
                {
                    saveText = File.ReadAllLines(app_file);
                }
                else
                {
                    if (!Directory.Exists(app_folder))
                        Directory.CreateDirectory(app_folder);
                    File.WriteAllLines(app_file, saveText);
                    saveText = File.ReadAllLines(app_file);
                }
                targetIndex = Convert.ToInt32(saveText[0]);
                ps3IP = saveText[1];

                if (targetIndex != -1)
                    targetStatus = "Target Number: " + targetIndex;
                if (ps3IP != "-1")
                    ccapiipStatus = "PS3 IP: " + ps3IP;
                label3.Text = targetStatus + "\n" + ccapiipStatus;

                if (saveText[2] == "1")
                    radioButton1.Checked = true;
                else if (saveText[2] == "2")
                    radioButton2.Checked = true;
                else if (saveText[2] == "3")
                    radioButton3.Checked = true;
                checkBox2.Checked = Convert.ToBoolean(saveText[3]);
                notifyIp = saveText[4];
                textBox3.Text = saveText[4];
                textBox3.Enabled = checkBox2.Checked;
                string[] rgbInt = Regex.Split(saveText[5], "-");
                string[] rgbInt1 = Regex.Split(saveText[6], "-");
                string[] rgbInt2 = Regex.Split(saveText[7], "-");

                string[] rgbInt3 = Regex.Split(saveText[11], "-");
                string[] rgbInt4 = Regex.Split(saveText[12], "-");
                string[] rgbInt5 = Regex.Split(saveText[13], "-");

                Color getColor = Color.FromArgb(Convert.ToInt32(rgbInt[0]), Convert.ToInt32(rgbInt[1]), Convert.ToInt32(rgbInt[2]));
                Color getColor1 = Color.FromArgb(Convert.ToInt32(rgbInt1[0]), Convert.ToInt32(rgbInt1[1]), Convert.ToInt32(rgbInt1[2]));
                Color getColor2 = Color.FromArgb(Convert.ToInt32(rgbInt2[0]), Convert.ToInt32(rgbInt2[1]), Convert.ToInt32(rgbInt2[2]));

                Color getColor3 = Color.FromArgb(Convert.ToInt32(rgbInt3[0]), Convert.ToInt32(rgbInt3[1]), Convert.ToInt32(rgbInt3[2]));
                Color getColor4 = Color.FromArgb(Convert.ToInt32(rgbInt4[0]), Convert.ToInt32(rgbInt4[1]), Convert.ToInt32(rgbInt4[2]));
                Color getColor5 = Color.FromArgb(Convert.ToInt32(rgbInt5[0]), Convert.ToInt32(rgbInt5[1]), Convert.ToInt32(rgbInt5[2]));

                saveThemeColor = getColor;
                saveTextColor = getColor1;
                saveBackColor = getColor2;
                Mtheme = getColor3;
                Mtext = getColor4;
                Mback = getColor5;
                colorDialog1.Color = saveThemeColor;
                colorDialog2.Color = saveTextColor;
                colorDialog3.Color = saveBackColor;
                McolorDialogTheme.Color = Mtheme;
                McolorDialogText.Color = Mtext;
                McolorDialogBackground.Color = Mback;
                checkBox10.Checked = Convert.ToBoolean(saveText[8]);
                checkBox9.Checked = Convert.ToBoolean(saveText[9]);
                loadConfigPath = saveText[10];
                useX2Scale = Convert.ToBoolean(saveText[14]);
                playClickSound = Convert.ToBoolean(saveText[15]);
                checkBox12.Checked = playClickSound;
            }
            catch
            {
                MessageBox.Show("Error has ocurred when retrieving settings.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void saveInfoClose()
        {
            try
            {
                saveText = new string[] { targetIndex.ToString(), ps3IP, (radioButton1.Checked) ? "1" : (radioButton2.Checked) ? "2" : (radioButton3.Checked) ? "3" : "0", checkBox2.Checked.ToString(), textBox3.Text, saveThemeColor.R + "-" + saveThemeColor.G + "-" + saveThemeColor.B, saveTextColor.R + "-" + saveTextColor.G + "-" + saveTextColor.B, saveBackColor.R + "-" + saveBackColor.G + "-" + saveBackColor.B, checkBox10.Checked.ToString(), checkBox9.Checked.ToString(), loadConfigPath, Mtheme.R + "-" + Mtheme.G + "-" + Mtheme.B, Mtext.R + "-" + Mtext.G + "-" + Mtext.B, Mback.R + "-" + Mback.G + "-" + Mback.B, useX2Scale.ToString(), playClickSound.ToString() };
                if (!Directory.Exists(app_folder))
                    Directory.CreateDirectory(app_folder);
                File.WriteAllLines(app_file, saveText);
            }
            catch
            {
                MessageBox.Show("Error has ocurred when saving settings.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region connection
        private void updateInfoLabel()
        {
            label6.Text = " PS3 Connect: " + ps3Status + "\n Game Attach: " + gameStatus + "\nSelected API: " + apiStatus;
            label6.Update();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                curAPI = "tm";
                labelTxtCT = "Select a Target Number(Default = 1)";
                listCT.Clear();
                for (int i = 1; i < 10; i++)
                    listCT.Add("Target " + i.ToString());
            }
            else if (radioButton2.Checked || radioButton3.Checked)
            {
                curAPI = "cc";
                labelTxtCT = "Select an IP";
                listCT.Clear();
                if (cList.Count != 0)
                {
                    foreach (CCAPI.ConsoleInfo item in cList)
                        listCT.Add(item.Name + " : " + item.Ip);
                }
                else
                {
                    textBoxCT = "192.168.1.1";
                    labelTxtCT = "No IPs Found - Enter IP Manually";
                }
            }
            radioButton1.Enabled = false;
            radioButton2.Enabled = false;
            radioButton3.Enabled = false;
            apiForm_.ShowDialog();
            radioButton1.Enabled = true;
            radioButton2.Enabled = true;
            radioButton3.Enabled = true;


            if (radioButton1.Checked)
                targetStatus = "Target Number: " + targetIndex;
            else if (radioButton2.Checked)
                ccapiipStatus = "PS3 IP: " + ps3IP;

            label3.Text = targetStatus + "\n" + ccapiipStatus;


        }

        private void button6_Click(object sender, EventArgs e)
        {
            doConnect();
        }
        private void doConnect()
        {
            bool canConnect = false;

            bool canTry2Connect = false;
            if (radioButton1.Checked)
            {
                if (targetIndex != -1)
                    canTry2Connect = true;
            }
            else if (radioButton2.Checked)
            {
                if (ps3IP != "-1")
                    canTry2Connect = true;
            }
            else if (radioButton3.Checked)
            {
                if (ps3IP != "-1")
                    canTry2Connect = true;
            }
            if (canTry2Connect)
            {
                try
                {
                    if (radioButton1.Checked) { PS3.ChangeAPI(SelectAPI.TargetManager); canConnect = PS3.ConnectTarget(targetIndex - 1); }
                    else if (radioButton2.Checked) { PS3.ChangeAPI(SelectAPI.ControlConsole); canConnect = PS3.ConnectTarget(ps3IP); }
                    else if (radioButton3.Checked) { PS3.ChangeAPI(SelectAPI.PS3Manager); canConnect = PS3.ConnectTarget(ps3IP, true); }

                    if (canConnect == true)
                    {
                        ps3Status = "True";
                        try
                        {
                            if (PS3.AttachProcess())
                            {
                                gameStatus = "True";
                                afterAttach();
                            }
                            else
                            {
                                gameStatus = "Cannot";
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                            gameStatus = "Impossible";
                        }
                    }
                    else
                    {
                        ps3Status = "Cannot";
                    }
                }
                catch
                {
                    ps3Status = "Impossible";
                }
                updateInfoLabel();
            }
            else
            {
                if (radioButton1.Checked)
                    MessageBox.Show("Please click the 'Change' button and select a target number to connect with.\n\nNOTE: Target 1 is default.", "Change Target Number", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else if (radioButton2.Checked || radioButton3.Checked)
                    MessageBox.Show("Please click the 'Change' button and select an IP to connect with.", "Change IP", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        #endregion

        #region after attach
        private void afterAttach()
        {
            button6.Enabled = false;
            button7.Enabled = false;
            radioButton1.Enabled = false;
            radioButton2.Enabled = false;
            radioButton3.Enabled = false;

            if (!loaded)
                loadInfo();
            canUseTool = true;
            name_backup = PS3.Extension.ReadString(getOfs(mcOfs.sx6si2n76p73uwk613zim));
            PS3.Extension.WriteBool(getOfs(mcOfs.msgd98575idgjdg39vhg3), true);
            PS3.Extension.WriteUInt32(getOfs(mcOfs.kgh39gjsngjfgh396723j), getOfs(mcOfs.ghflk3296jsdnmhgh2967));
            if (ins4.Count == 2)
                PS3.Extension.WriteUInt32(ins4[0], ins4[1]);
            modsTimer.Stop();
            modsTimer.Start();
            timer2.Stop();
            timer2.Start();
            if (!backgroundWorker1.IsBusy)
                backgroundWorker1.RunWorkerAsync();
            if (!backgroundWorker2.IsBusy)
                backgroundWorker2.RunWorkerAsync();
            if (!backgroundWorker3.IsBusy)
                backgroundWorker3.RunWorkerAsync();
            apiStatus = PS3.GetCurrentAPIName();
            if (apiStatus != "PS3 Manager")
                gameManagerPanel.Enabled = true;
            sub1.Enabled = true;
            modMenuPanel.Enabled = true;
            updateInfoLabel();
            button20.Enabled = true;
            if (checkBox9.Checked)
                loadOpts(false);
        }
        #endregion

        #region ult txt

        #region mc_listing
        string[] mc_listX = {
"kkmg57b7a5jhdhlsy1rbv",
"d16rfn7lvi3z6m7vkzrdu",
"Nvnca12ceuy2jn9pm105l",
"uc0frojmrgrio7ypn4qnu",
"b4haubpsmsjt9w1r4iuvs",
"aqv7dqomzucskmkr5zuq8",
"P5s6ysmgofoud2ygfnxo5",
"cd31q1iwlkvfydw0qvaeh",
"Awgra7iprghv1p357htgz",
"Jvp5voqfiexxj37a7l1ss",
"U2ffc9oij13ic3pvhk6vq",
"uchnttm8s38wqax6qk2va",
"Hh5qlovqol3wpgcpv1wsx",
"tq0q3h2bfsf6skuig0ce8",
"C6ugalgj7ilyxj7urpxdv",
"Ktk5f6eev4i4zsu16tpra",
"Asd7gqjima00d8sovyaeh",
"Ngd2o6x0ytc2hti46kj0w",
"h51vdr109gfhskk85a80q",
"Xdtgl2074p8j9lrlkcarz",
"Gjgsaqp05fhpo8itmvjk1",
"v35th6ig28y29rbh7bg5m",
"J32axm662236lv0jxcy72",
"bj77roq77awkoo712fmzc",
"Shd489aj1f3l0cwdcei2c",
"p7dcmykn27dhjvbafc8ro",
"bgf1hkul14zx7txeebsjz",
"lxr4cvbfbw8ag0o51l4be",
"Rxq2ixva686g4qr0b39cv",
"zpkf5zrge2m3grf1ctvwl",
"Zkhe14qr7yfqwj1zxpct8",
"Jdwftc7csbyfzcj8hfobi",
"yajqw6g6zqdwrcyiybuy7",
"In85990ua3rsbak74gsx5",
"Vanc8cyxnbjfuze5bnqwg",
"zv1qw4q97hzablmsmmj3f",
"Actlf91b8i6hmhvbf5j8n",
"Xh5wx1ww6h4fqtldp8mxw",
"bitn472xqu2t2tpehuk2y",
"Tlpzt0agvn3fep0jxs108",
"s9gmolm6eg65xu9l343d6",
"xwcc1xon2fqy3t3yeckio",
"Pdcor8ruqpq3yx3m7ev16",
"g8d80hbd0kg1tvz2txv2f",
"W47nzx9fzr1aqtlpaexj6",
"uo3fiyjd7b2js2wbb0idh",
"c6nitgkajk2pal61b1ean",
"n5iyzrrx6joj5ubaauwco",
"Yj4ximjh55ajwhzlyytby",
"Zwd96tupk60rfcwebupmh",
"Yk1bjfxx4zmlaun1f50z2",
"t469etdtvvkdig4n4cz15",
"E6uuupquy58g30unn260b",
"idcipic40a6df945jmozc",
"Ct50xdjswqacf8014mflm",
"sv3y85b46ydbngxrilvl9",
"Tthk948gjca7hdnqzh11c",
"lpw7n9y8lits03m2otye7",
"b4u3yg3k3g1au3it7k6af",
"m95bsrhn0ucgsw4i52igf",
"zoeeqs86v25dwx978slg9",
"icki88qr78yc8o0o4awyr",
"ek28z8t5w7jmqbhz45a5a",
"A97ud0c62ich8mxyxvufb",
"jxlb0mx9sf690z8tmh486",
"Kxco4boeoscjl53nx531c",
"wcnwmcqindlp0vinu7gz8",
"ytvadwy55v5qnd53jqb2u",
"Yf1kgxtzwp30ze2trnszo",
"Uum2h5bwzpde5oe22k3qd",
"J9jq2f1jlml67mo938clv",
"d69hlz4ka91htcwol6acd",
"ru8f2rqjqkbwtcwsujsch",
"Nqjlven4z9y68ai3uvdes",
"fkk5979ahopj271wsa294",
"Il3aqc4hkbwn89uagnlxf",
"fmxktpebjvku3ekgqjp7d",
"d10g2bk2m0qfyf3rytqa8",
"E38y0cu4yot67ouovqsse",
"Ylysef5xk2r72o9j2bpzq",
"Nqd8huhkvp6ia86wfqtvg",
"n6t66vdtpkwtb2cxi0lu8",
"Mvc56j74smels4st7hbvq",
"Xy5k3mhh6ioof9xv4x9xy",
"aibcgkbgjs0ayzdk02cuc",
"gz8j8zgth6zjio6ix2dsk",
"Ea7nsnzp5m5cvou9k1dre",
"Ps8n2r1k35x7ytjb1u0u9",
"G0x4bxx33675ywo2buvbv",
"cpwaz8ncfsizatrn4elf3",
"O8r771jberag9z9uexedj",
"Pvykyh4fea77jphx7yc8y",
"vm7ysb0lu7jh9i6ikgiz7",
"pd6etc7trlwpvgo7x92wr",
"Usvh107at9n1qmaup2epe",
"zg4ik3w348ukowioszn3f",
"S7ar859if3s55mrkym77d",
"Oefupdm3ewc0plkhgmko4",
"xoyaqzobe7zg1pza1pc4t",
"Mfds12ptckelctczqee0y",
"ylyh6589vjq0kp5ykfjyj",
"d5942odinauwllghr5w53",
"Op824nbwxnol5qq3l4os2",
"Dzwvy3p8ixhoso446g9om",
"Qqu9vj045n6wrddd3nda8",
"vcoaf92rvw6f49flfw9pc",
"oud51v7ok0atc8qkcu3wr",
"qjiiq01r828goy7n8siub",
"Dng5vnd5s5iu3m83l5oa3",
"tqqs14fnbdltmjudcnwdx",
"M58ctonb0ebdeh0v7yd1h",
"pz4puyht2508ikn7ro8nq",
"gex7cipes9gok558bts5g",
"D3j5nc4342dsz0kdb7mli",
"Ydb2ymxmpo685dgw42u9n",
"Lwkz5xzuu26dhgwd1qgap",
"grop6fwwtxiinm8w2m7bx",
"Hd2ws20zqc5owtu5h52za",
"ada6tx04ialpsenmz17do",
"C7fr24w32co7thbuc5d4c",
"F6rq1q5sgigq7zkc7teyb",
"g6cgvn5lc2j4xdasqy0m9",
"sext589378ws1p2f3k5nu",
"vupn8m24y1wj31z7jskwo",
"Gboef0cik4zf3m2oyjvtf",
"ufffmnz9046kai9tglihj",
"hut3cqpq9ki961rj6i22b",
"Pcsq8ofvnjinbojuvlc58",
"tjapv6nj1zw7sqggcd5yl",
"f4c0c58sr6xvg632cc4ba",
"q53xwk4vicsrpotdgkm08",
"R525cb1wwne9j4xpapd1a",
"gmkongf2mzw10dcfd8vvt",
"si848siv0ed1hu0vunr66",
"Z9j61njg1slb3sh2nqq57",
"jtbiw5ufmru0rzzu8ccui",
"Zc4h2b7yn8hd7v8m7bk62",
"Je3k7vte3w3lo5w5z3pu7",
"H52ojq261mx62f2ejujhs",
"f350e6zb8cxdw096loaq2",
"sxnq96tidswfuhceacjn1",
"O17yztkcg524t2p4po0im",
"Mq8qqrtox46jexzb0y0pv",
"Mrchz1v12hywlbak2qiha",
"Q5ol9tz5dod1xkw5o10y6",
"Z2wpfk8dxojjqtp0d0igc",
"j0xoe78aof6azulij8gzu",
"swiye4ke561xtuvgeilil",
"Q7yssit5hgreusvpr9jkw",
"I3esnirf8fdaw7nx7zf6k",
"So7ypwca8gyf9bvs2gej0",
"Lo7cdqswf7s13m9h6pc0f",
"org2q8bvm550v6g6r4v9e",
"uq5ax6lwcnvmdodjhfweo",
"G7kjc2g7gd0c4dvzwfetw",
"Rps8jswg26ymiruhgv75z",
"kop8xtsa3oxbacr9ol9uf",
"Saejoo3mtotahj4i9uk09",
"xwnnjxlg9v34vnzzjgujz",
"Wfqo5w30ij94ajusx090c",
"Nxn8vyo4te839ba4g8sx3",
"Yv80v94m2hcsg3gc2s3gi",
"x8gdkg48i0myim7rzxnv4",
"Xbcmcqxg58cxemo5o4ppe",
"C5dc4nk36zmefhmg63b4s",
"vxdkyyu67cd4i7r989syf",
"J3kfv7s6ai8u3u6q12nf3",
"no54vr6h0mi6lmzzn7z0f",
"dx5zdsbxbaifwm517puda",
"olfxabir5hd3dwafsg0dq",
"mjf0eck9q717nvz4rizcj",
"Xu146ob9mzi1zrx1fps70",
"zja7pfpr6fykqx36rl3za",
"ulw0z9i688ycz1mat3o19",
"Ktcgb8kbx1j3v36pwjiq6",
"rst8rwuzl2my7c0qiqz0y",
"Tgihy4q646nju75qaezoo",
"gv05ov6tcqhfus1zkljwf",
"fy4opdd9hkqe1kmcqn3d8",
"h73ozhzbffgy4cjz0lplr",
"K6m29cojgzj6sfxh5qzhn",
"pc3cd1jybwmf8rwbvaow3",
"yq5q5kfzpc4kvh7pdjzi3",
"lzitme8atvv4bco7gmg3v",
"Nuj82bt0uh8llg3dile1m",
"fef3q9it3ai0d5wjpj1kv",
"chqlwjt5jkz4iprroqr23",
"l96t9iipuux8u3fey4ghq",
"lnjslnrxof4919rvl7mob",
"Idkzw0kpjn3ujklq0oiv1",
"zubpzyhulu30r2fncu5vd",
"Gbnalk0qya56z1wqc5a8t",
"Lzdzuccqe8ogsws0gado7",
"l06lz6b0gzkhu7bn7yqji",
"Sjmzwzocj6jb1va332axa",
"Tlkpxgwuue2st3gyngyar",
"R8rjqjp86iuex2i786cpc",
"p3ree0s7ompweagb3b9o1",
"Jxymux40uj0rei7yrnfz0",
"Vruu38axwgd77yypffuq5",
"P1mfw8r6druq5jxkddsvw",
"vheof2tqursl2y39eo85q",
"Oeuewxbxanmbw83yw893o",
"bblv8jxhqyfyexfsw92s1",
"W5pgfry44emfpfqp29fma",
"u4hmiy693lcxgrbtvfqru",
"L2mllai9h0zw4pr7xd8ru",
"uzatbz88d63xty2hr5ahp",
"j71dvp219d5sh97422kwb",
"Pk5l6cdgwkp2c0bx878w6",
"yh99alqt18pzvogfbqgsl",
"Ewezydpq7j644xz3k5kvw",
"ntpy40gxu6ws0pkjcjl65",
"Q9wrbu57zm4ffv61hp487",
"L16axneonp1bunzw77wk5",
"Xi8hcqmftscwpn9ddw4yq",
"Zqujv3v26j4j3ucz3y7hb",
"L855nevgovskd83oyzwj4",
"Jujjx235kkkpywwruz5rh",
"Xook0ug40ybebymqzwhvk",
"S06dldvqlm383fcpg8sdv",
"X9ewjgnakg28rkgrsk8x8",
"Bzso4ck6w6k0dd9lvj4fz",
"Vvgfu5rt8u7694f6q01g5",
"pron5b4ok55ip38mtn49u",
"f17b9o0j8d44sxkhh2ksa",
"Mcidzyqg62nd61wdumoqk",
"Ovqhaa01t0f0cl9rt4ll7",
"cumfz180bhx4o3hpwbcy7",
"qzwgxwau2etzbdt0jkrjc",
"a9zmclmjet5s2wni7fsd1",
"en87x83kkrflt3w79kdlk",
"W1qiib7ozk3d2oryb1yes",
"Kb9xnt88apiwbg2a6zyvb",
"Rov9xcsfl76hv93i134zc",
"P8nkcgbwvr1mddddq99la",
"b3xctaacmtic49tcal7ra",
"X6t3gtes6z224tzjkl0bf",
"O9kbjyreuacfcrkej3696",
"Ssfw1piljj2zu6mbwsurc",
"Ta85xxzniv9rp1ew3xk3q",
"ig4kinugfjs1ip75tj9e0",
"C4cyklk31zh8h1a5gyxkc",
"Wti8dhia3iduxgdvdfa7d",
"J1ppcttrobz5wzbgwevcc",
"ujaswxlbxo2ax0gle26tx",
"S0v1sh88f699t843063pi",
"vs3ajzi5szc3hbomyi9pz",
"Zm61p3qz6nuh9qlf6us39",
"ucpp4f1sures7o05wcvqi",
"us8fe441ziqe0fpw7q6jb",
"F8fpicku0qt39bvqdkkak",
"f92lba218d7fglojnt6ct",
"mjajzwfyu9swf68bg3nij",
"Ctwwsnxxxlctniqb8swo4",
"reh9vk9knmcugx2axo0l9",
"tsai69j7p7cxh9nfmxbhn",
"snjljsn0pqnu2komd8cvb",
"lc4pjomgjxyans7wiz9nv",
"qtr9us57ubbnupfls4c4g",
"igq22ngjm1eo9yasu550t",
"P66yhadkru3utheugyqnq",
"Rwu26wn5ox1x9ll0vhgr6",
"ti6zx014rvp4yxo642m97",
"outz5qol4q35tzkdz5ef5",
"Utn2h68l6o524gumyg4hm",
"hqaa2tk9nlg9xgeog0s8s",
"ddopuabme7ota73osnaxw",
"y87vh6eycgf7y6yibup1s",
"w74p6x90mz5304mtf3iy5",
"wmk82r4eivn87ifyerzt7",
"Colnlmh4tfcil06fx5xp3",
"x4r1l65szypxdz1rb6xpj",
"qaudsfwgm9ai4k0c7ucor",
"Dyf50pew9oe1ihf3jnifj",
"kygzyg338ztr4i8u4zndb",
"V9h75j9wf62tl6e2sphtv",
"flxk5w69ju8uafekrj3og",
"Lgxc69g8efcos3rzl7cim",
"vanu7itf14ljv2mpxvn5q",
"M85dstbgxo8thvcg3deyq",
"Qagj4220rcc0tg1nfjcog",
"pmrn51cazgvuryoq2vjz0",
"ilzvmi9a3zbtb0ses2ncz",
"w2bkqsj52lutamx5w6bx1",
"Vch9fcs0gj79hh98kpe39",
"yehrerszcwsw1zkxubfn9",
"kszsoul3myvh1hyx4z5xt",
"H3yt1lir6mnij03roydtf",
"aznobl4ubw35gr4g3g1dm",
"V469km7anhifwls3qjrpq",
"ixqktsc16xxi6agl3ndzn",
"l3g4oxi49a0uymwznwq1j",
"Xfe0uaiwegacf2bwrw55j",
"kh157ctunr7h6lpizqjno",
"Xw03axo6kah10urboi2rq",
"Qyjwi2f4m37amrrxr85jy",
"Jwjmjgrm4o3qx270neuhs",
"huurchoid4upmt23o6mcl",
"p3979qmuu0jnny1ec2kc1",
"Nii94nde9emr1s5yuwrw4",
"p4ymvgcy2y1wvkkduadvm",
"xiuqo1v42cupkxh7u6oxl",
"dpllmz5ri2ets6jwkh73v",
"xh60dll8cnsywqk76idy6",
"rew98a6oovwm8ubdsvhbo",
"H7o4kp7bwmzcej6qv61do",
"o7tr0f0bpgolack801zsd",
"i52c5uizyvsv3ewrn6dey",
"R5wp7nbc8704hi9tervg7",
"Vbn3y2r5p2v3xv3iimess",
"Og004yovfcm6k7gxs21e6",
"hgwgm6gvo1l2mdx1lx8ao",
"q60nqytzpg0pvavmtun8r",
"d2go1ttgkom430zapjzyn",
"Rqgia6hmskh1jasvzlw6f",
"Hmpa45v4kv6k4zvbw7n5m",
"jgy9gvu3iekew2saafofk",
"wnc6n76upr9180t8xq3jk",
"T2wgl2xbguaqthu9e2vjy",
"Vao0esf5iunumf5s16vvj",
"x4o4rti0gu354tukn5b3w",
"V12whqdombiigaa3vtjvj",
"Xpzy0rz2uuf5428rc1xbp",
"a3nelvy4s0y3wqthce6z0",
"Nl326moobt146hfqbumf3",
"R4j36ljoi1p857keavh9h",
"Zj29946okdfr1165b96vd",
"G9gke3997bppnn7tbk4bo",
"g4dfv7gdbodazw5hds5g5",
"T7rjx0dn3m41f4hi6azgw",
"M57s7p01s0qtoygqn3s53",
"x2kzul45owkc3zt9a8lha",
"Wm5c5kmqx04cs3m3ui8wu",
"h4m5qo0yegqpsk5r7i3k8",
"Xnhy1hu9nzp1azxfaavrt",
"Txmqkpui856moxxgwydi4",
"L1lp1yo2xzr6wl0kb1nmw",
"klar2dmmcqsl6nx2m7ywa",
"E2uioazd7me5k1vs04wyl",
"Nczhhfajy78ec1l411d2n",
"Jjo0lxbe1fbrkak8cnbj9",
"Bqpana2tq10803kbx95ud",
"p5ss5r3cqn1n04374onl4",
"Esy9oc1r0jkdrrfe76e6g",
"H0cdami5anhjvuzvhtd2z",
"Bllhcx5jzy98jreepu8b4",
"u5rmcbs71t7o2lg4o4anr",
"t9glni9epvgwub8348fbf",
"S8rf1uf7kkzuuvu4zg93b",
"Pnsgnk40nmapz9issat2d",
"hb3f5vc8qdey9m91qk2r0",
"Mou7kk5uncmzxhzauml2i",
"O6kkimqnaqciiccyr55u0",
"Truo1ob2w9gd8ai3ekz84",
"Qru69eruebtyr0b1m5t3k",
"Tx1bk8jh3iuhg70i7xpx7",
"Zqxvpswh8rrj05xg0twa4",
"Dj15qmrta33yq554afv1m",
"jcjm1lqlkusnao2yz1edb",
"achfx23592gu75y19oef6",
"ifjpkpybchfibr0j4dy9s",
"ivmro7qf0bykx9h5314hd",
"C122w7tpfo65zexk31bn9",
"ytlbs5ubk5qdjr502u4qn",
"Ja9le2usm6bb0rhuq0j1m",
"Qrfk83wij7rj6v99t970k",
"Kczn3on2jljckdd64zmkg",
"Jmjoo1ffribr2trk11quq",
"G488xp93rdf3wxu82k9ci",
"yikbk2j1w3edj23lnl192",
"wmxoch4f9trr2olit6y4f",
"yhhy9bu33iurtak6u68c7",
"se2dlxl5rv1qx63ue9pbw",
"Gal08a71doyx8v6apemm0",
"Mzmiqd4wgz2ur7q72bekz",
"vt1d6dsb92eawck6ydk5g",
"flvowdgae9in9cwh8jlmu",
"T2xnu17oxtjz1ieo8nq27",
"Ss6au0auqd8o17koxh34f",
"M2nv0sw18ijv2tpb5x230",
"Wn7uv4747z00tvwefljbe",
"fjvh3nwirisao9e243a6u",
"n23issbg6k6tn1zq100hi",
"Qzmzhzlur4kmlnqmqnzkm",
"lplhm9xxjxaec2x5peb2h",
"Aqzbauiakn9oap53nfmib",
"jxk34fjszv6mm6d5zjg10",
"Cxn6xwdx64rk130tf5h4l",
"Rzkyrxceladd8vrokoghc",
"Dww4evvsfuz4cmqbmypau",
"t9l61nmfmmj1za2ycpu5b",
"It81kjbwfpcv8fxclzd1j",
"Apg3l7ecu186eu8bbtvrl",
"dza6jx3tmznnm3wvmeqme",
"e9corfqogwb1dvptpkuxe",
"buz4nvul7my6cjnlxwpdh",
"zom0xvj0ncgbu3itkha5v",
"rfq47ez4id535qqzi9h1m",
"v374gxmja3bqvtsb8s2s6",
"qoskhngdnslkajt1ivxk2",
"qq3ocohm8o1zgy47lxx2q",
"li5ss0qm903m4r0qudi2f",
"n3f81vdlowqu843tul5l8",
"T5mivp4z7onhp4xwd616x",
"Te7njioayg6ii64kr7nl1",
"ioo9jjfdhgqxu9x3798ma",
"T4a0se9samfgtpei07ead",
"Hk2r0iyiiamr8bl7oxrfj",
"Hxd4bkef4pd957i0btajp",
"U0j99yhreh4cq80qh7qqe",
"nso37nva2u54xiztne4mc",
"Gwbwvbt6g2sddte6lpbwc",
"kgytl9ohjhcdddorr1h64",
"Xz3ab21ed2h7cik58rkvw",
"Elw90pa9fxptif1mmyrti",
"Dker9ea42st9qwktc4jw1",
"u18qmxz7q7sja1nlgf9wo",
"lfhwdpdv4iksp41qlyemo",
"Mdo49k9zj8m74xivumm7u",
"Iechxa4f969raxhk1mw3q",
"hnm66mx1wg69mh1kbgh9p",
"I30m847hp73iztqg1glkm",
"rcs39af267jvfwnxxa7bp",
"Cqmzmyj30ut446xnk6m8z",
"Eekrxidcf3t1jk5603ql0",
"ombloo0j9am0x9mlf4bev",
"yhx7b1vua0wrqbhmc9dir",
"O3cfr2dj7t051l0tyekw3"};
        #endregion
        public class mc_list
        {
            public static string
            #region mclist
 kkmg57b7a5jhdhlsy1rbv = "",
pig9lvbiwic3aww77nrbn = "",
Erqj4xyfl7ac00fcdm4j6 = "",
J3l13qhqvoulkqxd26fx7 = "",
P66yhadkru3utheugyqnq = "",
Bit7nz2kcckghgma6wu3n = "",
z69au92cld6dq1hzm9lrh = "",
b2iokxnm5extdxauitmn7 = "",
u099fg0p9xx7lcvuxu07v = "",
jpggpma20wq2w7uq3ijd6 = "",
s8mhqziabq6y2p2rt3t2f = "",
B7ynh5lnsf1olwawc9z0e = "",
o91kz2ahfc69zq89k9avn = "",
P5s6ysmgofoud2ygfnxo5 = "",
Jeipi1z4yamd8dmir4whp = "",
J32axm662236lv0jxcy72 = "",
Esrn2lvappyl1q9blh165 = "",
F2b6hp1nmdvogyo6lphl0 = "",
I5rmdsf5wz7pk1c9qvgmu = "",
oixm4kecbcz69qf9lz3yk = "",
u50xffdowoq0i51shes2o = "",
Sc3u9bp4wcy12rcyragyg = "",
Fzqxw9xezx1ggajhcgxe0 = "",
cj2u0y712cah84vzwg7ao = "",
Olf9kru1h5wkmb876567b = "",
j6mxxuimouu5ix0pd3jie = "",
pft7pz466y20ka8r8sm0j = "",
zhnxk1bzlt4dvx35noh70 = "",
Hlq024viyiqvrt9626xxx = "",
nevn3yewhceukoa81w4qg = "",
J3bcciwcy6dr1ukvzd6dz = "",
j9bve5kctaegbhr3cskvc = "",
pc7k9x20eoixz10h2q8h8 = "",
Husy17pucqsh3lbwb0vqc = "",
ru8f2rqjqkbwtcwsujsch = "",
Jixx5b4o0efb4seovn6kq = "",
Ngd2o6x0ytc2hti46kj0w = "",
Actlf91b8i6hmhvbf5j8n = "",
odzgcm4ljkrldfxow2wpf = "",
zv1qw4q97hzablmsmmj3f = "",
dp2y1vehugomi332mjth6 = "",
g4obuqj12fcjs3jz3cyb0 = "",
Bip03m2hrugd3b6lb0dkl = "",
Bmooee4oud8jusrxoxiiy = "",
icki88qr78yc8o0o4awyr = "",
rnxov6skuj7os5vjcfqfx = "",
Jmrvp6kf2d3nat0lp5wbp = "",
Zg7xbkud3rmyurbe5b9zw = "",
Jnsrptn8ej3gsozrp3uel = "",
Qgml0f2tsvqn67pcxpir6 = "",
yw9txgfg1tybq4opah0k1 = "",
Y4ps3qjv9w4avdiyg3yu9 = "",
Cw197o6ct9cpz70cgrzg6 = "",
Othezyqnvzigtflecqvot = "",
Xgc9tokynfszeryppxki8 = "",
Rtq4166twva06kxzrhuko = "",
j1aqgtccr5zogmq90hixs = "",
b0b1f223387hc93gtaxh4 = "",
v3c05vtt4x9k972xziko0 = "",
fiit7smhtjq0ua3yyl6ui = "",
Lj9g8xhehfqlzirvvt3ni = "",
Amaugjz9ed9ol0fqjbujk = "",
Than3faltidfssl6jo9z7 = "",
Hiadgb99calt8tdbmw1bi = "",
Zoq5a463pjh5c4lcg6h1g = "",
Ibis7tg8pktwx8rt1fcle = "",
Mfu32preha4pp94hf78ry = "",
h8nezvhdn2kb45warp0rc = "",
Yc1opegxdjn4gvxg2pdgh = "",
zn0p02vun400hrpwg8zvp = "",
vu9dop5iipibmtjyllyxs = "",
Dwkjtxwygaa30r1xnxbk7 = "",
Rml7vyoyi0l4kbc3k0u03 = "",
Jgchppl41vkxknzgkmx4j = "",
L8qpzfsyo8nxckr0jdsgm = "",
Nt7wqxt6m6s7czr40xrk6 = "",
Rxq2ixva686g4qr0b39cv = "",
Dwlrqpun3wawvikzden3c = "",
ttanaldwh136ypyjl8m3c = "",
Xhhj8juwg2w7pfacw8rel = "",
Z8fb3e8gtbne1u04l0p10 = "",
Qrqpe6qsowxnrirecfq3k = "",
qoceosf5pg05s0n4sz76y = "",
rq16naxsdw1fkwqmolbv0 = "",
ovdi62415wwmitf4wg1o5 = "",
kx12ouv6japhylgcmt9vf = "",
h6xqao70qv0itw0d3k4mg = "",
b8r4hpy6ncrcggi99k29w = "",
j4qykhxbuciczxoho3jv0 = "",
Zamndxbno1ets4zms2ua1 = "",
Zwml3pnt1bugahiwscuwf = "",
mjx38zu48czwjj3dybtyk = "",
Fsvmh7skwd3ph75r9sme5 = "",
Isuzm871ne7qs6mwykwag = "";
            #endregion
        }
        public class ult_list
        {
            public static string
            #region ult txt
 kkmg57b7a5jhdhlsy1rbv = "",
d16rfn7lvi3z6m7vkzrdu = "",
Nvnca12ceuy2jn9pm105l = "",
uc0frojmrgrio7ypn4qnu = "",
b4haubpsmsjt9w1r4iuvs = "",
aqv7dqomzucskmkr5zuq8 = "",
P5s6ysmgofoud2ygfnxo5 = "",
cd31q1iwlkvfydw0qvaeh = "",
Awgra7iprghv1p357htgz = "",
Jvp5voqfiexxj37a7l1ss = "",
U2ffc9oij13ic3pvhk6vq = "",
uchnttm8s38wqax6qk2va = "",
Hh5qlovqol3wpgcpv1wsx = "",
tq0q3h2bfsf6skuig0ce8 = "",
C6ugalgj7ilyxj7urpxdv = "",
Ktk5f6eev4i4zsu16tpra = "",
Asd7gqjima00d8sovyaeh = "",
Ngd2o6x0ytc2hti46kj0w = "",
h51vdr109gfhskk85a80q = "",
Xdtgl2074p8j9lrlkcarz = "",
Gjgsaqp05fhpo8itmvjk1 = "",
v35th6ig28y29rbh7bg5m = "",
J32axm662236lv0jxcy72 = "",
bj77roq77awkoo712fmzc = "",
Shd489aj1f3l0cwdcei2c = "",
p7dcmykn27dhjvbafc8ro = "",
bgf1hkul14zx7txeebsjz = "",
lxr4cvbfbw8ag0o51l4be = "",
Rxq2ixva686g4qr0b39cv = "",
zpkf5zrge2m3grf1ctvwl = "",
Zkhe14qr7yfqwj1zxpct8 = "",
Jdwftc7csbyfzcj8hfobi = "",
yajqw6g6zqdwrcyiybuy7 = "",
In85990ua3rsbak74gsx5 = "",
Vanc8cyxnbjfuze5bnqwg = "",
zv1qw4q97hzablmsmmj3f = "",
Actlf91b8i6hmhvbf5j8n = "",
Xh5wx1ww6h4fqtldp8mxw = "",
bitn472xqu2t2tpehuk2y = "",
Tlpzt0agvn3fep0jxs108 = "",
s9gmolm6eg65xu9l343d6 = "",
xwcc1xon2fqy3t3yeckio = "",
Pdcor8ruqpq3yx3m7ev16 = "",
g8d80hbd0kg1tvz2txv2f = "",
W47nzx9fzr1aqtlpaexj6 = "",
uo3fiyjd7b2js2wbb0idh = "",
c6nitgkajk2pal61b1ean = "",
n5iyzrrx6joj5ubaauwco = "",
Yj4ximjh55ajwhzlyytby = "",
Zwd96tupk60rfcwebupmh = "",
Yk1bjfxx4zmlaun1f50z2 = "",
t469etdtvvkdig4n4cz15 = "",
E6uuupquy58g30unn260b = "",
idcipic40a6df945jmozc = "",
Ct50xdjswqacf8014mflm = "",
sv3y85b46ydbngxrilvl9 = "",
Tthk948gjca7hdnqzh11c = "",
lpw7n9y8lits03m2otye7 = "",
b4u3yg3k3g1au3it7k6af = "",
m95bsrhn0ucgsw4i52igf = "",
zoeeqs86v25dwx978slg9 = "",
icki88qr78yc8o0o4awyr = "",
ek28z8t5w7jmqbhz45a5a = "",
A97ud0c62ich8mxyxvufb = "",
jxlb0mx9sf690z8tmh486 = "",
Kxco4boeoscjl53nx531c = "",
wcnwmcqindlp0vinu7gz8 = "",
ytvadwy55v5qnd53jqb2u = "",
Yf1kgxtzwp30ze2trnszo = "",
Uum2h5bwzpde5oe22k3qd = "",
J9jq2f1jlml67mo938clv = "",
d69hlz4ka91htcwol6acd = "",
ru8f2rqjqkbwtcwsujsch = "",
Nqjlven4z9y68ai3uvdes = "",
fkk5979ahopj271wsa294 = "",
Il3aqc4hkbwn89uagnlxf = "",
fmxktpebjvku3ekgqjp7d = "",
d10g2bk2m0qfyf3rytqa8 = "",
E38y0cu4yot67ouovqsse = "",
Ylysef5xk2r72o9j2bpzq = "",
Nqd8huhkvp6ia86wfqtvg = "",
n6t66vdtpkwtb2cxi0lu8 = "",
Mvc56j74smels4st7hbvq = "",
Xy5k3mhh6ioof9xv4x9xy = "",
aibcgkbgjs0ayzdk02cuc = "",
gz8j8zgth6zjio6ix2dsk = "",
Ea7nsnzp5m5cvou9k1dre = "",
Ps8n2r1k35x7ytjb1u0u9 = "",
G0x4bxx33675ywo2buvbv = "",
cpwaz8ncfsizatrn4elf3 = "",
O8r771jberag9z9uexedj = "",
Pvykyh4fea77jphx7yc8y = "",
vm7ysb0lu7jh9i6ikgiz7 = "",
pd6etc7trlwpvgo7x92wr = "",
Usvh107at9n1qmaup2epe = "",
zg4ik3w348ukowioszn3f = "",
S7ar859if3s55mrkym77d = "",
Oefupdm3ewc0plkhgmko4 = "",
xoyaqzobe7zg1pza1pc4t = "",
Mfds12ptckelctczqee0y = "",
ylyh6589vjq0kp5ykfjyj = "",
d5942odinauwllghr5w53 = "",
Op824nbwxnol5qq3l4os2 = "",
Dzwvy3p8ixhoso446g9om = "",
Qqu9vj045n6wrddd3nda8 = "",
vcoaf92rvw6f49flfw9pc = "",
oud51v7ok0atc8qkcu3wr = "",
qjiiq01r828goy7n8siub = "",
Dng5vnd5s5iu3m83l5oa3 = "",
tqqs14fnbdltmjudcnwdx = "",
M58ctonb0ebdeh0v7yd1h = "",
pz4puyht2508ikn7ro8nq = "",
gex7cipes9gok558bts5g = "",
D3j5nc4342dsz0kdb7mli = "",
Ydb2ymxmpo685dgw42u9n = "",
Lwkz5xzuu26dhgwd1qgap = "",
grop6fwwtxiinm8w2m7bx = "",
Hd2ws20zqc5owtu5h52za = "",
ada6tx04ialpsenmz17do = "",
C7fr24w32co7thbuc5d4c = "",
F6rq1q5sgigq7zkc7teyb = "",
g6cgvn5lc2j4xdasqy0m9 = "",
sext589378ws1p2f3k5nu = "",
vupn8m24y1wj31z7jskwo = "",
Gboef0cik4zf3m2oyjvtf = "",
ufffmnz9046kai9tglihj = "",
hut3cqpq9ki961rj6i22b = "",
Pcsq8ofvnjinbojuvlc58 = "",
tjapv6nj1zw7sqggcd5yl = "",
f4c0c58sr6xvg632cc4ba = "",
q53xwk4vicsrpotdgkm08 = "",
R525cb1wwne9j4xpapd1a = "",
gmkongf2mzw10dcfd8vvt = "",
si848siv0ed1hu0vunr66 = "",
Z9j61njg1slb3sh2nqq57 = "",
jtbiw5ufmru0rzzu8ccui = "",
Zc4h2b7yn8hd7v8m7bk62 = "",
Je3k7vte3w3lo5w5z3pu7 = "",
H52ojq261mx62f2ejujhs = "",
f350e6zb8cxdw096loaq2 = "",
sxnq96tidswfuhceacjn1 = "",
O17yztkcg524t2p4po0im = "",
Mq8qqrtox46jexzb0y0pv = "",
Mrchz1v12hywlbak2qiha = "",
Q5ol9tz5dod1xkw5o10y6 = "",
Z2wpfk8dxojjqtp0d0igc = "",
j0xoe78aof6azulij8gzu = "",
swiye4ke561xtuvgeilil = "",
Q7yssit5hgreusvpr9jkw = "",
I3esnirf8fdaw7nx7zf6k = "",
So7ypwca8gyf9bvs2gej0 = "",
Lo7cdqswf7s13m9h6pc0f = "",
org2q8bvm550v6g6r4v9e = "",
uq5ax6lwcnvmdodjhfweo = "",
G7kjc2g7gd0c4dvzwfetw = "",
Rps8jswg26ymiruhgv75z = "",
kop8xtsa3oxbacr9ol9uf = "",
Saejoo3mtotahj4i9uk09 = "",
xwnnjxlg9v34vnzzjgujz = "",
Wfqo5w30ij94ajusx090c = "",
Nxn8vyo4te839ba4g8sx3 = "",
Yv80v94m2hcsg3gc2s3gi = "",
x8gdkg48i0myim7rzxnv4 = "",
Xbcmcqxg58cxemo5o4ppe = "",
C5dc4nk36zmefhmg63b4s = "",
vxdkyyu67cd4i7r989syf = "",
J3kfv7s6ai8u3u6q12nf3 = "",
no54vr6h0mi6lmzzn7z0f = "",
dx5zdsbxbaifwm517puda = "",
olfxabir5hd3dwafsg0dq = "",
mjf0eck9q717nvz4rizcj = "",
Xu146ob9mzi1zrx1fps70 = "",
zja7pfpr6fykqx36rl3za = "",
ulw0z9i688ycz1mat3o19 = "",
Ktcgb8kbx1j3v36pwjiq6 = "",
rst8rwuzl2my7c0qiqz0y = "",
Tgihy4q646nju75qaezoo = "",
gv05ov6tcqhfus1zkljwf = "",
fy4opdd9hkqe1kmcqn3d8 = "",
h73ozhzbffgy4cjz0lplr = "",
K6m29cojgzj6sfxh5qzhn = "",
pc3cd1jybwmf8rwbvaow3 = "",
yq5q5kfzpc4kvh7pdjzi3 = "",
lzitme8atvv4bco7gmg3v = "",
Nuj82bt0uh8llg3dile1m = "",
fef3q9it3ai0d5wjpj1kv = "",
chqlwjt5jkz4iprroqr23 = "",
l96t9iipuux8u3fey4ghq = "",
lnjslnrxof4919rvl7mob = "",
Idkzw0kpjn3ujklq0oiv1 = "",
zubpzyhulu30r2fncu5vd = "",
Gbnalk0qya56z1wqc5a8t = "",
Lzdzuccqe8ogsws0gado7 = "",
l06lz6b0gzkhu7bn7yqji = "",
Sjmzwzocj6jb1va332axa = "",
Tlkpxgwuue2st3gyngyar = "",
R8rjqjp86iuex2i786cpc = "",
p3ree0s7ompweagb3b9o1 = "",
Jxymux40uj0rei7yrnfz0 = "",
Vruu38axwgd77yypffuq5 = "",
P1mfw8r6druq5jxkddsvw = "",
vheof2tqursl2y39eo85q = "",
Oeuewxbxanmbw83yw893o = "",
bblv8jxhqyfyexfsw92s1 = "",
W5pgfry44emfpfqp29fma = "",
u4hmiy693lcxgrbtvfqru = "",
L2mllai9h0zw4pr7xd8ru = "",
uzatbz88d63xty2hr5ahp = "",
j71dvp219d5sh97422kwb = "",
Pk5l6cdgwkp2c0bx878w6 = "",
yh99alqt18pzvogfbqgsl = "",
Ewezydpq7j644xz3k5kvw = "",
ntpy40gxu6ws0pkjcjl65 = "",
Q9wrbu57zm4ffv61hp487 = "",
L16axneonp1bunzw77wk5 = "",
Xi8hcqmftscwpn9ddw4yq = "",
Zqujv3v26j4j3ucz3y7hb = "",
L855nevgovskd83oyzwj4 = "",
Jujjx235kkkpywwruz5rh = "",
Xook0ug40ybebymqzwhvk = "",
S06dldvqlm383fcpg8sdv = "",
X9ewjgnakg28rkgrsk8x8 = "",
Bzso4ck6w6k0dd9lvj4fz = "",
Vvgfu5rt8u7694f6q01g5 = "",
pron5b4ok55ip38mtn49u = "",
f17b9o0j8d44sxkhh2ksa = "",
Mcidzyqg62nd61wdumoqk = "",
Ovqhaa01t0f0cl9rt4ll7 = "",
cumfz180bhx4o3hpwbcy7 = "",
qzwgxwau2etzbdt0jkrjc = "",
a9zmclmjet5s2wni7fsd1 = "",
en87x83kkrflt3w79kdlk = "",
W1qiib7ozk3d2oryb1yes = "",
Kb9xnt88apiwbg2a6zyvb = "",
Rov9xcsfl76hv93i134zc = "",
P8nkcgbwvr1mddddq99la = "",
b3xctaacmtic49tcal7ra = "",
X6t3gtes6z224tzjkl0bf = "",
O9kbjyreuacfcrkej3696 = "",
Ssfw1piljj2zu6mbwsurc = "",
Ta85xxzniv9rp1ew3xk3q = "",
ig4kinugfjs1ip75tj9e0 = "",
C4cyklk31zh8h1a5gyxkc = "",
Wti8dhia3iduxgdvdfa7d = "",
J1ppcttrobz5wzbgwevcc = "",
ujaswxlbxo2ax0gle26tx = "",
S0v1sh88f699t843063pi = "",
vs3ajzi5szc3hbomyi9pz = "",
Zm61p3qz6nuh9qlf6us39 = "",
ucpp4f1sures7o05wcvqi = "",
us8fe441ziqe0fpw7q6jb = "",
F8fpicku0qt39bvqdkkak = "",
f92lba218d7fglojnt6ct = "",
mjajzwfyu9swf68bg3nij = "",
Ctwwsnxxxlctniqb8swo4 = "",
reh9vk9knmcugx2axo0l9 = "",
tsai69j7p7cxh9nfmxbhn = "",
snjljsn0pqnu2komd8cvb = "",
lc4pjomgjxyans7wiz9nv = "",
qtr9us57ubbnupfls4c4g = "",
igq22ngjm1eo9yasu550t = "",
P66yhadkru3utheugyqnq = "",
Rwu26wn5ox1x9ll0vhgr6 = "",
ti6zx014rvp4yxo642m97 = "",
outz5qol4q35tzkdz5ef5 = "",
Utn2h68l6o524gumyg4hm = "",
hqaa2tk9nlg9xgeog0s8s = "",
ddopuabme7ota73osnaxw = "",
y87vh6eycgf7y6yibup1s = "",
w74p6x90mz5304mtf3iy5 = "",
wmk82r4eivn87ifyerzt7 = "",
Colnlmh4tfcil06fx5xp3 = "",
x4r1l65szypxdz1rb6xpj = "",
qaudsfwgm9ai4k0c7ucor = "",
Dyf50pew9oe1ihf3jnifj = "",
kygzyg338ztr4i8u4zndb = "",
V9h75j9wf62tl6e2sphtv = "",
flxk5w69ju8uafekrj3og = "",
Lgxc69g8efcos3rzl7cim = "",
vanu7itf14ljv2mpxvn5q = "",
M85dstbgxo8thvcg3deyq = "",
Qagj4220rcc0tg1nfjcog = "",
pmrn51cazgvuryoq2vjz0 = "",
ilzvmi9a3zbtb0ses2ncz = "",
w2bkqsj52lutamx5w6bx1 = "",
Vch9fcs0gj79hh98kpe39 = "",
yehrerszcwsw1zkxubfn9 = "",
kszsoul3myvh1hyx4z5xt = "",
H3yt1lir6mnij03roydtf = "",
aznobl4ubw35gr4g3g1dm = "",
V469km7anhifwls3qjrpq = "",
ixqktsc16xxi6agl3ndzn = "",
l3g4oxi49a0uymwznwq1j = "",
Xfe0uaiwegacf2bwrw55j = "",
kh157ctunr7h6lpizqjno = "",
Xw03axo6kah10urboi2rq = "",
Qyjwi2f4m37amrrxr85jy = "",
Jwjmjgrm4o3qx270neuhs = "",
huurchoid4upmt23o6mcl = "",
p3979qmuu0jnny1ec2kc1 = "",
Nii94nde9emr1s5yuwrw4 = "",
p4ymvgcy2y1wvkkduadvm = "",
xiuqo1v42cupkxh7u6oxl = "",
dpllmz5ri2ets6jwkh73v = "",
xh60dll8cnsywqk76idy6 = "",
rew98a6oovwm8ubdsvhbo = "",
H7o4kp7bwmzcej6qv61do = "",
o7tr0f0bpgolack801zsd = "",
i52c5uizyvsv3ewrn6dey = "",
R5wp7nbc8704hi9tervg7 = "",
Vbn3y2r5p2v3xv3iimess = "",
Og004yovfcm6k7gxs21e6 = "",
hgwgm6gvo1l2mdx1lx8ao = "",
q60nqytzpg0pvavmtun8r = "",
d2go1ttgkom430zapjzyn = "",
Rqgia6hmskh1jasvzlw6f = "",
Hmpa45v4kv6k4zvbw7n5m = "",
jgy9gvu3iekew2saafofk = "",
wnc6n76upr9180t8xq3jk = "",
T2wgl2xbguaqthu9e2vjy = "",
Vao0esf5iunumf5s16vvj = "",
x4o4rti0gu354tukn5b3w = "",
V12whqdombiigaa3vtjvj = "",
Xpzy0rz2uuf5428rc1xbp = "",
a3nelvy4s0y3wqthce6z0 = "",
Nl326moobt146hfqbumf3 = "",
R4j36ljoi1p857keavh9h = "",
Zj29946okdfr1165b96vd = "",
G9gke3997bppnn7tbk4bo = "",
g4dfv7gdbodazw5hds5g5 = "",
T7rjx0dn3m41f4hi6azgw = "",
M57s7p01s0qtoygqn3s53 = "",
x2kzul45owkc3zt9a8lha = "",
Wm5c5kmqx04cs3m3ui8wu = "",
h4m5qo0yegqpsk5r7i3k8 = "",
Xnhy1hu9nzp1azxfaavrt = "",
Txmqkpui856moxxgwydi4 = "",
L1lp1yo2xzr6wl0kb1nmw = "",
klar2dmmcqsl6nx2m7ywa = "",
E2uioazd7me5k1vs04wyl = "",
Nczhhfajy78ec1l411d2n = "",
Jjo0lxbe1fbrkak8cnbj9 = "",
Bqpana2tq10803kbx95ud = "",
p5ss5r3cqn1n04374onl4 = "",
Esy9oc1r0jkdrrfe76e6g = "",
H0cdami5anhjvuzvhtd2z = "",
Bllhcx5jzy98jreepu8b4 = "",
u5rmcbs71t7o2lg4o4anr = "",
t9glni9epvgwub8348fbf = "",
S8rf1uf7kkzuuvu4zg93b = "",
Pnsgnk40nmapz9issat2d = "",
hb3f5vc8qdey9m91qk2r0 = "",
Mou7kk5uncmzxhzauml2i = "",
O6kkimqnaqciiccyr55u0 = "",
Truo1ob2w9gd8ai3ekz84 = "",
Qru69eruebtyr0b1m5t3k = "",
Tx1bk8jh3iuhg70i7xpx7 = "",
Zqxvpswh8rrj05xg0twa4 = "",
Dj15qmrta33yq554afv1m = "",
jcjm1lqlkusnao2yz1edb = "",
achfx23592gu75y19oef6 = "",
ifjpkpybchfibr0j4dy9s = "",
ivmro7qf0bykx9h5314hd = "",
C122w7tpfo65zexk31bn9 = "",
ytlbs5ubk5qdjr502u4qn = "",
Ja9le2usm6bb0rhuq0j1m = "",
Qrfk83wij7rj6v99t970k = "",
Kczn3on2jljckdd64zmkg = "",
Jmjoo1ffribr2trk11quq = "",
G488xp93rdf3wxu82k9ci = "",
yikbk2j1w3edj23lnl192 = "",
wmxoch4f9trr2olit6y4f = "",
yhhy9bu33iurtak6u68c7 = "",
se2dlxl5rv1qx63ue9pbw = "",
Gal08a71doyx8v6apemm0 = "",
Mzmiqd4wgz2ur7q72bekz = "",
vt1d6dsb92eawck6ydk5g = "",
flvowdgae9in9cwh8jlmu = "",
T2xnu17oxtjz1ieo8nq27 = "",
Ss6au0auqd8o17koxh34f = "",
M2nv0sw18ijv2tpb5x230 = "",
Wn7uv4747z00tvwefljbe = "",
fjvh3nwirisao9e243a6u = "",
n23issbg6k6tn1zq100hi = "",
Qzmzhzlur4kmlnqmqnzkm = "",
lplhm9xxjxaec2x5peb2h = "",
Aqzbauiakn9oap53nfmib = "",
jxk34fjszv6mm6d5zjg10 = "",
Cxn6xwdx64rk130tf5h4l = "",
Rzkyrxceladd8vrokoghc = "",
Dww4evvsfuz4cmqbmypau = "",
t9l61nmfmmj1za2ycpu5b = "",
It81kjbwfpcv8fxclzd1j = "",
Apg3l7ecu186eu8bbtvrl = "",
dza6jx3tmznnm3wvmeqme = "",
e9corfqogwb1dvptpkuxe = "",
buz4nvul7my6cjnlxwpdh = "",
zom0xvj0ncgbu3itkha5v = "",
rfq47ez4id535qqzi9h1m = "",
v374gxmja3bqvtsb8s2s6 = "",
qoskhngdnslkajt1ivxk2 = "",
qq3ocohm8o1zgy47lxx2q = "",
li5ss0qm903m4r0qudi2f = "",
n3f81vdlowqu843tul5l8 = "",
T5mivp4z7onhp4xwd616x = "",
Te7njioayg6ii64kr7nl1 = "",
ioo9jjfdhgqxu9x3798ma = "",
T4a0se9samfgtpei07ead = "",
Hk2r0iyiiamr8bl7oxrfj = "",
Hxd4bkef4pd957i0btajp = "",
U0j99yhreh4cq80qh7qqe = "",
nso37nva2u54xiztne4mc = "",
Gwbwvbt6g2sddte6lpbwc = "",
kgytl9ohjhcdddorr1h64 = "",
Xz3ab21ed2h7cik58rkvw = "",
Elw90pa9fxptif1mmyrti = "",
Dker9ea42st9qwktc4jw1 = "",
u18qmxz7q7sja1nlgf9wo = "",
lfhwdpdv4iksp41qlyemo = "",
Mdo49k9zj8m74xivumm7u = "",
Iechxa4f969raxhk1mw3q = "",
hnm66mx1wg69mh1kbgh9p = "",
I30m847hp73iztqg1glkm = "",
rcs39af267jvfwnxxa7bp = "",
Cqmzmyj30ut446xnk6m8z = "",
Eekrxidcf3t1jk5603ql0 = "",
ombloo0j9am0x9mlf4bev = "",
yhx7b1vua0wrqbhmc9dir = "",
O3cfr2dj7t051l0tyekw3 = "";
            #endregion
        }
        #endregion

        #region mc num
        #region ofs
        //string getName(string name)
        //{
        //    foreach (MemberInfo p in typeof(mc_list).GetMembers())
        //    {
        //        string propertyName = p.Name;

        //        MessageBox.Show(propertyName);
        //    }
        //}
        private class mcOfs
        {
            public static int count = 0;
            public static int
            Lhpvb05sk0dopf5u4qakf = count++,
            Wqmmsn21ib54wnbqodtt9 = count++,
            efl4z4r3hqvin0z55ddx7 = count++,
            Bdki4i2cepg06qkaeswx5 = count++,
            m9u1qxr6xguka5w54d9qc = count++,
            toy2j4l6py0nrp28ts1h1 = count++,
            a6p845zb4pfbsfurk2swl = count++,
            Ovq8ph3udxmml1zg907ne = count++,
            lkbaty4m5ky0af6gpqswc = count++,
            Ee7hc300pnrt4eratqp1m = count++,
            Urz29vmf5s1shkl9n3707 = count++,
            Wd6s3e56y5w9b0kupfiqq = count++,
            Iu57v8mt2rxzsy3ivh940 = count++,
            tqr952rqa1uivrjni8642 = count++,
            eldhi6qm7b9ifn0ad5b3r = count++,
            r5tb6oeapq9wlecomj08l = count++,
            Xet81mch1ikm7cn72ck32 = count++,
            Bq7qbm7blmy3fcsmlvjum = count++,
            P6jggxzi0ewj96g5gd6po = count++,
            Ia5purh5uawh30r5g1kox = count++,
            Xykgzo4i5xfhy4flb4wzp = count++,
            R3y0soqjplyp2r10zyzfw = count++,
            R9964os9uf4mfv939uyl8 = count++,
            au2u80ogcpwmfqcq415d6 = count++,
            Trykqmkhs80faohcho8e9 = count++,
            pl6etshyst8hzuoq5rewq = count++,
            ogydyql0iaip30euuu18e = count++,
            Lvy99spq91gzkly2x3pcg = count++,
            Cqpskto9q35lzfs5syegb = count++,
            t51r4sfsbl71ez1yfgzqe = count++,
            rq9f549f33k9yjalz8y1n = count++,
            g67e6dhan3zm8xbv5vw9t = count++,
            Sayia8c4zq9hr7cis5i1w = count++,
            B919d8aaiopdlyinhye8a = count++,
            Xml74s4bv3cam4mtjzec7 = count++,
            Ucwka552zza30k0kx3evd = count++,
            F9polp0qlyestba80b79w = count++,
            cbl63ijcec5put88wh8uf = count++,
            cpqaurkzj1tw6f8bxtvcf = count++,
            zxmj2z8adclscm3hvkll8 = count++,
            Hu3msjsov6kdw5psdhi5t = count++,
            Qjvhpbtum0qnhjev490tg = count++,
            rtog1i5h7lencq2y8v6rz = count++,
            l8c4p76n13xdryza5pqhf = count++,
            smxawdk1rpxici4hqu03m = count++,
            Zsqdxa5o013tfylnlbimw = count++,
            qe5mgpbi3rtkyw5x5tnvh = count++,
            K6azvecn6r6omoghwe7h9 = count++,
            Xwuiht4s3yr1ywezdg0cm = count++,
            exlmve8kqyb1wfwvm2rbj = count++,
            Mtuiae00kqepn54lkixdv = count++,
            Sucfw0fs9tnlyy23dcmrn = count++,
            li99tvn0kkkdeoqzqpwk8 = count++,
            ki01d21ycbih6fznudvbm = count++,
            sphzijgkhdmyqbtfri614 = count++,
            tyxjcch9zden3u7tbas3w = count++,
            Erq9zt14wt5lh4hx18wgc = count++,
            Ehue8945e9eq0cemhyusl = count++,
            immfi2f9nk1col0p6ma0z = count++,
            x50wpovez4pcne5z4p5f3 = count++,
            F4s3hbcomzq4x43qwz04h = count++,
            Obkt4zzjqburr564m6onl = count++,
            Lh29nuptlpdfza82u88sm = count++,
            s37lf9n278dzkmt9ikfkk = count++,
            Mf8b8p2q7ejo76bsjr4oh = count++,
            owwmmn4mr8tk3yih45m0h = count++,
            D653yy2ola01q0cxsvzvu = count++,
            Gp98u9vix4xneehk13xxu = count++,
            Vpbqi23cvvyjg1f176izd = count++,
            Jt1rnmwms25z7cafns01f = count++,
            msxcfohm8qn4u8tbyud6g = count++,
            vrt3z8ld1anpgrtu6zl8e = count++,
            Yjncpaf9s9r3o4vx93mhd = count++,
            Pev8c7yco8f9jf16dqoy2 = count++,
            Alu2sual55vcme5ayparm = count++,
            Hcuu4stjcytsoyo1t2pr6 = count++,
            amhsmcwfk1hyq7m01a8aa = count++,
            g1jhldyxzdr59tu95ch15 = count++,
            ho9lq5crlyas4oqfd9gjn = count++,
            u8pgkmz6mn4z3gfw280qa = count++,
            ygmbd8bvcp5557o692aeg = count++,
            dfe84lzxi4mfjzjhwodlk = count++,
            oe37r8352jxa7vk4bng2j = count++,
            Ynmic0wfxgjuyz4blhr5r = count++,
            h359hmiypofjhlc61v50m = count++,
            Yyivacli1is45llpsnbzs = count++,
            u70ib9mnw7k0m0t2vj9ea = count++,
            i97g5lo6awootfio89uaz = count++,
            I8v382se2s4in6zsaunzv = count++,
            dqn9t5ggse4vz9pcndhd2 = count++,
            Pjer2fawq0now4ojuwkdv = count++,
            Blwxxitorwe7mj6ml5ho4 = count++,
            tt020q94ufr13errxr4tv = count++,
            fvf3vqbm7c7zo6ibu36hi = count++,
            tz4memeh1py4by2io6gko = count++,
            sx6si2n76p73uwk613zim = count++,
            E4usndy0d9xxxv2v3mem9 = count++,
            zhlmr5jon6rvh88ucneed = count++,
            Yw362jg84zcpznifsibr3 = count++,
            Ekmhsbqyxhsph9innotiz = count++,
            Vlty3b63z3b4mxl2kwo03 = count++,
            krlwgxize51ey32s0ynqf = count++,
            ow84fxduxqc1a3oh97rg3 = count++,
            Ngz4b7gt43bvi7vhtrqtt = count++,
            sycx2ae5ous3hhx86e2ir = count++,
            Ruz3ortcigysq7wfdbbb3 = count++,
            uleklhoakwkoyic99ijlr = count++,
            Wcxh69njus44c0pgppsgc = count++,
            ks2v6j4h5xg520u0x7nm4 = count++,
            lfq11pm735ut0ci8kblwf = count++,
            Tgn7m9cmgyssbgm7ba4q7 = count++,
            Y6oadwezrvqwv0hx2tp1n = count++,
            Wa1fnbsuzl6jg5zi1n305 = count++,
            om4uh66k8yfsudd7fjwbd = count++,
            yuagyhp0b85pzz6afg7rf = count++,
            bhvagnzd12ds02wkmx6aq = count++,
            afja2z35gc19lf5699akr = count++,
            nl8j5nz6dvxsj7a98uiqu = count++,
            L47zadhu6zlnwvsfhaepa = count++,
            n71upjznf67o0u0xoji1f = count++,
            kgh39gjsngjfgh396723j = count++,
            ghflk3296jsdnmhgh2967 = count++,
            msgd98575idgjdg39vhg3 = count++,
            khr984hfjsg94ytfksgsh = count++;
        }
        #endregion
        #region num
        public static List<uint> ins1 = new List<uint>();
        public static List<double> ins2 = new List<double>();
        public static List<uint> ins3 = new List<uint>();
        public static List<uint> ins4 = new List<uint>();

        private class mcNum
        {
            public static int count = 0;
            public static int
            num1_1 = count++,
            num1_2 = count++,
            num1_3 = count++,
            num2_1 = count++,
            num2_2 = count++,
            num2_3 = count++,
            num3_1 = count++,
            num3_2 = count++,
            num3_3 = count++,
            num4_1 = count++,
            num4_2 = count++,
            num4_3 = count++,
            num5_1 = count++,
            num5_2 = count++,
            num5_3 = count++,
            num6_1 = count++,
            num6_2 = count++,
            num6_3 = count++,
            num7_1 = count++,
            num7_2 = count++,
            num7_3 = count++,
            num8_1 = count++,
            num8_2 = count++,
            num8_3 = count++,
            num10_1 = count++,
            num10_2 = count++,
            num11_1 = count++,
            num11_2 = count++,
            num12_1 = count++,
            num12_2 = count++,
            num13_1 = count++,
            num13_2 = count++,
            num14_1 = count++,
            num14_2 = count++,
            num15_1 = count++,
            num15_2 = count++,
            num16_1 = count++,
            num16_2 = count++,
            num17_1 = count++,
            num17_2 = count;
        }
        public static double getNum(int num)
        {
            return ins2[num];
        }
        #endregion
        #endregion

        #region setup toolstrip
        private void setupTS()
        {
            timer1.Stop();
            timer1.Start();
            countSM = 0;
            // oooooooooooooo();

            menuOptTxt.Clear();
            menuOptState.Clear();
            sycx2ae5ous3hhx86e2ir.Clear();
            menuOptStartIndex.Clear();
            optsMax.Clear();
            string[] main1 = { MF_SubMenu + "Non-host", MF_SubMenu + "Host Required" };
            string[] _main1 = { MF_SubMenu + "Non-host", MF_SubMenu + "Host Required", MF_SubMenu + "SPRX Options" };
            addMenuOpt(0, 0, 0, _main1);

            string[] main1_sub1 = { MF_SubMenu + "Combat", MF_SubMenu + "Explore", MF_SubMenu + "Action", MF_SubMenu + "Entities", MF_SubMenu + "Weather", MF_SubMenu + "Visuals", MF_SubMenu + "Camera", MF_SubMenu + "HUD", MF_SubMenu + "Blocks", MF_SubMenu + "Game Settings", MF_SubMenu + "Name Changer" };
            string[] main1_sub2 = { MF_SubMenu + "Combat", MF_SubMenu + "Items", MF_SubMenu + "Enities", MF_SubMenu + "Enchantement", MF_SubMenu + "Explosion", MF_SubMenu + "Weather", MF_SubMenu + "Water", MF_SubMenu + "Game Settings", };
            string[] main1_sub3 = { MF_SubMenu + "Combat", MF_SubMenu + "Explore", MF_SubMenu + "Move Menu", };
            addMenuOpt(1, 0, 0, main1_sub1);
            addMenuOpt(2, 0, 0, main1_sub2);
            addMenuOpt(3, 0, 0, main1_sub3);
            #region combat
            string[] main1_sub1_opt1_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Damage" };
            string[] main1_sub1_opt1_lvl2 = { MF_ComboBox + mc_list.L8qpzfsyo8nxckr0jdsgm, MF_ComboBox + mc_list.Rml7vyoyi0l4kbc3k0u03, MF_ComboBox + mc_list.Jgchppl41vkxknzgkmx4j, MF_Trackbar + ult_list.Dker9ea42st9qwktc4jw1, MF_Trackbar + ult_list.e9corfqogwb1dvptpkuxe };
            string[] main1_sub1_opt1_lvl3 = { MF_CheckBox + ult_list.h51vdr109gfhskk85a80q, MF_CheckBox + ult_list.Rwu26wn5ox1x9ll0vhgr6, MF_CheckBox + ult_list.vcoaf92rvw6f49flfw9pc, MF_CheckBox + ult_list.rst8rwuzl2my7c0qiqz0y, MF_CheckBox + ult_list.uo3fiyjd7b2js2wbb0idh, MF_CheckBox + ult_list.ek28z8t5w7jmqbhz45a5a, MF_CheckBox + ult_list.Actlf91b8i6hmhvbf5j8n, MF_CheckBox + ult_list.qzwgxwau2etzbdt0jkrjc, MF_CheckBox + ult_list.Nl326moobt146hfqbumf3, MF_CheckBox + ult_list.mjajzwfyu9swf68bg3nij, MF_CheckBox + ult_list.Utn2h68l6o524gumyg4hm, MF_CheckBox + ult_list.ada6tx04ialpsenmz17do, MF_CheckBox + ult_list.Je3k7vte3w3lo5w5z3pu7, MF_CheckBox + ult_list.M58ctonb0ebdeh0v7yd1h, MF_CheckBox + ult_list.T7rjx0dn3m41f4hi6azgw, MF_CheckBox + ult_list.dpllmz5ri2ets6jwkh73v, MF_CheckBox + ult_list.hb3f5vc8qdey9m91qk2r0, MF_CheckBox + ult_list.ytvadwy55v5qnd53jqb2u };
            addMenuOpt(1, 1, 1, main1_sub1_opt1_lvl1);
            addMenuOpt(1, 1, 2, main1_sub1_opt1_lvl2, new byte[] { 5, 5, 5, 4, 3 });
            addMenuOpt(1, 1, 3, main1_sub1_opt1_lvl3);
            int count_1122 = 0;
            string[][] main1_sub1_opt1_lvl2_Combo = new string[100][];
            main1_sub1_opt1_lvl2_Combo[count_1122++] = new string[] { "Default", "None", "Short", "Medium", "Far" }; optsMax.Add(mc_list.L8qpzfsyo8nxckr0jdsgm + ";5");
            main1_sub1_opt1_lvl2_Combo[count_1122++] = new string[] { "Default", "None", "Short", "Medium", "Far" }; optsMax.Add(mc_list.Rml7vyoyi0l4kbc3k0u03 + ";5");
            main1_sub1_opt1_lvl2_Combo[count_1122++] = new string[] { "Default", "None", "Slow", "Medium", "Fast" }; optsMax.Add(mc_list.Jgchppl41vkxknzgkmx4j + ";5");
            main1_sub1_opt1_lvl2_Combo[count_1122++] = new string[] { "4" }; optsMax.Add(ult_list.Dker9ea42st9qwktc4jw1 + ";4");
            main1_sub1_opt1_lvl2_Combo[count_1122++] = new string[] { "3" }; optsMax.Add(ult_list.e9corfqogwb1dvptpkuxe + ";3");
            #endregion

            #region explore
            string[] main1_sub1_opt2_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Fly", MF_SubMenu + "World View", MF_SubMenu + "ESP", MF_SubMenu + "Walking", MF_SubMenu + "Movement" };
            string[] main1_sub1_opt2_lvl2 = { MF_Trackbar + mc_list.Rxq2ixva686g4qr0b39cv, MF_Trackbar + mc_list.Jnsrptn8ej3gsozrp3uel, MF_Trackbar + mc_list.Dwlrqpun3wawvikzden3c, MF_Trackbar + mc_list.Qrqpe6qsowxnrirecfq3k, MF_Trackbar + mc_list.qoceosf5pg05s0n4sz76y, MF_Trackbar + mc_list.rq16naxsdw1fkwqmolbv0, MF_Trackbar + mc_list.ovdi62415wwmitf4wg1o5, MF_Trackbar + mc_list.kx12ouv6japhylgcmt9vf };
            string[] main1_sub1_opt2_lvl3 = { MF_CheckBox + ult_list.J32axm662236lv0jxcy72, MF_CheckBox + mc_list.J3bcciwcy6dr1ukvzd6dz, MF_CheckBox + mc_list.j9bve5kctaegbhr3cskvc, MF_CheckBox + mc_list.pc7k9x20eoixz10h2q8h8, MF_CheckBox + ult_list.ru8f2rqjqkbwtcwsujsch, MF_CheckBox + mc_list.Jixx5b4o0efb4seovn6kq, MF_CheckBox + ult_list.tqqs14fnbdltmjudcnwdx, MF_CheckBox + ult_list.A97ud0c62ich8mxyxvufb, MF_CheckBox + ult_list.yehrerszcwsw1zkxubfn9, MF_CheckBox + ult_list.bitn472xqu2t2tpehuk2y, MF_CheckBox + ult_list.y87vh6eycgf7y6yibup1s, MF_CheckBox + ult_list.J32axm662236lv0jxcy72, MF_CheckBox + ult_list.Ktk5f6eev4i4zsu16tpra, MF_CheckBox + ult_list.Xw03axo6kah10urboi2rq };
            string[] main1_sub1_opt2_lvl4 = { MF_CheckBox + mc_list.Bmooee4oud8jusrxoxiiy, MF_CheckBox + mc_list.Bip03m2hrugd3b6lb0dkl, MF_CheckBox + ult_list.J1ppcttrobz5wzbgwevcc, MF_CheckBox + ult_list.c6nitgkajk2pal61b1ean, MF_CheckBox + ult_list.Zc4h2b7yn8hd7v8m7bk62, MF_CheckBox + ult_list.pmrn51cazgvuryoq2vjz0, MF_CheckBox + ult_list.g8d80hbd0kg1tvz2txv2f, MF_CheckBox + ult_list.jxlb0mx9sf690z8tmh486, MF_CheckBox + ult_list.Xu146ob9mzi1zrx1fps70, MF_CheckBox + ult_list.ddopuabme7ota73osnaxw, MF_CheckBox + ult_list.Rxq2ixva686g4qr0b39cv, MF_CheckBox + mc_list.mjx38zu48czwjj3dybtyk, MF_CheckBox + ult_list.V469km7anhifwls3qjrpq, MF_CheckBox + ult_list.icki88qr78yc8o0o4awyr, MF_CheckBox + mc_list.h8nezvhdn2kb45warp0rc };
            string[] main1_sub1_opt2_lvl5 = { MF_CheckBox + ult_list.lzitme8atvv4bco7gmg3v, MF_CheckBox + ult_list.pz4puyht2508ikn7ro8nq, MF_CheckBox + ult_list.yq5q5kfzpc4kvh7pdjzi3, MF_CheckBox + ult_list.snjljsn0pqnu2komd8cvb, MF_CheckBox + ult_list.tsai69j7p7cxh9nfmxbhn, MF_CheckBox + ult_list.outz5qol4q35tzkdz5ef5 };
            string[] main1_sub1_opt2_lvl6 = { MF_CheckBox + ult_list.w2bkqsj52lutamx5w6bx1, MF_CheckBox + ult_list.uchnttm8s38wqax6qk2va, MF_CheckBox + ult_list.P8nkcgbwvr1mddddq99la, MF_CheckBox + ult_list.Qqu9vj045n6wrddd3nda8, MF_CheckBox + ult_list.D3j5nc4342dsz0kdb7mli, MF_CheckBox + ult_list.olfxabir5hd3dwafsg0dq, MF_CheckBox + ult_list.zja7pfpr6fykqx36rl3za, MF_CheckBox + ult_list.yh99alqt18pzvogfbqgsl, MF_CheckBox + ult_list.bgf1hkul14zx7txeebsjz, MF_CheckBox + ult_list.Q9wrbu57zm4ffv61hp487, MF_CheckBox + ult_list.vm7ysb0lu7jh9i6ikgiz7 };
            string[] main1_sub1_opt2_lvl7 = { MF_CheckBox + mc_list.Isuzm871ne7qs6mwykwag, MF_CheckBox + ult_list.Asd7gqjima00d8sovyaeh, MF_CheckBox + ult_list.bblv8jxhqyfyexfsw92s1, MF_CheckBox + ult_list.ufffmnz9046kai9tglihj, MF_CheckBox + ult_list.Ngd2o6x0ytc2hti46kj0w, MF_CheckBox + ult_list.kszsoul3myvh1hyx4z5xt, MF_CheckBox + mc_list.Cw197o6ct9cpz70cgrzg6 };

            int count_1112 = 0;
            string[][] main1_sub1_opt2_lvl2_Combo = new string[100][];
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "16" }; optsMax.Add(mc_list.Rxq2ixva686g4qr0b39cv + ";16");
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "7" }; optsMax.Add(mc_list.Jnsrptn8ej3gsozrp3uel + ";7");
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "6" }; optsMax.Add(mc_list.Dwlrqpun3wawvikzden3c + ";6");

            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "5" }; optsMax.Add(mc_list.Qrqpe6qsowxnrirecfq3k + ";5");
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "5" }; optsMax.Add(mc_list.qoceosf5pg05s0n4sz76y + ";5");
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "6" }; optsMax.Add(mc_list.rq16naxsdw1fkwqmolbv0 + ";6");
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "6" }; optsMax.Add(mc_list.ovdi62415wwmitf4wg1o5 + ";6");
            main1_sub1_opt2_lvl2_Combo[count_1112++] = new string[] { "6" }; optsMax.Add(mc_list.kx12ouv6japhylgcmt9vf + ";6");
            addMenuOpt(1, 2, 1, main1_sub1_opt2_lvl1);
            addMenuOpt(1, 2, 2, main1_sub1_opt2_lvl2, new byte[] { 16, 7, 6, 5, 5, 6, 6, 6 });
            addMenuOpt(1, 2, 3, main1_sub1_opt2_lvl3);
            addMenuOpt(1, 2, 4, main1_sub1_opt2_lvl4);
            addMenuOpt(1, 2, 5, main1_sub1_opt2_lvl5);
            addMenuOpt(1, 2, 6, main1_sub1_opt2_lvl6);
            addMenuOpt(1, 2, 7, main1_sub1_opt2_lvl7);

            #endregion

            #region menu
            string[] _main1_sub3_opt1_lvl1 = { MF_Trackbar + "Aimbot Command", MF_Trackbar + "Entity Filter", MF_Trackbar + "Entity Radius", MF_Trackbar + "Aim Key", MF_Trackbar + "Aim Reset Key", MF_Trackbar + "Aim Position", MF_CheckBox + "Auto Hit Proximity", MF_CheckBox + "Target Info", MF_CheckBox + "Target Locator" };
            string[] _main1_sub3_opt2_lvl1 = { MF_CheckBox + "Radar", MF_Trackbar + "Compass Pointer", MF_Trackbar + "Entity Filter", MF_Trackbar + "Entity Radius", MF_CheckBox + "Depth Indicator", MF_Trackbar + "Compass Radius", MF_CheckBox + "Self Info" };
            string[] _main1_sub3_opt3_lvl1 = { MF_none + "Up", MF_none + "Down", MF_none + "Left", MF_none + "Right" };

            addMenuOpt(3, 1, 1, _main1_sub3_opt1_lvl1);
            addMenuOpt(3, 2, 1, _main1_sub3_opt2_lvl1);
            addMenuOpt(3, 3, 1, _main1_sub3_opt3_lvl1);

            #endregion

            #region action
            string[] main1_sub1_opt3_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Mine", MF_SubMenu + "Build", MF_SubMenu + "Auto", MF_SubMenu + "Arms", MF_SubMenu + "Swim", MF_SubMenu + "Movement", MF_SubMenu + "Moving", MF_SubMenu + "Jumping" };
            string[] main1_sub1_opt3_lvl2 = { MF_Trackbar + mc_list.Jmrvp6kf2d3nat0lp5wbp, MF_ComboBox + mc_list.Z8fb3e8gtbne1u04l0p10 };
            string[] main1_sub1_opt3_lvl3 = { MF_CheckBox + ult_list.Xdtgl2074p8j9lrlkcarz, MF_CheckBox + ult_list.Colnlmh4tfcil06fx5xp3, MF_CheckBox + ult_list.V12whqdombiigaa3vtjvj };
            string[] main1_sub1_opt3_lvl4 = { MF_CheckBox + ult_list.d69hlz4ka91htcwol6acd, MF_CheckBox + ult_list.Xnhy1hu9nzp1azxfaavrt, MF_CheckBox + ult_list.Ea7nsnzp5m5cvou9k1dre, MF_CheckBox + ult_list.ti6zx014rvp4yxo642m97, };
            string[] main1_sub1_opt3_lvl5 = { MF_CheckBox + ult_list.Mvc56j74smels4st7hbvq, MF_CheckBox + ult_list.In85990ua3rsbak74gsx5, MF_CheckBox + ult_list.Jdwftc7csbyfzcj8hfobi, MF_CheckBox + ult_list.Wm5c5kmqx04cs3m3ui8wu, MF_CheckBox + ult_list.zv1qw4q97hzablmsmmj3f, MF_CheckBox + mc_list.odzgcm4ljkrldfxow2wpf };
            string[] main1_sub1_opt3_lvl6 = { MF_CheckBox + ult_list.d5942odinauwllghr5w53, MF_CheckBox + ult_list.Mfds12ptckelctczqee0y, MF_CheckBox + ult_list.R525cb1wwne9j4xpapd1a, MF_CheckBox + ult_list.si848siv0ed1hu0vunr66, MF_CheckBox + ult_list.cumfz180bhx4o3hpwbcy7, };
            string[] main1_sub1_opt3_lvl7 = { MF_CheckBox + ult_list.xwcc1xon2fqy3t3yeckio, MF_CheckBox + ult_list.Xh5wx1ww6h4fqtldp8mxw, MF_CheckBox + ult_list.Vanc8cyxnbjfuze5bnqwg, MF_CheckBox + ult_list.vxdkyyu67cd4i7r989syf, };

            string[] main1_sub1_opt3_lvl8 = { MF_CheckBox + ult_list.l06lz6b0gzkhu7bn7yqji, MF_CheckBox + ult_list.F8fpicku0qt39bvqdkkak, MF_CheckBox + ult_list.Pdcor8ruqpq3yx3m7ev16, MF_CheckBox + ult_list.gz8j8zgth6zjio6ix2dsk, MF_CheckBox + ult_list.jcjm1lqlkusnao2yz1edb, MF_CheckBox + ult_list.Dj15qmrta33yq554afv1m, MF_CheckBox + ult_list.ifjpkpybchfibr0j4dy9s, };
            string[] main1_sub1_opt3_lvl9 = { MF_CheckBox + ult_list.fef3q9it3ai0d5wjpj1kv, MF_CheckBox + ult_list.vheof2tqursl2y39eo85q, MF_CheckBox + ult_list.t9glni9epvgwub8348fbf, MF_CheckBox + ult_list.qjiiq01r828goy7n8siub, MF_CheckBox + ult_list.Yv80v94m2hcsg3gc2s3gi, MF_CheckBox + ult_list.x8gdkg48i0myim7rzxnv4, MF_CheckBox + ult_list.L855nevgovskd83oyzwj4, MF_CheckBox + ult_list.Oefupdm3ewc0plkhgmko4, MF_CheckBox + ult_list.t469etdtvvkdig4n4cz15, };
            string[] main1_sub1_opt3_lvl10 = { MF_CheckBox + ult_list.swiye4ke561xtuvgeilil, MF_CheckBox + ult_list.C122w7tpfo65zexk31bn9, MF_CheckBox + ult_list.bj77roq77awkoo712fmzc, MF_CheckBox + ult_list.I3esnirf8fdaw7nx7zf6k, MF_CheckBox + ult_list.Xpzy0rz2uuf5428rc1xbp, MF_CheckBox + ult_list.C6ugalgj7ilyxj7urpxdv, MF_CheckBox + ult_list.f92lba218d7fglojnt6ct, MF_CheckBox + ult_list.yajqw6g6zqdwrcyiybuy7, };

            addMenuOpt(1, 3, 1, main1_sub1_opt3_lvl1);
            addMenuOpt(1, 3, 2, main1_sub1_opt3_lvl2, new byte[] { 11, 4 });
            addMenuOpt(1, 3, 3, main1_sub1_opt3_lvl3);
            addMenuOpt(1, 3, 4, main1_sub1_opt3_lvl4);
            addMenuOpt(1, 3, 5, main1_sub1_opt3_lvl5);
            addMenuOpt(1, 3, 6, main1_sub1_opt3_lvl6);
            addMenuOpt(1, 3, 7, main1_sub1_opt3_lvl7);
            addMenuOpt(1, 3, 8, main1_sub1_opt3_lvl8);
            addMenuOpt(1, 3, 9, main1_sub1_opt3_lvl9);
            addMenuOpt(1, 3, 10, main1_sub1_opt3_lvl10);

            int count_1132 = 0;
            string[][] main1_sub1_opt3_lvl1_Combo = new string[100][];
            main1_sub1_opt3_lvl1_Combo[count_1132++] = new string[] { "11" }; optsMax.Add(mc_list.Jmrvp6kf2d3nat0lp5wbp + ";11");
            main1_sub1_opt3_lvl1_Combo[count_1132++] = new string[] { "Default", "2D", "Big", "Huge" }; optsMax.Add(mc_list.Z8fb3e8gtbne1u04l0p10 + ";4");

            #endregion

            #region Entites
            string[] main1_sub1_opt4_lvl1 = { MF_SubMenu + "All", MF_SubMenu + "Players", MF_SubMenu + "Mobs", MF_SubMenu + "Character", MF_SubMenu + "Anti", MF_SubMenu + "Skins", MF_SubMenu + "Misc." };
            string[] main1_sub1_opt4_lvl2 = { MF_CheckBox + mc_list.Ibis7tg8pktwx8rt1fcle, MF_CheckBox + mc_list.Mfu32preha4pp94hf78ry, MF_CheckBox + ult_list.Ktcgb8kbx1j3v36pwjiq6, MF_CheckBox + ult_list.G9gke3997bppnn7tbk4bo, MF_CheckBox + ult_list.Jxymux40uj0rei7yrnfz0, MF_CheckBox + ult_list.Nii94nde9emr1s5yuwrw4, MF_CheckBox + ult_list.H0cdami5anhjvuzvhtd2z, MF_CheckBox + mc_list.Mfu32preha4pp94hf78ry, MF_CheckBox + mc_list.Othezyqnvzigtflecqvot, MF_CheckBox + mc_list.Xgc9tokynfszeryppxki8, };
            string[] main1_sub1_opt4_lvl3 = { MF_CheckBox + mc_list.Yc1opegxdjn4gvxg2pdgh, MF_CheckBox + ult_list.F6rq1q5sgigq7zkc7teyb, MF_CheckBox + ult_list.V9h75j9wf62tl6e2sphtv, MF_CheckBox + ult_list.P1mfw8r6druq5jxkddsvw, MF_CheckBox + ult_list.vanu7itf14ljv2mpxvn5q, MF_CheckBox + ult_list.lxr4cvbfbw8ag0o51l4be, MF_CheckBox + ult_list.x4r1l65szypxdz1rb6xpj, MF_CheckBox + ult_list.Lzdzuccqe8ogsws0gado7, };
            string[] main1_sub1_opt4_lvl4 = { MF_CheckBox + ult_list.Gboef0cik4zf3m2oyjvtf, MF_CheckBox + ult_list.tq0q3h2bfsf6skuig0ce8, MF_CheckBox + ult_list.Vao0esf5iunumf5s16vvj, };
            string[] main1_sub1_opt4_lvl5 = { MF_CheckBox + ult_list.H52ojq261mx62f2ejujhs, MF_CheckBox + ult_list.h4m5qo0yegqpsk5r7i3k8, MF_CheckBox + ult_list.Og004yovfcm6k7gxs21e6, MF_CheckBox + ult_list.Zm61p3qz6nuh9qlf6us39, MF_CheckBox + ult_list.Usvh107at9n1qmaup2epe, MF_CheckBox + ult_list.Q7yssit5hgreusvpr9jkw, MF_CheckBox + ult_list.f17b9o0j8d44sxkhh2ksa, MF_CheckBox + ult_list.x4o4rti0gu354tukn5b3w, MF_CheckBox + ult_list.pd6etc7trlwpvgo7x92wr, MF_CheckBox + ult_list.xoyaqzobe7zg1pza1pc4t, MF_CheckBox + ult_list.ulw0z9i688ycz1mat3o19, MF_CheckBox + ult_list.Bllhcx5jzy98jreepu8b4, MF_CheckBox + ult_list.aznobl4ubw35gr4g3g1dm, MF_CheckBox + ult_list.H3yt1lir6mnij03roydtf, };
            string[] main1_sub1_opt4_lvl6 = { MF_CheckBox + ult_list.Nxn8vyo4te839ba4g8sx3, MF_CheckBox + ult_list.l96t9iipuux8u3fey4ghq, MF_CheckBox + ult_list.ig4kinugfjs1ip75tj9e0, MF_CheckBox + ult_list.Wfqo5w30ij94ajusx090c, MF_CheckBox + ult_list.v35th6ig28y29rbh7bg5m, };
            string[] main1_sub1_opt4_lvl7 = { MF_CheckBox + ult_list.Bqpana2tq10803kbx95ud, MF_CheckBox + ult_list.fy4opdd9hkqe1kmcqn3d8, MF_CheckBox + ult_list.chqlwjt5jkz4iprroqr23, MF_CheckBox + ult_list.Nuj82bt0uh8llg3dile1m, MF_CheckBox + ult_list.huurchoid4upmt23o6mcl, };
            string[] main1_sub1_opt4_lvl8 = { MF_CheckBox + ult_list.ylyh6589vjq0kp5ykfjyj, MF_CheckBox + ult_list.ucpp4f1sures7o05wcvqi, MF_CheckBox + ult_list.Zkhe14qr7yfqwj1zxpct8, MF_CheckBox + ult_list.Zwd96tupk60rfcwebupmh, MF_CheckBox + ult_list.Bzso4ck6w6k0dd9lvj4fz, MF_CheckBox + ult_list.Kxco4boeoscjl53nx531c, MF_CheckBox + ult_list.wnc6n76upr9180t8xq3jk, };
            addMenuOpt(1, 4, 1, main1_sub1_opt4_lvl1);
            addMenuOpt(1, 4, 2, main1_sub1_opt4_lvl2);
            addMenuOpt(1, 4, 3, main1_sub1_opt4_lvl3);
            addMenuOpt(1, 4, 4, main1_sub1_opt4_lvl4);
            addMenuOpt(1, 4, 5, main1_sub1_opt4_lvl5);
            addMenuOpt(1, 4, 6, main1_sub1_opt4_lvl6);
            addMenuOpt(1, 4, 7, main1_sub1_opt4_lvl7);
            addMenuOpt(1, 4, 8, main1_sub1_opt4_lvl8);

            #endregion

            #region weather
            string[] main1_sub1_opt5_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Misc.", };
            string[] main1_sub1_opt5_lvl2 = { MF_Trackbar + ult_list.T4a0se9samfgtpei07ead, MF_Trackbar + ult_list.U0j99yhreh4cq80qh7qqe, MF_Trackbar + ult_list.kgytl9ohjhcdddorr1h64, };
            string[] main1_sub1_opt5_lvl3 = { MF_CheckBox + ult_list.en87x83kkrflt3w79kdlk, MF_CheckBox + ult_list.a9zmclmjet5s2wni7fsd1, MF_CheckBox + ult_list.O8r771jberag9z9uexedj, MF_CheckBox + ult_list.hqaa2tk9nlg9xgeog0s8s, MF_CheckBox + ult_list.q53xwk4vicsrpotdgkm08, MF_CheckBox + ult_list.sxnq96tidswfuhceacjn1, MF_CheckBox + ult_list.reh9vk9knmcugx2axo0l9, MF_CheckBox + mc_list.Rtq4166twva06kxzrhuko, MF_CheckBox + mc_list.Zg7xbkud3rmyurbe5b9zw, MF_CheckBox + mc_list.v3c05vtt4x9k972xziko0, MF_CheckBox + ult_list.Ylysef5xk2r72o9j2bpzq, MF_CheckBox + ult_list.E38y0cu4yot67ouovqsse, MF_CheckBox + mc_list.Amaugjz9ed9ol0fqjbujk, MF_CheckBox + mc_list.yw9txgfg1tybq4opah0k1, };
            addMenuOpt(1, 5, 1, main1_sub1_opt5_lvl1);
            addMenuOpt(1, 5, 2, main1_sub1_opt5_lvl2, new byte[] { 9, 9, 10 });
            addMenuOpt(1, 5, 3, main1_sub1_opt5_lvl3);

            string[][] main1_sub1_opt5_lvl2_Combo = new string[100][];
            int count_1152 = 0;
            main1_sub1_opt5_lvl2_Combo[count_1152++] = new string[] { "9" }; optsMax.Add(ult_list.T4a0se9samfgtpei07ead + ";9");
            main1_sub1_opt5_lvl2_Combo[count_1152++] = new string[] { "9" }; optsMax.Add(ult_list.U0j99yhreh4cq80qh7qqe + ";9");
            main1_sub1_opt5_lvl2_Combo[count_1152++] = new string[] { "10" }; optsMax.Add(ult_list.kgytl9ohjhcdddorr1h64 + ";10");
            #endregion

            #region visuals
            string[] main1_sub1_opt6_lvl1 = { MF_SubMenu + "Editors", MF_CheckBox + ult_list.flxk5w69ju8uafekrj3og, MF_CheckBox + ult_list.wcnwmcqindlp0vinu7gz8, MF_CheckBox + ult_list.K6m29cojgzj6sfxh5qzhn, MF_CheckBox + ult_list.Il3aqc4hkbwn89uagnlxf, MF_CheckBox + ult_list.Wti8dhia3iduxgdvdfa7d, MF_CheckBox + ult_list.C4cyklk31zh8h1a5gyxkc, MF_CheckBox + ult_list.d10g2bk2m0qfyf3rytqa8, MF_CheckBox + ult_list.W1qiib7ozk3d2oryb1yes, MF_CheckBox + ult_list.f350e6zb8cxdw096loaq2, MF_CheckBox + ult_list.vs3ajzi5szc3hbomyi9pz, MF_CheckBox + ult_list.zubpzyhulu30r2fncu5vd, MF_CheckBox + ult_list.Yk1bjfxx4zmlaun1f50z2, };
            string[] main1_sub1_opt6_lvl2 = { MF_ComboBox + mc_list.Xhhj8juwg2w7pfacw8rel, MF_ComboBox + mc_list.ttanaldwh136ypyjl8m3c, MF_ComboBox + mc_list.Nt7wqxt6m6s7czr40xrk6, MF_Seperator + mc_list.b8r4hpy6ncrcggi99k29w, MF_ComboBox + mc_list.b8r4hpy6ncrcggi99k29w, MF_button + mc_list.b8r4hpy6ncrcggi99k29w, };
            addMenuOpt(1, 6, 1, main1_sub1_opt6_lvl1);
            addMenuOpt(1, 6, 2, main1_sub1_opt6_lvl2, new byte[] { 5, 5, 4, 3 });

            int count_1162 = 0;
            string[][] main1_sub1_opt6_lvl2_Combo = new string[100][];
            main1_sub1_opt6_lvl2_Combo[count_1162++] = new string[] { "Default", "Red", "Green", "Blue", "Dark" }; optsMax.Add(mc_list.Xhhj8juwg2w7pfacw8rel + ";5");
            main1_sub1_opt6_lvl2_Combo[count_1162++] = new string[] { "Default", "None", "Bright", "Dark", "Green" }; optsMax.Add(mc_list.ttanaldwh136ypyjl8m3c + ";5");
            main1_sub1_opt6_lvl2_Combo[count_1162++] = new string[] { "Default", "Rainbow", "Black", "None" }; optsMax.Add(mc_list.Nt7wqxt6m6s7czr40xrk6 + ";4");
            main1_sub1_opt6_lvl2_Combo[4] = new string[] { "Off", "Rainbow", "Flashing" }; optsMax.Add(mc_list.b8r4hpy6ncrcggi99k29w + ";3");
            #endregion

            #region camera
            string[] main1_sub1_opt7_lvl1 = { MF_SubMenu + "Editors", MF_CheckBox + mc_list.j1aqgtccr5zogmq90hixs, MF_CheckBox + ult_list.qtr9us57ubbnupfls4c4g, MF_CheckBox + ult_list.lc4pjomgjxyans7wiz9nv, MF_CheckBox + ult_list.Tlkpxgwuue2st3gyngyar, MF_CheckBox + ult_list.Lwkz5xzuu26dhgwd1qgap, MF_CheckBox + ult_list.Ydb2ymxmpo685dgw42u9n, MF_CheckBox + ult_list.Shd489aj1f3l0cwdcei2c, MF_CheckBox + ult_list.p7dcmykn27dhjvbafc8ro, MF_CheckBox + ult_list.ujaswxlbxo2ax0gle26tx, MF_CheckBox + ult_list.Xook0ug40ybebymqzwhvk, MF_CheckBox + ult_list.s9gmolm6eg65xu9l343d6, MF_CheckBox + ult_list.W47nzx9fzr1aqtlpaexj6 };
            string[] main1_sub1_opt7_lvl2 = { MF_Trackbar + mc_list.Dwkjtxwygaa30r1xnxbk7, MF_Trackbar + mc_list.Fsvmh7skwd3ph75r9sme5, MF_Trackbar + ult_list.nso37nva2u54xiztne4mc };
            addMenuOpt(1, 7, 1, main1_sub1_opt7_lvl1);
            addMenuOpt(1, 7, 2, main1_sub1_opt7_lvl2, new byte[] { 20, 7, 10 });

            int count_1172 = 0;
            string[][] main1_sub1_opt7_lvl1_Combo = new string[100][];
            main1_sub1_opt7_lvl1_Combo[count_1172++] = new string[] { "20" }; optsMax.Add(mc_list.Dwkjtxwygaa30r1xnxbk7 + ";20");
            main1_sub1_opt7_lvl1_Combo[count_1172++] = new string[] { "7" }; optsMax.Add(mc_list.Fsvmh7skwd3ph75r9sme5 + ";7");
            main1_sub1_opt7_lvl1_Combo[count_1172++] = new string[] { "10" }; optsMax.Add(ult_list.nso37nva2u54xiztne4mc + ";10");

            #endregion

            #region hud
            string[] main1_sub1_opt8_lvl1 = { MF_CheckBox + ult_list.Ct50xdjswqacf8014mflm, MF_CheckBox + ult_list.Ovqhaa01t0f0cl9rt4ll7, MF_CheckBox + ult_list.wmk82r4eivn87ifyerzt7, MF_CheckBox + ult_list.Mcidzyqg62nd61wdumoqk, MF_CheckBox + ult_list.Tlpzt0agvn3fep0jxs108, MF_CheckBox + ult_list.lpw7n9y8lits03m2otye7, MF_CheckBox + ult_list.J3kfv7s6ai8u3u6q12nf3, MF_CheckBox + ult_list.C7fr24w32co7thbuc5d4c, MF_CheckBox + mc_list.Lj9g8xhehfqlzirvvt3ni, MF_CheckBox + ult_list.ytlbs5ubk5qdjr502u4qn, MF_CheckBox + ult_list.aibcgkbgjs0ayzdk02cuc, MF_CheckBox + ult_list.Dyf50pew9oe1ihf3jnifj, MF_CheckBox + ult_list.hut3cqpq9ki961rj6i22b, MF_CheckBox + ult_list.zpkf5zrge2m3grf1ctvwl, MF_CheckBox + ult_list.g6cgvn5lc2j4xdasqy0m9, MF_CheckBox + ult_list.Te7njioayg6ii64kr7nl1, MF_CheckBox + ult_list.yhhy9bu33iurtak6u68c7, MF_CheckBox + ult_list.se2dlxl5rv1qx63ue9pbw, };
            addMenuOpt(1, 8, 1, main1_sub1_opt8_lvl1);

            #endregion

            #region blocks
            string[] main1_sub1_opt9_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Main", MF_SubMenu + "Misc.", MF_SubMenu + "Frosted Ice", MF_SubMenu + "Eggs" };
            string[] main1_sub1_opt9_lvl2 = { MF_Trackbar + ult_list.Hxd4bkef4pd957i0btajp, MF_Trackbar + ult_list.Gwbwvbt6g2sddte6lpbwc, MF_Trackbar + ult_list.rfq47ez4id535qqzi9h1m, MF_Trackbar + ult_list.Cqmzmyj30ut446xnk6m8z, };
            string[] main1_sub1_opt9_lvl3 = { MF_CheckBox + ult_list.Nqd8huhkvp6ia86wfqtvg, MF_CheckBox + ult_list.Txmqkpui856moxxgwydi4, MF_CheckBox + ult_list.l3g4oxi49a0uymwznwq1j, MF_CheckBox + ult_list.Nczhhfajy78ec1l411d2n, MF_CheckBox + ult_list.H7o4kp7bwmzcej6qv61do, MF_CheckBox + ult_list.E2uioazd7me5k1vs04wyl, MF_CheckBox + ult_list.zg4ik3w348ukowioszn3f, MF_CheckBox + ult_list.Gjgsaqp05fhpo8itmvjk1 };
            string[] main1_sub1_opt9_lvl4 = { MF_CheckBox + mc_list.Zoq5a463pjh5c4lcg6h1g, MF_CheckBox + mc_list.Hiadgb99calt8tdbmw1bi, MF_CheckBox + ult_list.cpwaz8ncfsizatrn4elf3, MF_CheckBox + ult_list.b3xctaacmtic49tcal7ra, MF_CheckBox + ult_list.Pk5l6cdgwkp2c0bx878w6, MF_CheckBox + ult_list.xiuqo1v42cupkxh7u6oxl, MF_CheckBox + ult_list.j71dvp219d5sh97422kwb, MF_CheckBox + ult_list.L16axneonp1bunzw77wk5, MF_CheckBox + ult_list.X9ewjgnakg28rkgrsk8x8, MF_CheckBox + ult_list.Qru69eruebtyr0b1m5t3k, MF_CheckBox + ult_list.Pcsq8ofvnjinbojuvlc58, MF_CheckBox + ult_list.rew98a6oovwm8ubdsvhbo, MF_CheckBox + ult_list.klar2dmmcqsl6nx2m7ywa, MF_CheckBox + ult_list.L1lp1yo2xzr6wl0kb1nmw };
            string[] main1_sub1_opt9_lvl5 = { MF_CheckBox + ult_list.Gal08a71doyx8v6apemm0, MF_CheckBox + ult_list.Mzmiqd4wgz2ur7q72bekz, MF_CheckBox + ult_list.vt1d6dsb92eawck6ydk5g, MF_CheckBox + ult_list.flvowdgae9in9cwh8jlmu, MF_CheckBox + ult_list.T2xnu17oxtjz1ieo8nq27, MF_CheckBox + ult_list.Ss6au0auqd8o17koxh34f, MF_CheckBox + ult_list.M2nv0sw18ijv2tpb5x230, MF_CheckBox + ult_list.Wn7uv4747z00tvwefljbe, MF_CheckBox + ult_list.fjvh3nwirisao9e243a6u, MF_CheckBox + ult_list.n23issbg6k6tn1zq100hi, };
            string[] main1_sub1_opt9_lvl6 = { MF_CheckBox + ult_list.lplhm9xxjxaec2x5peb2h, MF_CheckBox + ult_list.Aqzbauiakn9oap53nfmib, MF_CheckBox + ult_list.jxk34fjszv6mm6d5zjg10, MF_CheckBox + ult_list.Cxn6xwdx64rk130tf5h4l, MF_CheckBox + ult_list.Rzkyrxceladd8vrokoghc, MF_CheckBox + ult_list.Dww4evvsfuz4cmqbmypau, MF_CheckBox + ult_list.t9l61nmfmmj1za2ycpu5b, };
            addMenuOpt(1, 9, 1, main1_sub1_opt9_lvl1);
            addMenuOpt(1, 9, 2, main1_sub1_opt9_lvl2, new byte[] { 12, 7, 8, 4 });
            addMenuOpt(1, 9, 3, main1_sub1_opt9_lvl3);
            addMenuOpt(1, 9, 4, main1_sub1_opt9_lvl4);
            addMenuOpt(1, 9, 5, main1_sub1_opt9_lvl5);
            addMenuOpt(1, 9, 6, main1_sub1_opt9_lvl6);

            string[][] main1_sub1_opt9_lvl2_Combo = new string[100][];
            int count_1192 = 0;
            main1_sub1_opt9_lvl2_Combo[count_1192++] = new string[] { "12" }; optsMax.Add(ult_list.Hxd4bkef4pd957i0btajp + ";12");
            main1_sub1_opt9_lvl2_Combo[count_1192++] = new string[] { "7" }; optsMax.Add(ult_list.Gwbwvbt6g2sddte6lpbwc + ";7");
            main1_sub1_opt9_lvl2_Combo[count_1192++] = new string[] { "8" }; optsMax.Add(ult_list.rfq47ez4id535qqzi9h1m + ";8");
            main1_sub1_opt9_lvl2_Combo[count_1192++] = new string[] { "4" }; optsMax.Add(ult_list.Cqmzmyj30ut446xnk6m8z + ";4");

            #endregion

            #region game settings
            string[] main1_sub1_opt10_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Settings", MF_SubMenu + "Game Ending", MF_SubMenu + "Visuals", MF_SubMenu + "Particals", MF_SubMenu + "Misc." };
            string[] main1_sub1_opt10_lvl2 = { MF_Trackbar + ult_list.Elw90pa9fxptif1mmyrti, MF_Trackbar + ult_list.T5mivp4z7onhp4xwd616x, MF_Trackbar + ult_list.dza6jx3tmznnm3wvmeqme, MF_Trackbar + ult_list.buz4nvul7my6cjnlxwpdh, MF_Trackbar + ult_list.zom0xvj0ncgbu3itkha5v, MF_Trackbar + ult_list.ombloo0j9am0x9mlf4bev, MF_Trackbar + ult_list.yhx7b1vua0wrqbhmc9dir, MF_Trackbar + ult_list.O3cfr2dj7t051l0tyekw3, };
            string[] main1_sub1_opt10_lvl3 = { MF_CheckBox + ult_list.Xbcmcqxg58cxemo5o4ppe, MF_CheckBox + ult_list.C5dc4nk36zmefhmg63b4s, MF_CheckBox + ult_list.Lgxc69g8efcos3rzl7cim, MF_CheckBox + ult_list.o7tr0f0bpgolack801zsd, MF_CheckBox + ult_list.Zqxvpswh8rrj05xg0twa4, MF_CheckBox + ult_list.E6uuupquy58g30unn260b, MF_CheckBox + ult_list.O6kkimqnaqciiccyr55u0, MF_CheckBox + ult_list.Mou7kk5uncmzxhzauml2i, };
            string[] main1_sub1_opt10_lvl4 = { MF_CheckBox + ult_list.b4u3yg3k3g1au3it7k6af, MF_CheckBox + ult_list.Idkzw0kpjn3ujklq0oiv1, MF_CheckBox + ult_list.S06dldvqlm383fcpg8sdv, MF_CheckBox + ult_list.S0v1sh88f699t843063pi, MF_CheckBox + ult_list.i52c5uizyvsv3ewrn6dey, };
            string[] main1_sub1_opt10_lvl5 = { MF_CheckBox + ult_list.Sjmzwzocj6jb1va332axa, MF_CheckBox + ult_list.Vvgfu5rt8u7694f6q01g5, MF_CheckBox + ult_list.Yj4ximjh55ajwhzlyytby, MF_CheckBox + ult_list.gex7cipes9gok558bts5g, MF_CheckBox + ult_list.zoeeqs86v25dwx978slg9, };
            string[] main1_sub1_opt10_lvl6 = { MF_CheckBox + ult_list.J9jq2f1jlml67mo938clv, MF_CheckBox + ult_list.G0x4bxx33675ywo2buvbv, MF_CheckBox + ult_list.m95bsrhn0ucgsw4i52igf, MF_CheckBox + ult_list.Xy5k3mhh6ioof9xv4x9xy, MF_CheckBox + ult_list.Uum2h5bwzpde5oe22k3qd, MF_CheckBox + ult_list.Jwjmjgrm4o3qx270neuhs, MF_CheckBox + ult_list.Jujjx235kkkpywwruz5rh, MF_CheckBox + ult_list.us8fe441ziqe0fpw7q6jb, MF_CheckBox + ult_list.M57s7p01s0qtoygqn3s53, MF_CheckBox + ult_list.x2kzul45owkc3zt9a8lha, };
            string[] main1_sub1_opt10_lvl7 = { MF_CheckBox + ult_list.oud51v7ok0atc8qkcu3wr, MF_CheckBox + ult_list.idcipic40a6df945jmozc, MF_CheckBox + ult_list.Esy9oc1r0jkdrrfe76e6g, MF_CheckBox + ult_list.uzatbz88d63xty2hr5ahp, MF_CheckBox + ult_list.Yf1kgxtzwp30ze2trnszo, MF_CheckBox + ult_list.f4c0c58sr6xvg632cc4ba, MF_CheckBox + ult_list.Ja9le2usm6bb0rhuq0j1m, MF_CheckBox + ult_list.Z9j61njg1slb3sh2nqq57, MF_CheckBox + ult_list.Dng5vnd5s5iu3m83l5oa3, MF_CheckBox + ult_list.kygzyg338ztr4i8u4zndb, MF_CheckBox + ult_list.Nqjlven4z9y68ai3uvdes, MF_CheckBox + ult_list.S8rf1uf7kkzuuvu4zg93b, MF_CheckBox + ult_list.n5iyzrrx6joj5ubaauwco, MF_CheckBox + ult_list.Hd2ws20zqc5owtu5h52za, MF_CheckBox + ult_list.gmkongf2mzw10dcfd8vvt, MF_CheckBox + ult_list.kh157ctunr7h6lpizqjno, MF_CheckBox + ult_list.u5rmcbs71t7o2lg4o4anr, };
            addMenuOpt(1, 10, 1, main1_sub1_opt10_lvl1);
            addMenuOpt(1, 10, 2, main1_sub1_opt10_lvl2, new byte[] { 11, 16, 11, 8, 11, 3, 3, 3 });
            addMenuOpt(1, 10, 3, main1_sub1_opt10_lvl3);
            addMenuOpt(1, 10, 4, main1_sub1_opt10_lvl4);
            addMenuOpt(1, 10, 5, main1_sub1_opt10_lvl5);
            addMenuOpt(1, 10, 6, main1_sub1_opt10_lvl6);
            addMenuOpt(1, 10, 7, main1_sub1_opt10_lvl7);

            string[][] main1_sub1_opt10_lvl2_Combo = new string[100][];
            int count_11102 = 0;
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "11" }; optsMax.Add(ult_list.Elw90pa9fxptif1mmyrti + ";11");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "16" }; optsMax.Add(ult_list.T5mivp4z7onhp4xwd616x + ";16");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "11" }; optsMax.Add(ult_list.dza6jx3tmznnm3wvmeqme + ";11");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "8" }; optsMax.Add(ult_list.buz4nvul7my6cjnlxwpdh + ";8");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "11" }; optsMax.Add(ult_list.zom0xvj0ncgbu3itkha5v + ";11");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "3" }; optsMax.Add(ult_list.ombloo0j9am0x9mlf4bev + ";3");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "3" }; optsMax.Add(ult_list.yhx7b1vua0wrqbhmc9dir + ";3");
            main1_sub1_opt10_lvl2_Combo[count_11102++] = new string[] { "3" }; optsMax.Add(ult_list.O3cfr2dj7t051l0tyekw3 + ";3");
            #endregion

            #region name changer
            string[] main1_sub1_opt11_lvl1 = { MF_SubMenu + "Name Changer", MF_SubMenu + "Text Changer", };
            string[] main1_sub1_opt11_lvl2 = { MF_ComboBox + mc_list.h6xqao70qv0itw0d3k4mg, MF_textOnly + mc_list.h6xqao70qv0itw0d3k4mg, MF_button + mc_list.h6xqao70qv0itw0d3k4mg, MF_Seperator + mc_list.h6xqao70qv0itw0d3k4mg, MF_textBox + ult_list.hnm66mx1wg69mh1kbgh9p, MF_button + ult_list.hnm66mx1wg69mh1kbgh9p, MF_Seperator + ult_list.hnm66mx1wg69mh1kbgh9p, MF_textBox + ult_list.I30m847hp73iztqg1glkm, MF_button + ult_list.I30m847hp73iztqg1glkm, MF_Seperator + ult_list.I30m847hp73iztqg1glkm, MF_textBox + ult_list.rcs39af267jvfwnxxa7bp, MF_button + ult_list.rcs39af267jvfwnxxa7bp, MF_Seperator + ult_list.rcs39af267jvfwnxxa7bp, MF_textBox + ult_list.Eekrxidcf3t1jk5603ql0, MF_button + ult_list.Eekrxidcf3t1jk5603ql0 };
            string[] main1_sub1_opt11_lvl3 = { MF_textBox + ult_list.u18qmxz7q7sja1nlgf9wo, MF_button + ult_list.u18qmxz7q7sja1nlgf9wo, MF_Seperator + ult_list.u18qmxz7q7sja1nlgf9wo, MF_textBox + ult_list.lfhwdpdv4iksp41qlyemo, MF_button + ult_list.lfhwdpdv4iksp41qlyemo, MF_Seperator + ult_list.lfhwdpdv4iksp41qlyemo, MF_textBox + ult_list.Mdo49k9zj8m74xivumm7u, MF_button + ult_list.Mdo49k9zj8m74xivumm7u, MF_Seperator + ult_list.Mdo49k9zj8m74xivumm7u, MF_textBox + ult_list.Iechxa4f969raxhk1mw3q, MF_button + ult_list.Iechxa4f969raxhk1mw3q };
            addMenuOpt(1, 11, 1, main1_sub1_opt11_lvl1);
            addMenuOpt(1, 11, 2, main1_sub1_opt11_lvl2);
            addMenuOpt(1, 11, 3, main1_sub1_opt11_lvl3);

            string[][] main1_sub1_opt11_lvl2_Combo = new string[100][];
            main1_sub1_opt11_lvl2_Combo[0] = new string[] { "Default", "Black", "Blue", "Green", "Teal", "Red", "Purple", "Orange", "Grey", "Dark Grey", "Violet", "Lime Green", "Cyan", "Light red", "Pink", "Yellow", "Random Letters" }; optsMax.Add(mc_list.h6xqao70qv0itw0d3k4mg + ";18");

            #endregion

            //host
            #region combat
            string[] main1_sub2_opt1_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Gode Mode", MF_SubMenu + "Hit", MF_SubMenu + "Arrows" };
            string[] main1_sub2_opt1_lvl2 = { MF_Trackbar + mc_list.Hlq024viyiqvrt9626xxx, MF_Trackbar + mc_list.oixm4kecbcz69qf9lz3yk, MF_Trackbar + mc_list.I5rmdsf5wz7pk1c9qvgmu };
            string[] main1_sub2_opt1_lvl3 = { MF_CheckBox + ult_list.ixqktsc16xxi6agl3ndzn, MF_CheckBox + ult_list.kkmg57b7a5jhdhlsy1rbv, MF_CheckBox + ult_list.Jjo0lxbe1fbrkak8cnbj9, MF_CheckBox + ult_list.R8rjqjp86iuex2i786cpc, };
            string[] main1_sub2_opt1_lvl4 = { MF_CheckBox + ult_list.uc0frojmrgrio7ypn4qnu, MF_CheckBox + mc_list.Hlq024viyiqvrt9626xxx, MF_CheckBox + ult_list.Tgihy4q646nju75qaezoo, MF_CheckBox + ult_list.d16rfn7lvi3z6m7vkzrdu, MF_CheckBox + ult_list.b4haubpsmsjt9w1r4iuvs, MF_CheckBox + ult_list.p3ree0s7ompweagb3b9o1, MF_CheckBox + ult_list.Z2wpfk8dxojjqtp0d0igc, MF_CheckBox + ult_list.Ps8n2r1k35x7ytjb1u0u9, MF_CheckBox + ult_list.Ctwwsnxxxlctniqb8swo4, MF_CheckBox + mc_list.B7ynh5lnsf1olwawc9z0e, MF_CheckBox + mc_list.s8mhqziabq6y2p2rt3t2f, };
            string[] main1_sub2_opt1_lvl5 = { MF_CheckBox + mc_list.Sc3u9bp4wcy12rcyragyg, MF_CheckBox + ult_list.Zqujv3v26j4j3ucz3y7hb, MF_CheckBox + ult_list.Xi8hcqmftscwpn9ddw4yq, MF_CheckBox + ult_list.cd31q1iwlkvfydw0qvaeh, MF_CheckBox + ult_list.Xfe0uaiwegacf2bwrw55j, MF_CheckBox + ult_list.jtbiw5ufmru0rzzu8ccui, };
            addMenuOpt(2, 1, 1, main1_sub2_opt1_lvl1);
            addMenuOpt(2, 1, 2, main1_sub2_opt1_lvl2, new byte[] { 10, 10, 10 });
            addMenuOpt(2, 1, 3, main1_sub2_opt1_lvl3);
            addMenuOpt(2, 1, 4, main1_sub2_opt1_lvl4);
            addMenuOpt(2, 1, 5, main1_sub2_opt1_lvl5);


            string[][] main1_sub2_opt1_lvl2_Combo = new string[100][];
            int count_1212 = 0;
            main1_sub2_opt1_lvl2_Combo[count_1212++] = new string[] { "10" }; optsMax.Add(mc_list.Hlq024viyiqvrt9626xxx + ";10");
            main1_sub2_opt1_lvl2_Combo[count_1212++] = new string[] { "10" }; optsMax.Add(mc_list.oixm4kecbcz69qf9lz3yk + ";10");
            main1_sub2_opt1_lvl2_Combo[count_1212++] = new string[] { "10" }; optsMax.Add(mc_list.I5rmdsf5wz7pk1c9qvgmu + ";10");



            #endregion

            #region items
            string[] main1_sub2_opt2_lvl1 = { MF_SubMenu + "Main", MF_SubMenu + "Misc." };

            string[] main1_sub2_opt2_lvl2 = { MF_CheckBox + ult_list.zg4ik3w348ukowioszn3f, MF_CheckBox + ult_list.P5s6ysmgofoud2ygfnxo5, MF_CheckBox + ult_list.n6t66vdtpkwtb2cxi0lu8, MF_CheckBox + ult_list.Tthk948gjca7hdnqzh11c, MF_CheckBox + ult_list.P66yhadkru3utheugyqnq, MF_CheckBox + ult_list.Op824nbwxnol5qq3l4os2, MF_CheckBox + ult_list.Pnsgnk40nmapz9issat2d, MF_CheckBox + mc_list.Zwml3pnt1bugahiwscuwf };
            string[] main1_sub2_opt2_lvl3 = { MF_CheckBox + ult_list.T2wgl2xbguaqthu9e2vjy, MF_CheckBox + ult_list.M85dstbgxo8thvcg3deyq, MF_CheckBox + ult_list.Ssfw1piljj2zu6mbwsurc, MF_CheckBox + ult_list.tjapv6nj1zw7sqggcd5yl, MF_CheckBox + ult_list.Rps8jswg26ymiruhgv75z, MF_CheckBox + ult_list.L2mllai9h0zw4pr7xd8ru, MF_CheckBox + ult_list.jgy9gvu3iekew2saafofk, MF_CheckBox + ult_list.R5wp7nbc8704hi9tervg7, MF_CheckBox + ult_list.Vbn3y2r5p2v3xv3iimess, MF_CheckBox + ult_list.d2go1ttgkom430zapjzyn, MF_CheckBox + ult_list.Ewezydpq7j644xz3k5kvw, MF_CheckBox + ult_list.ntpy40gxu6ws0pkjcjl65, MF_CheckBox + ult_list.q60nqytzpg0pvavmtun8r, MF_CheckBox + ult_list.Vch9fcs0gj79hh98kpe39, MF_CheckBox + ult_list.Qagj4220rcc0tg1nfjcog, };

            addMenuOpt(2, 2, 1, main1_sub2_opt2_lvl1);
            addMenuOpt(2, 2, 2, main1_sub2_opt2_lvl2);
            addMenuOpt(2, 2, 3, main1_sub2_opt2_lvl3);

            #endregion

            #region entities
            string[] main1_sub2_opt3_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "All", MF_SubMenu + "Players" };
            string[] main1_sub2_opt3_lvl2 = { MF_Trackbar + ult_list.Xz3ab21ed2h7cik58rkvw, MF_Trackbar + mc_list.Fzqxw9xezx1ggajhcgxe0, MF_Trackbar + mc_list.pft7pz466y20ka8r8sm0j, MF_Trackbar + ult_list.li5ss0qm903m4r0qudi2f, MF_Trackbar + ult_list.n3f81vdlowqu843tul5l8, MF_Trackbar + ult_list.Hk2r0iyiiamr8bl7oxrfj, };
            string[] main1_sub2_opt3_lvl3 = { MF_CheckBox + ult_list.u4hmiy693lcxgrbtvfqru, MF_CheckBox + ult_list.no54vr6h0mi6lmzzn7z0f, MF_CheckBox + ult_list.Oeuewxbxanmbw83yw893o, MF_CheckBox + ult_list.Rqgia6hmskh1jasvzlw6f, MF_CheckBox + ult_list.Hh5qlovqol3wpgcpv1wsx, MF_CheckBox + ult_list.a3nelvy4s0y3wqthce6z0, MF_CheckBox + ult_list.Hmpa45v4kv6k4zvbw7n5m, MF_CheckBox + ult_list.p5ss5r3cqn1n04374onl4, MF_CheckBox + ult_list.xh60dll8cnsywqk76idy6, MF_CheckBox + ult_list.w74p6x90mz5304mtf3iy5, MF_CheckBox + ult_list.Truo1ob2w9gd8ai3ekz84, MF_CheckBox + ult_list.Vruu38axwgd77yypffuq5, MF_CheckBox + ult_list.org2q8bvm550v6g6r4v9e, MF_CheckBox + ult_list.Lo7cdqswf7s13m9h6pc0f, };
            string[] main1_sub2_opt3_lvl4 = { MF_CheckBox + ult_list.lnjslnrxof4919rvl7mob, MF_CheckBox + ult_list.X6t3gtes6z224tzjkl0bf, MF_CheckBox + ult_list.Awgra7iprghv1p357htgz, MF_CheckBox + ult_list.mjf0eck9q717nvz4rizcj, MF_CheckBox + ult_list.Jvp5voqfiexxj37a7l1ss, MF_CheckBox + ult_list.pron5b4ok55ip38mtn49u, MF_CheckBox + ult_list.xwnnjxlg9v34vnzzjgujz, MF_CheckBox + ult_list.Qyjwi2f4m37amrrxr85jy, MF_CheckBox + ult_list.j0xoe78aof6azulij8gzu, MF_CheckBox + ult_list.Ta85xxzniv9rp1ew3xk3q, MF_CheckBox + ult_list.Zj29946okdfr1165b96vd, MF_CheckBox + ult_list.igq22ngjm1eo9yasu550t, MF_CheckBox + ult_list.h73ozhzbffgy4cjz0lplr, };
            addMenuOpt(2, 3, 1, main1_sub2_opt3_lvl1);
            addMenuOpt(2, 3, 2, main1_sub2_opt3_lvl2, new byte[] { 4, 10, 10, 8, 7, 4 });
            addMenuOpt(2, 3, 3, main1_sub2_opt3_lvl3);
            addMenuOpt(2, 3, 4, main1_sub2_opt3_lvl4);

            string[][] main1_sub2_opt3_lvl2_Combo = new string[100][];
            int count_1231 = 0;
            main1_sub2_opt3_lvl2_Combo[count_1231++] = new string[] { "4" }; optsMax.Add(ult_list.Xz3ab21ed2h7cik58rkvw + ";4");
            main1_sub2_opt3_lvl2_Combo[count_1231++] = new string[] { "10" }; optsMax.Add(mc_list.Fzqxw9xezx1ggajhcgxe0 + ";10");
            main1_sub2_opt3_lvl2_Combo[count_1231++] = new string[] { "10" }; optsMax.Add(mc_list.pft7pz466y20ka8r8sm0j + ";10");
            main1_sub2_opt3_lvl2_Combo[count_1231++] = new string[] { "8" }; optsMax.Add(ult_list.li5ss0qm903m4r0qudi2f + ";8");
            main1_sub2_opt3_lvl2_Combo[count_1231++] = new string[] { "7" }; optsMax.Add(ult_list.n3f81vdlowqu843tul5l8 + ";7");
            main1_sub2_opt3_lvl2_Combo[count_1231++] = new string[] { "4" }; optsMax.Add(ult_list.Hk2r0iyiiamr8bl7oxrfj + ";4");

            #endregion

            #region enchantenment
            string[] main1_sub2_opt4_lvl1 = { MF_SubMenu + "XP Editor", MF_CheckBox + ult_list.dx5zdsbxbaifwm517puda, MF_CheckBox + ult_list.W5pgfry44emfpfqp29fma, MF_CheckBox + ult_list.ilzvmi9a3zbtb0ses2ncz };
            string[] main1_sub2_opt4_lvl2 = { MF_textBox + mc_list.zhnxk1bzlt4dvx35noh70, MF_button + mc_list.zhnxk1bzlt4dvx35noh70, MF_button2 + mc_list.zhnxk1bzlt4dvx35noh70, MF_Seperator + mc_list.zhnxk1bzlt4dvx35noh70, };
            addMenuOpt(2, 4, 1, main1_sub2_opt4_lvl1);
            addMenuOpt(2, 4, 2, main1_sub2_opt4_lvl2);

            #endregion

            #region explosion
            string[] main1_sub2_opt5_lvl1 = { MF_SubMenu + "Editors", MF_SubMenu + "Creeper", MF_SubMenu + "Tnt" };
            string[] main1_sub2_opt5_lvl2 = { MF_Trackbar + mc_list.Zamndxbno1ets4zms2ua1, MF_Trackbar + mc_list.cj2u0y712cah84vzwg7ao };
            string[] main1_sub2_opt5_lvl3 = { MF_CheckBox + ult_list.vupn8m24y1wj31z7jskwo, MF_CheckBox + ult_list.hgwgm6gvo1l2mdx1lx8ao, MF_CheckBox + ult_list.sext589378ws1p2f3k5nu, MF_CheckBox + ult_list.Mrchz1v12hywlbak2qiha, MF_CheckBox + ult_list.So7ypwca8gyf9bvs2gej0, MF_CheckBox + ult_list.Mq8qqrtox46jexzb0y0pv, MF_CheckBox + ult_list.Q5ol9tz5dod1xkw5o10y6, MF_CheckBox + ult_list.O17yztkcg524t2p4po0im, };
            string[] main1_sub2_opt5_lvl4 = { MF_CheckBox + ult_list.grop6fwwtxiinm8w2m7bx, MF_CheckBox + ult_list.uq5ax6lwcnvmdodjhfweo, MF_CheckBox + ult_list.Tx1bk8jh3iuhg70i7xpx7, MF_CheckBox + ult_list.achfx23592gu75y19oef6, MF_CheckBox + ult_list.Gbnalk0qya56z1wqc5a8t, MF_CheckBox + ult_list.kop8xtsa3oxbacr9ol9uf, MF_CheckBox + ult_list.pc3cd1jybwmf8rwbvaow3, MF_CheckBox + ult_list.Saejoo3mtotahj4i9uk09, MF_CheckBox + ult_list.G7kjc2g7gd0c4dvzwfetw, MF_CheckBox + ult_list.gv05ov6tcqhfus1zkljwf, };
            addMenuOpt(2, 5, 1, main1_sub2_opt5_lvl1);
            addMenuOpt(2, 5, 2, main1_sub2_opt5_lvl2, new byte[] { 10, 10 });
            addMenuOpt(2, 5, 3, main1_sub2_opt5_lvl3);
            addMenuOpt(2, 5, 4, main1_sub2_opt5_lvl4);

            string[][] main1_sub2_opt5_lvl2_Combo = new string[100][];
            int count_1252 = 0;
            main1_sub2_opt5_lvl2_Combo[count_1252++] = new string[] { "10" }; optsMax.Add(mc_list.Zamndxbno1ets4zms2ua1 + ";10");
            main1_sub2_opt5_lvl2_Combo[count_1252++] = new string[] { "10" }; optsMax.Add(mc_list.cj2u0y712cah84vzwg7ao + ";10");
            #endregion

            #region weather
            string[] main1_sub2_opt6_lvl1 = { MF_CheckBox + ult_list.fkk5979ahopj271wsa294, MF_CheckBox + ult_list.S7ar859if3s55mrkym77d, MF_CheckBox + ult_list.O9kbjyreuacfcrkej3696, MF_CheckBox + ult_list.Pvykyh4fea77jphx7yc8y, MF_CheckBox + ult_list.Kb9xnt88apiwbg2a6zyvb, MF_CheckBox + ult_list.Rov9xcsfl76hv93i134zc, MF_CheckBox + ult_list.fmxktpebjvku3ekgqjp7d, };
            addMenuOpt(2, 6, 1, main1_sub2_opt6_lvl1);

            #endregion

            #region water
            string[] main1_sub2_opt7_lvl1 = { MF_CheckBox + mc_list.pig9lvbiwic3aww77nrbn, MF_CheckBox + ult_list.qaudsfwgm9ai4k0c7ucor, MF_CheckBox + ult_list.sv3y85b46ydbngxrilvl9, MF_CheckBox + ult_list.p3979qmuu0jnny1ec2kc1, MF_CheckBox + ult_list.aqv7dqomzucskmkr5zuq8, MF_CheckBox + ult_list.Qrfk83wij7rj6v99t970k, MF_CheckBox + ult_list.Kczn3on2jljckdd64zmkg, MF_CheckBox + ult_list.Jmjoo1ffribr2trk11quq, MF_CheckBox + ult_list.G488xp93rdf3wxu82k9ci, MF_CheckBox + ult_list.yikbk2j1w3edj23lnl192, MF_CheckBox + ult_list.wmxoch4f9trr2olit6y4f, MF_CheckBox + mc_list.j4qykhxbuciczxoho3jv0, };
            addMenuOpt(2, 7, 1, main1_sub2_opt7_lvl1);

            #endregion

            #region game settings
            string[] main1_sub2_opt8_lvl1 = { MF_CheckBox + ult_list.U2ffc9oij13ic3pvhk6vq, MF_CheckBox + ult_list.R4j36ljoi1p857keavh9h, MF_CheckBox + ult_list.p4ymvgcy2y1wvkkduadvm, MF_CheckBox + ult_list.Dzwvy3p8ixhoso446g9om, MF_CheckBox + ult_list.g4dfv7gdbodazw5hds5g5, MF_CheckBox + ult_list.ivmro7qf0bykx9h5314hd, MF_CheckBox + ult_list.Qzmzhzlur4kmlnqmqnzkm, MF_CheckBox + ult_list.It81kjbwfpcv8fxclzd1j, };
            addMenuOpt(2, 8, 1, main1_sub2_opt8_lvl1);

            #endregion

            string[][] combo_none = new string[100][];
            ToolStripItemCollection[] TS_none = new ToolStripItemCollection[100];

            int subC = 0;
            mainOpts = addMenuFuncs(main1, subC++, combo_none, new ToolStripItemCollection[] {
                    addMenuFuncs(main1_sub1, subC++, combo_none, new ToolStripItemCollection[] {           
                    addMenuFuncs(main1_sub1_opt1_lvl1, subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt1_lvl2, subC++,main1_sub1_opt1_lvl2_Combo, TS_none),addMenuFuncs(main1_sub1_opt1_lvl3, subC++,main1_sub1_opt1_lvl2_Combo, TS_none) }) ,
                    addMenuFuncs(main1_sub1_opt2_lvl1, subC++, combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt2_lvl2, subC++,main1_sub1_opt2_lvl2_Combo, TS_none),addMenuFuncs(main1_sub1_opt2_lvl3, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt2_lvl4, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt2_lvl5, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt2_lvl6, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt2_lvl7, subC++,combo_none, TS_none) }) ,
                    addMenuFuncs(main1_sub1_opt3_lvl1, subC++, combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt3_lvl2, subC++,main1_sub1_opt3_lvl1_Combo, TS_none) ,addMenuFuncs(main1_sub1_opt3_lvl3, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt3_lvl4, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt3_lvl5, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt3_lvl6, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt3_lvl7, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt3_lvl8, subC++,combo_none, TS_none) , addMenuFuncs(main1_sub1_opt3_lvl9, subC++,combo_none, TS_none) , addMenuFuncs(main1_sub1_opt3_lvl10, subC++,combo_none, TS_none) }) ,  
                    addMenuFuncs(main1_sub1_opt4_lvl1, subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt4_lvl2, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt4_lvl3, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt4_lvl4, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt4_lvl5, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt4_lvl6, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt4_lvl7, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt4_lvl8, subC++,combo_none, TS_none) }) , 
                    addMenuFuncs(main1_sub1_opt5_lvl1, subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt5_lvl2, subC++,main1_sub1_opt5_lvl2_Combo, TS_none),addMenuFuncs(main1_sub1_opt5_lvl3, subC++,combo_none, TS_none)  } ) ,
                    addMenuFuncs(main1_sub1_opt6_lvl1, subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt6_lvl2, subC++,main1_sub1_opt6_lvl2_Combo, TS_none) }) ,
                    addMenuFuncs(main1_sub1_opt7_lvl1, subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt7_lvl2, subC++,main1_sub1_opt7_lvl1_Combo, TS_none) }) ,
                    addMenuFuncs(main1_sub1_opt8_lvl1, subC++,combo_none,  TS_none) ,
                    addMenuFuncs(main1_sub1_opt9_lvl1, subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub1_opt9_lvl2, subC++,main1_sub1_opt9_lvl2_Combo, TS_none),addMenuFuncs(main1_sub1_opt9_lvl3, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt9_lvl4, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt9_lvl5, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt9_lvl6, subC++,combo_none, TS_none), }) ,
                    addMenuFuncs(main1_sub1_opt10_lvl1, subC++,combo_none,  new ToolStripItemCollection[] {addMenuFuncs(main1_sub1_opt10_lvl2, subC++,main1_sub1_opt10_lvl2_Combo, TS_none),addMenuFuncs(main1_sub1_opt10_lvl3, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt10_lvl4, subC++,combo_none, TS_none),addMenuFuncs(main1_sub1_opt10_lvl5, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt10_lvl6, subC++,combo_none, TS_none), addMenuFuncs(main1_sub1_opt10_lvl7, subC++,combo_none, TS_none),}) ,        
                    addMenuFuncs(main1_sub1_opt11_lvl1, subC++,combo_none,  new ToolStripItemCollection[] {addMenuFuncs(main1_sub1_opt11_lvl2, subC++,main1_sub1_opt11_lvl2_Combo, TS_none),addMenuFuncs(main1_sub1_opt11_lvl3, subC++,combo_none, TS_none)}) ,        

                    }),
                addMenuFuncs(main1_sub2,subC++, combo_none, new ToolStripItemCollection[] {
                    
                    addMenuFuncs(main1_sub2_opt1_lvl1,subC++, combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub2_opt1_lvl2, subC++,main1_sub2_opt1_lvl2_Combo, TS_none) ,addMenuFuncs(main1_sub2_opt1_lvl3, subC++,combo_none, TS_none) , addMenuFuncs(main1_sub2_opt1_lvl4, subC++,combo_none, TS_none) ,addMenuFuncs(main1_sub2_opt1_lvl5, subC++,combo_none, TS_none) ,  } ),
                    addMenuFuncs(main1_sub2_opt2_lvl1,subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub2_opt2_lvl2, subC++,combo_none, TS_none) , addMenuFuncs(main1_sub2_opt2_lvl3, subC++,combo_none, TS_none) ,}) ,
                    addMenuFuncs(main1_sub2_opt3_lvl1,subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub2_opt3_lvl2, subC++,main1_sub2_opt3_lvl2_Combo, TS_none) ,addMenuFuncs(main1_sub2_opt3_lvl3, subC++,combo_none, TS_none) , addMenuFuncs(main1_sub2_opt3_lvl4, subC++,combo_none, TS_none) }) ,
                    addMenuFuncs(main1_sub2_opt4_lvl1,subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub2_opt4_lvl2, subC++,combo_none, TS_none) }) ,
                    addMenuFuncs(main1_sub2_opt5_lvl1,subC++,combo_none,  new ToolStripItemCollection[] { addMenuFuncs(main1_sub2_opt5_lvl2, subC++,main1_sub2_opt5_lvl2_Combo, TS_none) ,addMenuFuncs(main1_sub2_opt5_lvl3, subC++,combo_none, TS_none),addMenuFuncs(main1_sub2_opt5_lvl4, subC++,combo_none, TS_none), }) ,
                    addMenuFuncs(main1_sub2_opt6_lvl1,subC++,combo_none,  TS_none) ,
                    addMenuFuncs(main1_sub2_opt7_lvl1,subC++,combo_none,  TS_none) ,
                    addMenuFuncs(main1_sub2_opt8_lvl1,subC++,combo_none,  TS_none) ,  
                }),
});
            sub1.Items.Clear();
            for (int i = 0; i < mainOpts.Count; i++)
            {
                sub1.Items.Add(mainOpts[i]);
            }
            sub1.Renderer = new MyRenderer();
            contextMenuStrip1.Renderer = new MyRenderer();
            contextMenuStrip3.Renderer = new MyRenderer();
            contextMenuStrip4.Renderer = new MyRenderer();

            contextMenuStrip1.BackColor = backgroundColorCM;
            contextMenuStrip1.ForeColor = textColorCM;
            contextMenuStrip3.BackColor = backgroundColorCM;
            contextMenuStrip3.ForeColor = textColorCM;
            contextMenuStrip4.BackColor = backgroundColorCM;
            contextMenuStrip4.ForeColor = textColorCM;
            ToolStrip ts = new ToolStrip();
            ToolStripItemCollection toolColl = new ToolStripItemCollection(ts, new ToolStripMenuItem[] { });

            toolColl.AddRange(contextMenuStrip1.Items);
            toolColl.AddRange(contextMenuStrip3.Items);
            toolColl.AddRange(contextMenuStrip4.Items);

            for (int i = 0; i < 50; i++)
            {
                foreach (ToolStripTextBox item in toolColl.Find("toolStripTextBox" + i, true))
                {
                    item.ForeColor = textColorCM;
                    item.BackColor = backgroundColorCM;
                }
                foreach (ToolStripComboBox item in toolColl.Find("toolStripComboBox" + i, true))
                {
                    item.ForeColor = textColorCM;
                    item.BackColor = backgroundColorCM;
                    item.DropDownStyle = ComboBoxStyle.DropDownList;
                }
                foreach (ToolStripMenuItem item in toolColl.Find("toolStripMenuItem" + i, true))
                {
                    item.BackColor = backgroundColorCM;
                    item.ForeColor = textColorCM;
                    item.DropDown.BackColor = backgroundColorCM;
                    item.DropDown.ForeColor = textColorCM;
                    (item.DropDown as ToolStripDropDownMenu).ShowImageMargin = false;
                    (item.DropDown as ToolStripDropDownMenu).ShowCheckMargin = false;
                    (item.DropDown as ToolStripDropDownMenu).ShowItemToolTips = false;
                }
            }
            for (int a = 0; a < 3; a++)
                for (int b = 0; b < 12; b++)
                    for (int c = 0; c < 10; c++)
                        for (int d = 0; d < 30; d++)
                            menuValue[a, b, c, d] = 1;

            for (int i = 0; i < tsMenuItems.Length; i++)
            {
                if (!Object.ReferenceEquals(tsMenuItems[i], null))
                    this.tsMenuItems[i].DropDown.Closing += new System.Windows.Forms.ToolStripDropDownClosingEventHandler(this.TS_MenuItem_Closing);
            }
            for (int i = 0; i < TS_Item.Length; i++)
            {
                if (!Object.ReferenceEquals(TS_Item[i], null))
                    this.TS_Item[i].MouseDown += new MouseEventHandler(this.TS_Item_Click);
            }
            for (int i = 0; i < TS_TrackBar.Length; i++)
            {
                if (!Object.ReferenceEquals(TS_TrackBar[i], null))
                {
                    this.TS_TrackBar[i].MouseHover += new EventHandler(this.TS_TrackBar_MouseHover);
                    this.TS_TrackBar[i].MouseDown += new MouseEventHandler(this.TS_TrackBar_Click);
                }
            }
            for (int i = 0; i < TS_ComboBox.Length; i++)
            {
                if (!Object.ReferenceEquals(TS_ComboBox[i], null))
                {
                    this.TS_ComboBox[i].MouseHover += new EventHandler(this.TS_ComboBox_MouseHover);
                    this.TS_ComboBox[i].MouseDown += new MouseEventHandler(this.TS_ComboBox_Click);
                }
            }

        }
        #endregion

        #region update func timer
        private void timer1_Tick(object sender, EventArgs e)
        {

        }
        private void updateFuncValues()
        {
            for (int i = 0; i < 10000; i++)
            {
                if (!Object.ReferenceEquals(TS_ComboBox[i], null))//checks if control if null
                {
                    funcVal[i] = TS_Label[i].Text + ";comboBox;" + TS_ComboBox[i].SelectedIndex.ToString();
                }
                if (!Object.ReferenceEquals(TS_TrackBar[i], null))//checks if control if null
                {
                    if (!saveLabel[i])
                    {
                        saveLabel[i] = true;
                        saveL[i] = TS_Label[i].Text;
                    }
                    funcVal[i] = saveL[i] + ";trackBar;" + TS_TrackBar[i].Value.ToString();
                    TS_Label[i].Text = saveL[i] + " : " + ((TS_TrackBar[i].Value == 0) ? "Default" : TS_TrackBar[i].Value.ToString());
                }
                if (!Object.ReferenceEquals(TS_Item[i], null))//checks if control if null
                {
                    if (TS_Item[i].Name.Contains("button"))
                    {
                        TS_Item[i].CheckOnClick = true;
                        if (TS_Item[i].Checked)
                        {
                            funcVal[i] = TSbtns[i] + ";button;1";
                        }
                        else
                            funcVal[i] = TSbtns[i] + ";button;0";
                    }
                    else if (TS_Item[i].Name.Contains("btn"))
                    {
                        TS_Item[i].CheckOnClick = true;
                        if (TS_Item[i].Checked)
                        {
                            funcVal[i] = TSbtns[i] + ";btn;1";
                        }
                        else
                            funcVal[i] = TSbtns[i] + ";btn;0";
                    }
                    else if (TS_Item[i].Name.Contains("checkBox"))
                    {
                        TS_Item[i].CheckOnClick = true;

                        if (TS_Item[i].Checked)
                        {
                            funcVal[i] = TS_Item[i].Text + ";checkBox;1";
                        }
                        else
                            funcVal[i] = TS_Item[i].Text + ";checkBox;0";
                    }
                }
            }

            if (!setOnce)
            {
                setOnce = true;
                for (int i = 0; i < 10000; i++)
                {
                    saveValues[i] = funcVal[i];
                }
            }
        }
        #endregion

        #region selecting
        List<string> optsMax = new List<string>();
        string[] saveValues = new string[10000];
        int valueChanged(string[] values)
        {
            for (int i = 0; i < values.Length; i++)
            {
                if (saveValues[i] != values[i])
                {
                    saveValues[i] = values[i];
                    return i;
                }
            }
            return -1;
        }
        private void selectOpt(int valueIndex, string funcValue)
        {
            string[] splitTxt = Regex.Split(funcVal[valueIndex], ";");
            string funcTxt = splitTxt[0];
            string funcState = splitTxt[1];
            if (funcState != "btn" && funcState != "button")
                modHub(funcTxt.ToUpper().Replace(" ", "_"), Convert.ToInt32(funcValue), valueIndex, funcState);
        }
        private void selectOpt()
        {
            int valueIndex = valueChanged(funcVal);
            if (valueIndex != -1)
            {
                string[] splitTxt = Regex.Split(funcVal[valueIndex], ";");
                string funcTxt = splitTxt[0];
                string funcState = splitTxt[1];
                string funcValue = splitTxt[2];
                modHub(funcTxt.ToUpper().Replace(" ", "_"), Convert.ToInt32(funcValue), valueIndex, funcState);
            }
        }
        #endregion

        #region hub
        //note: encrypt this
        public string initialTxt = "idjl6a3fjafa40x00510dbc<m1>0x00cc7e56<m1>0x00492d35<m1>0x006dc070<m1>0x00f2c19b<m1>0x001127b5<m1>0x00bb4f66<m1>0x009c361c<m1>0x0014d30b<m1>0x00bf4983<m1>0x00a5d56e<m1>0x00d676c1<m1>0x00a00f15<m1>0x0072aa9f<m1>0x0087b156<m1>0x00bbdbfb<m1>0x003dff35<m1>0x00e51639<m1>0x004678c0<m1>0x003a5779<m1>0x00c6ab5a<m1>0x00d9bf6d<m1>0x00018e5e<m1>0x007ceb69<m1>0x008c871e<m1>0x00f500c6<m1>0x004d9124<m1>0x007e9424<m1>0x001ee1a5<m1>0x004a9bc3<m1>0x00c017aa<m1>0x0079fc42<m1>0x00e043e2<m1>0x009e3d0d<m1>0x00a8455b<m1>0x0063a0eb<m1>0x00dae962<m1>0x00fe45c4<m1>0x00ab61b7<m1>0x0098ad6b<m1>0x000ced0a<m1>0x0018b20d<m1>0x00da2a7b<m1>0x003e5a44<m1>0x00fe2d00<m1>0x00b9ec33<m1>0x00ec83dd<m1>0x003143da<m1>0x00f8a841<m1>0x00ff248b<m1>0x002e2410<m1>0x009b1865<m1>0x00c9b20c<m1>0x0095a181<m1>0x000cf66d<m1>0x00b4e7a9<m1>0x0058ae3c<m1>0x0030cf54<m1>0x00079f4c<m1>0x00abfaef<m1>0x00bdee6c<m1>0x000f9b61<m1>0x00c4b871<m1>0x00fa04f8<m1>0x00e59b79<m1>0x003544d0<m1>0x007f4980<m1>0x005eb1d9<m1>0x00acd75d<m1>0x00807f9a<m1>0x00de2a2b<m1>0x007115a2<m1>0x007fca9b<m1>0x007719b5<m1>0x00559066<m1>0x0031f363<m1>0x00756936<m1>0x002fb4af<m1>0x00b8162c<m1>0x003ed7e6<m1>0x00b145b2<m1>0x00de33cd<m1>0x00e7d416<m1>0x003b54f7<m1>0x00e79c92<m1>0x000a0a7c<m1>0x00b6d315<m1>0x00515d24<m1>0x009860dd<m1>0x00a1b71e<m1>0x002aebdc<m1>0x006dab34<m1>0x003a3a87<m1>0x00caffdb<m1>0x00596d90<m1>0x00aef8a1<m1>0x0004e31e<m1>0x0047fb7d<m1>0x003a2e40<m1>0x009d6dfd<m1>0x00f3e3ae<m1>0x00f49c3e<m1>0x00223a40<m1>0x0063b239<m1>0x00863886<m1>0x004debd7<m1>0x00ab6a6d<m1>0x00d11e5c<m1>0x00783006<m1>0x00c69f4e<m1>0x00415d1f<m1>0x0091f5a3<m1>0x003678fc<m1>0x0013a1aa<m1>0x00dd7280<m1>0x0084010f<m1>0x001a9bfe<m1>0x006b7974<m1>0x008e167b<m1>0x00ec05ad<m1>0x0020287f<m1>0x00dbf20e<m1>0x006ad3<x>582.8<m2>846.9<m2>838.6<m2>474.1<m2>158.3<m2>624.4<m2>315.5<m2>421.6<m2>143.6<m2>542.1<m2>137.6<m2>423.3<m2>566.9<m2>572.3<m2>485.8<m2>825.6<m2>235.1<m2>575.6<m2>473.4<m2>489.2<m2>721.7<m2>622.3<m2>293.7<m2>942.9<m2>724.2<m2>638.7<m2>296.7<m2>589.6<m2>941.6<m2>171.1<m2>228.5<m2>587.1<m2>546.3<m2>475.4<m2>436.7<m2>548.4<m2>167.5<m2>358.1<m2>141.4<x>0x325d5b5c<m3>0x329515e8<m3>0x32f398a1<m3>0x32fd4b99<m3>0x32233972<m3>0x32e5ca89<m3>0x321322e1<m3>0x3227659b<m3>0x32c721b4<m3>0x32e3e52b<m3>0x32297903<m3>0x325e4911<m3>0x32878c2c<m3>0x32d74279<m3>0x32a6325e<m3>0x3255a1af<m3>0x32330d94<m3>0x320c0b2e<m3>0x325cbb25<m3>0x3219b883<m3>0x329d30e5<m3>0x32016328<m3>0x326979b5<m3>0x3229ef63<m3>0x32d4df9a<m3>0x32d556d5<m3>0x32ba754b<m3>0x321c3cf2<m3>0x328280f8<m3>0x32f419c4<m3>0x322b2607<m3>0x32da6b7b<m3>0x3277ec73<m3>0x32abf411<m3>0x32c70603<m3>0x32eb7dd3<m3>0x3235658e<m3>0x32664621<m3>0x324c689b<m3>0x32f74a32<m3>0x32113d75<m3>0x32d4453c<m3>0x327eca84<m3>0x326fe8bd<m3>0x326fc58f<m3>0x3292bde0<m3>0x32528828<m3>0x327923a5<m3>0x329f99de<m3>0x32e2f001<m3>0x32325e5b<m3>0x32a495ef<m3>0x325760ac<m3>0x324cf063<m3>0x32fae786<m3>0x32bfb1fa<m3>0x32c3d12f<m3>0x325da4df<m3>0x32182c5e<m3>0x32cc6c85<m3>0x326d5d49<m3>0x32ee26d1<m3>0x329c4942<m3>0x322568fa<m3>0x32d837ec<m3>0x32ea424f<x>0x00c25435<m4>0x318acda4";

        int setTog(int _value, int _togIndex, int _optMax)
        {
            if (_value >= _optMax - 1)
                _togIndex = 0;
            else
                _togIndex += (_value + 1);
            return _togIndex;
        }
        int modHub(string modName, int value, int index, string state)
        {
            int togIndex = 0;
            if (canUseTool)
            {
                if (playClickSound)
                    snd.Play();
                if (state == "checkBox")
                {
                    if (value == 0)
                        runNotify(modName + " : Off");
                    else if (value == 1)
                        runNotify(modName + " : On");
                }
                else if (state == "trackBar" || state == "comboBox")
                    runNotify(modName + " : " + ((value == 0) ? "Default" : value.ToString()));
                else if (state == "multiOpt")
                    runNotify(modName + " : " + ((value == 0) ? "Default" : value.ToString()));
                else if (state == "button")
                    runNotify(modName + " : Set");

                int optMax = 0;
                int optMaxNorm = 2;
                for (int i = 0; i < optsMax.Count; i++)
                {
                    string[] split = Regex.Split(optsMax[i], ";");
                    if (split[0] == modName)
                    {
                        try
                        {
                            optMax = Convert.ToInt32(split[1]);
                            break;
                        }
                        catch
                        {

                        }
                    }
                }

                // MessageBox.Show(modName + " - " + value);
                #region xxxxxxxxxxxx
                if (modName == mc_list.kkmg57b7a5jhdhlsy1rbv)
                    togIndex = writeMem(modName, getOfs(mcOfs.Xwuiht4s3yr1ywezdg0cm), value, new byte[] { 0xFC, 0x80, 0xF8, 0x90 }, new byte[] { 0xFC, 0x20, 0xF8, 0x90 });
                else if (modName == mc_list.pig9lvbiwic3aww77nrbn)
                    togIndex = writeMem(modName, getOfs(mcOfs.eldhi6qm7b9ifn0ad5b3r), value, new byte[] { 0xC3, 0x43 }, new byte[] { 0xC0, 0x43 });
                else if (modName == mc_list.Erqj4xyfl7ac00fcdm4j6)
                    togIndex = writeMem(modName, getOfs(mcOfs.Wd6s3e56y5w9b0kupfiqq) + 3, value, new byte[] { 0x00 }, new byte[] { 0x01 });
                else if (modName == mc_list.J3l13qhqvoulkqxd26fx7)
                    togIndex = writeMem(modName, getOfs(mcOfs.Iu57v8mt2rxzsy3ivh940) + 3, value, new byte[] { 0x00 }, new byte[] { 0x01 });
                else if (modName == mc_list.P66yhadkru3utheugyqnq)
                    togIndex = writeMem(modName, getOfs(mcOfs.r5tb6oeapq9wlecomj08l) + 3, value, new byte[] { 0x00 }, new byte[] { 0x01 });
                else if (modName == mc_list.Bit7nz2kcckghgma6wu3n)
                    togIndex = writeMem(modName, getOfs(mcOfs.Xet81mch1ikm7cn72ck32) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.z69au92cld6dq1hzm9lrh)
                    togIndex = writeMem(modName, getOfs(mcOfs.P6jggxzi0ewj96g5gd6po), value, new byte[] { 0x00, 0x00 }, new byte[] { 0xBF, 0x80 });
                else if (modName == mc_list.b2iokxnm5extdxauitmn7)
                    togIndex = writeMem(modName, getOfs(mcOfs.Zsqdxa5o013tfylnlbimw) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.u099fg0p9xx7lcvuxu07v)
                    togIndex = writeMem(modName, getOfs(mcOfs.Bq7qbm7blmy3fcsmlvjum), value, new byte[] { 0x45, 0x00 }, new byte[] { 0x40, 0x00 });
                else if (modName == mc_list.jpggpma20wq2w7uq3ijd6)
                    togIndex = writeMem(modName, getOfs(mcOfs.Xml74s4bv3cam4mtjzec7), value, new byte[] { 0x30, 0x00 }, new byte[] { 0x3F, 0x80 });
                else if (modName == mc_list.s8mhqziabq6y2p2rt3t2f)
                    togIndex = writeMem(modName, getOfs(mcOfs.exlmve8kqyb1wfwvm2rbj), value, new byte[] { 0x38, 0x80, 0x00, 0x03, 0x38, 0xC0, 0x00, 0x02 }, new byte[] { 0x38, 0x80, 0x00, 0x01, 0x38, 0xC0, 0x00, 0x00 });
                else if (modName == mc_list.B7ynh5lnsf1olwawc9z0e)
                {
                    if (value == 1)
                        useOP = true;
                    else if (value == 0)
                    {
                        useOP = false;
                        PS3.SetMemory(getOfs(mcOfs.Sayia8c4zq9hr7cis5i1w), new byte[] { 0x3F });
                    }
                    togIndex = setTog(value, togIndex, optMaxNorm);
                }
                else if (modName == mc_list.P5s6ysmgofoud2ygfnxo5)
                    togIndex = writeMem(modName, getOfs(mcOfs.tqr952rqa1uivrjni8642) + 3, value, new byte[] { 0x00 }, new byte[] { 0x01 });
                else if (modName == mc_list.Jeipi1z4yamd8dmir4whp)
                    togIndex = writeMem(modName, getOfs(mcOfs.Mtuiae00kqepn54lkixdv) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.J32axm662236lv0jxcy72)
                {
                    uint ofs = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientPlus;
                    if (value == 1)
                    {
                        useUfo = true;
                        PS3.SetMemory(getOfs(mcOfs.Xwuiht4s3yr1ywezdg0cm), new byte[] { 0xFC, 0x80, 0xF8, 0x90 });
                        PS3.SetMemory(ofs, new byte[] { 0x01 });
                        PS3.SetMemory(ofs - 1, new byte[] { 0x01 });
                        mapBoundsToggle(true);
                    }
                    else if (value == 0)
                    {
                        useUfo = false;
                        PS3.SetMemory(getOfs(mcOfs.Xwuiht4s3yr1ywezdg0cm), new byte[] { 0xFC, 0x20, 0xF8, 0x90 });
                        PS3.SetMemory(ofs, new byte[] { 0x00 });
                        PS3.SetMemory(ofs - 1, new byte[] { 0x00 });
                        mapBoundsToggle(false);
                    }
                    togIndex = setTog(value, togIndex, optMaxNorm);
                }
                else if (modName == mc_list.Esrn2lvappyl1q9blh165)
                    togIndex = writeMem(modName, getOfs(mcOfs.Sucfw0fs9tnlyy23dcmrn), value, new byte[] { 0x3F, 0x40, 0x00, 0x00 }, new byte[] { 0x3D, 0xCC, 0xCC, 0xCD });
                else if (modName == mc_list.F2b6hp1nmdvogyo6lphl0)
                    togIndex = writeMem(modName, getOfs(mcOfs.Qjvhpbtum0qnhjev490tg), value, new byte[] { 0x3F, 0xA4 }, new byte[] { 0x3F, 0x04 }, new byte[] { 0x3F, 0x74 }, new byte[] { 0x3F, 0xF4 });
                else if (modName == mc_list.Zwml3pnt1bugahiwscuwf)
                    togIndex = writeMem(modName, getOfs(mcOfs.Hu3msjsov6kdw5psdhi5t) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.Sc3u9bp4wcy12rcyragyg)
                    togIndex = writeMem(modName, getOfs(mcOfs.rtog1i5h7lencq2y8v6rz) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.j6mxxuimouu5ix0pd3jie)
                    togIndex = writeMem(modName, getOfs(mcOfs.zxmj2z8adclscm3hvkll8) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.o91kz2ahfc69zq89k9avn)
                    togIndex = writeMem(modName, getOfs(mcOfs.qe5mgpbi3rtkyw5x5tnvh), value, new byte[] { 0xFC, 0x80, 0xF0, 0x90 }, new byte[] { 0xFC, 0x20, 0xF0, 0x90 });
                else if (modName == mc_list.j4qykhxbuciczxoho3jv0)
                    togIndex = writeMem(modName, getOfs(mcOfs.Vlty3b63z3b4mxl2kwo03), value, new byte[] { 0x40 }, new byte[] { 0x41 });

                #endregion

                #region xxxxxxxxxxxx
                else if (modName == mc_list.oixm4kecbcz69qf9lz3yk)
                {
                    PS3.Extension.WriteInt16(getOfs(mcOfs.l8c4p76n13xdryza5pqhf), Convert.ToInt16(getTrackValue(value, 0x3E4C, 0x3000, 0x414C, optMax, 0x3000)));
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.Hlq024viyiqvrt9626xxx)
                {
                    double dft = .4;
                    double sValue;
                    if (value == 0)
                        sValue = dft;
                    else if (value == 1)
                        sValue = 0;
                    else
                        sValue = dft + (.4 * (value - 1));

                    PS3.Extension.WriteFloat(getOfs(mcOfs.K6azvecn6r6omoghwe7h9), (float)sValue);
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.I5rmdsf5wz7pk1c9qvgmu)
                {
                    PS3.Extension.WriteInt16(getOfs(mcOfs.smxawdk1rpxici4hqu03m), Convert.ToInt16(getTrackValue(value, 0x3FA9, 0x3F09, 0x4000, optMax)));
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.cj2u0y712cah84vzwg7ao)
                {
                    PS3.Extension.WriteInt16(getOfs(mcOfs.cbl63ijcec5put88wh8uf), Convert.ToInt16(getTrackValue(value, 0x4080, 0x4080, 0x4200, optMax, 0x3000)));
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.Zamndxbno1ets4zms2ua1)
                {
                    PS3.Extension.WriteInt16(getOfs(mcOfs.cpqaurkzj1tw6f8bxtvcf), Convert.ToInt16(getTrackValue(value, 0x3F80, 0x3F00, 0x4200, optMax, 0x3000)));
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.Fzqxw9xezx1ggajhcgxe0)
                {
                    PS3.Extension.WriteInt16(getOfs(mcOfs.Ucwka552zza30k0kx3evd), Convert.ToInt16(getTrackValue(value, 0x3F80, 0x3000, 0x4300, optMax)));
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.pft7pz466y20ka8r8sm0j)
                {
                    PS3.Extension.WriteInt16(getOfs(mcOfs.Sayia8c4zq9hr7cis5i1w), Convert.ToInt16(getTrackValue(value, 0x3F80, 0x3F00, 0x4200, optMax, 0x3000, true)));
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.zhnxk1bzlt4dvx35noh70)
                {
                    if (state == "button")
                    {
                        if (Regex.IsMatch(TS_TextBox[index - 1].Text, "^[0-9]+$"))
                        {
                            int xpValue;
                            if (!Int32.TryParse(TS_TextBox[index - 1].Text, out xpValue))
                            {
                                xpValue = 32767;
                                TS_TextBox[index - 1].Text = "" + 32767;
                            }

                            if (xpValue > 32767)
                            {
                                xpValue = 32767;
                                TS_TextBox[index - 1].Text = "" + 32767;
                            }
                            PS3.SetMemory(getOfs(mcOfs.g67e6dhan3zm8xbv5vw9t), new byte[] { 0x30, 0xA5 });
                            PS3.Extension.WriteInt16(getOfs(mcOfs.g67e6dhan3zm8xbv5vw9t) + 2, (short)xpValue);
                            sub1.Focus();
                            togIndex = 0;
                            MessageBox.Show("XP level: " + xpValue + "\nTo set, gain an enchantment level.", "XP Level", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    if (state == "btn")
                    {
                        PS3.SetMemory(getOfs(mcOfs.g67e6dhan3zm8xbv5vw9t), new byte[] { 0x7C, 0xA5, 0x20, 0x14 });
                        sub1.Focus();
                        togIndex = 0;
                        MessageBox.Show("XP Level: Default\nTo set, gain an enchantment level.", "XP Level", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                #endregion

                #region xxxxxxxxxxxx
                else if (modName == mc_list.nevn3yewhceukoa81w4qg)
                    togIndex = writeMem(modName, getOfs(mcOfs.F4s3hbcomzq4x43qwz04h), value, new byte[] { 0xBF, 0x80, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00 });
                else if (modName == mc_list.J3bcciwcy6dr1ukvzd6dz)
                    togIndex = writeMem(modName, getOfs(mcOfs.owwmmn4mr8tk3yih45m0h) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.Actlf91b8i6hmhvbf5j8n)
                    togIndex = writeMem(modName, getOfs(mcOfs.ki01d21ycbih6fznudvbm) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.Ngd2o6x0ytc2hti46kj0w)
                    togIndex = writeMem(modName, getOfs(mcOfs.li99tvn0kkkdeoqzqpwk8), value, new byte[] { 0x41 }, new byte[] { 0x40 });
                else if (modName == mc_list.zv1qw4q97hzablmsmmj3f)
                    togIndex = writeMem(modName, getOfs(mcOfs.sphzijgkhdmyqbtfri614) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.odzgcm4ljkrldfxow2wpf)
                    togIndex = writeMem(modName, getOfs(mcOfs.tyxjcch9zden3u7tbas3w) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.dp2y1vehugomi332mjth6)
                    togIndex = writeMem(modName, getOfs(mcOfs.Erq9zt14wt5lh4hx18wgc), value, new byte[] { 0x40 }, new byte[] { 0x41 });
                else if (modName == mc_list.Y4ps3qjv9w4avdiyg3yu9)
                    togIndex = writeMem(modName, getOfs(mcOfs.Ehue8945e9eq0cemhyusl) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.Husy17pucqsh3lbwb0vqc)
                    togIndex = writeMem(modName, getOfs(mcOfs.Vpbqi23cvvyjg1f176izd) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.Cw197o6ct9cpz70cgrzg6)
                    togIndex = writeMem(modName, getOfs(mcOfs.msxcfohm8qn4u8tbyud6g), value, new byte[] { 0x30, 0x00, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00 });
                else if (modName == mc_list.b0b1f223387hc93gtaxh4)
                    togIndex = writeMem(modName, getOfs(mcOfs.vrt3z8ld1anpgrtu6zl8e) + 3, value, new byte[] { 0x28 }, new byte[] { 0x18 });
                else if (modName == mc_list.Jixx5b4o0efb4seovn6kq)
                    togIndex = writeMem(modName, getOfs(mcOfs.Jt1rnmwms25z7cafns01f) + 1, value, new byte[] { 0x80 }, new byte[] { 0x20 });
                else if (modName == mc_list.ru8f2rqjqkbwtcwsujsch)
                    togIndex = writeMem(modName, PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientPlus, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.g4obuqj12fcjs3jz3cyb0)
                    togIndex = writeMem(modName, getOfs(mcOfs.amhsmcwfk1hyq7m01a8aa) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.Xgc9tokynfszeryppxki8)
                    togIndex = writeMem(modName, getOfs(mcOfs.Lh29nuptlpdfza82u88sm) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.Rtq4166twva06kxzrhuko)
                    togIndex = writeMem(modName, getOfs(mcOfs.s37lf9n278dzkmt9ikfkk) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.Mfu32preha4pp94hf78ry)
                    togIndex = writeMem(modName, getOfs(mcOfs.Bdki4i2cepg06qkaeswx5) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.Othezyqnvzigtflecqvot)
                    togIndex = writeMem(modName, getOfs(mcOfs.Mf8b8p2q7ejo76bsjr4oh) + 3, value, new byte[] { 0x01 }, new byte[] { 0x00 });
                else if (modName == mc_list.pc7k9x20eoixz10h2q8h8)
                    togIndex = writeMem(modName, getOfs(mcOfs.Ovq8ph3udxmml1zg907ne), value, new byte[] { 0xCF, 0x00, 0x00, 0x00 }, new byte[] { 0x3F, 0xEF, 0x5C, 0x29 });
                else if (modName == mc_list.yw9txgfg1tybq4opah0k1)
                    togIndex = writeMem(modName, getOfs(mcOfs.dfe84lzxi4mfjzjhwodlk), value, new byte[] { 0x30, 0x00, 0x00, 0x00 }, new byte[] { 0x3F, 0xB0, 0x00, 0x00 });
                else if (modName == mc_list.Zg7xbkud3rmyurbe5b9zw)
                    togIndex = writeMem(modName, getOfs(mcOfs.Ynmic0wfxgjuyz4blhr5r), value, new byte[] { 0x30, 0x00, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00 });
                else if (modName == mc_list.Bip03m2hrugd3b6lb0dkl)
                    togIndex = writeMem(modName, getOfs(mcOfs.D653yy2ola01q0cxsvzvu), value, new byte[] { 0x30, 0x00, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00 });
                else if (modName == mc_list.Bmooee4oud8jusrxoxiiy)
                    togIndex = writeMem(modName, getOfs(mcOfs.Gp98u9vix4xneehk13xxu), value, new byte[] { 0x30, 0x00, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00 });
                else if (modName == mc_list.icki88qr78yc8o0o4awyr)
                    togIndex = writeMem(modName, getOfs(mcOfs.g1jhldyxzdr59tu95ch15), value, new byte[] { 0x7F, 0x80, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00 });
                else if (modName == mc_list.Hiadgb99calt8tdbmw1bi)
                    togIndex = writeMem(modName, getOfs(mcOfs.ogydyql0iaip30euuu18e), value, new byte[] { 0x30, 0x00, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00 });
                else if (modName == mc_list.Zoq5a463pjh5c4lcg6h1g)
                    togIndex = writeMem(modName, getOfs(mcOfs.ho9lq5crlyas4oqfd9gjn), value, new byte[] { 0x41, 0x00, 0x00, 0x00 }, new byte[] { 0x3E, 0xCC, 0xCC, 0xCD });
                else if (modName == mc_list.Lj9g8xhehfqlzirvvt3ni)
                    togIndex = writeMem(modName, getOfs(mcOfs.Lvy99spq91gzkly2x3pcg) + 3, value, new byte[] { 0x00 }, new byte[] { 0x01 });
                else if (modName == mc_list.Amaugjz9ed9ol0fqjbujk)
                    togIndex = writeMem(modName, getOfs(mcOfs.u8pgkmz6mn4z3gfw280qa), value, new byte[] { 0x30, 0x00, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00 });
                else if (modName == mc_list.Than3faltidfssl6jo9z7)
                    togIndex = writeMem(modName, getOfs(mcOfs.Cqpskto9q35lzfs5syegb), value, new byte[] { 0x30, 0x00, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00 });
                else if (modName == mc_list.Ibis7tg8pktwx8rt1fcle)
                    togIndex = writeMem(modName, getOfs(mcOfs.ygmbd8bvcp5557o692aeg), value, new byte[] { 0x30, 0x00, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00 });
                else if (modName == mc_list.v3c05vtt4x9k972xziko0)
                    togIndex = writeMem(modName, getOfs(mcOfs.Cqpskto9q35lzfs5syegb), value, new byte[] { 0x40, 0x00, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00 });
                else if (modName == mc_list.j1aqgtccr5zogmq90hixs)
                    togIndex = writeMem(modName, getOfs(mcOfs.efl4z4r3hqvin0z55ddx7), value, new byte[] { 0x30, 0x00, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00 });
                else if (modName == mc_list.mjx38zu48czwjj3dybtyk)
                {
                    if ((int)value == 1)
                    {
                        PS3.SetMemory(getOfs(mcOfs.m9u1qxr6xguka5w54d9qc), new byte[] { 0x42, 0x00 });
                        PS3.SetMemory(getOfs(mcOfs.toy2j4l6py0nrp28ts1h1), new byte[] { 0xC0, 0x00 });
                    }
                    else if ((int)value == 0)
                    {
                        PS3.SetMemory(getOfs(mcOfs.m9u1qxr6xguka5w54d9qc), new byte[] { 0x3F, 0x80 });
                        PS3.SetMemory(getOfs(mcOfs.toy2j4l6py0nrp28ts1h1), new byte[] { 0x3F, 0x80 });
                    }
                    togIndex = setTog(value, togIndex, optMaxNorm);
                }
                else if (modName == mc_list.j9bve5kctaegbhr3cskvc)
                {
                    if ((int)value == 1)
                    {
                        PS3.SetMemory(getOfs(mcOfs.Urz29vmf5s1shkl9n3707), new byte[] { 0x3F, 0x80 });
                        PS3.SetMemory(getOfs(mcOfs.Ee7hc300pnrt4eratqp1m), new byte[] { 0x3F, 0xEE });
                    }
                    else if ((int)value == 0)
                    {
                        PS3.SetMemory(getOfs(mcOfs.Urz29vmf5s1shkl9n3707), new byte[] { 0x3F, 0x66, 0x66, 0x66 });
                        PS3.SetMemory(getOfs(mcOfs.Ee7hc300pnrt4eratqp1m), new byte[] { 0x3F, 0xE9, 0x99, 0x99 });
                    }
                    togIndex = writeMem(modName, getOfs(mcOfs.Obkt4zzjqburr564m6onl) + 3, value, new byte[] { 0x01, }, new byte[] { 0x00 });
                }
                else if (modName == mc_list.h8nezvhdn2kb45warp0rc)
                {
                    if (value == 1)
                    {
                        if (!usePS3notify)
                        {
                            sub1.Focus();
                            MessageBox.Show("webMan is required to use 'Near By Sounds'.\nPlease turn the notify on in 'Connection' tab.", "webMan Notify Needed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                        else
                            canListen = true;
                    }
                    else if (value == 0)
                        canListen = false;

                    togIndex = setTog(value, togIndex, optMaxNorm);
                }
                else if (modName == mc_list.Yc1opegxdjn4gvxg2pdgh)
                {
                    if ((int)value == 1)
                    {
                        if (PS3.Extension.ReadString(getOfs(mcOfs.Lhpvb05sk0dopf5u4qakf)) != "")
                            if (PS3.Extension.ReadString(getOfs(mcOfs.Lhpvb05sk0dopf5u4qakf)) != PS3.Extension.ReadString(getOfs(mcOfs.sx6si2n76p73uwk613zim)))
                            {
                                setName(PS3.Extension.ReadString(getOfs(mcOfs.Lhpvb05sk0dopf5u4qakf)), "");
                                sub1.Focus();
                                MessageBox.Show("Rejoin world to set.", "NOTICE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                sub1.Focus();
                                MessageBox.Show("You cannot imitate yourself!", "NOTICE", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        else
                        {
                            sub1.Focus();
                            MessageBox.Show("Cannot find host!", "NOTICE", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else if ((int)value == 0)
                        setName(name_backup, "");

                    togIndex = value;
                }
                #endregion

                #region xxxxxxxxxxxx
                else if (modName == mc_list.Rxq2ixva686g4qr0b39cv)
                {
                    short dftGH = 15692;
                    short dftXR = 16256;
                    if (value < 6)
                    {
                        int sValue;
                        if (value != 0)
                            sValue = dftGH + (value * 255);
                        else
                            sValue = dftGH;
                        PS3.Extension.WriteInt16(getOfs(mcOfs.u70ib9mnw7k0m0t2vj9ea), dftXR);
                        PS3.Extension.WriteInt16(getOfs(mcOfs.Yyivacli1is45llpsnbzs), Convert.ToInt16(sValue));
                    }
                    else
                    {
                        int sValue = -19456 + ((value - 5) * 255);
                        PS3.Extension.WriteInt16(getOfs(mcOfs.Yyivacli1is45llpsnbzs), dftGH);
                        PS3.Extension.WriteInt16(getOfs(mcOfs.u70ib9mnw7k0m0t2vj9ea), Convert.ToInt16(sValue));
                    }
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.Jnsrptn8ej3gsozrp3uel)
                {
                    int sValue;
                    if (value != 1)
                        sValue = 16256 + (value * 125);
                    else
                        sValue = 12288;
                    PS3.Extension.WriteInt16(getOfs(mcOfs.t51r4sfsbl71ez1yfgzqe), Convert.ToInt16(sValue));
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.Fsvmh7skwd3ph75r9sme5)
                {
                    double dft = 1;
                    double sValue;
                    if (value == 0)
                        sValue = dft;
                    else
                        sValue = dft - 1 + (.25 * (value - 1));

                    PS3.Extension.WriteFloat(getOfs(mcOfs.i97g5lo6awootfio89uaz), (float)sValue);
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.Dwkjtxwygaa30r1xnxbk7)
                {
                    if (value < 16)
                    {
                        int sValue;
                        if (value != 0)
                            sValue = 16329 - (value * 10);
                        else
                            sValue = 16329;
                        PS3.Extension.WriteInt16(getOfs(mcOfs.rq9f549f33k9yjalz8y1n), Convert.ToInt16(sValue));
                    }
                    else
                    {
                        int sValue = 16329 + ((value - 15) * 10);
                        PS3.Extension.WriteInt16(getOfs(mcOfs.rq9f549f33k9yjalz8y1n), Convert.ToInt16(sValue));
                    }
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.Rml7vyoyi0l4kbc3k0u03)
                {
                    writeMem(modName, getOfs(mcOfs.Alu2sual55vcme5ayparm), value, new byte[] { 0x40, 0x90, 0x00, 0x00 }, new byte[] { 0x30, 0x90, 0x00, 0x00 }, new byte[] { 0x3F, 0xD0, 0x00, 0x00 }, new byte[] { 0x42, 0x00, 0x00, 0x00 }, new byte[] { 0x45, 0x00, 0x00, 0x00 });
                    togIndex = writeMem(modName, getOfs(mcOfs.Hcuu4stjcytsoyo1t2pr6), value, new byte[] { 0x40, 0x08, 0x00, 0x00 }, new byte[] { 0x30, 0x08, 0x00, 0x00 }, new byte[] { 0x3F, 0xD0, 0x00, 0x00 }, new byte[] { 0x42, 0x08, 0x00, 0x00 }, new byte[] { 0x45, 0x08, 0x00, 0x00 });
                }
                else if (modName == mc_list.L8qpzfsyo8nxckr0jdsgm)
                    togIndex = writeMem(modName, getOfs(mcOfs.Pev8c7yco8f9jf16dqoy2), value, new byte[] { 0x00, 0x00 }, new byte[] { 0xBF, 0x00 }, new byte[] { 0xB0, 0x00 }, new byte[] { 0x3E, 0x50 }, new byte[] { 0x7F, 0x80 });
                else if (modName == mc_list.Jgchppl41vkxknzgkmx4j)
                    togIndex = writeMem(modName, getOfs(mcOfs.Yjncpaf9s9r3o4vx93mhd), value, new byte[] { 0x3E, 0x80 }, new byte[] { 0x7F, 0x00 }, new byte[] { 0x40, 0x00 }, new byte[] { 0x3E, 0x00 }, new byte[] { 0x30, 0x00 });
                else if (modName == mc_list.Nt7wqxt6m6s7czr40xrk6)
                    togIndex = writeMem(modName, getOfs(mcOfs.I8v382se2s4in6zsaunzv), value, new byte[] { 0x3F, 0x80, 0x00, 0x00, 0x3F, 0x80, 0x00, 0x00 }, new byte[] { 0x3F, 0x80, 0x00, 0x00, 0x4F, 0x00, 0x00, 0x00 }, new byte[] { 0x30, 0x80, 0x00, 0x00, 0x3F, 0x80, 0x00, 0x00 }, new byte[] { 0x30, 0x00, 0x00, 0x00, 0x30, 0x00, 0x00, 0x00 });
                else if (modName == mc_list.Dwlrqpun3wawvikzden3c)
                {
                    int sValue;
                    if (value != 0)
                        sValue = 16160 + (value * 255);
                    else
                        sValue = 16256;

                    PS3.Extension.WriteInt16(getOfs(mcOfs.Blwxxitorwe7mj6ml5ho4), Convert.ToInt16(sValue));
                    togIndex = setTog(value, togIndex, optMax);
                }

                else if (modName == mc_list.ttanaldwh136ypyjl8m3c)
                    togIndex = writeMem(modName, getOfs(mcOfs.tt020q94ufr13errxr4tv), value, new byte[] { 0x3F, 0x73, 0x33, 0x33, 0x3D, 0x4C, 0xCC, 0xCD, 0x3D, 0xCC, 0xCC, 0xCD, 0x3F, 0xC0, 0x00, 0x00, 0x3F, 0x26, 0x66, 0x66 }, new byte[] { 0x3F, 0x73, 0x33, 0x33, 0x3D, 0x4C, 0xCC, 0xCD, 0x30, 0xCC, 0xCC, 0xCD, 0x30, 0xC0, 0x00, 0x00, 0x3F, 0x26, 0x66, 0x66 }, new byte[] { 0x3F, 0x73, 0x33, 0x33, 0x4D, 0x4C, 0xCC, 0xCD, 0x3D, 0xCC, 0xCC, 0xCD, 0x3F, 0xC0, 0x00, 0x00, 0x3F, 0x26, 0x66, 0x66 }, new byte[] { 0x30, 0x73, 0x33, 0x33, 0x30, 0x4C, 0xCC, 0xCD, 0x3D, 0xCC, 0xCC, 0xCD, 0x3F, 0xC0, 0x00, 0x00, 0x3F, 0x26, 0x66, 0x66 }, new byte[] { 0x3F, 0x73, 0x33, 0x33, 0x3D, 0x4C, 0xCC, 0xCD, 0x3D, 0xCC, 0xCC, 0xCD, 0xD0, 0xC0, 0x00, 0x00, 0x3F, 0x26, 0x66, 0x66 });
                else if (modName == mc_list.Xhhj8juwg2w7pfacw8rel)
                    togIndex = writeMem(modName, getOfs(mcOfs.Pjer2fawq0now4ojuwkdv), value, new byte[] { 0x40, 0xC0, 0x00, 0x00, 0x3F, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x43, 0x7F, 0x00, 0x00 }, new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x00, 0x00, 0x00 }, new byte[] { 0x50, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x42, 0xA0, 0x00, 0x00 }, new byte[] { 0x50, 0x00, 0x00, 0x00, 0x41, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x42, 0x00, 0x00, 0x00 }, new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 });
                else if (modName == mc_list.Z8fb3e8gtbne1u04l0p10)
                    togIndex = writeMem(modName, getOfs(mcOfs.x50wpovez4pcne5z4p5f3), value, new byte[] { 0x3F, 0x80 }, new byte[] { 0x30, 0x00 }, new byte[] { 0x41, 0x00 }, new byte[] { 0xBF, 0x80 });
                else if (modName == mc_list.Jmrvp6kf2d3nat0lp5wbp)
                {
                    if (value < 6)
                    {
                        int sValue;
                        if (value != 0)
                            sValue = 16256 + (value * 75);
                        else
                            sValue = 16256;
                        PS3.Extension.WriteInt16(getOfs(mcOfs.oe37r8352jxa7vk4bng2j), Convert.ToInt16(sValue));
                    }
                    else
                    {
                        int sValue = 16256 - ((value - 5) * 75);
                        PS3.Extension.WriteInt16(getOfs(mcOfs.oe37r8352jxa7vk4bng2j), Convert.ToInt16(sValue));
                    }
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.b8r4hpy6ncrcggi99k29w)
                {
                    if (state == "button")
                    {
                        setAllHudColor();
                    }
                    if (state == "comboBox")
                    {
                        colorInt = TS_ComboBox[index].SelectedIndex;
                        indexAllHudColor();
                    }
                    togIndex = 0;
                }
                else if (modName == mc_list.h6xqao70qv0itw0d3k4mg)
                {
                    if (state == "button")
                    {
                        setName(TS_TextBox[index - 1].Text, "");
                        togIndex = 0;
                        MessageBox.Show("Name has been set!\n\nIf you are in a world then re-join for it to update.", "INFO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                #endregion

                #region xxxxxxxxxxxx
                else if (modName == mc_list.Qrqpe6qsowxnrirecfq3k)
                {
                    double dft = 1.87;
                    double sValue;
                    if (value == 0)
                        sValue = dft;
                    else if (value == 1)
                        sValue = dft - 1;
                    else
                        sValue = dft + (.01 * (value - 1));

                    PS3.Extension.WriteFloat(getOfs(mcOfs.Ovq8ph3udxmml1zg907ne), (float)sValue);
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.qoceosf5pg05s0n4sz76y)
                {
                    double dft = .91;
                    double sValue;
                    if (value == 0)
                        sValue = dft;
                    else
                        sValue = dft - (.15 * (value - 1));

                    PS3.Extension.WriteFloat(getOfs(mcOfs.a6p845zb4pfbsfurk2swl), (float)sValue);
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.rq16naxsdw1fkwqmolbv0)
                {
                    double dft = 1.65;
                    double sValue;
                    if (value == 0)
                        sValue = dft;
                    else if (value == 1)
                        sValue = 0;
                    else
                        sValue = dft + (.20 * (value - 1));

                    PS3.Extension.WriteFloat(getOfs(mcOfs.lkbaty4m5ky0af6gpqswc), (float)sValue);
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.ovdi62415wwmitf4wg1o5)
                {
                    double dft = 1.825;
                    double sValue;
                    if (value == 0)
                        sValue = dft;
                    else if (value == 1)
                        sValue = -0.1;
                    else
                        sValue = dft + (.1 * (value - 1));

                    PS3.Extension.WriteFloat(getOfs(mcOfs.Ee7hc300pnrt4eratqp1m), (float)sValue);
                    togIndex = setTog(value, togIndex, optMax);
                }
                else if (modName == mc_list.kx12ouv6japhylgcmt9vf)
                {
                    double dft = .9;
                    double sValue;
                    if (value == 0)
                        sValue = dft;
                    else
                        sValue = dft + (.2 * (value));

                    PS3.Extension.WriteFloat(getOfs(mcOfs.Urz29vmf5s1shkl9n3707), (float)sValue);
                    togIndex = setTog(value, togIndex, optMax);
                }
                #endregion

                #region ultmods
                else if (modName != "ultmods")
                {
                    try
                    {
                        Type thisType = ult.GetType();
                        string mod = "nadaaa";
                        for (int i = 0; i < xxxxxxxxx.Count; i++)
                        {
                            if (xxxxxxxxx[i] == modName)
                            {
                                mod = mc_listX[i];
                                break;
                            }
                        }
                        MethodInfo theMethod = thisType
                            .GetMethod(mod, BindingFlags.Public | BindingFlags.Instance);
                        togIndex = (int)theMethod.Invoke(ult, new object[] { value });
                    }
                    catch
                    {

                    }
                }
                #endregion
            }
            else
            {
                if (checkCon)
                {
                    DialogResult ync = MessageBox.Show("You are NOT connected or attached to your PS3!\nPlease connect and attach to use an option.\n\nContinue showing this pop-up?", "No Connection", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                    if (ync == DialogResult.No)
                        checkCon = false;
                }
            }
            return togIndex;
        }
        #endregion

        #region functions
        int getTrackValue(int val, ushort dftVal, ushort minVal, ushort maxVal, int trackMax)
        {
            int sValue;
            if (val != 0)
                sValue = minVal + (val * ((maxVal - minVal) / trackMax));
            else
                sValue = dftVal;
            return sValue;
        }
        int getTrackValue(int val, ushort dftVal, ushort minVal, ushort maxVal, int trackMax, ushort overrideVal_1)
        {
            int sValue;
            if (val == 1)
                sValue = overrideVal_1;
            else if (val != 0)
                sValue = minVal + (val * ((maxVal - minVal) / trackMax));
            else
                sValue = dftVal;
            return sValue;
        }
        int getTrackValue(int val, ushort dftVal, ushort minVal, ushort maxVal, int trackMax, ushort overrideVal_1, bool reverse)
        {
            int sValue;
            if (val == 10)
                sValue = overrideVal_1;
            else if (val != 0)
                sValue = maxVal - (val * ((maxVal - minVal) / trackMax));
            else
                sValue = dftVal;
            return sValue;
        }

        public static Color ChangeColorBrightness(Color color, float correctionFactor)
        {
            float red = (float)color.R;
            float green = (float)color.G;
            float blue = (float)color.B;

            if (correctionFactor < 0)
            {
                correctionFactor = 1 + correctionFactor;
                red *= correctionFactor;
                green *= correctionFactor;
                blue *= correctionFactor;
            }
            else
            {
                red = (255 - red) * correctionFactor + red;
                green = (255 - green) * correctionFactor + green;
                blue = (255 - blue) * correctionFactor + blue;
            }

            return Color.FromArgb(color.A, (int)red, (int)green, (int)blue);
        }

        private void PS3api()
        {
            if (PS3.GetCurrentAPIName() == "Target Manager")
                PS3.ConnectTarget(targetIndex - 1);
            else if (PS3.GetCurrentAPIName() == "Control Console")
                for (int i = 0; i < 10; i++)
                    PS3.ConnectTarget(ps3IP);
            else if (PS3.GetCurrentAPIName() == "PS3 Manager")
                PS3.ConnectTarget(ps3IP, true);
        }

        private void mapBoundsToggle(bool toggle)
        {
            byte[] hud;
            byte[] bounds;
            if (toggle)
            {
                hud = new byte[] { 0xBF, 0x80, 0x00, 0x00 };
                bounds = new byte[] { 0xFC, 0x80 };
            }
            else
            {
                hud = new byte[] { 0x3F, 0x80, 0x00, 0x00 };
                bounds = new byte[] { 0xFC, 0x20 };
            }
            PS3.SetMemory(getOfs(mcOfs.pl6etshyst8hzuoq5rewq), hud);
            PS3.SetMemory(getOfs(mcOfs.Ia5purh5uawh30r5g1kox), bounds);
            PS3.SetMemory(getOfs(mcOfs.Xykgzo4i5xfhy4flb4wzp), bounds);
            PS3.SetMemory(getOfs(mcOfs.R3y0soqjplyp2r10zyzfw), bounds);
            PS3.SetMemory(getOfs(mcOfs.R9964os9uf4mfv939uyl8), bounds);
            PS3.SetMemory(getOfs(mcOfs.au2u80ogcpwmfqcq415d6), bounds);
            PS3.SetMemory(getOfs(mcOfs.Trykqmkhs80faohcho8e9), bounds);
        }
        private void setLocation(float x, float y, float z, bool fallDamage)
        {
            double[] xyz1 = { x, y, z };
            double[] xyz2 = { x + .6, y + 1.8, z + .6 };
            List<byte> xyzBytes = new List<byte>();
            for (int i = 0; i < 3; i++)
            {
                byte[] rev1 = BitConverter.GetBytes(xyz1[i]);
                Array.Reverse(rev1);
                xyzBytes.AddRange(rev1);
            }
            for (int i = 0; i < 3; i++)
            {
                byte[] rev2 = BitConverter.GetBytes(xyz2[i]);
                Array.Reverse(rev2);
                xyzBytes.AddRange(rev2);
            }
            bool checkOfs = false;
            uint ofs = getOfs(mcOfs.vrt3z8ld1anpgrtu6zl8e);
            if (!fallDamage)
            {
                if (PS3.Extension.ReadUInt32(ofs) == 0x41820018)
                {
                    checkOfs = true;
                    PS3.Extension.WriteUInt32(ofs, 0x41820028);
                }
            }
            PS3.SetMemory(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + 0x158), xyzBytes.ToArray());
            if (checkOfs && !fallDamage)
            {
                Task.Delay(500).Wait();
                PS3.Extension.WriteUInt32(ofs, 0x41820018);
            }
        }
        private void setLocation(float x, float y, float z)
        {
            double[] xyz1 = { x, y, z };
            double[] xyz2 = { x + .6, y + 1.8, z + .6 };
            List<byte> xyzBytes = new List<byte>();
            for (int i = 0; i < 3; i++)
            {
                byte[] rev1 = BitConverter.GetBytes(xyz1[i]);
                Array.Reverse(rev1);
                xyzBytes.AddRange(rev1);
            }
            for (int i = 0; i < 3; i++)
            {
                byte[] rev2 = BitConverter.GetBytes(xyz2[i]);
                Array.Reverse(rev2);
                xyzBytes.AddRange(rev2);
            }
            PS3.SetMemory(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + 0x158), xyzBytes.ToArray());
        }

        private void setLocation(float x, float y, float z, float yPlus)
        {
            double[] xyz1 = { x, y, z };
            double[] xyz2 = { x + .6, y + yPlus, z + .6 };
            List<byte> xyzBytes = new List<byte>();
            for (int i = 0; i < 3; i++)
            {
                byte[] rev1 = BitConverter.GetBytes(xyz1[i]);
                Array.Reverse(rev1);
                xyzBytes.AddRange(rev1);
            }
            for (int i = 0; i < 3; i++)
            {
                byte[] rev2 = BitConverter.GetBytes(xyz2[i]);
                Array.Reverse(rev2);
                xyzBytes.AddRange(rev2);
            }
            PS3.SetMemory(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + 0x158), xyzBytes.ToArray());
        }

        private void doTeleport(string xyz)
        {
            try
            {
                string[] split = Regex.Split(xyz, ",");
                setLocation(Convert.ToInt32(split[0]), Convert.ToInt32(split[1]), Convert.ToInt32(split[2]), false);
            }
            catch
            {
                MessageBox.Show("Input: " + xyz + " is not valid.\n\nAn example of a valid input is: 123,45,678", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        string hexColor(Color cRGB)
        {
            uint index = 0x3D00;
            double interval = 3.0117;
            double hexR = cRGB.R * interval + index;
            double hexG = cRGB.G * interval + index;
            double hexB = cRGB.B * interval + index;
            double hexA = cRGB.A * interval + index;
            string getHexR = String.Format("{0:X}", Convert.ToUInt32(hexR));
            string getHexG = String.Format("{0:X}", Convert.ToUInt32(hexG));
            string getHexB = String.Format("{0:X}", Convert.ToUInt32(hexB));
            return getHexR + "0000" + getHexG + "0000" + getHexB + "0000";
        }
        Color rainbowRGB(int[] changeRGB, int changeVal)
        {
            if (changeRGB[0] == 255 && changeRGB[1] < 255 && changeRGB[2] == 0)
                changeRGB[1] += changeVal;
            else if (changeRGB[0] > 0 && changeRGB[1] == 255 && changeRGB[2] == 0)
                changeRGB[0] -= changeVal;
            else if (changeRGB[0] == 0 && changeRGB[1] == 255 && changeRGB[2] < 255)
                changeRGB[2] += changeVal;
            else if (changeRGB[0] == 0 && changeRGB[1] > 0 && changeRGB[2] == 255)
                changeRGB[1] -= changeVal;
            else if (changeRGB[0] < 255 && changeRGB[1] == 0 && changeRGB[2] == 255)
                changeRGB[0] += changeVal;
            else if (changeRGB[0] == 255 && changeRGB[1] == 0 && changeRGB[2] > 0)
                changeRGB[2] -= changeVal;

            return Color.FromArgb(changeRGB[0], changeRGB[1], changeRGB[2]);
        }

        private void setAllHudColor()
        {
            sub1.Focus();
            rgb.FullOpen = true;
            if (rgb.ShowDialog() == DialogResult.OK)
            {
                PS3.SetMemory(getOfs(mcOfs.E4usndy0d9xxxv2v3mem9), ConvertHexToBytes(hexColor(rgb.Color)));
            }
        }
        private void indexAllHudColor()
        {
            if (colorInt == 0)
                PS3.SetMemory(getOfs(mcOfs.E4usndy0d9xxxv2v3mem9), new byte[] { 0x3F, 0x80, 0x00, 0x00, 0x3F, 0x80, 0x00, 0x00, 0x3F, 0x80, 0x00, 0x00 });
        }
        private void timer2_Tick(object sender, EventArgs e)
        {

        }

        private void takeDamage()
        {
            int getY = (int)playerPos()[1];

            bool checkOfs = false;
            uint ofs = getOfs(mcOfs.vrt3z8ld1anpgrtu6zl8e);
            if (PS3.Extension.ReadUInt32(ofs) == 0x41820028)
            {
                checkOfs = true;
                PS3.Extension.WriteUInt32(ofs, 0x41820018);
            }

            for (int i = 0; i < 3; i++)
            {
                setLocation((int)playerPos()[0], 500, (int)playerPos()[2], true);
                Task.Delay(100).Wait();
                setLocation((int)playerPos()[0], getY, (int)playerPos()[2], true);
                Task.Delay(100).Wait();
                getY = (int)playerPos()[1];
                Task.Delay(100).Wait();
            }
            if (checkOfs)
            {
                Task.Delay(500).Wait();
                PS3.Extension.WriteUInt32(ofs, 0x41820028);
            }
        }
        private void setRegen(bool tog)
        {
            byte[] buffer;
            if (tog)
                buffer = new byte[] { 0xFC, 0x80 };
            else
                buffer = new byte[] { 0xFC, 0x20 };
            PS3.SetMemory(getOfs(mcOfs.B919d8aaiopdlyinhye8a), buffer);
        }
        private void setName(string name, string color)
        {
            List<byte> addB = new List<byte>();
            if (color != "")
                addB.AddRange(new byte[] { 0xC2, 0xA7 });
            addB.AddRange(Encoding.ASCII.GetBytes(color + name + "\0"));
            PS3.SetMemory(getOfs(mcOfs.sx6si2n76p73uwk613zim), addB.ToArray());
        }
        float[] playerPos()
        {
            uint ofs = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientStruct.origin;
            int x = (int)PS3.Extension.ReadDouble(ofs);
            int y = (int)PS3.Extension.ReadDouble(ofs + 0x10);
            return new float[] { (x > 0) ? x : x - 1, (float)Math.Round(PS3.Extension.ReadDouble(ofs + 0x08)) + 1, (y > 0) ? y : y - 1 };
        }
        float[] playerPos(float yPlus)
        {
            uint ofs = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientOrg;
            int x = (int)PS3.Extension.ReadDouble(ofs);
            int y = (int)PS3.Extension.ReadDouble(ofs + 0x10);
            return new float[] { (x > 0) ? x : x - 1, (float)Math.Round(PS3.Extension.ReadDouble(ofs + 0x08)) + yPlus, (y > 0) ? y : y - 1 };
        }
        uint _getOfs(uint num)
        {
            return num;
        }
        uint getOfs(int num)
        {
            return ins1[num];
        }

        #endregion

        #region writeMem
        int writeMem(string notifyTxt, uint offset, object index, byte[] arrayOn, byte[] arrayOff)
        {
            if ((int)index == 1)
            {
                PS3.SetMemory(offset, arrayOn);
                return 0;
            }
            else if ((int)index == 0)
            {
                PS3.SetMemory(offset, arrayOff);
                return 1;
            }
            else
                return 0;
        }

        int writeMem(string notifyTxt, uint offset, object index, byte[] array1, byte[] array2, byte[] array3, byte[] array4)
        {
            if ((int)index == 0)
            {
                PS3.SetMemory(offset, array1);
                return 1;
            }
            else if ((int)index == 1)
            {
                PS3.SetMemory(offset, array2);
                return 2;
            }
            else if ((int)index == 2)
            {
                PS3.SetMemory(offset, array3);
                return 3;
            }
            else if ((int)index == 3)
            {
                PS3.SetMemory(offset, array4);
                return 0;
            }
            else
                return 0;
        }

        int writeMem(string notifyTxt, uint offset, object index, byte[] array1, byte[] array2, byte[] array3, byte[] array4, byte[] array5)
        {
            if ((int)index == 0)
            {
                PS3.SetMemory(offset, array1);
                return 1;
            }
            else if ((int)index == 1)
            {
                PS3.SetMemory(offset, array2);
                return 2;
            }
            else if ((int)index == 2)
            {
                PS3.SetMemory(offset, array3);
                return 3;
            }
            else if ((int)index == 3)
            {
                PS3.SetMemory(offset, array4);
                return 4;
            }
            else if ((int)index == 4)
            {
                PS3.SetMemory(offset, array5);
                return 0;
            }
            else
                return 0;
        }

        #endregion

        #region notify
        bool usePS3notify = false;
        bool monNotify = false;
        string notifyIp = "";
        int wait5Secs = 0;

        private void runNotify(string txt)
        {
            if (usePS3notify && canUseTool && wait5Secs == 0)
                try
                {
                    new WebClient().DownloadString("http://" + notifyIp + "/notify.ps3mapi?msg=" + txt);
                    wait5Secs = 1;
                }
                catch
                {
                    usePS3notify = false;
                    MessageBox.Show("Did not notify PS3!\n\nPossible reasons why:\n1) Invalid IP\n2) webMan disabled\n3) webMan version incompatible", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            wait5Secs = 0;
            timer3.Stop();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            textBox3.Enabled = checkBox2.Checked;
            monNotify = checkBox2.Checked;
            usePS3notify = checkBox2.Checked;
        }
        #endregion

        #region Button Monitoring
        private class btnOfs
        {
            public static uint
                _L2 = 0xF0,
                _R2 = 0xF1,
                R1 = 0xB3,
                R2 = 0xB1,
                R3 = 0xB2,
                L1 = 0xB3,
                L2 = 0xB1,
                L3 = 0xB2,
                DpadUp = 0xB2,
                DpadDown = 0xB2,
                DpadLeft = 0xB2,
                DpadRight = 0xB2,
                Cross = 0xB3,
                Square = 0xB3,
                Circle = 0xB3,
                Triangle = 0xB3,
                Select = 0xB3,
                Start = 0xB3;
        }
        private class btnByte
        {
            public static byte
                R1 = 0x40,
                R2 = 0x40,
                R3 = 0x01,
                L1 = 0x80,
                L2 = 0x80,
                L3 = 0x02,
                DpadUp = 0x04,
                DpadDown = 0x08,
                DpadLeft = 0x10,
                DpadRight = 0x20,
                Cross = 0x01,
                Square = 0x04,
                Circle = 0x02,
                Triangle = 0x08,
                Select = 0x20,
                Start = 0x10;
        }
        private bool buttonPressed(uint MCoffset, byte Mcbyte)
        {
            if (PS3.Extension.ReadByte(getOfs(mcOfs.Ekmhsbqyxhsph9innotiz) + MCoffset) == Mcbyte)
                return true;
            else
                return false;
        }
        private bool buttonPressed(uint MCoffset, int lowerThan)
        {
            if (PS3.Extension.ReadByte(getOfs(mcOfs.Ekmhsbqyxhsph9innotiz) + MCoffset) > lowerThan)
                return true;
            else
                return false;
        }
        #endregion

        #region auto struct
        private void setReach(int index)
        {
            writeMem("Action Reach", getOfs(mcOfs.Alu2sual55vcme5ayparm), index, new byte[] { 0x40, 0x90, 0x00, 0x00 }, new byte[] { 0x30, 0x90, 0x00, 0x00 }, new byte[] { 0x3F, 0xD0, 0x00, 0x00 }, new byte[] { 0x42, 0x00, 0x00, 0x00 }, new byte[] { 0x45, 0x00, 0x00, 0x00 });
            writeMem("Action Reach", getOfs(mcOfs.Hcuu4stjcytsoyo1t2pr6), index, new byte[] { 0x40, 0x08, 0x00, 0x00 }, new byte[] { 0x30, 0x08, 0x00, 0x00 }, new byte[] { 0x3F, 0xD0, 0x00, 0x00 }, new byte[] { 0x42, 0x08, 0x00, 0x00 }, new byte[] { 0x45, 0x08, 0x00, 0x00 });
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                useBuild = true;
                buildMods(true);
            }
            else
            {
                useBuild = false;
                canBuild = false;
                buildMods(false);
                setReach(0);
                PS3.SetMemory(getOfs(mcOfs.Wd6s3e56y5w9b0kupfiqq) + 3, new byte[] { 0x01 });
                crosshairColor(Color.DodgerBlue, true);
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            structS = (int)numericUpDown1.Value;
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            structH = (int)numericUpDown2.Value;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1) Click 'Use Build' check box\n2) Choose a size and height(each increament = one block)\n3) Move your camera with R3 to pick your screen angle. The zhlmr5jon6rvh88ucneed will change colors depending on your angle (Blue = Straight, Yellow = Diagonal)\n4) Once you are ready to build, press the 'L2' & 'R2' at the same time on your bhvagnzd12ds02wkmx6aq to start building\n\nAdditional Notes:\nTo stop building, press the 'X' button on your bhvagnzd12ds02wkmx6aq.\nMake sure you're on ground before you start building.\nThe Auto-build structure will build clock-wise(Starting at the bottom left corner). When using this on someone's world, you will need to have enough blocks to cover the size and height. For your own world, you only need one block. This only works in Survival.\n\nAuto-build Structure created by MayhemModding\nAuto-build offset founded by DublinModz", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        bool useBuild = false;
        bool canBuild = false;
        int structH = 0;
        int structS = 0;
        string compass = "n";
        int buildProg = 0;
        int buildProgMax = 0;
        bool useBuildProg = false;
        int[] structShape(string angle, int index)
        {
            int[] xyz = { 0, 0, 0 };
            if (angle == "n")
            {
                if (index == 0)
                    xyz = compassNav("n");
                else if (index == 1)
                    xyz = compassNav("e");
                else if (index == 2)
                    xyz = compassNav("s");
                else if (index == 3)
                    xyz = compassNav("w");
            }
            else if (angle == "e")
            {
                if (index == 0)
                    xyz = compassNav("e");
                else if (index == 1)
                    xyz = compassNav("s");
                else if (index == 2)
                    xyz = compassNav("w");
                else if (index == 3)
                    xyz = compassNav("n");
            }
            else if (angle == "s")
            {
                if (index == 0)
                    xyz = compassNav("s");
                else if (index == 1)
                    xyz = compassNav("w");
                else if (index == 2)
                    xyz = compassNav("n");
                else if (index == 3)
                    xyz = compassNav("e");
            }
            else if (angle == "w")
            {
                if (index == 0)
                    xyz = compassNav("w");
                else if (index == 1)
                    xyz = compassNav("n");
                else if (index == 2)
                    xyz = compassNav("e");
                else if (index == 3)
                    xyz = compassNav("s");
            }
            else if (angle == "ne")
            {
                if (index == 0)
                    xyz = compassNav("ne");
                else if (index == 1)
                    xyz = compassNav("se");
                else if (index == 2)
                    xyz = compassNav("sw");
                else if (index == 3)
                    xyz = compassNav("nw");
            }
            else if (angle == "se")
            {
                if (index == 0)
                    xyz = compassNav("se");
                else if (index == 1)
                    xyz = compassNav("sw");
                else if (index == 2)
                    xyz = compassNav("nw");
                else if (index == 3)
                    xyz = compassNav("ne");
            }
            else if (angle == "sw")
            {
                if (index == 0)
                    xyz = compassNav("sw");
                else if (index == 1)
                    xyz = compassNav("nw");
                else if (index == 2)
                    xyz = compassNav("ne");
                else if (index == 3)
                    xyz = compassNav("se");
            }
            else if (angle == "nw")
            {
                if (index == 0)
                    xyz = compassNav("nw");
                else if (index == 1)
                    xyz = compassNav("ne");
                else if (index == 2)
                    xyz = compassNav("se");
                else if (index == 3)
                    xyz = compassNav("sw");
            }
            return xyz;
        }

        int[] compassNav(string direction)
        {
            double[] xyz = { 100, 100, 100 };
            if (direction == "n")
                xyz = new double[] { getNum(mcNum.num1_1), getNum(mcNum.num1_2), getNum(mcNum.num1_3) };
            else if (direction == "e")
                xyz = new double[] { getNum(mcNum.num2_1), getNum(mcNum.num2_2), getNum(mcNum.num2_3) };
            else if (direction == "s")
                xyz = new double[] { getNum(mcNum.num3_1), getNum(mcNum.num3_2), getNum(mcNum.num3_3) };
            else if (direction == "w")
                xyz = new double[] { getNum(mcNum.num4_1), getNum(mcNum.num4_2), getNum(mcNum.num4_3) };
            else if (direction == "ne")
                xyz = new double[] { getNum(mcNum.num5_1), getNum(mcNum.num5_2), getNum(mcNum.num5_3) };
            else if (direction == "se")
                xyz = new double[] { getNum(mcNum.num6_1), getNum(mcNum.num6_2), getNum(mcNum.num6_3) };
            else if (direction == "sw")
                xyz = new double[] { getNum(mcNum.num7_1), getNum(mcNum.num7_2), getNum(mcNum.num7_3) };
            else if (direction == "nw")
                xyz = new double[] { getNum(mcNum.num8_1), getNum(mcNum.num8_2), getNum(mcNum.num8_3) };
            return new int[] { (int)xyz[0], (int)xyz[1], (int)xyz[2] };
        }

        private void buildMods(bool useMods)
        {
            if (useMods)
                PS3.SetMemory(getOfs(mcOfs.Wd6s3e56y5w9b0kupfiqq) + 3, new byte[] { 0x00 });
            else
            {
                PS3.SetMemory(getOfs(mcOfs.Yjncpaf9s9r3o4vx93mhd), new byte[] { 0x3E, 0x80 });
                PS3.SetMemory(getOfs(mcOfs.li99tvn0kkkdeoqzqpwk8), new byte[] { 0x40 });
                PS3.SetMemory(getOfs(mcOfs.tyxjcch9zden3u7tbas3w) + 3, new byte[] { 0x00 });
                buildProgMax = 0;
                buildProg = 0;
                useBuildProg = false;
            }
        }
        float[] playerView(uint ofs)
        {
            float[] view = PS3.Extension.ReadFloats(ofs, 2);

            float math1 = view[0] / 360;
            float math2 = view[0] - 360 * (int)math1;
            float math3 = math2;
            if (math2 < 0)
                math3 = Math.Abs(math2 - math2 - 180 - math2) + 180;

            return new float[] { math3, view[0] };
        }
        string compassStr()
        {
            double view = (double)playerView(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientView)[0];
            if (view >= getNum(mcNum.num10_1) && view < getNum(mcNum.num10_2))
                return "n";
            else if (view >= getNum(mcNum.num11_1) && view < getNum(mcNum.num11_2))
                return "ne";
            else if (view >= getNum(mcNum.num12_1) && view < getNum(mcNum.num12_2))
                return "e";
            else if (view >= getNum(mcNum.num13_1) && view < getNum(mcNum.num13_2))
                return "se";
            else if (view >= getNum(mcNum.num14_1) || view < getNum(mcNum.num14_2))
                return "s";
            else if (view >= getNum(mcNum.num15_1) && view < getNum(mcNum.num15_2))
                return "sw";
            else if (view >= getNum(mcNum.num16_1) && view < getNum(mcNum.num16_2))
                return "w";
            else if (view >= getNum(mcNum.num17_1) && view < getNum(mcNum.num17_2))
                return "nw";
            else
                return "n";
        }
        private void crosshairColor(Color color, bool defaultColor)
        {
            uint ofs = PS3.Extension.ReadUInt32(getOfs(mcOfs.zhlmr5jon6rvh88ucneed));
            if (PS3.Extension.ReadString(ofs + 0x80).Contains("Crosshair"))
            {
                if (defaultColor)
                    PS3.SetMemory(ofs + 0x60, ConvertHexToBytes("3F8000003F8000003F800000"));
                else
                    PS3.SetMemory(ofs + 0x60, ConvertHexToBytes(hexColor(color)));
            }
        }
        private void runStruct()
        {
            if (useBuild)
            {
                if (!canBuild)
                {
                    compass = compassStr();

                    if (compass == "n" || compass == "e" || compass == "s" || compass == "w")
                        crosshairColor(Color.Blue, false);
                    else if (compass == "ne" || compass == "se" || compass == "sw" || compass == "nw")
                        crosshairColor(Color.Yellow, false);
                    if (buttonPressed(btnOfs._L2, 0) && buttonPressed(btnOfs._R2, 0))
                        canBuild = true;
                }
                else
                    buildStruct(structS, structH, compass);
            }
        }
        private void setView(uint ofs, float val)
        {
            PS3.Extension.WriteFloat(ofs, val);
        }
        private void lockView(uint ofs, float[] view)
        {
            double sumH = view[0];
            double sumV = 90;
            if (sumH < 361 && sumH > -1)
                setView(ofs + clientView2, (float)sumH);
            if (sumV < 91 && sumV > -91)
                setView(ofs + clientView2 + 4, (float)sumV);
        }

        private void buildStruct(int size, int height, string angle)
        {
            uint ofs = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44);
            PS3.SetMemory(ofs + clientPlus - 1, new byte[] { 0x01, 0x01 });
            PS3.SetMemory(getOfs(mcOfs.Yjncpaf9s9r3o4vx93mhd), new byte[] { 0x30, 0x00 });
            Task.Delay(200).Wait();
            size += 1;
            float[] view = playerView(ofs + clientView);
            float[] pos = playerPos();
            double baseH = pos[1] + height;
            setReach(4);
            int len = 4;
            buildProgMax = len * size;
            buildProg = 0;
            useBuildProg = true;
            for (int x = 0; x < len; x++)
            {
                int[] xyzNum = structShape(angle, x);
                for (int i = 0; i < size; i++)
                {
                    buildProg++;
                    lockView(ofs, view);
                    PS3.SetMemory(getOfs(mcOfs.li99tvn0kkkdeoqzqpwk8), new byte[] { 0x41 });
                    PS3.SetMemory(getOfs(mcOfs.tyxjcch9zden3u7tbas3w) + 3, new byte[] { 0x01 });
                    while (true)
                    {
                        lockView(ofs, view);
                        if (playerPos()[1] > baseH || !canBuild)
                            break;
                    }
                    PS3.SetMemory(getOfs(mcOfs.li99tvn0kkkdeoqzqpwk8), new byte[] { 0x40 });
                    PS3.SetMemory(getOfs(mcOfs.tyxjcch9zden3u7tbas3w) + 3, new byte[] { 0x00 });

                    if (x == len - 1 && i == size - 1 || !canBuild)
                        break;
                    pos[0] += xyzNum[0];
                    pos[2] += xyzNum[2];
                    setLocation((int)pos[0], (int)pos[1] - 1, (int)pos[2]);
                    Task.Delay(200).Wait();
                }
                if (!canBuild)
                    break;
            }
            canBuild = false;
            useBuildProg = false;
            setReach(0);
            buildMods(false);
        }

        private void button39_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1) Click 'Use Build' check box\n2) Choose a size and height(each increament = one block)\n3) Move your camera with R3 to pick your screen angle. The zhlmr5jon6rvh88ucneed will change colors depending on your angle (Blue = Straight, Yellow = Diagonal)\n4) Once you are ready to build, press the 'L2' & 'R2' at the same time on your SBKAXWZbE25mVclDr3Hfp to start building\n\nAdditional Notes:\nTo stop building, press the 'X' button on your SBKAXWZbE25mVclDr3Hfp.\nMake sure you're on ground before you start building.\nThe Auto-build structure will build clock-wise(Starting at the bottom left corner). When using this on someone's world, you will need to have enough blocks to cover the size and height. For your own world, you only need one block. This only works in Survival.\n\nAuto-build Structure created by MayhemModding\nAuto-build offset founded by DublinModz", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        #endregion

        #region player Opts
        private void button23_Click(object sender, EventArgs e)
        {
            MessageBox.Show("God Mode / Invisiblity - Glitch\n\nTo activate this mod properly you have to take damage quickly. Keep pressing the 'Take Damage' button until a message says that you have fallen to your death (Make sure you're in a open area before pressing). To verify that you're in God Mode, you will still be alive after you see the death message.", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            setRegen(true);
            Task.Delay(1000).Wait();
            takeDamage();
            Task.Delay(1000).Wait();
            setRegen(false);
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            godOpt = checkBox5.Checked;
            setOpt("god", godOpt);
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            pickBlock = checkBox4.Checked;
            setOpt("pick", pickBlock);
        }

        private void buttonuse_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1) Click 'Enable' checkbox\n2) Searching for user host will start (May take awhile)\n\nNOTE: If not working properly try restart game and/or application.", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private const string chars_ = "123456789";
        private const string chars = "abcdef0123456789";
        private readonly Random _rng = new Random();

        private string RandomString(int size)
        {
            char[] buffer = new char[size];

            for (int i = 0; i < size; i++)
            {
                buffer[i] = chars[_rng.Next(chars.Length)];
            }
            return new string(buffer);
        }
        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            usePlayerOpts = checkBox6.Checked;
        }

        string[] canUpdateTxt = new string[100];
        bool canUpdate(int index, string txt)
        {
            if (canUpdateTxt[index] != txt)
            {
                canUpdateTxt[index] = txt;
                return true;
            }
            else
                return false;
        }
        uint saveHostOfs = 0;
        bool pickBlock = false;
        bool godOpt = false;
        int xpNum = 0;
        bool usePlayerOpts = false;

        bool canShowCoor = false;

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            xpNum = (int)numericUpDown3.Value;
            setOpt("xp", true);
        }

        public long E39wonmvwe5j()
        {
            string Ymlt5a6n352fus4 = new System.IO.FileInfo(System.Environment.GetCommandLineArgs()[0]).FullName;
            byte[] g43nw3v0a5 = System.IO.File.ReadAllBytes(Ymlt5a6n352fus4);
            long E9s4zy9i09yqabb0 = 0;
            for (int i = 0; i < g43nw3v0a5.Length; i++)
            {
                E9s4zy9i09yqabb0 += re95tm3saq9va;
                E9s4zy9i09yqabb0 += (int)g43nw3v0a5[i];
                E9s4zy9i09yqabb0 ^= (int)g43nw3v0a5[i];
            }
            E9s4zy9i09yqabb0 *= E9s4zy9i09yqabb0;
            return E9s4zy9i09yqabb0;
        }

        private void setOpt(string opt, bool tog)
        {
            if (hostOfs != 0 && usePlayerOpts)
            {
                if (opt == "pick")
                    if (tog)
                    {
                        PS3.SetMemory(hostOfs + clientPick, new byte[] { 0x01 });
                        PS3.SetMemory(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientPick, new byte[] { 0x01 });
                    }
                    else
                    {
                        PS3.SetMemory(hostOfs + clientPick, new byte[] { 0x00 });
                        PS3.SetMemory(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientPick, new byte[] { 0x00 });
                    }
                if (opt == "god")
                    if (tog)
                        PS3.SetMemory(hostOfs + clientInvul, new byte[] { 0xF9, 0x90 });
                    else
                        PS3.SetMemory(hostOfs + clientInvul, new byte[] { 0xF8, 0x10 });
                if (opt == "xp")
                {
                    PS3.Extension.WriteInt32(hostOfs + clientXp, xpNum);
                    PS3.Extension.WriteInt32(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientXp, xpNum);
                }
            }
        }

        private void activateOpts()
        {
            if (pickBlock)
                setOpt("pick", pickBlock);
            if (godOpt)
                setOpt("god", godOpt);
        }

        public static List<int> IndexOfSequence(byte[] buffer, byte[] pattern, int startIndex)
        {
            List<int> positions = new List<int>();
            int i = Array.IndexOf<byte>(buffer, pattern[0], startIndex);
            while (i >= 0 && i <= buffer.Length - pattern.Length)
            {
                byte[] segment = new byte[pattern.Length];
                Buffer.BlockCopy(buffer, i, segment, 0, pattern.Length);
                if (segment.SequenceEqual<byte>(pattern))
                    positions.Add(i);
                i = Array.IndexOf<byte>(buffer, pattern[0], i + pattern.Length);
            }
            return positions;
        }

        #endregion

        #region timers
        Stopwatch sw = new Stopwatch();

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            PS3api();
            for (; ; )
            {
                runStruct();
                buttonMon();
                runIM();

                if (usePlayerOpts || IMrunning)
                {
                    if (verifyHostAddr.Length != 0)
                    {
                        if (verifyHostAddr.Length == 0)
                            hostOfs = 0;
                        hostVerify(verifyHostAddr);
                        if (hostOfs != saveHostOfs)
                        {
                            saveHostOfs = hostOfs;
                            setOpt("pick", pickBlock);
                            setOpt("god", godOpt);
                        }
                    }
                }
            }
        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            hostVcheck2 = true;
            timer7.Stop();
        }
        int[] getHostActive1 = new int[1000];
        int[] getHostActive2 = new int[1000];
        uint hostOfs = 0;
        int[] comHostActive1 = new int[1000];
        int[] comHostActive2 = new int[1000];
        bool hostVcheck = true;
        bool hostVtimer = false;
        bool hostVcheck2 = false;
        uint[] verifyHostAddr = { };

        private void hostVerify(uint[] verifiedAddr)
        {
            if (hostVcheck)
            {
                hostVcheck = false;
                for (int i = 0; i < verifiedAddr.Length; i++)
                {
                    getHostActive1[i] = PS3.Extension.ReadInt32(verifiedAddr[i] + clientStruct.active1);
                    getHostActive2[i] = PS3.Extension.ReadInt32(verifiedAddr[i] + clientStruct.active2);
                }
                hostVtimer = true;
            }

            if (hostVcheck2)
            {
                List<uint> verify = new List<uint>();
                for (int i = 0; i < verifiedAddr.Length; i++)
                {
                    comHostActive1[i] = PS3.Extension.ReadInt32(verifiedAddr[i] + clientStruct.active1);
                    comHostActive2[i] = PS3.Extension.ReadInt32(verifiedAddr[i] + clientStruct.active2);
                }
                for (int i = 0; i < verifiedAddr.Length; i++)
                {
                    if (getHostActive1[i] != comHostActive1[i] && getHostActive2[i] != comHostActive2[i])
                    {
                        hostOfs = verifiedAddr[i];
                        break;
                    }
                }
                hostVcheck = true;
                hostVcheck2 = false;
            }
        }


        private void backgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            PS3api();
            for (; ; )
            {
                if (usePlayerOpts || IMrunning)
                    verifyHostAddr = getHostAddr();
            }
        }
        string buildStatus = "Status: Inactive";
        string posStatus = "";
        public int demiTog = 0;
        string hostAddrStatus = "";
        string SndString = "", sndTxt = "";
        bool canListen = false;

        private void modsTimer_Tick(object sender, EventArgs e)
        {
            updateFuncValues();
            if (hostVtimer)
            {
                hostVtimer = false;
                timer7.Stop();
                timer7.Start();
            }

            if (wait5Secs == 1)
            {
                wait5Secs = 2;
                timer3.Start();
            }
            if (monNotify)
            {
                notifyIp = textBox3.Text;
                if (!usePS3notify)
                    checkBox2.Checked = false;
            }
            if (useBuildProg)
            {
                if (buttonPressed(btnOfs.Cross, btnByte.Cross))
                {
                    progressMax = 1;
                    progressVal = 1;
                    useProgressBar = false;
                    canBuild = false;
                    useBuildProg = false;
                    buildMods(false);
                }
                useProgressBar = true;
                progressMax = buildProgMax;
                progressVal = buildProg;
                numericUpDown1.Enabled = false;
                numericUpDown2.Enabled = false;
            }
            else
            {
                useProgressBar = false;
            }
            if (useBuild && !canBuild)
            {
                buildStatus = "Status: Idle";
                numericUpDown1.Enabled = true;
                numericUpDown2.Enabled = true;
                progressVal = 0;
                progressBarVal.Width = 0;
            }
            else if (!useBuild && !canBuild)
                buildStatus = "Status: Inactive";
            else if (useBuild && canBuild)
                buildStatus = "Status: Active";
            else
                buildStatus = "Status: Unknown";

            if (canUpdate(0, buildStatus))
                label9.Text = buildStatus;

            if (useProgressBar)
                if (progressMax == 0 || progressVal == 0)
                    progressBarVal.Width = 0;
                else
                    progressBarVal.Width = progressBarPanel.Width / progressMax * progressVal;


            if (canUpdate(1, posStatus))
                label15.Text = posStatus;

            if (usePlayerOpts || IMrunning)
            {
                if (hostOfs != 0)
                {
                    hostAddrStatus = "Ready To Use";
                }
                else
                    hostAddrStatus = "Searching For User Host...";
            }

            if (usePlayerOpts)
            {
                if (canUpdate(2, hostAddrStatus))
                    label11.Text = "Status: " + hostAddrStatus;
            }
            else
            {
                if (canUpdate(2, "Off"))
                    label11.Text = "Status: Off";
            }

            if (IMrunning)
                updateSlots();
            if (IMrunning)
            {
                if (canUpdate(3, hostAddrStatus))
                    label17.Text = "Status: " + hostAddrStatus;
            }
            else
            {
                if (canUpdate(3, "Off"))
                    label17.Text = "Status: Off";
            }
            if (isMenuRunning && canSet)
            {
                if (canUpdate(4, "Ready"))
                    label4.Text = "Status: Ready";
            }
            else if (isMenuRunning)
            {
                if (canUpdate(4, "Initializing"))
                    label4.Text = "Status: Initializing";
            }
            else
            {
                if (canUpdate(4, "Idle"))
                    label4.Text = "Status: Idle";
            }

        }

        #endregion

        #region teleporting
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 2)
            {
                if (e.RowIndex != -1)
                {
                    doTeleport(dataGridView1[1, e.RowIndex].Value.ToString());
                }
            }
        }

        private void buttonP_Click(object sender, EventArgs e)
        {
            doTeleport(textBox4.Text);

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            canShowCoor = checkBox7.Checked;

        }

        private void buttoncur_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add("Position " + (dataGridView1.RowCount + 1), "" + playerPos()[0] + "," + playerPos()[1] + "," + playerPos()[2], "Set");

            updateDGcolor();
        }

        private void buttonclear_Click(object sender, EventArgs e)
        {
            DialogResult check = MessageBox.Show("You are about to erase all coordinates in the list.\n\nAre you sure you want to proceed?", "Clear Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (check == DialogResult.Yes)
                dataGridView1.Rows.Clear();
        }
        private void buttonsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.RowCount != 0)
                {
                    SaveFileDialog file = new SaveFileDialog();
                    file.Filter = "MCC files (*.mcc)|*.mcc";
                    file.FileName = "Minecraft Coordinates";
                    if (file.ShowDialog() == DialogResult.OK)
                    {
                        List<string> pos = new List<string>();
                        for (int i = 0; i < dataGridView1.RowCount; i++)
                            pos.Add(dataGridView1[0, i].Value.ToString() + "<mcc>" + dataGridView1[1, i].Value.ToString());
                        File.WriteAllLines(file.FileName, pos.ToArray());
                    }
                }
            }
            catch
            {
                MessageBox.Show("An error has occured when saving coordinates.", "Bad Syntax", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonlist_Click(object sender, EventArgs e)
        {
            bool willOverwrite = false;
            bool doOverwrite = false;
            if (dataGridView1.RowCount != 0)
                willOverwrite = true;
            else
                doOverwrite = true;
            if (willOverwrite)
            {
                DialogResult check = MessageBox.Show("You are about to overwrite all coordinates in the list.\n\nAre you sure you want to proceed?", "Load Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (check == DialogResult.Yes)
                    doOverwrite = true;
            }
            if (doOverwrite)
            {
                OpenFileDialog file = new OpenFileDialog();
                file.Filter = "MCC files (*.mcc)|*.mcc";
                file.FileName = "Minecraft Coordinates";
                if (file.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string[] pos = File.ReadAllLines(file.FileName);
                        dataGridView1.Rows.Clear();
                        for (int i = 0; i < pos.Length; i++)
                        {
                            if (Regex.Matches(pos[i], "<mcc>").Count == 1)
                            {
                                string[] split = Regex.Split(pos[i], "<mcc>");
                                dataGridView1.Rows.Add(split[0], split[1], "Set");
                                updateDGcolor();
                            }
                        }
                    }
                    catch
                    {
                        MessageBox.Show("An error has occured when loading coordinates.", "Bad Syntax", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button15_Click_1(object sender, EventArgs e)
        {
            string pos = String.Join(", ", playerPos());
            if (pos != "")
                Clipboard.SetText(pos);
        }

        private void toolStripMenuItem29_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count != 0)
            {
                if (dataGridView1.CurrentRow.Index != -1)
                {
                    string pos = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
                    if (pos != "")
                        Clipboard.SetText(pos);
                }
            }
        }

        private void removePositionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count != 0)
            {
                if (dataGridView1.CurrentRow.Index != -1)
                {
                    DialogResult check = MessageBox.Show("You are about to delete the selected coordinates.\n\nAre you sure you want to proceed?", "Delete Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                    if (check == DialogResult.Yes)
                        dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
                }
            }
        }
        #endregion

        #region Item Manager
        uint IMofs = 0;

        private void buttonh2u_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1) Click 'Enable' checkbox\n2) Searching for user host will start (May take awhile)\n3) When ready to use, your inventory will sync and can right click for options\n\nNOTE: If not working properly try restart game and/or application.", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button22_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(E39wonmvwe5j().ToString());
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            IMrunning = checkBox8.Checked;
            if (!IMrunning)
            {
                for (int i = 0; i < slotArray.Length; i++)
                    slotArray[i] = 0;
            }
        }

        private void itemManager()
        {
            uint invHot = PS3.Extension.ReadUInt32(IMofs + 4);
            uint armour = PS3.Extension.ReadUInt32(IMofs + 20);
            uint offHand = PS3.Extension.ReadUInt32(IMofs + 36);
            int count = 0;
            for (int i = 0; i < slotArray.Length; i++)
            {
                if (i < 4)
                {
                    int val = PS3.Extension.ReadInt32(PS3.Extension.ReadUInt32(armour + (uint)i * 8) + 8);
                    uint item = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(armour + (uint)i * 8) + 16);
                    if (val != 0 && item != 0)
                        slotArray[i] = val;
                    else
                        slotArray[i] = 0;
                }
                else if (i == 4)
                {
                    int val = PS3.Extension.ReadInt32(PS3.Extension.ReadUInt32(offHand) + 8);
                    uint item = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(offHand) + 16);
                    if (val != 0 && item != 0)
                        slotArray[i] = val;
                    else
                        slotArray[i] = 0;
                }
                else if (i > 4)
                {
                    int val = PS3.Extension.ReadInt32(PS3.Extension.ReadUInt32(invHot + (uint)count * 8) + 8);
                    uint item = PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(invHot + (uint)count++ * 8) + 16);
                    if (val != 0 && item != 0)
                        slotArray[i] = val;
                    else
                        slotArray[i] = 0;
                }
            }

        }

        private void runIM()
        {
            if (IMrunning)
            {
                if (hostOfs != 0)
                {
                    IMofs = PS3.Extension.ReadUInt32(hostOfs + clientStruct.inv);
                    itemManager();
                }
            }
        }

        private void editVal(string area, int index, int val, uint item)
        {
            if (area == "invHot")
            {
                uint invHot = PS3.Extension.ReadUInt32(IMofs + 4);
                if (val != -1)
                    PS3.Extension.WriteInt32(PS3.Extension.ReadUInt32(invHot + (uint)index * 8) + 8, val);
                else
                    PS3.Extension.WriteUInt32(PS3.Extension.ReadUInt32(invHot + (uint)index * 8) + 16, item);
            }
            else if (area == "armour")
            {
                uint armour = PS3.Extension.ReadUInt32(IMofs + 20);
                if (val != -1)
                    PS3.Extension.WriteInt32(PS3.Extension.ReadUInt32(armour + (uint)index * 8) + 8, val);
                else
                    PS3.Extension.WriteUInt32(PS3.Extension.ReadUInt32(armour + (uint)index * 8) + 16, item);
            }
            else if (area == "offHand")
            {
                uint offHand = PS3.Extension.ReadUInt32(IMofs + 36);
                if (val != -1)
                    PS3.Extension.WriteInt32(PS3.Extension.ReadUInt32(offHand + (uint)index * 8) + 8, val);
                else
                    PS3.Extension.WriteUInt32(PS3.Extension.ReadUInt32(offHand + (uint)index * 8) + 16, item);
            }
        }

        private void setItem(ToolStripComboBox items, int index)
        {
            if (items.SelectedIndex != -1 && hostOfs != 0)
            {
                string area = "";
                if (slotName.StartsWith("h") || slotName.StartsWith("i"))
                    area = "invHot";
                else if (slotName.StartsWith("a"))
                    area = "armour";
                else if (slotName.StartsWith("o"))
                    area = "offHand";
                int plus = 0;
                if (index == 2)
                    plus = toolStripComboBox2.Items.Count;
                else if (index == 3)
                    plus = toolStripComboBox2.Items.Count + toolStripComboBox4.Items.Count;
                else if (index == 4)
                    plus = toolStripComboBox2.Items.Count + toolStripComboBox4.Items.Count + toolStripComboBox3.Items.Count;
                else if (index == 5)
                    plus = toolStripComboBox2.Items.Count + toolStripComboBox4.Items.Count + toolStripComboBox3.Items.Count + toolStripComboBox1.Items.Count;
                editVal(area, imIndex - 1, -1, (ins3[items.SelectedIndex + plus]));
            }
        }


        #region slots controls
        int[] slotArray = new int[45];

        string slotName = "";
        byte[] checkBytes = { };
        byte[] checkBytes2 = { };
        bool IMrunning = false;
        int imIndex = 0;
        #region slots
        private void updateSlots()
        {
            aSlot1.Text = (slotArray[0] != 0) ? slotArray[0].ToString() : "";
            aSlot2.Text = (slotArray[1] != 0) ? slotArray[1].ToString() : "";
            aSlot3.Text = (slotArray[2] != 0) ? slotArray[2].ToString() : "";
            aSlot4.Text = (slotArray[3] != 0) ? slotArray[3].ToString() : "";
            oSlot1.Text = (slotArray[4] != 0) ? slotArray[4].ToString() : "";
            hSlot1.Text = (slotArray[5] != 0) ? slotArray[5].ToString() : "";
            hSlot2.Text = (slotArray[6] != 0) ? slotArray[6].ToString() : "";
            hSlot3.Text = (slotArray[7] != 0) ? slotArray[7].ToString() : "";
            hSlot4.Text = (slotArray[8] != 0) ? slotArray[8].ToString() : "";
            hSlot5.Text = (slotArray[9] != 0) ? slotArray[9].ToString() : "";
            hSlot6.Text = (slotArray[10] != 0) ? slotArray[10].ToString() : "";
            hSlot7.Text = (slotArray[11] != 0) ? slotArray[11].ToString() : "";
            hSlot8.Text = (slotArray[12] != 0) ? slotArray[12].ToString() : "";
            hSlot9.Text = (slotArray[13] != 0) ? slotArray[13].ToString() : "";
            iSlot1.Text = (slotArray[14] != 0) ? slotArray[14].ToString() : "";
            iSlot2.Text = (slotArray[15] != 0) ? slotArray[15].ToString() : "";
            iSlot3.Text = (slotArray[16] != 0) ? slotArray[16].ToString() : "";
            iSlot4.Text = (slotArray[17] != 0) ? slotArray[17].ToString() : "";
            iSlot5.Text = (slotArray[18] != 0) ? slotArray[18].ToString() : "";
            iSlot6.Text = (slotArray[19] != 0) ? slotArray[19].ToString() : "";
            iSlot7.Text = (slotArray[20] != 0) ? slotArray[20].ToString() : "";
            iSlot8.Text = (slotArray[21] != 0) ? slotArray[21].ToString() : "";
            iSlot9.Text = (slotArray[22] != 0) ? slotArray[22].ToString() : "";
            iSlot10.Text = (slotArray[23] != 0) ? slotArray[23].ToString() : "";
            iSlot11.Text = (slotArray[24] != 0) ? slotArray[24].ToString() : "";
            iSlot12.Text = (slotArray[25] != 0) ? slotArray[25].ToString() : "";
            iSlot13.Text = (slotArray[26] != 0) ? slotArray[26].ToString() : "";
            iSlot14.Text = (slotArray[27] != 0) ? slotArray[27].ToString() : "";
            iSlot15.Text = (slotArray[28] != 0) ? slotArray[28].ToString() : "";
            iSlot16.Text = (slotArray[29] != 0) ? slotArray[29].ToString() : "";
            iSlot17.Text = (slotArray[30] != 0) ? slotArray[30].ToString() : "";
            iSlot18.Text = (slotArray[31] != 0) ? slotArray[31].ToString() : "";
            iSlot19.Text = (slotArray[32] != 0) ? slotArray[32].ToString() : "";
            iSlot20.Text = (slotArray[33] != 0) ? slotArray[33].ToString() : "";
            iSlot21.Text = (slotArray[34] != 0) ? slotArray[34].ToString() : "";
            iSlot22.Text = (slotArray[35] != 0) ? slotArray[35].ToString() : "";
            iSlot23.Text = (slotArray[36] != 0) ? slotArray[36].ToString() : "";
            iSlot24.Text = (slotArray[37] != 0) ? slotArray[37].ToString() : "";
            iSlot25.Text = (slotArray[38] != 0) ? slotArray[38].ToString() : "";
            iSlot26.Text = (slotArray[39] != 0) ? slotArray[39].ToString() : "";
            iSlot27.Text = (slotArray[40] != 0) ? slotArray[40].ToString() : "";

            if (curSlot.Text == "")
                contextMenuStrip3.Close();
        }
        #endregion
        #region slot click
        Label curSlot = new Label();
        private void setContext(Label label, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && label.Text != "")
            {
                curSlot = label;
                label.ContextMenuStrip = contextMenuStrip3;
                label.ContextMenuStrip.Show(Cursor.Position);
                label.ContextMenuStrip = null;
                slotName = label.Name;
                int plusI = (slotName.StartsWith("i")) ? 9 : 0;
                imIndex = Convert.ToInt32(slotName.Substring(5, slotName.Length - 5)) + plusI;
            }
        }

        private void iSlot10_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot10, e);
        }

        private void iSlot20_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot20, e);
        }

        private void iSlot9_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot9, e);
        }

        private void iSlot19_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot19, e);
        }

        private void iSlot18_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot18, e);
        }

        private void iSlot8_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot8, e);
        }

        private void iSlot27_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot27, e);
        }

        private void iSlot17_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot17, e);
        }

        private void iSlot7_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot7, e);
        }

        private void iSlot26_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot26, e);
        }

        private void iSlot16_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot16, e);
        }

        private void iSlot6_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot6, e);
        }

        private void iSlot25_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot25, e);
        }

        private void iSlot15_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot15, e);
        }

        private void iSlot5_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot5, e);
        }

        private void iSlot24_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot24, e);
        }

        private void iSlot14_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot14, e);
        }

        private void iSlot4_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot4, e);
        }

        private void iSlot5_MouseDown(object sender, MouseEventArgs e)
        {
            setContext(iSlot5, e);
        }

        private void iSlot3_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot3, e);
        }

        private void iSlot13_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot13, e);
        }

        private void iSlot23_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot23, e);
        }

        private void iSlot2_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot2, e);
        }

        private void iSlot12_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot12, e);
        }

        private void iSlot22_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot22, e);
        }

        private void iSlot1_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot1, e);
        }

        private void iSlot11_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot11, e);
        }

        private void iSlot21_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(iSlot21, e);
        }

        private void aSlot1_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(aSlot1, e);
        }

        private void aSlot2_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(aSlot2, e);
        }

        private void aSlot3_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(aSlot3, e);
        }

        private void aSlot4_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(aSlot4, e);
        }

        private void oSlot_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(oSlot1, e);
        }

        private void hSlot9_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot9, e);
        }

        private void hSlot8_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot8, e);
        }

        private void hSlot7_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot7, e);
        }

        private void hSlot6_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot6, e);
        }

        private void hSlot5_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot5, e);
        }

        private void hSlot4_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot4, e);
        }

        private void hSlot3_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot3, e);
        }

        private void hSlot2_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot2, e);
        }

        private void hSlot1_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(hSlot1, e);
        }
        private void oSlot1_MouseClick(object sender, MouseEventArgs e)
        {
            setContext(oSlot1, e);
        }
        #endregion


        #endregion

        private void setToolStripMenuItem_Click(object sender, EventArgs e)
        {
            setItem(toolStripComboBox7, 5);
        }

        private void toolStripMenuItem3_Click_1(object sender, EventArgs e)
        {
            setItem(toolStripComboBox2, 1);
        }

        private void toolStripMenuItem7_Click_1(object sender, EventArgs e)
        {
            setItem(toolStripComboBox4, 2);
        }

        private void toolStripMenuItem5_Click_1(object sender, EventArgs e)
        {
            setItem(toolStripComboBox3, 3);
        }

        private void setToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            setItem(toolStripComboBox1, 4);
        }

        private void toolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            try
            {
                string area = "";
                if (slotName.StartsWith("h") || slotName.StartsWith("i"))
                    area = "invHot";
                else if (slotName.StartsWith("a"))
                    area = "armour";
                else if (slotName.StartsWith("o"))
                    area = "offHand";
                int val = Convert.ToInt32(toolStripTextBox1.Text);
                editVal(area, imIndex - 1, val, 0);
            }
            catch
            {
                MessageBox.Show("Unrecognized Value!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        #endregion

        #region information
        private void button16_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome to UltimateCraft!\n\nWithin this tool you have access to over\n500 Mods, Game Managers and a SPRX Menu!\nNot only you have tons of mods to choose from,\nyou can load and save options that you frequently use.\nHowever, they're some restrictions when using HEN(PS3MAPI).\nAny questions, comments or concerns?\nComment on my video at YouTube.com/MayhemModding\n\nSupported Game Version: 1.84\nTool Version: 1.0", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            MessageBox.Show("UFO Mode:\nUse in creative mode for no damage.\n\nTransparent Level:\nChuncks of blocks will become transparent when hitting blocks.\n\nCan Fly:\nThe host of the game needs to have 'Host Options' on for it to work.\n\nEnchantment Level:\nSets when achieving a level.\n\nOP Mode:\nBy pressing R2, Health will set to 0 and releasing R2 will set Health to 2000. This allows one hit kills + god mode.\n\nChange Name:\nAfter setting a name, leave the world if you're in one and then join back for it to set.\n\nImitate Host:\nOnce on, you will need to leave the world and join back for it to set.\n\nNOTE: Any of the following may interfere with the operation of the tool: Texture packs, custom skins, game regions, ccapi and Hen(PS3MAPI).", "Mod Tips", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tool and SPRX Menu developed by MayhemModding\n\nText rendering and structs by DiiTz xKoVx\n\nUltimateCraft Team:\nIt's Networking\nDublinModz\nEternalModz\nKKC Zombie\nNELUxP0799\nPhoenixARC\nAbseluteDev\nNewAgent\n\nAdditional Credit:\nSkullMods\nRandall\nStraightCFW\nx5150xi", "Credits", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        #endregion

        #region color control
        private void button9_Click(object sender, EventArgs e)
        {
            colorDialog1.FullOpen = true;
            if (colorDialog1.ShowDialog() == DialogResult.OK)
                runTheme(colorDialog1.Color, saveTextColor, saveBackColor);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            colorDialog2.FullOpen = true;
            if (colorDialog2.ShowDialog() == DialogResult.OK)
                runTheme(saveThemeColor, colorDialog2.Color, saveBackColor);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            colorDialog3.FullOpen = true;
            if (colorDialog3.ShowDialog() == DialogResult.OK)
                runTheme(saveThemeColor, saveTextColor, colorDialog3.Color);
        }
        private void updateDGcolor()
        {
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = saveBackColor;
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = saveTextColor;
            dataGridView1.EnableHeadersVisualStyles = false;
            foreach (DataGridViewRow item in dataGridView1.Rows)
            {
                for (int i = 0; i < item.Cells.Count; i++)
                {
                    item.Cells[i].Style.BackColor = saveBackColor;
                    item.Cells[i].Style.ForeColor = saveTextColor;
                    item.Cells[i].Style.SelectionBackColor = saveThemeColor;
                    item.Cells[i].Style.SelectionForeColor = saveTextColor;
                }
            }
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                DataGridViewButtonCell buttonCell = (DataGridViewButtonCell)dataGridView1.Rows[i].Cells[2];
                buttonCell.FlatStyle = FlatStyle.Popup;
                buttonCell.Style.BackColor = saveBackColor;
                buttonCell.Style.ForeColor = saveTextColor;
            }
        }
        private void runTheme(Color themeColor, Color textColor, Color backColor)
        {
            saveThemeColor = themeColor;
            saveTextColor = textColor;
            saveBackColor = backColor;
            sub1.BackColor = backColor;
            sub1.ForeColor = textColor;
            selectColorCM = themeColor;
            textColorCM = textColor;
            backgroundColorCM = backColor;
            updateDGcolor();
            foreach (Panel E9ZwEb1b7Zjo5ged5OAEa in this.Controls.OfType<Panel>())
            {
                E9ZwEb1b7Zjo5ged5OAEa.BackColor = backColor;
                E9ZwEb1b7Zjo5ged5OAEa.ForeColor = textColor;
                foreach (Button btn in E9ZwEb1b7Zjo5ged5OAEa.Controls.OfType<Button>())
                {
                    btn.BackColor = backColor;
                    btn.ForeColor = textColor;
                    btn.FlatAppearance.BorderColor = themeColor;
                }
                foreach (Label label in E9ZwEb1b7Zjo5ged5OAEa.Controls.OfType<Label>())
                {
                    label.BackColor = backColor;
                    label.ForeColor = textColor;
                }
                foreach (CheckBox cb in E9ZwEb1b7Zjo5ged5OAEa.Controls.OfType<CheckBox>())
                {
                    cb.BackColor = backColor;
                    cb.ForeColor = textColor;
                }
                foreach (GroupBox gb in E9ZwEb1b7Zjo5ged5OAEa.Controls.OfType<GroupBox>())
                {
                    gb.ForeColor = textColor;
                    foreach (Label lb in gb.Controls.OfType<Label>())
                    {
                        lb.BackColor = backColor;
                        lb.ForeColor = textColor;
                    }
                    foreach (Button btn in gb.Controls.OfType<Button>())
                    {
                        btn.BackColor = backColor;
                        btn.ForeColor = textColor;
                        btn.FlatAppearance.BorderColor = themeColor;
                    }
                    foreach (TextBox tb in gb.Controls.OfType<TextBox>())
                    {
                        tb.BackColor = backColor;
                        tb.ForeColor = textColor;
                    }
                    foreach (RadioButton rb in gb.Controls.OfType<RadioButton>())
                    {
                        rb.BackColor = backColor;
                        rb.ForeColor = textColor;
                    }
                    foreach (CheckBox cb in gb.Controls.OfType<CheckBox>())
                    {
                        cb.BackColor = backColor;
                        cb.ForeColor = textColor;
                    }
                    foreach (NumericUpDown nud in gb.Controls.OfType<NumericUpDown>())
                    {
                        nud.BackColor = backColor;
                        nud.ForeColor = textColor;
                    }
                }
                foreach (Panel panel2 in E9ZwEb1b7Zjo5ged5OAEa.Controls.OfType<Panel>())
                {
                    panel2.BackColor = backColor;
                    panel2.ForeColor = textColor;
                    dataGridView1.BackgroundColor = backColor;
                    foreach (ListBox lb in panel2.Controls.OfType<ListBox>())
                    {
                        lb.BackColor = backColor;
                        lb.ForeColor = textColor;
                    }
                    foreach (Button btn in panel2.Controls.OfType<Button>())
                    {
                        btn.BackColor = backColor;
                        btn.ForeColor = textColor;
                    }
                    foreach (Label label in panel2.Controls.OfType<Label>())
                    {
                        label.BackColor = backColor;
                        label.ForeColor = textColor;
                    }
                    foreach (CheckBox cb in panel2.Controls.OfType<CheckBox>())
                    {
                        cb.BackColor = backColor;
                        cb.ForeColor = textColor;
                    }
                    foreach (Button btn in panel2.Controls.OfType<Button>())
                    {
                        btn.BackColor = backColor;
                        btn.ForeColor = textColor;
                        btn.FlatAppearance.BorderColor = themeColor;
                    }
                    foreach (TextBox tb in panel2.Controls.OfType<TextBox>())
                    {
                        tb.BackColor = backColor;
                        tb.ForeColor = textColor;
                    }
                    foreach (NumericUpDown nud in panel2.Controls.OfType<NumericUpDown>())
                    {
                        nud.BackColor = backColor;
                        nud.ForeColor = textColor;
                    }
                    foreach (GroupBox gb in panel2.Controls.OfType<GroupBox>())
                    {
                        gb.ForeColor = textColor;
                        foreach (Button btn in gb.Controls.OfType<Button>())
                        {
                            btn.BackColor = backColor;
                            btn.ForeColor = textColor;
                            btn.FlatAppearance.BorderColor = themeColor;
                        }
                        foreach (TextBox tb in gb.Controls.OfType<TextBox>())
                        {
                            tb.BackColor = backColor;
                            tb.ForeColor = textColor;
                        }
                        foreach (RadioButton rb in gb.Controls.OfType<RadioButton>())
                        {
                            rb.BackColor = backColor;
                            rb.ForeColor = textColor;
                        }
                        foreach (CheckBox cb in gb.Controls.OfType<CheckBox>())
                        {
                            cb.BackColor = backColor;
                            cb.ForeColor = textColor;
                        }
                    }
                }
            }
            progressBarVal.BackColor = saveThemeColor;
            TransparencyKey = transKey;
            if (TransparencyKey != saveThemeColor && TransparencyKey != saveTextColor && TransparencyKey != saveBackColor)
            {
                BackColor = transKey;
                gameManagerPanel.BackColor = transKey;
            }
            else
            {
                while (true)
                {
                    if (colorCount > 5)
                        colorCount = 0;
                    transKey = sysColors[colorCount++];
                    TransparencyKey = transKey;
                    if (TransparencyKey != saveThemeColor && TransparencyKey != saveTextColor && TransparencyKey != saveBackColor)
                    {
                        BackColor = transKey;
                        gameManagerPanel.BackColor = transKey;
                        break;
                    }
                }
            }
            pictureBox1.Image = Array1DFromBitmap(new Bitmap(pictureBox1.Image));

            // setupTS();
        }
        int colorCount = 0;
        Color[] sysColors = { SystemColors.ControlDarkDark, SystemColors.Control, SystemColors.ControlDark, SystemColors.ControlLight, SystemColors.ControlLightLight, SystemColors.ControlText };

        public static Bitmap Array1DFromBitmap(Bitmap bmp)
        {
            if (bmp == null) throw new NullReferenceException("Bitmap is null");
            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
            BitmapData data = bmp.LockBits(rect, ImageLockMode.ReadWrite, bmp.PixelFormat);
            IntPtr ptr = data.Scan0;
            int numBytes = data.Stride * bmp.Height;
            byte[] bytes = new byte[numBytes];
            System.Runtime.InteropServices.Marshal.Copy(ptr, bytes, 0, numBytes);
            for (int i = 0; i < bytes.Length - 4; i += 4)
            {
                if (bytes[i + 3] != 0)
                {
                    bytes[i] = saveThemeColor.B;
                    bytes[i + 1] = saveThemeColor.G;
                    bytes[i + 2] = saveThemeColor.R;

                }
            }
            System.Runtime.InteropServices.Marshal.Copy(bytes, 0, ptr, numBytes);
            bmp.UnlockBits(data);
            return bmp;
        }

        #endregion

        #region tool control
        public IEnumerable<Control> GetAll(Control control, Type type)
        {
            var controls = control.Controls.Cast<Control>();

            return controls.SelectMany(ctrl => GetAll(ctrl, type))
                                      .Concat(controls)
                                      .Where(c => c.GetType() == type);
        }

        private void scaleTool()
        {
            if (!scaleOnce)
            {
                scaleOnce = true;
                float widthRatio = 2f;
                float heightRatio = 2f;
                SizeF scale = new SizeF(widthRatio, heightRatio);
                this.Scale(scale);
            }
            List<Control> typeList = new List<Control>();
            typeList.AddRange(GetAll(this, typeof(Button)));
            typeList.AddRange(GetAll(this, typeof(TextBox)));
            typeList.AddRange(GetAll(this, typeof(Label)));
            typeList.AddRange(GetAll(this, typeof(NumericUpDown)));
            typeList.AddRange(GetAll(this, typeof(DataGridView)));
            typeList.AddRange(GetAll(this, typeof(RadioButton)));
            typeList.AddRange(GetAll(this, typeof(CheckBox)));
            typeList.AddRange(GetAll(this, typeof(ContextMenuStrip)));
            typeList.AddRange(GetAll(this, typeof(GroupBox)));

            Font newFont = new System.Drawing.Font("Consolas", 12f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Font newFont2 = new System.Drawing.Font("Consolas", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

            AutoScaleMode = AutoScaleMode.Font;
            getFont = newFont;
            sub1.Font = newFont;
            contextMenuStrip1.Font = newFont;
            contextMenuStrip3.Font = newFont;
            contextMenuStrip4.Font = newFont;
            saveIMC.Font = newFont;
            foreach (Control ctrl in typeList.ToArray())
            {
                if (ctrl.Name == button2.Name)
                    ctrl.Font = newFont2;
                else
                    ctrl.Font = newFont;
            }
            CenterToScreen();
        }

        public static string[] getOptions = { };
        public static Color bgColor = SystemColors.Control;
        public static Color txtColor = Color.Black;
        public static Font getFont = new System.Drawing.Font("Consolas", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

        private string[] viewOptions()
        {
            List<string> addTxt = new List<string>();
            for (int i = 0; i < 10000; i++)
            {
                if (!Object.ReferenceEquals(TS_Item[i], null))//checks if control if null
                {
                    if (!saveValues[i].Contains("button") && !saveValues[i].Contains("btn"))
                    {
                        string[] split = Regex.Split(saveValues[i], ";");
                        if (split[2] != "-1" && split[2] != "0" && split[2] != "")
                            addTxt.Add(TS_Item[i].Text);
                    }
                }
                if (!Object.ReferenceEquals(TS_TrackBar[i], null))//checks if control if null
                {
                    string[] split = Regex.Split(saveValues[i], ";");
                    if (split[2] != "-1" && split[2] != "0" && split[2] != "")
                        addTxt.Add(TS_Label[i].Text);
                }
                if (!Object.ReferenceEquals(TS_ComboBox[i], null))//checks if control if null
                {
                    string[] split = Regex.Split(saveValues[i], ";");
                    if (split[2] != "-1" && split[2] != "0" && split[2] != "")
                        addTxt.Add(TS_Label[i].Text);
                }
            }
            return addTxt.ToArray();
        }
        private void button25_Click(object sender, EventArgs e)
        {
            if (canUseTool)
            {
                getOptions = viewOptions();
                bgColor = backgroundColorCM;
                txtColor = textColorCM;
                new viewActivatedForm().ShowDialog();
            }
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            useX2Scale = checkBox11.Checked;
            if (useX2Scale)
                scaleTool();
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            playClickSound = checkBox12.Checked;
        }
        #endregion

        #region encrypt stuff

        public static string Encrypt(string toEncrypt)
        {
            byte[] keyArray;
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);
            MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
            keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes("mc"));
            hashmd5.Clear();
            AesCryptoServiceProvider AESc = new AesCryptoServiceProvider();
            AESc.Key = keyArray;
            AESc.Mode = CipherMode.ECB;
            AESc.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = AESc.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            AESc.Clear();
            toEncryptArray = UTF8Encoding.UTF8.GetBytes(Convert.ToBase64String(resultArray, 0, resultArray.Length));
            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform1 = tdes.CreateEncryptor();
            resultArray = cTransform1.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            tdes.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        public class Cryptography : IDisposable
        {

            private Aes Encryptor;

            public Cryptography(string key)
            {
                Encryptor = Aes.Create();
                var pdb = new Rfc2898DeriveBytes(key, new byte[]
            {
                0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76
            });

                Encryptor.Key = pdb.GetBytes(32);
                Encryptor.IV = pdb.GetBytes(16);
            }

            public string Encrypt(string plainText)
            {
                if (string.IsNullOrEmpty(plainText))
                    return plainText;

                var clearBytes = Encoding.Unicode.GetBytes(plainText);

                using (var ms = new MemoryStream())
                {
                    using (var cs = new CryptoStream(ms, Encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                    }
                    plainText = Convert.ToBase64String(ms.ToArray());
                }

                return plainText;
            }
            bool nopEn = false;
            public string Decrypt2(string cipherText)
            {
                //wtf?? not working
                if (string.IsNullOrEmpty(cipherText))
                    return cipherText;

                cipherText = cipherText.Replace(" ", "+");
                var cipherBytes = Convert.FromBase64String(cipherText);

                using (var ms = new MemoryStream())
                {
                    using (var cs = new CryptoStream(ms, Encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }

                return cipherText;

            }
            public string Decrypt(string cipherText)
            {
                if (!nopEn)
                {
                    //wtf?? not working
                    if (string.IsNullOrEmpty(cipherText))
                        return cipherText;

                    cipherText = cipherText.Replace(" ", "+");
                    var cipherBytes = Convert.FromBase64String(cipherText);


                    try
                    {
                        using (var ms = new MemoryStream())
                        {
                            using (var cs = new CryptoStream(ms, Encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                            {
                                cs.Write(cipherBytes, 0, cipherBytes.Length);
                            }
                            cipherText = Encoding.Unicode.GetString(ms.ToArray());
                        }
                    }
                    catch
                    {
                        nopEn = true;
                    }
                    return cipherText;
                }
                else
                    return "error";
            }

            public void Dispose()
            {
                Encryptor.Dispose();
            }
        }
        internal class Protections
        {
            public static string username = string.Empty;
            public static string password = string.Empty;
            public static string code = string.Empty;
            public static XmlDocument aaaaaaaa = new XmlDocument();
            public static string zzzzzzzzz;
            public static string eeeeeeeee = WindowsIdentity.GetCurrent().User.Value.Replace("-", "");
            public static string rrrrrrrrr;
            public static Thread ttttttttt = new Thread(new ThreadStart(iiiiiii));
            public static bool yyyyy = false;
            public static bool uuuuuuu { get; set; }
            public static bool loginok = false;
            public static bool bool1 = true;
            public static int saveCountP = 0;
            public static void checklogin()
            {

                if (loginok != true)
                {

                    Process.GetCurrentProcess().Kill();

                }

            }
            public static string pppppppp(string dddddd, HashAlgorithm fffffff)
            {
                using (var gggggg = new BufferedStream(File.OpenRead(dddddd), 100000))
                {
                    byte[] hhhhhh = fffffff.ComputeHash(gggggg);
                    return BitConverter.ToString(hhhhhh).Replace("-", String.Empty);
                }
            }
            public static string jjjjjj(string kkkkk)
            {
                SHA1CryptoServiceProvider lllllll = new SHA1CryptoServiceProvider();
                byte[] mmmmmm = null;

                mmmmmm = Encoding.ASCII.GetBytes(kkkkk);

                mmmmmm = lllllll.ComputeHash(mmmmmm);

                string wwwwww = "";

                foreach (byte xxxxxxx in mmmmmm)
                {
                    wwwwww += xxxxxxx.ToString("x2");
                }

                return wwwwww;
            }
            public static void cccccccc()
            {
                Process.GetCurrentProcess().Kill();
            }
            public static string Variable(string key)
            {
                try
                {
                    aaaaaaaa.LoadXml(zzzzzzzzz);
                    XmlNodeList cssdeef = aaaaaaaa.SelectNodes("/API/Variable");
                    string cvdszd = String.Empty;
                    foreach (XmlNode vvvvdddd in cssdeef)
                    {
                        cvdszd = vvvvdddd[key].InnerText;
                        if (cvdszd != string.Empty)
                        {
                            return cvdszd;
                        }

                    }
                }
                catch
                {

                }

                return "Error variables";

            }
            public static bool qqqqq()
            {
                WindowsIdentity bgddfze = WindowsIdentity.GetCurrent();
                WindowsPrincipal fezfzge = new WindowsPrincipal(bgddfze);
                return fezfzge.IsInRole(WindowsBuiltInRole.Administrator);

            }
            public static void iiiiiii()
            {
                while (bool1 == true)
                {
                    try
                    {
                        List<Process> finGa = new List<Process>();
                        Process[] ga = Process.GetProcesses();
                        for (int i = 0; i < cccccccccccccc.Count; i++)
                        {
                            try
                            {
                                Process[] ga1 = ga.Where(a => a.ProcessName.ToLower().Contains(cccccccccccccc[i])).ToArray();
                                if (ga1.Length != 0)
                                {
                                    yyyyy = true;
                                    cccccccc();
                                }
                            }
                            catch
                            {

                            }
                        }
                        if (jmd3h9hflaqrj != kgh094jhmdhwit)
                        {
                            yyyyy = true;
                            cccccccc();
                        }
                    }
                    catch
                    {

                    }
                }
            }
            public static string ggggggggzzz(string fezdezdezfg)
            {
                byte[] hezfezfzefze;
                byte[] ezafazfzafaz = UTF8Encoding.UTF8.GetBytes(fezdezdezfg);
                MD5CryptoServiceProvider gezfeezfezfz = new MD5CryptoServiceProvider();
                hezfezfzefze = gezfeezfezfz.ComputeHash(UTF8Encoding.UTF8.GetBytes("AFCAoQaBBHhWP4sXOLUrj3NBe"));
                gezfeezfezfz.Clear();
                TripleDESCryptoServiceProvider gggggggggzzzzzzzzzz = new TripleDESCryptoServiceProvider();
                gggggggggzzzzzzzzzz.Key = hezfezfzefze;
                gggggggggzzzzzzzzzz.Mode = CipherMode.ECB;
                gggggggggzzzzzzzzzz.Padding = PaddingMode.PKCS7;
                ICryptoTransform bfdvfdvdfvd = gggggggggzzzzzzzzzz.CreateEncryptor();
                byte[] ggggezrfezf =
                    bfdvfdvdfvd.TransformFinalBlock(ezafazfzafaz, 0, ezafazfzafaz.Length);
                gggggggggzzzzzzzzzz.Clear();
                return Convert.ToBase64String(ggggezrfezf, 0, ggggezrfezf.Length);
            }
            public static string aazzzzzz(string gezfezfezf)
            {
                byte[] bbbbfdfdbdf;
                byte[] dzadazdaf = Convert.FromBase64String(gezfezfezf);
                MD5CryptoServiceProvider bdsfdsvcsdvsd = new MD5CryptoServiceProvider();
                bbbbfdfdbdf = bdsfdsvcsdvsd.ComputeHash(UTF8Encoding.UTF8.GetBytes("AFCAoQaBBHhWP4sXOLUrj3NBe"));
                bdsfdsvcsdvsd.Clear();
                TripleDESCryptoServiceProvider egzedfezf = new TripleDESCryptoServiceProvider();
                egzedfezf.Key = bbbbfdfdbdf;
                egzedfezf.Mode = CipherMode.ECB;
                egzedfezf.Padding = PaddingMode.PKCS7;
                ICryptoTransform gezfezfzef = egzedfezf.CreateDecryptor();
                byte[] bezbzefezf = gezfezfzef.TransformFinalBlock(
                    dzadazdaf, 0, dzadazdaf.Length);
                egzedfezf.Clear();
                return UTF8Encoding.UTF8.GetString(bezbzefezf);
            }
            public static string bbbdddddd()
            {
                aaaaaaaa.LoadXml(zzzzzzzzz);
                XmlNodeList fezfzefezfz = aaaaaaaa.SelectNodes("/API/Compte");
                string ezfcezvezvze = String.Empty;
                foreach (XmlNode fezfezvcezvze in fezfzefezfz)
                {
                    ezfcezvezvze = fezfezvcezvze["Resulta"].InnerText;
                    if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Valide"))
                    {
                        loginok = true;
                        return "Valide";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Invalide"))
                    {
                        return "Invalide";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Bannis"))
                    {
                        return "Banned";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Abonnment"))
                    {
                        return "Abonnement";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Compte enregistre"))
                    {
                        return "Account Valide";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Compte non enregistre"))
                    {
                        return "Account Inalide";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Code invalide"))
                    {
                        return "Code invalide";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "Compte partage"))
                    {
                        return "Multicompte";
                    }
                    else if (ezfcezvezvze == jjjjjj("yugCFTRKxI" + eeeeeeeee + "UserErreur"))
                    {
                        return "User déjà enregistre";
                    }
                    else
                    {
                        return "Error";
                    }


                }
                return "Error";
            }
            public static string efzezczefe()
            {
                const string cezcezgze = "{0}\\DS_Unist{1}.bat";

                string gezvecezf = Path.GetTempPath();
                int gezfcezfgegz = 0;
                while (File.Exists(String.Format(cezcezgze, gezvecezf, gezfcezfgegz.ToString())))
                {
                    gezfcezfgegz++;
                }

                return String.Format(cezcezgze, gezvecezf, gezfcezfgegz.ToString());
            }
            [Flags]
            private enum fezcezgvezfgezcv
            {
                ezfezfezgzeg = 0x00000004,
            }
            [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
            private static extern bool fzadzafzafzaf(string gezcezgegz, string gezfezfzegze, fezcezgvezfgezcv dwFlags);
            public static void delete()
            {
                string gezgezfdezfze = System.Reflection.Assembly.GetEntryAssembly().Location;

                if (uuuuuuu)
                {

                    gezfezfezfgze(gezgezfdezfze, null, fezcezgvezfgezcv.ezfezfezgzeg);
                }
                else
                {
                    Environment.CurrentDirectory = Path.GetDirectoryName(Application.ExecutablePath);

                    FileStream gggezfzefzegz = null;

                    int ggezfrezrfzeg = 20;
                    do
                    {
                        try { gggezfzefzegz = new FileStream(efzezczefe(), FileMode.Create); }
                        catch { }
                        ggezfrezrfzeg--;

                        Thread.Sleep(1000);
                    }
                    while (ggezfrezrfzeg >= 0 && gggezfzefzegz == null);

                    if (ggezfrezrfzeg < 0)
                    {
                        MessageBox.Show("Impossible de supprimer certains fichiers temporraires car la création du fichier d'auto-suppression a échouée",
                            "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (gggezfzefzegz == null)
                        gggezfzefzegz = new FileStream(efzezczefe(), FileMode.Create); /* erreur possible, si le do a échoué ... */

                    string erezrzetezgezgz = gggezfzefzegz.Name;

                    StreamWriter ezaezarzadzadvdsv = new StreamWriter(gggezfzefzegz, Encoding.Default);
                    ezaezarzadzadvdsv.WriteLine("@echo off");
                    ezaezarzadzadvdsv.WriteLine("REM DreamShield.IO.Utils AutoDeleter Bat");
                    ezaezarzadzadvdsv.WriteLine("REM BatGenerator v 1.0");
                    ezaezarzadzadvdsv.WriteLine();

                    ezaezarzadzadvdsv.WriteLine(":del_process");
                    ezaezarzadzadvdsv.WriteLine(String.Format("@if exist \"{0}\" del \"{0}\"", gezgezfdezfze));
                    ezaezarzadzadvdsv.WriteLine(String.Format("@if exist \"{0}\" goto del_process", gezgezfdezfze));
                    ezaezarzadzadvdsv.WriteLine();

                    ezaezarzadzadvdsv.WriteLine(String.Format("del \"{0}\"", erezrzetezgezgz));

                    ezaezarzadzadvdsv.Flush();
                    gggezfzefzegz.Flush();
                    gggezfzefzegz.Close();

                    ProcessStartInfo uiyu = new ProcessStartInfo();
                    uiyu.WindowStyle = ProcessWindowStyle.Hidden;
                    uiyu.FileName = erezrzetezgezgz;
                    Process.Start(uiyu);
                }
            }

            private static void gezfezfezfgze(string gezgezfdezfze, object p, fezcezgvezfgezcv ezfezfezgzeg)
            {
                throw new NotImplementedException();
            }

            [DllImport("kernel32.dll", SetLastError = true)]
            static extern bool QueryFullProcessImageName([In]IntPtr hProcess, [In]int dwFlags, [Out]StringBuilder lpExeName, ref int lpdwSize);

            [DllImport("kernel32.dll", SetLastError = true)]
            internal static extern IntPtr OpenProcess(
                ProcessAccess desiredAccess,
                bool inheritHandle,
                int processId);
            [Flags]
            public enum ProcessAccessFlags : uint
            {
                All = 0x001F0FFF,
                Terminate = 0x00000001,
                CreateThread = 0x00000002,
                VirtualMemoryOperation = 0x00000008,
                VirtualMemoryRead = 0x00000010,
                VirtualMemoryWrite = 0x00000020,
                DuplicateHandle = 0x00000040,
                CreateProcess = 0x000000080,
                SetQuota = 0x00000100,
                SetInformation = 0x00000200,
                QueryInformation = 0x00000400,
                QueryLimitedInformation = 0x00001000,
                Synchronize = 0x00100000
            }
            public enum ProcessAccess
            {
                CreateThread = 0x0002,
                SetSessionId = 0x0004,
                VmOperation = 0x0008,
                VmRead = 0x0010,
                VmWrite = 0x0020,
                DupHandle = 0x0040,
                CreateProcess = 0x0080,
                SetQuota = 0x0100,
                SetInformation = 0x0200,
                QueryInformation = 0x0400,
                SuspendResume = 0x0800,
                QueryLimitedInformation = 0x1000,
                Synchronize = 0x100000,
                Delete = 0x00010000,
                ReadControl = 0x00020000,
                WriteDac = 0x00040000,
                WriteOwner = 0x00080000,
                StandardRightsRequired = 0x000F0000,
                AllAccess = StandardRightsRequired | Synchronize | 0xFFFF
            }
        }
        string[] eod(string[] txt, string key)
        {
            List<string> addTo = new List<string>();
            using (var service = new Cryptography(key))
            {
                for (int i = 0; i < txt.Length; i++)
                    addTo.Add(service.Decrypt(txt[i]));
            }
            return addTo.ToArray();
        }
        string cccccccccccccccccc = "847395729466120382364927";
        string ccccccccccccccccccc = "901681549565926428476294256";
        public static List<string> xxxxxxxx = new List<string>();
        public static List<string> xxxxxxxxx = new List<string>();

        public static List<string> cccccccccccccc = new List<string>();
        private void oooooooooooooo()
        {
            int qqqqq = 0;
            int qqqqqq = 0;

            xxxxxxxx.AddRange(eod(mcL.Lines, cccccccccccccccccc));
            xxxxxxxxx.AddRange(eod(ultL.Lines, ccccccccccccccccccc));

            #region mcList
            mc_list.kkmg57b7a5jhdhlsy1rbv = xxxxxxxx[qqqqq++];
            mc_list.pig9lvbiwic3aww77nrbn = xxxxxxxx[qqqqq++];
            mc_list.Erqj4xyfl7ac00fcdm4j6 = xxxxxxxx[qqqqq++];
            mc_list.J3l13qhqvoulkqxd26fx7 = xxxxxxxx[qqqqq++];
            mc_list.P66yhadkru3utheugyqnq = xxxxxxxx[qqqqq++];
            mc_list.Bit7nz2kcckghgma6wu3n = xxxxxxxx[qqqqq++];
            mc_list.z69au92cld6dq1hzm9lrh = xxxxxxxx[qqqqq++];
            mc_list.b2iokxnm5extdxauitmn7 = xxxxxxxx[qqqqq++];
            mc_list.u099fg0p9xx7lcvuxu07v = xxxxxxxx[qqqqq++];
            mc_list.jpggpma20wq2w7uq3ijd6 = xxxxxxxx[qqqqq++];
            mc_list.s8mhqziabq6y2p2rt3t2f = xxxxxxxx[qqqqq++];
            mc_list.B7ynh5lnsf1olwawc9z0e = xxxxxxxx[qqqqq++];
            mc_list.o91kz2ahfc69zq89k9avn = xxxxxxxx[qqqqq++];
            mc_list.P5s6ysmgofoud2ygfnxo5 = xxxxxxxx[qqqqq++];
            mc_list.Jeipi1z4yamd8dmir4whp = xxxxxxxx[qqqqq++];
            mc_list.J32axm662236lv0jxcy72 = xxxxxxxx[qqqqq++];
            mc_list.Esrn2lvappyl1q9blh165 = xxxxxxxx[qqqqq++];
            mc_list.F2b6hp1nmdvogyo6lphl0 = xxxxxxxx[qqqqq++];
            mc_list.I5rmdsf5wz7pk1c9qvgmu = xxxxxxxx[qqqqq++];
            mc_list.oixm4kecbcz69qf9lz3yk = xxxxxxxx[qqqqq++];
            mc_list.u50xffdowoq0i51shes2o = xxxxxxxx[qqqqq++];
            mc_list.Sc3u9bp4wcy12rcyragyg = xxxxxxxx[qqqqq++];
            mc_list.Fzqxw9xezx1ggajhcgxe0 = xxxxxxxx[qqqqq++];
            mc_list.cj2u0y712cah84vzwg7ao = xxxxxxxx[qqqqq++];
            mc_list.Olf9kru1h5wkmb876567b = xxxxxxxx[qqqqq++];
            mc_list.j6mxxuimouu5ix0pd3jie = xxxxxxxx[qqqqq++];
            mc_list.pft7pz466y20ka8r8sm0j = xxxxxxxx[qqqqq++];
            mc_list.zhnxk1bzlt4dvx35noh70 = xxxxxxxx[qqqqq++];
            mc_list.Hlq024viyiqvrt9626xxx = xxxxxxxx[qqqqq++];
            mc_list.nevn3yewhceukoa81w4qg = xxxxxxxx[qqqqq++];
            mc_list.J3bcciwcy6dr1ukvzd6dz = xxxxxxxx[qqqqq++];
            mc_list.j9bve5kctaegbhr3cskvc = xxxxxxxx[qqqqq++];
            mc_list.pc7k9x20eoixz10h2q8h8 = xxxxxxxx[qqqqq++];
            mc_list.Husy17pucqsh3lbwb0vqc = xxxxxxxx[qqqqq++];
            mc_list.ru8f2rqjqkbwtcwsujsch = xxxxxxxx[qqqqq++];
            mc_list.Jixx5b4o0efb4seovn6kq = xxxxxxxx[qqqqq++];
            mc_list.Ngd2o6x0ytc2hti46kj0w = xxxxxxxx[qqqqq++];
            mc_list.Actlf91b8i6hmhvbf5j8n = xxxxxxxx[qqqqq++];
            mc_list.odzgcm4ljkrldfxow2wpf = xxxxxxxx[qqqqq++];
            mc_list.zv1qw4q97hzablmsmmj3f = xxxxxxxx[qqqqq++];
            mc_list.dp2y1vehugomi332mjth6 = xxxxxxxx[qqqqq++];
            mc_list.g4obuqj12fcjs3jz3cyb0 = xxxxxxxx[qqqqq++];
            mc_list.Bip03m2hrugd3b6lb0dkl = xxxxxxxx[qqqqq++];
            mc_list.Bmooee4oud8jusrxoxiiy = xxxxxxxx[qqqqq++];
            mc_list.icki88qr78yc8o0o4awyr = xxxxxxxx[qqqqq++];
            mc_list.rnxov6skuj7os5vjcfqfx = xxxxxxxx[qqqqq++];
            mc_list.Jmrvp6kf2d3nat0lp5wbp = xxxxxxxx[qqqqq++];
            mc_list.Zg7xbkud3rmyurbe5b9zw = xxxxxxxx[qqqqq++];
            mc_list.Jnsrptn8ej3gsozrp3uel = xxxxxxxx[qqqqq++];
            mc_list.Qgml0f2tsvqn67pcxpir6 = xxxxxxxx[qqqqq++];
            mc_list.yw9txgfg1tybq4opah0k1 = xxxxxxxx[qqqqq++];
            mc_list.Y4ps3qjv9w4avdiyg3yu9 = xxxxxxxx[qqqqq++];
            mc_list.Cw197o6ct9cpz70cgrzg6 = xxxxxxxx[qqqqq++];
            mc_list.Othezyqnvzigtflecqvot = xxxxxxxx[qqqqq++];
            mc_list.Xgc9tokynfszeryppxki8 = xxxxxxxx[qqqqq++];
            mc_list.Rtq4166twva06kxzrhuko = xxxxxxxx[qqqqq++];
            mc_list.j1aqgtccr5zogmq90hixs = xxxxxxxx[qqqqq++];
            mc_list.b0b1f223387hc93gtaxh4 = xxxxxxxx[qqqqq++];
            mc_list.v3c05vtt4x9k972xziko0 = xxxxxxxx[qqqqq++];
            mc_list.fiit7smhtjq0ua3yyl6ui = xxxxxxxx[qqqqq++];
            mc_list.Lj9g8xhehfqlzirvvt3ni = xxxxxxxx[qqqqq++];
            mc_list.Amaugjz9ed9ol0fqjbujk = xxxxxxxx[qqqqq++];
            mc_list.Than3faltidfssl6jo9z7 = xxxxxxxx[qqqqq++];
            mc_list.Hiadgb99calt8tdbmw1bi = xxxxxxxx[qqqqq++];
            mc_list.Zoq5a463pjh5c4lcg6h1g = xxxxxxxx[qqqqq++];
            mc_list.Ibis7tg8pktwx8rt1fcle = xxxxxxxx[qqqqq++];
            mc_list.Mfu32preha4pp94hf78ry = xxxxxxxx[qqqqq++];
            mc_list.h8nezvhdn2kb45warp0rc = xxxxxxxx[qqqqq++];
            mc_list.Yc1opegxdjn4gvxg2pdgh = xxxxxxxx[qqqqq++];
            mc_list.zn0p02vun400hrpwg8zvp = xxxxxxxx[qqqqq++];
            mc_list.vu9dop5iipibmtjyllyxs = xxxxxxxx[qqqqq++];
            mc_list.Dwkjtxwygaa30r1xnxbk7 = xxxxxxxx[qqqqq++];
            mc_list.Rml7vyoyi0l4kbc3k0u03 = xxxxxxxx[qqqqq++];
            mc_list.Jgchppl41vkxknzgkmx4j = xxxxxxxx[qqqqq++];
            mc_list.L8qpzfsyo8nxckr0jdsgm = xxxxxxxx[qqqqq++];
            mc_list.Nt7wqxt6m6s7czr40xrk6 = xxxxxxxx[qqqqq++];
            mc_list.Rxq2ixva686g4qr0b39cv = xxxxxxxx[qqqqq++];
            mc_list.Dwlrqpun3wawvikzden3c = xxxxxxxx[qqqqq++];
            mc_list.ttanaldwh136ypyjl8m3c = xxxxxxxx[qqqqq++];
            mc_list.Xhhj8juwg2w7pfacw8rel = xxxxxxxx[qqqqq++];
            mc_list.Z8fb3e8gtbne1u04l0p10 = xxxxxxxx[qqqqq++];
            mc_list.Qrqpe6qsowxnrirecfq3k = xxxxxxxx[qqqqq++];
            mc_list.qoceosf5pg05s0n4sz76y = xxxxxxxx[qqqqq++];
            mc_list.rq16naxsdw1fkwqmolbv0 = xxxxxxxx[qqqqq++];
            mc_list.ovdi62415wwmitf4wg1o5 = xxxxxxxx[qqqqq++];
            mc_list.kx12ouv6japhylgcmt9vf = xxxxxxxx[qqqqq++];
            mc_list.h6xqao70qv0itw0d3k4mg = xxxxxxxx[qqqqq++];
            mc_list.b8r4hpy6ncrcggi99k29w = xxxxxxxx[qqqqq++];
            mc_list.j4qykhxbuciczxoho3jv0 = xxxxxxxx[qqqqq++];
            mc_list.Zamndxbno1ets4zms2ua1 = xxxxxxxx[qqqqq++];
            mc_list.Zwml3pnt1bugahiwscuwf = xxxxxxxx[qqqqq++];
            mc_list.mjx38zu48czwjj3dybtyk = xxxxxxxx[qqqqq++];
            mc_list.Fsvmh7skwd3ph75r9sme5 = xxxxxxxx[qqqqq++];
            mc_list.Isuzm871ne7qs6mwykwag = xxxxxxxx[qqqqq++];
            #endregion
            #region ultList
            ult_list.kkmg57b7a5jhdhlsy1rbv = xxxxxxxxx[qqqqqq++];
            ult_list.d16rfn7lvi3z6m7vkzrdu = xxxxxxxxx[qqqqqq++];
            ult_list.Nvnca12ceuy2jn9pm105l = xxxxxxxxx[qqqqqq++];
            ult_list.uc0frojmrgrio7ypn4qnu = xxxxxxxxx[qqqqqq++];
            ult_list.b4haubpsmsjt9w1r4iuvs = xxxxxxxxx[qqqqqq++];
            ult_list.aqv7dqomzucskmkr5zuq8 = xxxxxxxxx[qqqqqq++];
            ult_list.P5s6ysmgofoud2ygfnxo5 = xxxxxxxxx[qqqqqq++];
            ult_list.cd31q1iwlkvfydw0qvaeh = xxxxxxxxx[qqqqqq++];
            ult_list.Awgra7iprghv1p357htgz = xxxxxxxxx[qqqqqq++];
            ult_list.Jvp5voqfiexxj37a7l1ss = xxxxxxxxx[qqqqqq++];
            ult_list.U2ffc9oij13ic3pvhk6vq = xxxxxxxxx[qqqqqq++];
            ult_list.uchnttm8s38wqax6qk2va = xxxxxxxxx[qqqqqq++];
            ult_list.Hh5qlovqol3wpgcpv1wsx = xxxxxxxxx[qqqqqq++];
            ult_list.tq0q3h2bfsf6skuig0ce8 = xxxxxxxxx[qqqqqq++];
            ult_list.C6ugalgj7ilyxj7urpxdv = xxxxxxxxx[qqqqqq++];
            ult_list.Ktk5f6eev4i4zsu16tpra = xxxxxxxxx[qqqqqq++];
            ult_list.Asd7gqjima00d8sovyaeh = xxxxxxxxx[qqqqqq++];
            ult_list.Ngd2o6x0ytc2hti46kj0w = xxxxxxxxx[qqqqqq++];
            ult_list.h51vdr109gfhskk85a80q = xxxxxxxxx[qqqqqq++];
            ult_list.Xdtgl2074p8j9lrlkcarz = xxxxxxxxx[qqqqqq++];
            ult_list.Gjgsaqp05fhpo8itmvjk1 = xxxxxxxxx[qqqqqq++];
            ult_list.v35th6ig28y29rbh7bg5m = xxxxxxxxx[qqqqqq++];
            ult_list.J32axm662236lv0jxcy72 = xxxxxxxxx[qqqqqq++];
            ult_list.bj77roq77awkoo712fmzc = xxxxxxxxx[qqqqqq++];
            ult_list.Shd489aj1f3l0cwdcei2c = xxxxxxxxx[qqqqqq++];
            ult_list.p7dcmykn27dhjvbafc8ro = xxxxxxxxx[qqqqqq++];
            ult_list.bgf1hkul14zx7txeebsjz = xxxxxxxxx[qqqqqq++];
            ult_list.lxr4cvbfbw8ag0o51l4be = xxxxxxxxx[qqqqqq++];
            ult_list.Rxq2ixva686g4qr0b39cv = xxxxxxxxx[qqqqqq++];
            ult_list.zpkf5zrge2m3grf1ctvwl = xxxxxxxxx[qqqqqq++];
            ult_list.Zkhe14qr7yfqwj1zxpct8 = xxxxxxxxx[qqqqqq++];
            ult_list.Jdwftc7csbyfzcj8hfobi = xxxxxxxxx[qqqqqq++];
            ult_list.yajqw6g6zqdwrcyiybuy7 = xxxxxxxxx[qqqqqq++];
            ult_list.In85990ua3rsbak74gsx5 = xxxxxxxxx[qqqqqq++];
            ult_list.Vanc8cyxnbjfuze5bnqwg = xxxxxxxxx[qqqqqq++];
            ult_list.zv1qw4q97hzablmsmmj3f = xxxxxxxxx[qqqqqq++];
            ult_list.Actlf91b8i6hmhvbf5j8n = xxxxxxxxx[qqqqqq++];
            ult_list.Xh5wx1ww6h4fqtldp8mxw = xxxxxxxxx[qqqqqq++];
            ult_list.bitn472xqu2t2tpehuk2y = xxxxxxxxx[qqqqqq++];
            ult_list.Tlpzt0agvn3fep0jxs108 = xxxxxxxxx[qqqqqq++];
            ult_list.s9gmolm6eg65xu9l343d6 = xxxxxxxxx[qqqqqq++];
            ult_list.xwcc1xon2fqy3t3yeckio = xxxxxxxxx[qqqqqq++];
            ult_list.Pdcor8ruqpq3yx3m7ev16 = xxxxxxxxx[qqqqqq++];
            ult_list.g8d80hbd0kg1tvz2txv2f = xxxxxxxxx[qqqqqq++];
            ult_list.W47nzx9fzr1aqtlpaexj6 = xxxxxxxxx[qqqqqq++];
            ult_list.uo3fiyjd7b2js2wbb0idh = xxxxxxxxx[qqqqqq++];
            ult_list.c6nitgkajk2pal61b1ean = xxxxxxxxx[qqqqqq++];
            ult_list.n5iyzrrx6joj5ubaauwco = xxxxxxxxx[qqqqqq++];
            ult_list.Yj4ximjh55ajwhzlyytby = xxxxxxxxx[qqqqqq++];
            ult_list.Zwd96tupk60rfcwebupmh = xxxxxxxxx[qqqqqq++];
            ult_list.Yk1bjfxx4zmlaun1f50z2 = xxxxxxxxx[qqqqqq++];
            ult_list.t469etdtvvkdig4n4cz15 = xxxxxxxxx[qqqqqq++];
            ult_list.E6uuupquy58g30unn260b = xxxxxxxxx[qqqqqq++];
            ult_list.idcipic40a6df945jmozc = xxxxxxxxx[qqqqqq++];
            ult_list.Ct50xdjswqacf8014mflm = xxxxxxxxx[qqqqqq++];
            ult_list.sv3y85b46ydbngxrilvl9 = xxxxxxxxx[qqqqqq++];
            ult_list.Tthk948gjca7hdnqzh11c = xxxxxxxxx[qqqqqq++];
            ult_list.lpw7n9y8lits03m2otye7 = xxxxxxxxx[qqqqqq++];
            ult_list.b4u3yg3k3g1au3it7k6af = xxxxxxxxx[qqqqqq++];
            ult_list.m95bsrhn0ucgsw4i52igf = xxxxxxxxx[qqqqqq++];
            ult_list.zoeeqs86v25dwx978slg9 = xxxxxxxxx[qqqqqq++];
            ult_list.icki88qr78yc8o0o4awyr = xxxxxxxxx[qqqqqq++];
            ult_list.ek28z8t5w7jmqbhz45a5a = xxxxxxxxx[qqqqqq++];
            ult_list.A97ud0c62ich8mxyxvufb = xxxxxxxxx[qqqqqq++];
            ult_list.jxlb0mx9sf690z8tmh486 = xxxxxxxxx[qqqqqq++];
            ult_list.Kxco4boeoscjl53nx531c = xxxxxxxxx[qqqqqq++];
            ult_list.wcnwmcqindlp0vinu7gz8 = xxxxxxxxx[qqqqqq++];
            ult_list.ytvadwy55v5qnd53jqb2u = xxxxxxxxx[qqqqqq++];
            ult_list.Yf1kgxtzwp30ze2trnszo = xxxxxxxxx[qqqqqq++];
            ult_list.Uum2h5bwzpde5oe22k3qd = xxxxxxxxx[qqqqqq++];
            ult_list.J9jq2f1jlml67mo938clv = xxxxxxxxx[qqqqqq++];
            ult_list.d69hlz4ka91htcwol6acd = xxxxxxxxx[qqqqqq++];
            ult_list.ru8f2rqjqkbwtcwsujsch = xxxxxxxxx[qqqqqq++];
            ult_list.Nqjlven4z9y68ai3uvdes = xxxxxxxxx[qqqqqq++];
            ult_list.fkk5979ahopj271wsa294 = xxxxxxxxx[qqqqqq++];
            ult_list.Il3aqc4hkbwn89uagnlxf = xxxxxxxxx[qqqqqq++];
            ult_list.fmxktpebjvku3ekgqjp7d = xxxxxxxxx[qqqqqq++];
            ult_list.d10g2bk2m0qfyf3rytqa8 = xxxxxxxxx[qqqqqq++];
            ult_list.E38y0cu4yot67ouovqsse = xxxxxxxxx[qqqqqq++];
            ult_list.Ylysef5xk2r72o9j2bpzq = xxxxxxxxx[qqqqqq++];
            ult_list.Nqd8huhkvp6ia86wfqtvg = xxxxxxxxx[qqqqqq++];
            ult_list.n6t66vdtpkwtb2cxi0lu8 = xxxxxxxxx[qqqqqq++];
            ult_list.Mvc56j74smels4st7hbvq = xxxxxxxxx[qqqqqq++];
            ult_list.Xy5k3mhh6ioof9xv4x9xy = xxxxxxxxx[qqqqqq++];
            ult_list.aibcgkbgjs0ayzdk02cuc = xxxxxxxxx[qqqqqq++];
            ult_list.gz8j8zgth6zjio6ix2dsk = xxxxxxxxx[qqqqqq++];
            ult_list.Ea7nsnzp5m5cvou9k1dre = xxxxxxxxx[qqqqqq++];
            ult_list.Ps8n2r1k35x7ytjb1u0u9 = xxxxxxxxx[qqqqqq++];
            ult_list.G0x4bxx33675ywo2buvbv = xxxxxxxxx[qqqqqq++];
            ult_list.cpwaz8ncfsizatrn4elf3 = xxxxxxxxx[qqqqqq++];
            ult_list.O8r771jberag9z9uexedj = xxxxxxxxx[qqqqqq++];
            ult_list.Pvykyh4fea77jphx7yc8y = xxxxxxxxx[qqqqqq++];
            ult_list.vm7ysb0lu7jh9i6ikgiz7 = xxxxxxxxx[qqqqqq++];
            ult_list.pd6etc7trlwpvgo7x92wr = xxxxxxxxx[qqqqqq++];
            ult_list.Usvh107at9n1qmaup2epe = xxxxxxxxx[qqqqqq++];
            ult_list.zg4ik3w348ukowioszn3f = xxxxxxxxx[qqqqqq++];
            ult_list.S7ar859if3s55mrkym77d = xxxxxxxxx[qqqqqq++];
            ult_list.Oefupdm3ewc0plkhgmko4 = xxxxxxxxx[qqqqqq++];
            ult_list.xoyaqzobe7zg1pza1pc4t = xxxxxxxxx[qqqqqq++];
            ult_list.Mfds12ptckelctczqee0y = xxxxxxxxx[qqqqqq++];
            ult_list.ylyh6589vjq0kp5ykfjyj = xxxxxxxxx[qqqqqq++];
            ult_list.d5942odinauwllghr5w53 = xxxxxxxxx[qqqqqq++];
            ult_list.Op824nbwxnol5qq3l4os2 = xxxxxxxxx[qqqqqq++];
            ult_list.Dzwvy3p8ixhoso446g9om = xxxxxxxxx[qqqqqq++];
            ult_list.Qqu9vj045n6wrddd3nda8 = xxxxxxxxx[qqqqqq++];
            ult_list.vcoaf92rvw6f49flfw9pc = xxxxxxxxx[qqqqqq++];
            ult_list.oud51v7ok0atc8qkcu3wr = xxxxxxxxx[qqqqqq++];
            ult_list.qjiiq01r828goy7n8siub = xxxxxxxxx[qqqqqq++];
            ult_list.Dng5vnd5s5iu3m83l5oa3 = xxxxxxxxx[qqqqqq++];
            ult_list.tqqs14fnbdltmjudcnwdx = xxxxxxxxx[qqqqqq++];
            ult_list.M58ctonb0ebdeh0v7yd1h = xxxxxxxxx[qqqqqq++];
            ult_list.pz4puyht2508ikn7ro8nq = xxxxxxxxx[qqqqqq++];
            ult_list.gex7cipes9gok558bts5g = xxxxxxxxx[qqqqqq++];
            ult_list.D3j5nc4342dsz0kdb7mli = xxxxxxxxx[qqqqqq++];
            ult_list.Ydb2ymxmpo685dgw42u9n = xxxxxxxxx[qqqqqq++];
            ult_list.Lwkz5xzuu26dhgwd1qgap = xxxxxxxxx[qqqqqq++];
            ult_list.grop6fwwtxiinm8w2m7bx = xxxxxxxxx[qqqqqq++];
            ult_list.Hd2ws20zqc5owtu5h52za = xxxxxxxxx[qqqqqq++];
            ult_list.ada6tx04ialpsenmz17do = xxxxxxxxx[qqqqqq++];
            ult_list.C7fr24w32co7thbuc5d4c = xxxxxxxxx[qqqqqq++];
            ult_list.F6rq1q5sgigq7zkc7teyb = xxxxxxxxx[qqqqqq++];
            ult_list.g6cgvn5lc2j4xdasqy0m9 = xxxxxxxxx[qqqqqq++];
            ult_list.sext589378ws1p2f3k5nu = xxxxxxxxx[qqqqqq++];
            ult_list.vupn8m24y1wj31z7jskwo = xxxxxxxxx[qqqqqq++];
            ult_list.Gboef0cik4zf3m2oyjvtf = xxxxxxxxx[qqqqqq++];
            ult_list.ufffmnz9046kai9tglihj = xxxxxxxxx[qqqqqq++];
            ult_list.hut3cqpq9ki961rj6i22b = xxxxxxxxx[qqqqqq++];
            ult_list.Pcsq8ofvnjinbojuvlc58 = xxxxxxxxx[qqqqqq++];
            ult_list.tjapv6nj1zw7sqggcd5yl = xxxxxxxxx[qqqqqq++];
            ult_list.f4c0c58sr6xvg632cc4ba = xxxxxxxxx[qqqqqq++];
            ult_list.q53xwk4vicsrpotdgkm08 = xxxxxxxxx[qqqqqq++];
            ult_list.R525cb1wwne9j4xpapd1a = xxxxxxxxx[qqqqqq++];
            ult_list.gmkongf2mzw10dcfd8vvt = xxxxxxxxx[qqqqqq++];
            ult_list.si848siv0ed1hu0vunr66 = xxxxxxxxx[qqqqqq++];
            ult_list.Z9j61njg1slb3sh2nqq57 = xxxxxxxxx[qqqqqq++];
            ult_list.jtbiw5ufmru0rzzu8ccui = xxxxxxxxx[qqqqqq++];
            ult_list.Zc4h2b7yn8hd7v8m7bk62 = xxxxxxxxx[qqqqqq++];
            ult_list.Je3k7vte3w3lo5w5z3pu7 = xxxxxxxxx[qqqqqq++];
            ult_list.H52ojq261mx62f2ejujhs = xxxxxxxxx[qqqqqq++];
            ult_list.f350e6zb8cxdw096loaq2 = xxxxxxxxx[qqqqqq++];
            ult_list.sxnq96tidswfuhceacjn1 = xxxxxxxxx[qqqqqq++];
            ult_list.O17yztkcg524t2p4po0im = xxxxxxxxx[qqqqqq++];
            ult_list.Mq8qqrtox46jexzb0y0pv = xxxxxxxxx[qqqqqq++];
            ult_list.Mrchz1v12hywlbak2qiha = xxxxxxxxx[qqqqqq++];
            ult_list.Q5ol9tz5dod1xkw5o10y6 = xxxxxxxxx[qqqqqq++];
            ult_list.Z2wpfk8dxojjqtp0d0igc = xxxxxxxxx[qqqqqq++];
            ult_list.j0xoe78aof6azulij8gzu = xxxxxxxxx[qqqqqq++];
            ult_list.swiye4ke561xtuvgeilil = xxxxxxxxx[qqqqqq++];
            ult_list.Q7yssit5hgreusvpr9jkw = xxxxxxxxx[qqqqqq++];
            ult_list.I3esnirf8fdaw7nx7zf6k = xxxxxxxxx[qqqqqq++];
            ult_list.So7ypwca8gyf9bvs2gej0 = xxxxxxxxx[qqqqqq++];
            ult_list.Lo7cdqswf7s13m9h6pc0f = xxxxxxxxx[qqqqqq++];
            ult_list.org2q8bvm550v6g6r4v9e = xxxxxxxxx[qqqqqq++];
            ult_list.uq5ax6lwcnvmdodjhfweo = xxxxxxxxx[qqqqqq++];
            ult_list.G7kjc2g7gd0c4dvzwfetw = xxxxxxxxx[qqqqqq++];
            ult_list.Rps8jswg26ymiruhgv75z = xxxxxxxxx[qqqqqq++];
            ult_list.kop8xtsa3oxbacr9ol9uf = xxxxxxxxx[qqqqqq++];
            ult_list.Saejoo3mtotahj4i9uk09 = xxxxxxxxx[qqqqqq++];
            ult_list.xwnnjxlg9v34vnzzjgujz = xxxxxxxxx[qqqqqq++];
            ult_list.Wfqo5w30ij94ajusx090c = xxxxxxxxx[qqqqqq++];
            ult_list.Nxn8vyo4te839ba4g8sx3 = xxxxxxxxx[qqqqqq++];
            ult_list.Yv80v94m2hcsg3gc2s3gi = xxxxxxxxx[qqqqqq++];
            ult_list.x8gdkg48i0myim7rzxnv4 = xxxxxxxxx[qqqqqq++];
            ult_list.Xbcmcqxg58cxemo5o4ppe = xxxxxxxxx[qqqqqq++];
            ult_list.C5dc4nk36zmefhmg63b4s = xxxxxxxxx[qqqqqq++];
            ult_list.vxdkyyu67cd4i7r989syf = xxxxxxxxx[qqqqqq++];
            ult_list.J3kfv7s6ai8u3u6q12nf3 = xxxxxxxxx[qqqqqq++];
            ult_list.no54vr6h0mi6lmzzn7z0f = xxxxxxxxx[qqqqqq++];
            ult_list.dx5zdsbxbaifwm517puda = xxxxxxxxx[qqqqqq++];
            ult_list.olfxabir5hd3dwafsg0dq = xxxxxxxxx[qqqqqq++];
            ult_list.mjf0eck9q717nvz4rizcj = xxxxxxxxx[qqqqqq++];
            ult_list.Xu146ob9mzi1zrx1fps70 = xxxxxxxxx[qqqqqq++];
            ult_list.zja7pfpr6fykqx36rl3za = xxxxxxxxx[qqqqqq++];
            ult_list.ulw0z9i688ycz1mat3o19 = xxxxxxxxx[qqqqqq++];
            ult_list.Ktcgb8kbx1j3v36pwjiq6 = xxxxxxxxx[qqqqqq++];
            ult_list.rst8rwuzl2my7c0qiqz0y = xxxxxxxxx[qqqqqq++];
            ult_list.Tgihy4q646nju75qaezoo = xxxxxxxxx[qqqqqq++];
            ult_list.gv05ov6tcqhfus1zkljwf = xxxxxxxxx[qqqqqq++];
            ult_list.fy4opdd9hkqe1kmcqn3d8 = xxxxxxxxx[qqqqqq++];
            ult_list.h73ozhzbffgy4cjz0lplr = xxxxxxxxx[qqqqqq++];
            ult_list.K6m29cojgzj6sfxh5qzhn = xxxxxxxxx[qqqqqq++];
            ult_list.pc3cd1jybwmf8rwbvaow3 = xxxxxxxxx[qqqqqq++];
            ult_list.yq5q5kfzpc4kvh7pdjzi3 = xxxxxxxxx[qqqqqq++];
            ult_list.lzitme8atvv4bco7gmg3v = xxxxxxxxx[qqqqqq++];
            ult_list.Nuj82bt0uh8llg3dile1m = xxxxxxxxx[qqqqqq++];
            ult_list.fef3q9it3ai0d5wjpj1kv = xxxxxxxxx[qqqqqq++];
            ult_list.chqlwjt5jkz4iprroqr23 = xxxxxxxxx[qqqqqq++];
            ult_list.l96t9iipuux8u3fey4ghq = xxxxxxxxx[qqqqqq++];
            ult_list.lnjslnrxof4919rvl7mob = xxxxxxxxx[qqqqqq++];
            ult_list.Idkzw0kpjn3ujklq0oiv1 = xxxxxxxxx[qqqqqq++];
            ult_list.zubpzyhulu30r2fncu5vd = xxxxxxxxx[qqqqqq++];
            ult_list.Gbnalk0qya56z1wqc5a8t = xxxxxxxxx[qqqqqq++];
            ult_list.Lzdzuccqe8ogsws0gado7 = xxxxxxxxx[qqqqqq++];
            ult_list.l06lz6b0gzkhu7bn7yqji = xxxxxxxxx[qqqqqq++];
            ult_list.Sjmzwzocj6jb1va332axa = xxxxxxxxx[qqqqqq++];
            ult_list.Tlkpxgwuue2st3gyngyar = xxxxxxxxx[qqqqqq++];
            ult_list.R8rjqjp86iuex2i786cpc = xxxxxxxxx[qqqqqq++];
            ult_list.p3ree0s7ompweagb3b9o1 = xxxxxxxxx[qqqqqq++];
            ult_list.Jxymux40uj0rei7yrnfz0 = xxxxxxxxx[qqqqqq++];
            ult_list.Vruu38axwgd77yypffuq5 = xxxxxxxxx[qqqqqq++];
            ult_list.P1mfw8r6druq5jxkddsvw = xxxxxxxxx[qqqqqq++];
            ult_list.vheof2tqursl2y39eo85q = xxxxxxxxx[qqqqqq++];
            ult_list.Oeuewxbxanmbw83yw893o = xxxxxxxxx[qqqqqq++];
            ult_list.bblv8jxhqyfyexfsw92s1 = xxxxxxxxx[qqqqqq++];
            ult_list.W5pgfry44emfpfqp29fma = xxxxxxxxx[qqqqqq++];
            ult_list.u4hmiy693lcxgrbtvfqru = xxxxxxxxx[qqqqqq++];
            ult_list.L2mllai9h0zw4pr7xd8ru = xxxxxxxxx[qqqqqq++];
            ult_list.uzatbz88d63xty2hr5ahp = xxxxxxxxx[qqqqqq++];
            ult_list.j71dvp219d5sh97422kwb = xxxxxxxxx[qqqqqq++];
            ult_list.Pk5l6cdgwkp2c0bx878w6 = xxxxxxxxx[qqqqqq++];
            ult_list.yh99alqt18pzvogfbqgsl = xxxxxxxxx[qqqqqq++];
            ult_list.Ewezydpq7j644xz3k5kvw = xxxxxxxxx[qqqqqq++];
            ult_list.ntpy40gxu6ws0pkjcjl65 = xxxxxxxxx[qqqqqq++];
            ult_list.Q9wrbu57zm4ffv61hp487 = xxxxxxxxx[qqqqqq++];
            ult_list.L16axneonp1bunzw77wk5 = xxxxxxxxx[qqqqqq++];
            ult_list.Xi8hcqmftscwpn9ddw4yq = xxxxxxxxx[qqqqqq++];
            ult_list.Zqujv3v26j4j3ucz3y7hb = xxxxxxxxx[qqqqqq++];
            ult_list.L855nevgovskd83oyzwj4 = xxxxxxxxx[qqqqqq++];
            ult_list.Jujjx235kkkpywwruz5rh = xxxxxxxxx[qqqqqq++];
            ult_list.Xook0ug40ybebymqzwhvk = xxxxxxxxx[qqqqqq++];
            ult_list.S06dldvqlm383fcpg8sdv = xxxxxxxxx[qqqqqq++];
            ult_list.X9ewjgnakg28rkgrsk8x8 = xxxxxxxxx[qqqqqq++];
            ult_list.Bzso4ck6w6k0dd9lvj4fz = xxxxxxxxx[qqqqqq++];
            ult_list.Vvgfu5rt8u7694f6q01g5 = xxxxxxxxx[qqqqqq++];
            ult_list.pron5b4ok55ip38mtn49u = xxxxxxxxx[qqqqqq++];
            ult_list.f17b9o0j8d44sxkhh2ksa = xxxxxxxxx[qqqqqq++];
            ult_list.Mcidzyqg62nd61wdumoqk = xxxxxxxxx[qqqqqq++];
            ult_list.Ovqhaa01t0f0cl9rt4ll7 = xxxxxxxxx[qqqqqq++];
            ult_list.cumfz180bhx4o3hpwbcy7 = xxxxxxxxx[qqqqqq++];
            ult_list.qzwgxwau2etzbdt0jkrjc = xxxxxxxxx[qqqqqq++];
            ult_list.a9zmclmjet5s2wni7fsd1 = xxxxxxxxx[qqqqqq++];
            ult_list.en87x83kkrflt3w79kdlk = xxxxxxxxx[qqqqqq++];
            ult_list.W1qiib7ozk3d2oryb1yes = xxxxxxxxx[qqqqqq++];
            ult_list.Kb9xnt88apiwbg2a6zyvb = xxxxxxxxx[qqqqqq++];
            ult_list.Rov9xcsfl76hv93i134zc = xxxxxxxxx[qqqqqq++];
            ult_list.P8nkcgbwvr1mddddq99la = xxxxxxxxx[qqqqqq++];
            ult_list.b3xctaacmtic49tcal7ra = xxxxxxxxx[qqqqqq++];
            ult_list.X6t3gtes6z224tzjkl0bf = xxxxxxxxx[qqqqqq++];
            ult_list.O9kbjyreuacfcrkej3696 = xxxxxxxxx[qqqqqq++];
            ult_list.Ssfw1piljj2zu6mbwsurc = xxxxxxxxx[qqqqqq++];
            ult_list.Ta85xxzniv9rp1ew3xk3q = xxxxxxxxx[qqqqqq++];
            ult_list.ig4kinugfjs1ip75tj9e0 = xxxxxxxxx[qqqqqq++];
            ult_list.C4cyklk31zh8h1a5gyxkc = xxxxxxxxx[qqqqqq++];
            ult_list.Wti8dhia3iduxgdvdfa7d = xxxxxxxxx[qqqqqq++];
            ult_list.J1ppcttrobz5wzbgwevcc = xxxxxxxxx[qqqqqq++];
            ult_list.ujaswxlbxo2ax0gle26tx = xxxxxxxxx[qqqqqq++];
            ult_list.S0v1sh88f699t843063pi = xxxxxxxxx[qqqqqq++];
            ult_list.vs3ajzi5szc3hbomyi9pz = xxxxxxxxx[qqqqqq++];
            ult_list.Zm61p3qz6nuh9qlf6us39 = xxxxxxxxx[qqqqqq++];
            ult_list.ucpp4f1sures7o05wcvqi = xxxxxxxxx[qqqqqq++];
            ult_list.us8fe441ziqe0fpw7q6jb = xxxxxxxxx[qqqqqq++];
            ult_list.F8fpicku0qt39bvqdkkak = xxxxxxxxx[qqqqqq++];
            ult_list.f92lba218d7fglojnt6ct = xxxxxxxxx[qqqqqq++];
            ult_list.mjajzwfyu9swf68bg3nij = xxxxxxxxx[qqqqqq++];
            ult_list.Ctwwsnxxxlctniqb8swo4 = xxxxxxxxx[qqqqqq++];
            ult_list.reh9vk9knmcugx2axo0l9 = xxxxxxxxx[qqqqqq++];
            ult_list.tsai69j7p7cxh9nfmxbhn = xxxxxxxxx[qqqqqq++];
            ult_list.snjljsn0pqnu2komd8cvb = xxxxxxxxx[qqqqqq++];
            ult_list.lc4pjomgjxyans7wiz9nv = xxxxxxxxx[qqqqqq++];
            ult_list.qtr9us57ubbnupfls4c4g = xxxxxxxxx[qqqqqq++];
            ult_list.igq22ngjm1eo9yasu550t = xxxxxxxxx[qqqqqq++];
            ult_list.P66yhadkru3utheugyqnq = xxxxxxxxx[qqqqqq++];
            ult_list.Rwu26wn5ox1x9ll0vhgr6 = xxxxxxxxx[qqqqqq++];
            ult_list.ti6zx014rvp4yxo642m97 = xxxxxxxxx[qqqqqq++];
            ult_list.outz5qol4q35tzkdz5ef5 = xxxxxxxxx[qqqqqq++];
            ult_list.Utn2h68l6o524gumyg4hm = xxxxxxxxx[qqqqqq++];
            ult_list.hqaa2tk9nlg9xgeog0s8s = xxxxxxxxx[qqqqqq++];
            ult_list.ddopuabme7ota73osnaxw = xxxxxxxxx[qqqqqq++];
            ult_list.y87vh6eycgf7y6yibup1s = xxxxxxxxx[qqqqqq++];
            ult_list.w74p6x90mz5304mtf3iy5 = xxxxxxxxx[qqqqqq++];
            ult_list.wmk82r4eivn87ifyerzt7 = xxxxxxxxx[qqqqqq++];
            ult_list.Colnlmh4tfcil06fx5xp3 = xxxxxxxxx[qqqqqq++];
            ult_list.x4r1l65szypxdz1rb6xpj = xxxxxxxxx[qqqqqq++];
            ult_list.qaudsfwgm9ai4k0c7ucor = xxxxxxxxx[qqqqqq++];
            ult_list.Dyf50pew9oe1ihf3jnifj = xxxxxxxxx[qqqqqq++];
            ult_list.kygzyg338ztr4i8u4zndb = xxxxxxxxx[qqqqqq++];
            ult_list.V9h75j9wf62tl6e2sphtv = xxxxxxxxx[qqqqqq++];
            ult_list.flxk5w69ju8uafekrj3og = xxxxxxxxx[qqqqqq++];
            ult_list.Lgxc69g8efcos3rzl7cim = xxxxxxxxx[qqqqqq++];
            ult_list.vanu7itf14ljv2mpxvn5q = xxxxxxxxx[qqqqqq++];
            ult_list.M85dstbgxo8thvcg3deyq = xxxxxxxxx[qqqqqq++];
            ult_list.Qagj4220rcc0tg1nfjcog = xxxxxxxxx[qqqqqq++];
            ult_list.pmrn51cazgvuryoq2vjz0 = xxxxxxxxx[qqqqqq++];
            ult_list.ilzvmi9a3zbtb0ses2ncz = xxxxxxxxx[qqqqqq++];
            ult_list.w2bkqsj52lutamx5w6bx1 = xxxxxxxxx[qqqqqq++];
            ult_list.Vch9fcs0gj79hh98kpe39 = xxxxxxxxx[qqqqqq++];
            ult_list.yehrerszcwsw1zkxubfn9 = xxxxxxxxx[qqqqqq++];
            ult_list.kszsoul3myvh1hyx4z5xt = xxxxxxxxx[qqqqqq++];
            ult_list.H3yt1lir6mnij03roydtf = xxxxxxxxx[qqqqqq++];
            ult_list.aznobl4ubw35gr4g3g1dm = xxxxxxxxx[qqqqqq++];
            ult_list.V469km7anhifwls3qjrpq = xxxxxxxxx[qqqqqq++];
            ult_list.ixqktsc16xxi6agl3ndzn = xxxxxxxxx[qqqqqq++];
            ult_list.l3g4oxi49a0uymwznwq1j = xxxxxxxxx[qqqqqq++];
            ult_list.Xfe0uaiwegacf2bwrw55j = xxxxxxxxx[qqqqqq++];
            ult_list.kh157ctunr7h6lpizqjno = xxxxxxxxx[qqqqqq++];
            ult_list.Xw03axo6kah10urboi2rq = xxxxxxxxx[qqqqqq++];
            ult_list.Qyjwi2f4m37amrrxr85jy = xxxxxxxxx[qqqqqq++];
            ult_list.Jwjmjgrm4o3qx270neuhs = xxxxxxxxx[qqqqqq++];
            ult_list.huurchoid4upmt23o6mcl = xxxxxxxxx[qqqqqq++];
            ult_list.p3979qmuu0jnny1ec2kc1 = xxxxxxxxx[qqqqqq++];
            ult_list.Nii94nde9emr1s5yuwrw4 = xxxxxxxxx[qqqqqq++];
            ult_list.p4ymvgcy2y1wvkkduadvm = xxxxxxxxx[qqqqqq++];
            ult_list.xiuqo1v42cupkxh7u6oxl = xxxxxxxxx[qqqqqq++];
            ult_list.dpllmz5ri2ets6jwkh73v = xxxxxxxxx[qqqqqq++];
            ult_list.xh60dll8cnsywqk76idy6 = xxxxxxxxx[qqqqqq++];
            ult_list.rew98a6oovwm8ubdsvhbo = xxxxxxxxx[qqqqqq++];
            ult_list.H7o4kp7bwmzcej6qv61do = xxxxxxxxx[qqqqqq++];
            ult_list.o7tr0f0bpgolack801zsd = xxxxxxxxx[qqqqqq++];
            ult_list.i52c5uizyvsv3ewrn6dey = xxxxxxxxx[qqqqqq++];
            ult_list.R5wp7nbc8704hi9tervg7 = xxxxxxxxx[qqqqqq++];
            ult_list.Vbn3y2r5p2v3xv3iimess = xxxxxxxxx[qqqqqq++];
            ult_list.Og004yovfcm6k7gxs21e6 = xxxxxxxxx[qqqqqq++];
            ult_list.hgwgm6gvo1l2mdx1lx8ao = xxxxxxxxx[qqqqqq++];
            ult_list.q60nqytzpg0pvavmtun8r = xxxxxxxxx[qqqqqq++];
            ult_list.d2go1ttgkom430zapjzyn = xxxxxxxxx[qqqqqq++];
            ult_list.Rqgia6hmskh1jasvzlw6f = xxxxxxxxx[qqqqqq++];
            ult_list.Hmpa45v4kv6k4zvbw7n5m = xxxxxxxxx[qqqqqq++];
            ult_list.jgy9gvu3iekew2saafofk = xxxxxxxxx[qqqqqq++];
            ult_list.wnc6n76upr9180t8xq3jk = xxxxxxxxx[qqqqqq++];
            ult_list.T2wgl2xbguaqthu9e2vjy = xxxxxxxxx[qqqqqq++];
            ult_list.Vao0esf5iunumf5s16vvj = xxxxxxxxx[qqqqqq++];
            ult_list.x4o4rti0gu354tukn5b3w = xxxxxxxxx[qqqqqq++];
            ult_list.V12whqdombiigaa3vtjvj = xxxxxxxxx[qqqqqq++];
            ult_list.Xpzy0rz2uuf5428rc1xbp = xxxxxxxxx[qqqqqq++];
            ult_list.a3nelvy4s0y3wqthce6z0 = xxxxxxxxx[qqqqqq++];
            ult_list.Nl326moobt146hfqbumf3 = xxxxxxxxx[qqqqqq++];
            ult_list.R4j36ljoi1p857keavh9h = xxxxxxxxx[qqqqqq++];
            ult_list.Zj29946okdfr1165b96vd = xxxxxxxxx[qqqqqq++];
            ult_list.G9gke3997bppnn7tbk4bo = xxxxxxxxx[qqqqqq++];
            ult_list.g4dfv7gdbodazw5hds5g5 = xxxxxxxxx[qqqqqq++];
            ult_list.T7rjx0dn3m41f4hi6azgw = xxxxxxxxx[qqqqqq++];
            ult_list.M57s7p01s0qtoygqn3s53 = xxxxxxxxx[qqqqqq++];
            ult_list.x2kzul45owkc3zt9a8lha = xxxxxxxxx[qqqqqq++];
            ult_list.Wm5c5kmqx04cs3m3ui8wu = xxxxxxxxx[qqqqqq++];
            ult_list.h4m5qo0yegqpsk5r7i3k8 = xxxxxxxxx[qqqqqq++];
            ult_list.Xnhy1hu9nzp1azxfaavrt = xxxxxxxxx[qqqqqq++];
            ult_list.Txmqkpui856moxxgwydi4 = xxxxxxxxx[qqqqqq++];
            ult_list.L1lp1yo2xzr6wl0kb1nmw = xxxxxxxxx[qqqqqq++];
            ult_list.klar2dmmcqsl6nx2m7ywa = xxxxxxxxx[qqqqqq++];
            ult_list.E2uioazd7me5k1vs04wyl = xxxxxxxxx[qqqqqq++];
            ult_list.Nczhhfajy78ec1l411d2n = xxxxxxxxx[qqqqqq++];
            ult_list.Jjo0lxbe1fbrkak8cnbj9 = xxxxxxxxx[qqqqqq++];
            ult_list.Bqpana2tq10803kbx95ud = xxxxxxxxx[qqqqqq++];
            ult_list.p5ss5r3cqn1n04374onl4 = xxxxxxxxx[qqqqqq++];
            ult_list.Esy9oc1r0jkdrrfe76e6g = xxxxxxxxx[qqqqqq++];
            ult_list.H0cdami5anhjvuzvhtd2z = xxxxxxxxx[qqqqqq++];
            ult_list.Bllhcx5jzy98jreepu8b4 = xxxxxxxxx[qqqqqq++];
            ult_list.u5rmcbs71t7o2lg4o4anr = xxxxxxxxx[qqqqqq++];
            ult_list.t9glni9epvgwub8348fbf = xxxxxxxxx[qqqqqq++];
            ult_list.S8rf1uf7kkzuuvu4zg93b = xxxxxxxxx[qqqqqq++];
            ult_list.Pnsgnk40nmapz9issat2d = xxxxxxxxx[qqqqqq++];
            ult_list.hb3f5vc8qdey9m91qk2r0 = xxxxxxxxx[qqqqqq++];
            ult_list.Mou7kk5uncmzxhzauml2i = xxxxxxxxx[qqqqqq++];
            ult_list.O6kkimqnaqciiccyr55u0 = xxxxxxxxx[qqqqqq++];
            ult_list.Truo1ob2w9gd8ai3ekz84 = xxxxxxxxx[qqqqqq++];
            ult_list.Qru69eruebtyr0b1m5t3k = xxxxxxxxx[qqqqqq++];
            ult_list.Tx1bk8jh3iuhg70i7xpx7 = xxxxxxxxx[qqqqqq++];
            ult_list.Zqxvpswh8rrj05xg0twa4 = xxxxxxxxx[qqqqqq++];
            ult_list.Dj15qmrta33yq554afv1m = xxxxxxxxx[qqqqqq++];
            ult_list.jcjm1lqlkusnao2yz1edb = xxxxxxxxx[qqqqqq++];
            ult_list.achfx23592gu75y19oef6 = xxxxxxxxx[qqqqqq++];
            ult_list.ifjpkpybchfibr0j4dy9s = xxxxxxxxx[qqqqqq++];
            ult_list.ivmro7qf0bykx9h5314hd = xxxxxxxxx[qqqqqq++];
            ult_list.C122w7tpfo65zexk31bn9 = xxxxxxxxx[qqqqqq++];
            ult_list.ytlbs5ubk5qdjr502u4qn = xxxxxxxxx[qqqqqq++];
            ult_list.Ja9le2usm6bb0rhuq0j1m = xxxxxxxxx[qqqqqq++];
            ult_list.Qrfk83wij7rj6v99t970k = xxxxxxxxx[qqqqqq++];
            ult_list.Kczn3on2jljckdd64zmkg = xxxxxxxxx[qqqqqq++];
            ult_list.Jmjoo1ffribr2trk11quq = xxxxxxxxx[qqqqqq++];
            ult_list.G488xp93rdf3wxu82k9ci = xxxxxxxxx[qqqqqq++];
            ult_list.yikbk2j1w3edj23lnl192 = xxxxxxxxx[qqqqqq++];
            ult_list.wmxoch4f9trr2olit6y4f = xxxxxxxxx[qqqqqq++];
            ult_list.yhhy9bu33iurtak6u68c7 = xxxxxxxxx[qqqqqq++];
            ult_list.se2dlxl5rv1qx63ue9pbw = xxxxxxxxx[qqqqqq++];
            ult_list.Gal08a71doyx8v6apemm0 = xxxxxxxxx[qqqqqq++];
            ult_list.Mzmiqd4wgz2ur7q72bekz = xxxxxxxxx[qqqqqq++];
            ult_list.vt1d6dsb92eawck6ydk5g = xxxxxxxxx[qqqqqq++];
            ult_list.flvowdgae9in9cwh8jlmu = xxxxxxxxx[qqqqqq++];
            ult_list.T2xnu17oxtjz1ieo8nq27 = xxxxxxxxx[qqqqqq++];
            ult_list.Ss6au0auqd8o17koxh34f = xxxxxxxxx[qqqqqq++];
            ult_list.M2nv0sw18ijv2tpb5x230 = xxxxxxxxx[qqqqqq++];
            ult_list.Wn7uv4747z00tvwefljbe = xxxxxxxxx[qqqqqq++];
            ult_list.fjvh3nwirisao9e243a6u = xxxxxxxxx[qqqqqq++];
            ult_list.n23issbg6k6tn1zq100hi = xxxxxxxxx[qqqqqq++];
            ult_list.Qzmzhzlur4kmlnqmqnzkm = xxxxxxxxx[qqqqqq++];
            ult_list.lplhm9xxjxaec2x5peb2h = xxxxxxxxx[qqqqqq++];
            ult_list.Aqzbauiakn9oap53nfmib = xxxxxxxxx[qqqqqq++];
            ult_list.jxk34fjszv6mm6d5zjg10 = xxxxxxxxx[qqqqqq++];
            ult_list.Cxn6xwdx64rk130tf5h4l = xxxxxxxxx[qqqqqq++];
            ult_list.Rzkyrxceladd8vrokoghc = xxxxxxxxx[qqqqqq++];
            ult_list.Dww4evvsfuz4cmqbmypau = xxxxxxxxx[qqqqqq++];
            ult_list.t9l61nmfmmj1za2ycpu5b = xxxxxxxxx[qqqqqq++];
            ult_list.It81kjbwfpcv8fxclzd1j = xxxxxxxxx[qqqqqq++];
            ult_list.Apg3l7ecu186eu8bbtvrl = xxxxxxxxx[qqqqqq++];
            ult_list.dza6jx3tmznnm3wvmeqme = xxxxxxxxx[qqqqqq++];
            ult_list.e9corfqogwb1dvptpkuxe = xxxxxxxxx[qqqqqq++];
            ult_list.buz4nvul7my6cjnlxwpdh = xxxxxxxxx[qqqqqq++];
            ult_list.zom0xvj0ncgbu3itkha5v = xxxxxxxxx[qqqqqq++];
            ult_list.rfq47ez4id535qqzi9h1m = xxxxxxxxx[qqqqqq++];
            ult_list.v374gxmja3bqvtsb8s2s6 = xxxxxxxxx[qqqqqq++];
            ult_list.qoskhngdnslkajt1ivxk2 = xxxxxxxxx[qqqqqq++];
            ult_list.qq3ocohm8o1zgy47lxx2q = xxxxxxxxx[qqqqqq++];
            ult_list.li5ss0qm903m4r0qudi2f = xxxxxxxxx[qqqqqq++];
            ult_list.n3f81vdlowqu843tul5l8 = xxxxxxxxx[qqqqqq++];
            ult_list.T5mivp4z7onhp4xwd616x = xxxxxxxxx[qqqqqq++];
            ult_list.Te7njioayg6ii64kr7nl1 = xxxxxxxxx[qqqqqq++];
            ult_list.ioo9jjfdhgqxu9x3798ma = xxxxxxxxx[qqqqqq++];
            ult_list.T4a0se9samfgtpei07ead = xxxxxxxxx[qqqqqq++];
            ult_list.Hk2r0iyiiamr8bl7oxrfj = xxxxxxxxx[qqqqqq++];
            ult_list.Hxd4bkef4pd957i0btajp = xxxxxxxxx[qqqqqq++];
            ult_list.U0j99yhreh4cq80qh7qqe = xxxxxxxxx[qqqqqq++];
            ult_list.nso37nva2u54xiztne4mc = xxxxxxxxx[qqqqqq++];
            ult_list.Gwbwvbt6g2sddte6lpbwc = xxxxxxxxx[qqqqqq++];
            ult_list.kgytl9ohjhcdddorr1h64 = xxxxxxxxx[qqqqqq++];
            ult_list.Xz3ab21ed2h7cik58rkvw = xxxxxxxxx[qqqqqq++];
            ult_list.Elw90pa9fxptif1mmyrti = xxxxxxxxx[qqqqqq++];
            ult_list.Dker9ea42st9qwktc4jw1 = xxxxxxxxx[qqqqqq++];
            ult_list.u18qmxz7q7sja1nlgf9wo = xxxxxxxxx[qqqqqq++];
            ult_list.lfhwdpdv4iksp41qlyemo = xxxxxxxxx[qqqqqq++];
            ult_list.Mdo49k9zj8m74xivumm7u = xxxxxxxxx[qqqqqq++];
            ult_list.Iechxa4f969raxhk1mw3q = xxxxxxxxx[qqqqqq++];
            ult_list.hnm66mx1wg69mh1kbgh9p = xxxxxxxxx[qqqqqq++];
            ult_list.I30m847hp73iztqg1glkm = xxxxxxxxx[qqqqqq++];
            ult_list.rcs39af267jvfwnxxa7bp = xxxxxxxxx[qqqqqq++];
            ult_list.Cqmzmyj30ut446xnk6m8z = xxxxxxxxx[qqqqqq++];
            ult_list.Eekrxidcf3t1jk5603ql0 = xxxxxxxxx[qqqqqq++];
            ult_list.ombloo0j9am0x9mlf4bev = xxxxxxxxx[qqqqqq++];
            ult_list.yhx7b1vua0wrqbhmc9dir = xxxxxxxxx[qqqqqq++];
            ult_list.O3cfr2dj7t051l0tyekw3 = xxxxxxxxx[qqqqqq++];
            #endregion
        }
        private void llllllllllllllll()
        {
            jmd3h9hflaqrj = xxxx.Text + xxxxxxxxxxxxxxxxxx.Text + xxxxxxxxxxxxxxxxxxxxxxxxxxxxx.Text + xxxxxxxxxxxxxxxxx.Text;
            mHk69B3quzv48 = E39wonmvwe5j().ToString();
            string[] decrypt_ = xxxxx.Lines;
            string[] decrypt = new string[decrypt_.Length];
            using (var service = new Cryptography(jmd3h9hflaqrj))
            {
                for (int i = 0; i < decrypt.Length; i++)
                    cccccccccccccc.Add(service.Decrypt(decrypt_[i]));
            }
        }
        public static string kgh094jhmdhwit = "8947390572058265572842";
        public static string jmd3h9hflaqrj = "10373521036692743";
        public static long kh394hgmsjg92 = 85927536272;
        string E7664vlykqx35 = "94687859898536246885183671472";
        string bve3myzeo0jhe = "337126101191648667";
        string Qwrldldl0myp2 = "2105933058709621045099329211";
        long wnbp8mm0hiygc = 321634;
        long Lav9nmcs6zb8w = 756061141;
        string hglsk394gusu92 = "93758683288902591292776923721168";
        public static int re95tm3saq9va = 4;
        string Smn4ffjmefl4q = "93892301177088083654647551051615";
        string Zavb87m48ilcg = "231748203951578";
        string mHk69B3quzv48 = "9027671982816636526";
        string Xf01b63c3mvuq = "8748305356340240452846234351686";
        #endregion

        #region bind monitor
        List<string> bindStr = new List<string>();
        List<string> bindStrState = new List<string>();
        List<int> saveBind = new List<int>();
        List<int> bindTogIndex = new List<int>();



        string resetSelected = "!";
        #region btns
        uint[] btnOfsList = new uint[] { 
                btnOfs.DpadUp, 
                btnOfs.DpadDown,
                btnOfs.DpadLeft,
                btnOfs.DpadRight,
                btnOfs.Start ,
                btnOfs.Select ,
                btnOfs.Triangle ,
                btnOfs.Square ,
                btnOfs.Circle ,
                btnOfs.Cross ,
                btnOfs.R1 ,
                btnOfs.R2 ,
                btnOfs.R3 ,
                btnOfs.L1 ,
                btnOfs.L2 ,
                btnOfs.L3                
                };
        byte[] btnByteList = new byte[] { 
                btnByte.DpadUp, 
                btnByte.DpadDown,
                btnByte.DpadLeft,
                btnByte.DpadRight,
                btnByte.Start ,
                btnByte.Select ,
                btnByte.Triangle ,
                btnByte.Square ,
                btnByte.Circle ,
                btnByte.Cross ,
                btnByte.R1 ,
                btnByte.R2 ,
                btnByte.R3 ,
                btnByte.L1 ,
                btnByte.L2 ,
                btnByte.L3                
                };
        #endregion
        private void buttonMon()
        {
            for (int i = 0; i < bindStr.Count; i++)
            {
                if (buttonPressed(btnOfsList[saveBind[i]], btnByteList[saveBind[i]]))
                {
                    bindTogIndex[i] = modHub(bindStr[i].ToUpper().Replace(" ", "_"), bindTogIndex[i], 0, bindStrState[i]);
                    Task.Delay(200).Wait();
                }
            }
        }

        private void setToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            bool canAdd = true;
            for (int i = 0; i < listBox3.Items.Count; i++)
            {
                if (listBox3.Items[i].ToString().Contains(toolStripComboBox5.SelectedItem.ToString()))
                    canAdd = false;
            }
            if (canAdd)
            {
                saveBind.Add(toolStripComboBox5.SelectedIndex);
                bindStr.Add(selectedOptionTxt);
                bindStrState.Add(selectedOptionState);
                bindTogIndex.Add(1);
                listBox3.Items.Add(selectedOptionTxt + " : " + toolStripComboBox5.SelectedItem.ToString());
            }
            else
                MessageBox.Show("Cannot set bind more than once", "Bind Not Set", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

        }

        private void buttonR_Click(object sender, EventArgs e)
        {
            if (listBox3.SelectedIndex != -1)
            {
                for (int i = 0; i < bindStr.Count; i++)
                {
                    if (resetSelected.Contains(bindStr[i]))
                    {
                        bindStr.RemoveAt(listBox3.SelectedIndex);
                        bindStrState.RemoveAt(listBox3.SelectedIndex);
                        saveBind.RemoveAt(listBox3.SelectedIndex);
                        bindTogIndex.RemoveAt(listBox3.SelectedIndex);
                        listBox3.Items.RemoveAt(listBox3.SelectedIndex);
                    }
                }
            }
        }


        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox3.SelectedIndex != -1)
                resetSelected = listBox3.SelectedItem.ToString();
        }
        private void button24_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Right click on an option in the 'Game Mods' context menu, then select a button for it to be set.", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        #endregion

        #region host search

        uint[] getHostAddr()
        {
            byte[] searchBytes = PS3.Extension.ReadBytes(getOfs(mcOfs.L47zadhu6zlnwvsfhaepa), (int)getOfs(mcOfs.n71upjznf67o0u0xoji1f));
            byte[] _findWhat = BitConverter.GetBytes(getOfs(mcOfs.nl8j5nz6dvxsj7a98uiqu));
            Array.Reverse(_findWhat);
            int[] indexes = IndexOfSequence(searchBytes, _findWhat, 0).ToArray();
            List<uint> rawIndexes = new List<uint>();
            for (int i = 0; i < indexes.Length; i++)
                rawIndexes.Add(PS3.Extension.ReadUInt32(getOfs(mcOfs.L47zadhu6zlnwvsfhaepa) + (uint)indexes[i] + 0x0C));
            return rawIndexes.ToArray();
        }

        int[] getActive = new int[1000];
        int[] comActive = new int[1000];
        uint[] vResults = new uint[1000];
        #endregion

        #region save Load
        string loadConfigPath = "N/A";

        private void button20_Click(object sender, EventArgs e)
        {
            loadOpts(true);
        }

        private void button21_Click(object sender, EventArgs e)
        {
            saveOpts();
        }

        private void saveOpts()
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "mcConfig files (*.mcc)|*.mcc";
            saveFileDialog1.FileName = "Modcraft Config";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    List<string> addOpts = new List<string>();
                    for (int i = 0; i < 10000; i++)
                    {
                        if (!String.IsNullOrEmpty(funcVal[i]))
                            addOpts.Add("" + i + "<s>" + funcVal[i]);
                    }
                    File.WriteAllLines(saveFileDialog1.FileName, addOpts.ToArray());
                    MessageBox.Show("Saved at: " + saveFileDialog1.FileName, "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show("Something went wrong", "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void loadOpts(bool useDialog)
        {
            if (useDialog)
            {
                OpenFileDialog openFileDialog1 = new OpenFileDialog();
                openFileDialog1.Filter = "mcc files (*.mcc)|*.mcc";
                openFileDialog1.FilterIndex = 2;
                openFileDialog1.FileName = "Modcraft Config";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    doLoadOpts(openFileDialog1.FileName);
                }
            }
            else
                doLoadOpts(loadConfigPath);
        }

        private void doLoadOpts(string file)
        {
            try
            {
                if (File.Exists(file))
                {
                    if (file != "N/A")
                    {
                        string[] getOpts = File.ReadAllLines(file);
                        loadConfigPath = file;
                        for (int i = 0; i < getOpts.Length; i++)
                        {
                            string[] split = Regex.Split(getOpts[i], "<s>");

                            int val;
                            if (int.TryParse(split[0], out val))
                            {
                                string[] splitOpt = Regex.Split(split[1], ";");

                                if (splitOpt[1] == "checkBox")
                                {
                                    if (splitOpt[2] == "1")
                                        TS_Item[val].Checked = true;
                                    else
                                        TS_Item[val].Checked = false;
                                }
                                if (splitOpt[1] == "comboBox")
                                {
                                    int cVal;
                                    if (int.TryParse(splitOpt[2], out cVal))
                                    {
                                        if (cVal != 0)
                                        {
                                            TS_ComboBox[val].SelectedIndex = cVal;
                                        }
                                        else
                                            TS_ComboBox[val].SelectedIndex = 0;
                                    }
                                }
                                if (splitOpt[1] == "trackBar")
                                {
                                    int cVal;
                                    if (int.TryParse(splitOpt[2], out cVal))
                                    {
                                        if (cVal != 0)
                                        {
                                            TS_TrackBar[val].Value = cVal;
                                        }
                                        else
                                            TS_TrackBar[val].Value = 0;
                                    }
                                }
                            }
                        }
                    }
                }
                else
                    MessageBox.Show("Load file does not exist", "No File Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch
            {
                MessageBox.Show("Incorrect Syntax", "Unrecognized File", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            DialogResult result;

            if (apiStatus == "PS3 Manager")
                result = MessageBox.Show("You are about to reset all game mods in the tool.\n\nAfter selecting yes, the tool will be running slow for a few moments.\n\nDo you want to reset?", "Reset Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);
            else
                result = MessageBox.Show("You are about to reset all game mods in the tool.\n\nDo you want to reset?", "Reset Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                for (int i = 0; i < 10000; i++)
                {
                    if (!Object.ReferenceEquals(TS_Item[i], null))//checks if control if null
                    {
                        if (!saveValues[i].Contains("button") && !saveValues[i].Contains("btn"))
                            saveValues[i] = "-1";
                    }
                    if (!Object.ReferenceEquals(TS_TrackBar[i], null))//checks if control if null
                        saveValues[i] = "-1";
                    if (!Object.ReferenceEquals(TS_ComboBox[i], null))//checks if control if null
                        saveValues[i] = "-1";
                }
            }
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show(loadConfigPath, "Load Config Path", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        #endregion

        #region output
        private static byte[] ConvertHexToBytes(string input)
        {
            var result = new byte[(input.Length + 1) / 2];
            var offset = 0;
            if (input.Length % 2 == 1)
            {
                result[0] = (byte)Convert.ToUInt32(input[0] + "", 16);
                offset = 1;
            }
            for (int i = 0; i < input.Length / 2; i++)
            {
                result[i + offset] = (byte)Convert.ToUInt32(input.Substring(i * 2 + offset, 2), 16);
            }
            return result;
        }

        string[] setFuncState(string[] txt, string state)
        {
            for (int i = 0; i < txt.Length; i++)
                txt[i] = txt[i].Insert(0, state);
            return txt;
        }

        ToolStripMenuItem[] addMenuItems(string[] txt)
        {
            ToolStripMenuItem[] tsmi = new ToolStripMenuItem[txt.Length];
            for (int i = 0; i < txt.Length; i++)
            {
                tsmi[i] = new ToolStripMenuItem();
                tsmi[i].Text = txt[i];
            }
            return tsmi;
        }
        int countSM = 0;

        ToolStripItemCollection addMenuFuncs(string[] txt, int subCount, object[][] itemsCB, ToolStripItemCollection[] subMenu)
        {
            ToolStrip ts = new ToolStrip();
            ToolStripItemCollection toolColl = new ToolStripItemCollection(ts, new ToolStripMenuItem[] { });
            string[] optTxt = new string[txt.Length];
            string[] funcTxt = new string[txt.Length];

            int txtC = 0;
            for (int i = (subCount * 100); i < (subCount * 100) + txt.Length; i++)
            {
                string[] split = { };
                split = Regex.Split(txt[txtC], ";");

                funcTxt[txtC] = split[0];
                optTxt[txtC] = split[1].ToLower();
                optTxt[txtC] = char.ToUpper(optTxt[txtC][0]) + optTxt[txtC].Substring(1).Replace("_", " ");
                func_state[i] = funcTxt[txtC];
                if (funcTxt[txtC] == "trackBar")
                {
                    TS_Label[i] = new LabelMenuItem();
                    TS_Label[i].ForeColor = textColorCM;
                    TS_Label[i].BackColor = backgroundColorCM;
                    TS_Label[i].Text = optTxt[txtC];
                    toolColl.Add(TS_Label[i]);
                    TS_TrackBar[i] = new TrackBarMenuItem();
                    TS_TrackBar[i].Name = "trackBar";
                    TS_TrackBar[i].AutoSize = false;

                    TS_TrackBar[i].Size = new Size(200, 20);
                    TS_TrackBar[i].ForeColor = textColorCM;
                    TS_TrackBar[i].BackColor = backgroundColorCM;
                    TS_TrackBar[i].MaxValue = Convert.ToInt32(itemsCB[txtC][0]);

                    toolColl.Add(TS_TrackBar[i]);
                }
                else if (funcTxt[txtC] == "comboBox")
                {
                    TS_Label[i] = new LabelMenuItem();
                    TS_Label[i].ForeColor = textColorCM;
                    TS_Label[i].BackColor = backgroundColorCM;
                    TS_Label[i].Text = optTxt[txtC];
                    toolColl.Add(TS_Label[i]);
                    TS_ComboBox[i] = new colorCBTS();
                    TS_ComboBox[i].Name = "comboBox";
                    TS_ComboBox[i].ForeColor = textColorCM;
                    TS_ComboBox[i].BackColor = backgroundColorCM;
                    TS_ComboBox[i].DropDownStyle = ComboBoxStyle.DropDownList;
                    TS_ComboBox[i].Items.AddRange(itemsCB[txtC]);
                    TS_ComboBox[i].SelectedIndex = 0;
                    toolColl.Add(TS_ComboBox[i]);
                }
                else if (funcTxt[txtC] == "checkBox")
                {
                    TS_Item[i] = new ToolStripMenuItem();
                    TS_Item[i].ForeColor = textColorCM;
                    TS_Item[i].BackColor = backgroundColorCM;
                    TS_Item[i].Name = "checkBox";
                    TS_Item[i].Text = optTxt[txtC];
                    toolColl.Add(TS_Item[i]);
                }
                else if (funcTxt[txtC] == "seperator")
                {
                    TS_Seperator[i] = new ToolStripSeparator();
                    TS_Seperator[i].ForeColor = textColorCM;
                    TS_Seperator[i].BackColor = backgroundColorCM;
                    toolColl.Add(TS_Seperator[i]);
                }
                else if (funcTxt[txtC] == "textBox")
                {
                    TS_Label[i] = new LabelMenuItem();
                    TS_Label[i].ForeColor = textColorCM;
                    TS_Label[i].BackColor = backgroundColorCM;
                    TS_Label[i].Text = optTxt[txtC];
                    toolColl.Add(TS_Label[i]);
                    TS_TextBox[i] = new ToolStripTextBox();
                    TS_TextBox[i].Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    TS_TextBox[i].BorderStyle = BorderStyle.FixedSingle;
                    TS_TextBox[i].ForeColor = textColorCM;
                    TS_TextBox[i].BackColor = backgroundColorCM;
                    toolColl.Add(TS_TextBox[i]);
                }
                else if (funcTxt[txtC] == "textOnly")
                {
                    TS_TextBox[i] = new ToolStripTextBox();
                    TS_TextBox[i].Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    TS_TextBox[i].BorderStyle = BorderStyle.FixedSingle;
                    TS_TextBox[i].ForeColor = textColorCM;
                    TS_TextBox[i].BackColor = backgroundColorCM;
                    toolColl.Add(TS_TextBox[i]);
                }
                else if (funcTxt[txtC] == "button")
                {
                    TS_Item[i] = new ToolStripMenuItem();
                    TS_Item[i].ForeColor = textColorCM;
                    TS_Item[i].BackColor = backgroundColorCM;
                    TS_Item[i].Name = "button";
                    TS_Item[i].Text = "Set";
                    TSbtns[i] = optTxt[txtC];
                    toolColl.Add(TS_Item[i]);
                }
                else if (funcTxt[txtC] == "btn")
                {
                    TS_Item[i] = new ToolStripMenuItem();
                    TS_Item[i].ForeColor = textColorCM;
                    TS_Item[i].BackColor = backgroundColorCM;
                    TS_Item[i].Name = "btn";
                    TS_Item[i].Text = "Reset";
                    TSbtns[i] = optTxt[txtC];
                    toolColl.Add(TS_Item[i]);
                }
                else if (funcTxt[txtC] == "subMenu")
                {
                    TS_MenuItem[i] = new ToolStripMenuItem();
                    TS_MenuItem[i].Name = "subMenu";
                    TS_MenuItem[i].ForeColor = textColorCM;
                    TS_MenuItem[i].BackColor = backgroundColorCM;
                    TS_MenuItem[i].Text = optTxt[txtC];
                    tsMenuItems[countSM] = new ToolStripMenuItem();
                    tsMenuItems[countSM].ForeColor = textColorCM;
                    tsMenuItems[countSM].BackColor = backgroundColorCM;
                    tsMenuItems[countSM++] = TS_MenuItem[i];
                    TS_MenuItem[i].DropDown.BackColor = backgroundColorCM;
                    TS_MenuItem[i].DropDownItems.AddRange(subMenu[txtC]);
                    (TS_MenuItem[i].DropDown as ToolStripDropDownMenu).ShowImageMargin = false;
                    (TS_MenuItem[i].DropDown as ToolStripDropDownMenu).ShowCheckMargin = false;
                    (TS_MenuItem[i].DropDown as ToolStripDropDownMenu).ShowItemToolTips = false;
                    for (int a = 0; a < TS_MenuItem[i].DropDownItems.Count; a++)
                    {

                        if (TS_MenuItem[i].DropDownItems[a].Name.Contains("checkBox"))
                            (TS_MenuItem[i].DropDown as ToolStripDropDownMenu).ShowCheckMargin = true;
                    }

                    toolColl.Add(TS_MenuItem[i]);
                }
                else if (funcTxt[txtC] == "none")
                {
                    TS_Label[i] = new LabelMenuItem();
                    TS_Label[i].ForeColor = textColorCM;
                    TS_Label[i].BackColor = backgroundColorCM;
                    TS_Label[i].Text = optTxt[txtC];
                    toolColl.Add(TS_Label[i]);
                }
                txtC++;
            }

            return toolColl;
        }
        #endregion

        #region menuOpts
        private IEnumerable<ToolStripMenuItem> GetItems(ToolStripMenuItem item)
        {
            foreach (ToolStripMenuItem dropDownItem in item.DropDownItems)
            {
                if (dropDownItem.HasDropDownItems)
                {
                    foreach (ToolStripMenuItem subItem in GetItems(dropDownItem))
                        yield return subItem;
                }
                yield return dropDownItem;
            }
        }
        List<string> menuOptTxt = new List<string>();
        List<string> menuOptState = new List<string>();
        List<byte[]> menuOptMax = new List<byte[]>();
        List<byte[]> sycx2ae5ous3hhx86e2ir = new List<byte[]>();
        List<int> menuOptStartIndex = new List<int>();
        private void addMenuOpt(byte sub, byte subOpt, byte subLvl, string[] opts, byte[] optMax = null)
        {
            int[] noMultOpts = { };

            int startIndex = menuOptTxt.Count;
            int countOpts = 0;
            for (int i = 0; i < opts.Length; i++)
            {
                string[] split = Regex.Split(opts[i], ";");
                if (split[0] != "textOnly" && split[0] != "textBox" && split[0] != "seperator" && split[0] != "button" && split[0] != "btn" && opts[i] != MF_SubMenu + "XP Editor")
                {
                    if (split[1].Length < 5)
                        split[1] += "     ";
                    if (split[0] == "comboBox" || split[0] == "trackBar")
                    {
                        menuOptState.Add("multiOpt");
                    }
                    else
                        menuOptState.Add(split[0]);
                    menuOptTxt.Add(split[1]);
                    ++countOpts;
                }
            }
            if (!Object.ReferenceEquals(optMax, null))
                menuOptMax.Add(optMax);
            else
                menuOptMax.Add(new byte[] { });
            sycx2ae5ous3hhx86e2ir.Add(new byte[] { sub, subOpt, subLvl, (byte)countOpts });
            menuOptStartIndex.Add(startIndex);
        }
        #endregion

        #region menu
        int[, , ,] menuValue = new int[3, 12, 10, 30];
        public class clientStruct
        {
            public static uint
             native_pointer = 0,
             struct_pointer = 0x04,
             getView = 0xE0,
             setView = 0x148,
             origin = 0x100,
             active1 = 0x1E8,
             active2 = 0x3AC,
             alive1 = 0x197,
             alive2 = 0x138,
             inv = 0x5DC,
             name = 0x764,
             id1 = 0x774,
             id2 = 0x7AC;
        }

        bool isMenuRunning = false;
        ColorDialog McolorDialogTheme = new ColorDialog();
        ColorDialog McolorDialogText = new ColorDialog();
        ColorDialog McolorDialogBackground = new ColorDialog();
        Color Mtheme = Color.Blue;
        Color Mtext = Color.White;
        Color Mback = Color.Yellow;
        bool menuLoad = true;
        bool canSet = false;
        //2548
        byte[] menuTxt = new byte[38200];
        byte[] menuNum = new byte[2600];

        private void button4_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("This menu only works if you have Modcraft_Promo in your PS3 TMP folder (with SPRX Eboot in the Minecraft game folder). If you don't have the SPRX menu then download from the Modcraft video description on MayhemModding YouTube channel.\n\nControls:\nOpen - Dpad Up\nNavigate - Dpad Up/Down\nSelect - Square\nGo Back - Circle\nQuick Close - Triangle\n\nCredits:\nMenu Developed by MayhemModding", "How To Use", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (PS3.Extension.ReadBool(getOfs(mcOfs.khr984hfjsg94ytfksgsh)))
            {
                isMenuRunning = checkBox1.Checked;
                if (isMenuRunning && canUseTool)
                {
                    canSet = false;
                    menuLoad = true;
                }
            }
        }
        private void menuInit(bool get)
        {
            if (get)
            {
                for (int i = 0; i < menuOptTxt.Count; i++)
                {
                    menuOptTxt[i] = menuOptTxt[i].ToLower();
                    menuOptTxt[i] = char.ToUpper(menuOptTxt[i][0]) + menuOptTxt[i].Substring(1).Replace("_", " ");

                    PS3.Extension.WriteString(getOfs(mcOfs.ow84fxduxqc1a3oh97rg3) + ((uint)i * 0x30), menuOptTxt[i] + "\0");
                    PS3.Extension.WriteString(getOfs(mcOfs.Ngz4b7gt43bvi7vhtrqtt) + ((uint)i * 0x10), menuOptState[i] + "\0");
                }
                for (int i = 0; i < sycx2ae5ous3hhx86e2ir.Count; i++)
                {
                    PS3.Extension.WriteBytes(getOfs(mcOfs.sycx2ae5ous3hhx86e2ir) + ((uint)i * 0x20), sycx2ae5ous3hhx86e2ir[i]);
                    PS3.Extension.WriteInt32(getOfs(mcOfs.sycx2ae5ous3hhx86e2ir) + 4 + ((uint)i * 0x20), menuOptStartIndex[i]);
                    if (!Object.ReferenceEquals(menuOptMax[i], null))
                        PS3.Extension.WriteBytes(getOfs(mcOfs.sycx2ae5ous3hhx86e2ir) + 8 + ((uint)i * 0x20), menuOptMax[i]);
                }
                PS3.Extension.WriteInt32(getOfs(mcOfs.Ruz3ortcigysq7wfdbbb3), sycx2ae5ous3hhx86e2ir.Count);
            }
            else
            {
                PS3.SetMemory(getOfs(mcOfs.ow84fxduxqc1a3oh97rg3), Properties.Resources.dump1);
                PS3.SetMemory(getOfs(mcOfs.Ruz3ortcigysq7wfdbbb3), Properties.Resources.dump2);
                PS3.Extension.WriteBool(getOfs(mcOfs.Ruz3ortcigysq7wfdbbb3) - 4, (apiStatus == "PS3 Manager") ? true : false);
            }
        }
        private void backgroundWorker3_DoWork(object sender, DoWorkEventArgs e)
        {
            PS3api();
            for (; ; )
            {
                if (isMenuRunning && canUseTool)
                {
                    if (menuLoad)
                    {
                        menuInit(false);
                        runMenuTheme(Mtheme, Mtext, Mback);
                        menuLoad = false;
                        canSet = true;
                    }
                }
                #region menu
                try
                {
                    if (isMenuRunning && canSet && apiStatus != "PS3 Manager")
                    {
                        if (PS3.Extension.ReadBool(getOfs(mcOfs.Wcxh69njus44c0pgppsgc)))
                        {
                            PS3.Extension.WriteBool(getOfs(mcOfs.Wcxh69njus44c0pgppsgc), false);

                            string funcName = PS3.Extension.ReadString(getOfs(mcOfs.lfq11pm735ut0ci8kblwf));
                            if (funcName.EndsWith("     "))
                                funcName = funcName.Replace("     ", "");

                            byte[] index = PS3.Extension.ReadBytes(getOfs(mcOfs.Y6oadwezrvqwv0hx2tp1n), 4);

                            PS3.Extension.WriteInt32(getOfs(mcOfs.Wa1fnbsuzl6jg5zi1n305), menuValue[index[0], index[1], index[2], index[3]]);
                            PS3.Extension.WriteBool(getOfs(mcOfs.ks2v6j4h5xg520u0x7nm4), true);
                            menuValue[index[0], index[1], index[2], index[3]] = modHub(funcName.ToUpper().Replace(" ", "_"), menuValue[index[0], index[1], index[2], index[3]], 0, PS3.Extension.ReadString(getOfs(mcOfs.Tgn7m9cmgyssbgm7ba4q7)));
                        }
                    }
                }
                catch
                {

                }
                #endregion

                selectOpt();
                if (colorInt == 0)
                {
                    if (!sw.IsRunning || sw.ElapsedMilliseconds > 2000)
                    {
                        sw.Restart();
                    }
                    if (sw.ElapsedMilliseconds >= 1000)
                    {
                        sw.Reset();
                        if (colorInt == 1)
                            PS3.SetMemory(getOfs(mcOfs.E4usndy0d9xxxv2v3mem9), ConvertHexToBytes(hexColor(rainbowRGB(hudRGB, 15))));
                        else if (colorInt == 2)
                            PS3.SetMemory(getOfs(mcOfs.E4usndy0d9xxxv2v3mem9), ConvertHexToBytes(hexColor(Color.FromArgb(rhudRGB.Next(0, 255), rhudRGB.Next(0, 255), rhudRGB.Next(0, 255)))));
                    }
                }
                if (canShowCoor)
                    posStatus = "X: " + playerPos()[0] + "\nY: " + playerPos()[1] + "\nZ: " + playerPos()[2];
                else
                    posStatus = "X: N/A\nY: N/A\nZ: N/A";

                if (canListen && usePS3notify)
                {
                    SndString = PS3.Extension.ReadString(getOfs(mcOfs.fvf3vqbm7c7zo6ibu36hi));
                    if (SndString.StartsWith("mob") || SndString.StartsWith("liquid"))
                    {
                        string[] obj = SndString.Split('/');
                        sndTxt = "Can Hear: " + obj[1].First().ToString().ToUpper() + obj[1].Substring(1);
                        runNotify(sndTxt);
                    }
                }

                if (useUfo)
                {
                    if (PS3.Extension.ReadByte(PS3.Extension.ReadUInt32(PS3.Extension.ReadUInt32(getOfs(mcOfs.Yw362jg84zcpznifsibr3)) + 0x44) + clientPlus - 1) == 0x00)
                    {
                        if (PS3.Extension.ReadByte(getOfs(mcOfs.Ia5purh5uawh30r5g1kox) + 1) == 0x80)
                            mapBoundsToggle(false);
                    }
                    else
                        if (PS3.Extension.ReadByte(getOfs(mcOfs.Ia5purh5uawh30r5g1kox) + 1) == 0x20)
                            mapBoundsToggle(true);
                }

                if (useOP)
                {
                    if (buttonPressed(btnOfs._R2, 0x01))
                    {
                        if (demiTog == 0 || demiTog == 1)
                        {
                            demiTog = 2;
                            PS3.SetMemory(getOfs(mcOfs.Sayia8c4zq9hr7cis5i1w), new byte[] { 0x42 });
                        }

                    }
                    else
                    {
                        if (demiTog == 0 || demiTog == 2)
                        {
                            demiTog = 1;
                            PS3.SetMemory(getOfs(mcOfs.Sayia8c4zq9hr7cis5i1w), new byte[] { 0x3A });
                        }

                    }
                }
            }
        }
        private void button12_Click_1(object sender, EventArgs e)
        {
            McolorDialogTheme.FullOpen = true;
            if (McolorDialogTheme.ShowDialog() == DialogResult.OK)
                runMenuTheme(McolorDialogTheme.Color, Mtext, Mback);
        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            McolorDialogText.FullOpen = true;
            if (McolorDialogText.ShowDialog() == DialogResult.OK)
                runMenuTheme(Mtheme, McolorDialogText.Color, Mback);
        }

        private void button14_Click_1(object sender, EventArgs e)
        {
            McolorDialogBackground.FullOpen = true;
            if (McolorDialogBackground.ShowDialog() == DialogResult.OK)
                runMenuTheme(Mtheme, Mtext, McolorDialogBackground.Color);
        }

        private void runMenuTheme(Color theme, Color text, Color back)
        {
            Mtheme = theme;
            Mtext = text;
            Mback = back;
            List<byte> getColor = new List<byte>();
            Color[] colorArray = { theme, text, back };
            for (int i = 0; i < colorArray.Length; i++)
            {
                byte[] array1 = new byte[4];
                byte[] array2 = new byte[4];
                byte[] array3 = new byte[4];
                int r = colorArray[i].R;
                int g = colorArray[i].G;
                int b = colorArray[i].B;

                System.BitConverter.GetBytes(r).CopyTo(array1, 0);
                System.BitConverter.GetBytes(g).CopyTo(array2, 0);
                System.BitConverter.GetBytes(b).CopyTo(array3, 0);

                System.Array.Reverse(array1, 0, 4);
                System.Array.Reverse(array2, 0, 4);
                System.Array.Reverse(array3, 0, 4);

                getColor.AddRange(array1);
                getColor.AddRange(array2);
                getColor.AddRange(array3);
            }
            PS3.SetMemory(getOfs(mcOfs.uleklhoakwkoyic99ijlr), getColor.ToArray());
            PS3.Extension.WriteBool(getOfs(mcOfs.uleklhoakwkoyic99ijlr) + 36, true);
        }

        public static bool checkAddr(uint addr)
        {
            if (PS3.GetCurrentAPI() == SelectAPI.TargetManager)
            {
                byte[] val = new byte[1];
                bool ret = (PS3Lib.NET.PS3TMAPI.ProcessGetMemory(0, PS3Lib.NET.PS3TMAPI.UnitType.PPU, PS3Lib.TMAPI.Parameters.ProcessID, 0, addr, ref val) ==
                    PS3Lib.NET.PS3TMAPI.SNRESULT.SN_S_OK);
                return ret;
            }
            else
            {
                if (PS3.Extension.GetMemX(addr) == 0)
                    return true;
                else
                    return false;
            }
        }
        #endregion
    }
}