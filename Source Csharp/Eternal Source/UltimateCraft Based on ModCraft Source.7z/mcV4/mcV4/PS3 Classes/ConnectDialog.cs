﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace PS3Lib
{
	public partial class ConnectDialog : Form
	{
		public ConnectDialog()
		{
			this.InitializeComponent();
		}
	}
}
